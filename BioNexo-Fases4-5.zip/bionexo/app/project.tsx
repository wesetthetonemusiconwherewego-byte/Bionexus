import React, { useEffect, useState } from "react";
import { Platform } from "react-native";
import { router } from "expo-router";
import { catalog, conceptById } from "../src/content";
import type { Exercise } from "../src/domain/models";
import { prerequisiteMet } from "../src/domain/learning";
import { useApp } from "../src/ui/provider";
import { StudySession } from "../src/ui/session";
import { Button, Card, Heading, Label, Page } from "../src/ui/components";
export default function Project() {
  const { state } = useApp();
  const [round, setRound] = useState<Exercise[] | null>(null);
  // Web exports split routes. Prepare the completion destination while online;
  // native resources are already included in the installed bundle.
  useEffect(() => {
    if (Platform.OS === "web" && state?.onboarded)
      router.prefetch("/?tab=progress");
  }, [state?.onboarded]);
  const activity = catalog.transferActivities?.find(
    (a) => a.id === "project-dilution-v1",
  );
  if (!state || !activity)
    return (
      <Page>
        <Heading>
          {state ? "Proyecto no disponible" : "Abriendo perfil…"}
        </Heading>
        <Button onPress={() => router.replace("/?tab=learn")}>
          Volver al mapa
        </Button>
      </Page>
    );
  if (round)
    return (
      <StudySession exercises={round} mode="review" title={activity.title} />
    );
  const answered = new Set(
    state.attempts
      .filter((a) => activity.exercises.some((e) => e.id === a.exerciseId))
      .map((a) => a.exerciseId),
  );
  const remaining = activity.exercises.filter((e) => !answered.has(e.id));
  const prereqs = [
      ...new Set(activity.exercises.flatMap((e) => e.prerequisites)),
    ],
    missing = prereqs.filter((id) => !prerequisiteMet(state, id));
  const conclusion = state.attempts
    .filter((a) => a.exerciseId === "project-dilution-v1-q6")
    .at(-1);
  return (
    <Page>
      <Button secondary onPress={() => router.replace("/?tab=learn")}>
        Volver al mapa
      </Button>
      <Heading>{activity.title}</Heading>
      <Card>
        <Label>{activity.objective}</Label>
        <Heading small>Modelo y ejemplo desarrollado</Heading>
        <Label>{activity.model}</Label>
        <Heading small>Supuestos y datos simulados</Heading>
        {activity.assumptions.map((a) => (
          <Label key={a} muted>
            {a}
          </Label>
        ))}
        <Label muted>
          Contenido original, fuentes OpenStax en Biblioteca. Revisión académica
          humana pendiente. No hay trabajo con organismos.
        </Label>
      </Card>
      <Card>
        <Heading small>Bases disponibles</Heading>
        <Label>{prereqs.map((id) => conceptById[id]?.title).join(" · ")}</Label>
        {missing.length > 0 && (
          <Label muted>
            Bases recomendadas por reforzar:{" "}
            {missing.map((id) => conceptById[id]?.title).join(", ")}. Puedes
            explorar el proyecto y volver a ellas.
          </Label>
        )}
        {missing.map((id) => {
          const lesson = catalog.lessons.find((l) => l.conceptIds.includes(id));
          return lesson ? (
            <Button
              key={id}
              secondary
              onPress={() => router.push(`/lesson/${lesson.id}`)}
            >
              Reforzar: {conceptById[id]?.title}
            </Button>
          ) : null;
        })}
      </Card>
      <Card>
        <Heading small>Tu recorrido</Heading>
        <Label>
          {answered.size} de {activity.exercises.length} retos contestados.
          Contestar no equivale a dominar; los errores también forman parte del
          recorrido.
        </Label>
        <Label muted>
          Las respuestas confirmadas se conservan. Al volver continuamos con los
          retos todavía sin respuesta; un borrador de esta ronda no queda
          guardado. Los premios correctos se otorgan una sola vez.
        </Label>
        {conclusion && (
          <Label>
            Última conclusión:{" "}
            {conclusion.correct
              ? "reconoce los límites del modelo"
              : "conviene revisar el alcance de la evidencia"}
            .{" "}
            {conclusion.hinted
              ? "Con ayuda registrada."
              : "Sin pistas registradas en ese intento."}
          </Label>
        )}
      </Card>
      <Button
        onPress={() =>
          setRound(remaining.length ? remaining : activity.exercises)
        }
      >
        {remaining.length
          ? "Continuar proyecto"
          : "Practicar el proyecto de nuevo"}
      </Button>
    </Page>
  );
}
