import React, { useState } from "react";
import { View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { useApp } from "../../src/ui/provider";
import {
  Button,
  Card,
  Heading,
  Label,
  Page,
  Plot,
} from "../../src/ui/components";
import { labComparisons } from "../../src/domain/lab-notebook";
export default function SavedLaboratory() {
  const { id } = useLocalSearchParams<{ id: string }>(),
    { state } = useApp();
  const [limit, setLimit] = useState(20),
    [model, setModel] = useState<string | null>(null);
  const entry = state?.labs.find((l) => l.id === id);
  const back = () =>
    router.canGoBack() ? router.back() : router.replace("/?tab=lab");
  if (!entry)
    return (
      <Page>
        <Heading>
          {state ? "Registro no encontrado" : "Abriendo cuaderno…"}
        </Heading>
        <Button onPress={back}>Volver al laboratorio</Button>
      </Page>
    );
  const models = [...new Set(entry.points.map((p) => p.enzyme))];
  const active = models.includes(model ?? "") ? model! : models[0]!;
  const readings = entry.points
    .filter((p) => p.enzyme === active)
    .map((p) => ({ x: p.ph, y: p.activity }))
    .sort((a, b) => a.x - b.x);
  const sampled =
    readings.length <= 200
      ? readings
      : Array.from(
          { length: 200 },
          (_, i) => readings[Math.round((i * (readings.length - 1)) / 199)]!,
        );
  const comparisons = labComparisons(entry.points);
  return (
    <Page>
      <Button secondary onPress={back}>
        Volver al laboratorio
      </Button>
      <Heading>Registro del laboratorio</Heading>
      <Label>{new Date(entry.at).toLocaleString("es-CL")}</Label>
      <Card>
        <Heading small>Hipótesis guardada</Heading>
        <Label>{entry.hypothesis}</Label>
        <Heading small>Observación escrita</Heading>
        <Label>{entry.observation}</Label>
      </Card>
      <Card>
        <Heading small>Lecturas simuladas guardadas</Heading>
        <Label muted>
          Se conservan las cifras originales; no se recalculan ni se ajustan al
          modelo actual. Unir puntos solo facilita su lectura; no representa un
          ajuste experimental.
        </Label>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
          {models.map((m) => (
            <Button
              secondary={active !== m}
              key={m}
              onPress={() => setModel(m)}
            >
              {m === "neutral"
                ? "Lecturas del modelo N"
                : "Lecturas del modelo A"}
            </Button>
          ))}
        </View>
        <Plot
          points={sampled}
          marker={sampled.at(-1)}
          xLabel="pH guardado (sin unidad)"
          yLabel="Actividad guardada (%)"
        />
        {sampled.length < readings.length && (
          <Label muted>
            Vista gráfica con {sampled.length} de {readings.length} puntos para
            mantener respuesta móvil. La tabla y el respaldo conservan todos.
          </Label>
        )}
        {entry.points.slice(0, limit).map((p, i) => (
          <Label key={i}>
            {i + 1}. {p.enzyme === "neutral" ? "N" : "A"} · pH {p.ph} ·{" "}
            {p.activity} %
          </Label>
        ))}
        {limit < entry.points.length && (
          <Button secondary onPress={() => setLimit((n) => n + 20)}>
            Mostrar 20 condiciones más
          </Button>
        )}
      </Card>
      <Card>
        <Heading small>Qué permite comparar este registro</Heading>
        {!comparisons.length && (
          <Label>
            Registro previo sin dos pH distintos de un mismo modelo. Sigue
            siendo parte de tu cuaderno; no acredita una comparación controlada
            de pH.
          </Label>
        )}
        {comparisons.map((c) => (
          <Label key={c.first.enzyme}>
            Modelo {c.first.enzyme === "neutral" ? "N" : "A"}: pH {c.first.ph} a{" "}
            {c.second.ph}; diferencia guardada segunda − primera:{" "}
            {c.delta.toFixed(3)} puntos porcentuales.
          </Label>
        ))}
        <Label muted>
          La comparación usa la primera condición y la primera posterior con
          otro pH de cada modelo. No prueba causalidad real, viabilidad,
          significación estadística ni validez experimental.
        </Label>
      </Card>
    </Page>
  );
}
