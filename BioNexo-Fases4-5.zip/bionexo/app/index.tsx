import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  useWindowDimensions,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { useApp } from "../src/ui/provider";
import { RecoveryPanel } from "../src/ui/recovery";
import {
  Button,
  Card,
  Eyebrow,
  Heading,
  Icon,
  Label,
  Page,
  ScienceArt,
} from "../src/ui/components";
import {
  Home,
  Learn,
  Practice,
  Laboratory,
  Progress,
  Library,
  Settings,
} from "../src/ui/screens";
const tabs = [
  ["home", "Inicio", "home"],
  ["learn", "Aprender", "route"],
  ["practice", "Practicar", "practice"],
  ["lab", "Laboratorio", "flask"],
  ["progress", "Mi progreso", "progress"],
  ["library", "Biblioteca", "book"],
  ["settings", "Configuración", "settings"],
] as const;
type Tab = (typeof tabs)[number][0];
export default function Index() {
  const { state, error, theme, update, retry, dismissError } = useApp();
  const params = useLocalSearchParams<{ tab?: string }>();
  const [tab, setTab] = useState<Tab>("home");
  const [focused, setFocused] = useState<string | null>(null);
  const { width, fontScale } = useWindowDimensions();
  const wide = width >= 1000;
  useEffect(() => {
    if (tabs.some((t) => t[0] === params.tab)) setTab(params.tab as Tab);
  }, [params.tab]);
  const nav = (id: Tab) => {
    setTab(id);
    router.setParams({ tab: id });
  };
  if (!state)
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }}>
        <Page>
          <ScienceArt />
          <Heading>BioNexo</Heading>
          {error ? (
            <RecoveryPanel />
          ) : (
            <>
              <ActivityIndicator color={theme.accent} />
              <Label>Abriendo tu cuaderno científico…</Label>
            </>
          )}
        </Page>
      </SafeAreaView>
    );
  if (!state.onboarded)
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }}>
        <Page>
          <View style={{ alignItems: "center" }}>
            <ScienceArt />
          </View>
          <Eyebrow>BIENVENIDO A BIONEXO</Eyebrow>
          <Heading>Conecta lo que sabes.{"\n"}Descubre lo que puedes.</Heading>
          <Label muted>
            Biología, química, física y matemáticas para construir tu camino
            hacia la biotecnología.
          </Label>
          <Card>
            <Heading small>Pequeñas expediciones, ideas profundas</Heading>
            <Label>
              Lecciones de 5–12 minutos, práctica sin vidas limitadas y un
              laboratorio virtual. Todo el contenido incluido funciona sin
              conexión.
            </Label>
            <Label muted>
              El diagnóstico es opcional. Orienta tu primer paso; no es una
              medida de capacidad universitaria.
            </Label>
          </Card>
          {error && <Label>{error}</Label>}
          <Button
            onPress={() => {
              void update((s) => ({ ...s, onboarded: true }))
                .then(() => router.push("/diagnostic"))
                .catch(() => {});
            }}
          >
            Encontrar mi punto de partida
          </Button>
          <Button
            secondary
            onPress={() => {
              void update((s) => ({ ...s, onboarded: true })).catch(() => {});
            }}
          >
            Explorar sin diagnóstico
          </Button>
          <Label muted style={{ fontSize: 12 }}>
            Proyecto educativo independiente. Sin vínculo oficial con UNAB o
            MIT.
          </Label>
        </Page>
      </SafeAreaView>
    );
  const screens: Record<Tab, React.ReactNode> = {
    home: <Home />,
    learn: <Learn />,
    practice: <Practice />,
    lab: <Laboratory />,
    progress: <Progress />,
    library: <Library />,
    settings: <Settings />,
  };
  const navButton = (item: (typeof tabs)[number], vertical: boolean) => {
    const active = tab === item[0];
    return (
      <Pressable
        key={item[0]}
        accessibilityRole="tab"
        accessibilityLabel={item[1]}
        accessibilityState={{ selected: active }}
        aria-selected={active}
        onFocus={() => setFocused(item[0])}
        onBlur={() => setFocused(null)}
        onPress={() => nav(item[0])}
        style={({ pressed }) => ({
          minHeight: 56,
          minWidth: 0,
          outlineStyle: "solid",
          outlineWidth: focused === item[0] ? 3 : 0,
          outlineColor: theme.warm,
          flex: vertical ? undefined : 1,
          padding: vertical ? 14 : 4,
          borderRadius: 14,
          backgroundColor: active ? theme.raised : "transparent",
          opacity: pressed ? 0.8 : 1,
          alignItems: vertical ? "center" : "center",
          flexDirection: vertical ? "row" : "column",
          gap: vertical ? 14 : 2,
        })}
      >
        <Icon
          name={item[2]}
          size={22}
          color={active ? theme.accent : theme.muted}
        />
        <Label
          style={{
            fontSize: vertical ? 14 : 10,
            flexShrink: 1,
            maxWidth: "100%",
            textAlign: vertical ? "left" : "center",
            lineHeight: vertical ? 22 : 15,
            fontWeight: active ? "700" : "500",
            color: active ? theme.text : theme.muted,
          }}
        >
          {item[1]}
        </Label>
      </Pressable>
    );
  };
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }}>
      <View style={{ flex: 1, flexDirection: "row" }}>
        {wide && (
          <View
            style={{
              width: 230,
              borderRightWidth: 1,
              borderColor: theme.border,
              padding: 18,
              gap: 24,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 10,
                padding: 12,
              }}
            >
              <Icon name="dna" size={30} />
              <Label style={{ fontSize: 22, fontWeight: "800", flexShrink: 1 }}>
                bionexo
              </Label>
            </View>
            <View style={{ gap: 6 }}>
              {tabs.map((t) => navButton(t, true))}
            </View>
            <View style={{ marginTop: "auto", padding: 12, gap: 8 }}>
              <ChipLocal />
              <Label muted style={{ fontSize: 12 }}>
                Tu laboratorio de ideas.{"\n"}Siempre contigo.
              </Label>
            </View>
          </View>
        )}
        <View style={{ flex: 1 }}>
          <View
            style={{
              minHeight: 72,
              paddingHorizontal: wide ? 32 : 20,
              borderBottomWidth: 1,
              borderColor: theme.border,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            {wide ? (
              <Label muted style={{ fontSize: 13 }}>
                TU ESPACIO DE APRENDIZAJE /{" "}
                {tabs.find((t) => t[0] === tab)?.[1].toUpperCase()}
              </Label>
            ) : (
              <View
                style={{
                  flexDirection: "row",
                  gap: 8,
                  alignItems: "center",
                  flexShrink: 1,
                  minWidth: 0,
                }}
              >
                <Icon name="dna" />
                {width >= 360 && fontScale < 1.5 && (
                  <Label
                    style={{ fontSize: 22, fontWeight: "800", flexShrink: 1 }}
                  >
                    bionexo
                  </Label>
                )}
              </View>
            )}
            <View style={{ flexDirection: "row", gap: 8 }}>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Abrir biblioteca"
                onFocus={() => setFocused("library-shortcut")}
                onBlur={() => setFocused(null)}
                onPress={() => nav("library")}
                style={{
                  outlineStyle: "solid",
                  outlineWidth: focused === "library-shortcut" ? 3 : 0,
                  outlineColor: theme.warm,
                  minWidth: 48,
                  minHeight: 48,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icon name="book" color={theme.muted} />
              </Pressable>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Abrir configuración"
                onFocus={() => setFocused("settings-shortcut")}
                onBlur={() => setFocused(null)}
                onPress={() => nav("settings")}
                style={{
                  outlineStyle: "solid",
                  outlineWidth: focused === "settings-shortcut" ? 3 : 0,
                  outlineColor: theme.warm,
                  minWidth: 48,
                  minHeight: 48,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Icon name="settings" color={theme.muted} />
              </Pressable>
            </View>
          </View>
          {error && (
            <View
              accessibilityRole="alert"
              style={{ padding: 12, backgroundColor: theme.raised }}
            >
              <Label style={{ color: theme.danger }}>{error}</Label>
              <Button secondary onPress={dismissError}>
                Cerrar aviso
              </Button>
            </View>
          )}
          <Page key={tab}>{screens[tab]}</Page>
          {!wide && (
            <View
              style={{
                borderTopWidth: 1,
                borderColor: theme.border,
                paddingHorizontal: 6,
                paddingTop: 6,
                flexDirection: "row",
                backgroundColor: theme.surface,
              }}
            >
              {tabs.slice(0, 5).map((t) => navButton(t, false))}
            </View>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}
function ChipLocal() {
  const { theme } = useApp();
  return (
    <Label style={{ color: theme.accent, fontSize: 11, letterSpacing: 1.5 }}>
      ● CONTENIDO SIN CONEXIÓN
    </Label>
  );
}
