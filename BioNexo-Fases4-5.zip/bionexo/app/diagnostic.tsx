import React, { useState } from "react";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { catalog } from "../src/content";
import { useApp } from "../src/ui/provider";
import {
  Button,
  Card,
  Eyebrow,
  Heading,
  Label,
  Page,
} from "../src/ui/components";
import { StudySession } from "../src/ui/session";
export default function Diagnostic() {
  const [started, setStarted] = useState(false);
  const { state, theme } = useApp();
  if (!state)
    return (
      <Page>
        <Label>Abriendo perfil…</Label>
        <Button onPress={() => router.replace("/")}>Volver</Button>
      </Page>
    );
  if (started)
    return (
      <StudySession
        exercises={catalog.diagnostic}
        title="Punto de partida"
        mode="diagnostic"
      />
    );
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }}>
      <Page>
        <Eyebrow>CONOCER TUS BASES</Eyebrow>
        <Heading>No es un examen.{"\n"}Es un punto de partida.</Heading>
        <Label muted>
          12 preguntas de las cuatro ciencias, con especial atención a álgebra,
          factorización y funciones.
        </Label>
        <Card>
          <Label>
            Responde lo que puedas. Recibirás una explicación en cada reto. Una
            respuesta incorrecta nos ayuda a recomendar una base.
          </Label>
          <Label muted>
            Este diagnóstico breve no mide aptitud universitaria, no asigna
            dominio ni bloquea contenidos. Puedes repetirlo.
          </Label>
        </Card>
        <Button onPress={() => setStarted(true)}>Comenzar diagnóstico</Button>
        <Button secondary onPress={() => router.replace("/")}>
          Omitir por ahora
        </Button>
      </Page>
    </SafeAreaView>
  );
}
