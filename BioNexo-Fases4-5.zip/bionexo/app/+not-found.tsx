import { router } from "expo-router";
import { Page, Heading, Label, Button } from "../src/ui/components";
export default function NotFound() {
  return (
    <Page>
      <Heading>Ruta no encontrada</Heading>
      <Label>Este contenido no está disponible en el catálogo instalado.</Label>
      <Button onPress={() => router.replace("/")}>Volver al inicio</Button>
    </Page>
  );
}
