import React, { useState } from "react";
import { router } from "expo-router";
import { catalog } from "../src/content";
import { useApp } from "../src/ui/provider";
import { StudySession } from "../src/ui/session";
import { Button, Card, Heading, Label, Page } from "../src/ui/components";

export default function Transfer() {
  const { state } = useApp();
  const [started, setStarted] = useState(false);
  const activity = catalog.transferActivities?.[0];
  if (!state || !activity)
    return (
      <Page>
        <Heading>
          {state ? "Actividad no disponible" : "Abriendo perfil…"}
        </Heading>
        <Button onPress={() => router.replace("/?tab=practice")}>
          Volver a práctica
        </Button>
      </Page>
    );
  if (started)
    return (
      <StudySession
        exercises={activity.exercises}
        mode="review"
        title={activity.title}
      />
    );
  return (
    <Page>
      <Button secondary onPress={() => router.replace("/?tab=practice")}>
        Volver a práctica
      </Button>
      <Heading>{activity.title}</Heading>
      <Card>
        <Label>{activity.objective}</Label>
        <Label>{activity.model}</Label>
        <Heading small>Modelo supuesto · sin datos experimentales</Heading>
        {activity.assumptions.map((a) => (
          <Label key={a} muted>
            {a}
          </Label>
        ))}
        <Label muted>
          Conservaremos la primera respuesta de cada reto como muestra. Las
          prácticas posteriores siguen registrándose. No acredita dominio ni
          capacidad universitaria.
        </Label>
        <Label muted>
          Texto original de BioNexo. Fuentes:{" "}
          {activity.sourceIds
            .map((id) => catalog.sources.find((s) => s.id === id)?.title)
            .join(" · ")}
          . Revisión académica humana pendiente.
        </Label>
      </Card>
      <Button onPress={() => setStarted(true)}>Comenzar transferencia</Button>
    </Page>
  );
}
