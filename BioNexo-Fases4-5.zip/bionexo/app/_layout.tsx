import React from "react";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { AppProvider, useApp } from "../src/ui/provider";
export { ErrorBoundary } from "expo-router";
function Navigation() {
  const { theme, state, reduceMotion } = useApp();
  return (
    <>
      <StatusBar style={theme.bg === "#09151C" ? "light" : "dark"} />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: theme.bg },
          animation: reduceMotion ? "none" : "fade",
          gestureEnabled: !!state,
        }}
      />
    </>
  );
}
export default function Root() {
  return (
    <SafeAreaProvider>
      <AppProvider>
        <Navigation />
      </AppProvider>
    </SafeAreaProvider>
  );
}
