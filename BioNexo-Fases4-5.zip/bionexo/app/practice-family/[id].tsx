import React, { useState } from "react";
import { router, useLocalSearchParams } from "expo-router";
import { catalog } from "../../src/content";
import { selectVariants } from "../../src/domain/variants";
import type { PracticeFamily, UserState } from "../../src/domain/models";
import { useApp } from "../../src/ui/provider";
import { Button, Card, Heading, Label, Page } from "../../src/ui/components";
import { StudySession } from "../../src/ui/session";

export default function FamilyPractice() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { state } = useApp();
  const family = catalog.practiceFamilies?.find((f) => f.id === id);
  if (!state || !family)
    return (
      <Page>
        <Heading>
          {state ? "Familia no disponible" : "Abriendo perfil…"}
        </Heading>
        <Button onPress={() => router.replace("/?tab=practice")}>
          Volver a práctica
        </Button>
      </Page>
    );
  return <FamilyContent key={family.id} family={family} initial={state} />;
}
function FamilyContent({
  family,
  initial,
}: {
  family: PracticeFamily;
  initial: UserState;
}) {
  const [exercises] = useState(() => selectVariants(family, initial));
  const [started, setStarted] = useState(false);
  if (started)
    return (
      <StudySession exercises={exercises} title={family.title} mode="review" />
    );
  return (
    <Page>
      <Button secondary onPress={() => router.replace("/?tab=practice")}>
        Volver a práctica
      </Button>
      <Heading>{family.title}</Heading>
      <Card>
        <Label>{family.objective}</Label>
        <Label>
          Practicarás tres variantes, priorizando datos que aún no has
          respondido.
        </Label>
        <Label muted>
          La familia completa comparte un premio de 10 XP. Cambiar de variante
          no crea premios nuevos. La práctica y el dominio se registran por
          separado.
        </Label>
        <Label muted>
          El historial y los parámetros se conservan por ID. Salir termina esta
          ronda; sus respuestas confirmadas permanecen guardadas.
        </Label>
        <Label muted>
          Contenido original; fuentes:{" "}
          {family.sourceIds
            .map((id) => catalog.sources.find((s) => s.id === id)?.title)
            .join(" · ")}
          . Revisión académica humana pendiente.
        </Label>
      </Card>
      <Button onPress={() => setStarted(true)}>Comenzar variantes</Button>
    </Page>
  );
}
