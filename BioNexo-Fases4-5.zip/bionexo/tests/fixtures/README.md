# Fixture de compatibilidad histórica

`progress-v0.1.0.json` contiene datos sintéticos, sin información real del estudiante. Se capturó en esta auditoría usando el código del commit `0a5451d` antes de modificar el comportamiento de almacenamiento.

Formato de perfil: `version: 1`. Contiene 18 intentos (6 de una lección y 12 diagnósticos), 80 XP, finalización de lección, dominio, repaso, días de práctica, preferencias y una sesión de laboratorio con resultados simulados. Se utiliza tanto como respaldo como dentro de un SQLite de esquema 1 para comprobar migración al esquema 3. P0-03 conserva intacta esta fixture y prueba su conversión al envoltorio 2, sin modificar el perfil interno 1.

No lo regeneres con el nuevo motor para hacer pasar una prueba. Si cambia la representación, conserva esta fixture y añade versiones nuevas con su procedencia y política de migración. Esta fixture no prueba el driver `expo-sqlite` en Android ni representa todas las variantes históricas posibles.

## Formato P0-03/P0-04

`progress-p0-03-v2.json` se capturó desde `ff375cc` antes de editar persistencia en P1-01: envoltorio 2, referencias históricas 1, perfil 1 idéntico a la fixture 0.1.0, SQLite de origen 3. Es sintético, no datos del estudiante. Se usa para probar migración al envoltorio 3 con copia exacta, valores intactos y ausencia de sesiones inventadas. SQL permanece en esquema 3. No regenerar esta fixture con el motor nuevo; fallos/reintentos deben conservar el original.

## progress-p1-01-v3.json

Capturada con el motor del commit `ae7a8ab` antes de modificar el catálogo P1-02. Parte del respaldo v2 congelado y agrega dos checkpoints: factorización con distractor b/pista y fracciones con 3/4/pista. Envoltorio 3, perfil 1, checkpoint 1; sin migración SQL. SHA-256 `6a54f58649415aefe2d00f5232f05f412e93c8c2a7438d14889915221fbc5ad8`. No regenerar: demuestra conservación exacta, actualización explícita del piloto y reanudación de otra lección.

## progress-phase1-v3.json

Capturada con el motor d2a3258 antes de P2-02. Datos sintéticos: estado anterior v2, un intento de revisión phys-vectors-q3 con 1/1e309 aceptado como cero por el evaluador antiguo y checkpoints de Fase 1 de fracciones/factorización con pista. SHA-256 `89b43a23c06ef1c5851db0ddb395d649874a5c71dbccdf03fdef2d215c83528c`. Demuestra conservación exacta de resultados/XP/revisiones/sesiones aunque el evaluador vigente rechace la entrada. No regenerar.

## progress-phase2-v3.json

Capturada con el motor `6d5e92d` antes de editar Fase 3. Agrega a la fixture de Fase 1 un intento real del generador v1 y uno de transferencia mediante el motor anterior; conserva resultados/XP previos, dos checkpoints y cuaderno simulado. SHA-256 `3f7be3e76a11bd9f5894ffca01dc235b10d9d2770bc2b71ff4667d7ba13ffc84`. Misma representación SQL 3/envoltorio 3/perfil 1/checkpoint 1. Se exige lectura/exportación/restauración exacta y firmas compatibles. Datos sintéticos, no del usuario; no regenerar.
