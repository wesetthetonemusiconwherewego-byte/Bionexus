import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { exerciseById } from "../src/content";
import { parseBackup } from "../src/domain/validation";
import { SQLiteRepository, type SqlPort } from "../src/storage/repository";
const legacyJson = readFileSync("tests/fixtures/progress-v0.1.0.json", "utf8");
const legacy = JSON.parse(legacyJson);
function port(db: DatabaseSync): SqlPort {
  return {
    execAsync: async (sql) => {
      db.exec(sql);
    },
    runAsync: async (sql, ...p) => {
      db.prepare(sql).run(...p);
    },
    getFirstAsync: async <T>(sql: string, ...p: (string | number | null)[]) =>
      (db.prepare(sql).get(...p) as T | undefined) ?? null,
  };
}

test("historial: corregir una solución del catálogo no recalifica ni invalida el perfil antiguo", () => {
  const e = exerciseById["math-fractions-q1"]!;
  assert.equal(e.type, "numeric");
  if (e.type !== "numeric") return;
  const original = e.correct;
  try {
    e.correct = original + 1;
    assert.deepEqual(parseBackup(legacyJson), legacy);
  } finally {
    e.correct = original;
  }
});
test("historial: retirar un ejercicio del catálogo vigente conserva el perfil anterior", () => {
  const e = exerciseById["math-fractions-q1"]!;
  try {
    delete exerciseById[e.id];
    assert.deepEqual(parseBackup(legacyJson), legacy);
  } finally {
    exerciseById[e.id] = e;
  }
});
test("SQLite: una base existente sin perfil no se convierte en instalación nueva", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    db.exec(
      "CREATE TABLE user_state(id INTEGER PRIMARY KEY,payload TEXT NOT NULL); PRAGMA user_version=2;",
    );
    const repo = new SQLiteRepository(port(db));
    await assert.rejects(repo.load(), /perfil/);
    assert.equal(
      db.prepare("SELECT COUNT(*) AS n FROM user_state").get()!.n,
      0,
    );
  } finally {
    db.close();
  }
});

import {
  createDocument,
  readDocument,
  serializeDocument,
  latestValidRecoveryCopy,
  utf8ByteLength,
} from "../src/domain/progress-document";
import {
  openRepository as openWeb,
  WEB_PROFILE_KEY,
  WEB_RECOVERY_KEY,
} from "../src/storage/open.web";
function seed(db: DatabaseSync, raw: string, version = 2) {
  db.exec(
    "CREATE TABLE user_state(id INTEGER PRIMARY KEY,payload TEXT NOT NULL);",
  );
  db.prepare("INSERT INTO user_state VALUES(1,?)").run(raw);
  db.exec(`PRAGMA user_version=${version};`);
}
function payload(db: DatabaseSync) {
  return db.prepare("SELECT payload FROM user_state WHERE id=1").get()!
    .payload as string;
}

async function web(
  initial: string | null,
  run: (inspect: {
    data: Map<string, string>;
    storage: {
      getItem: (key: string) => string | null;
      setItem: (key: string, value: string) => void;
    };
  }) => Promise<void>,
  fail?: (key: string, value: string) => boolean,
) {
  const before = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
  const data = new Map<string, string>();
  if (initial !== null) data.set(WEB_PROFILE_KEY, initial);
  const storage = {
    getItem: (key: string) => data.get(key) ?? null,
    setItem: (key: string, value: string) => {
      if (fail?.(key, value)) throw new Error("simulated quota/write failure");
      data.set(key, value);
    },
  };
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: storage,
  });
  try {
    await run({ data, storage });
  } finally {
    if (before) Object.defineProperty(globalThis, "localStorage", before);
    else Reflect.deleteProperty(globalThis, "localStorage");
  }
}

test("documento histórico autocontenido conserva IDs retirados y no necesita soluciones actuales", async () => {
  const document = createDocument(parseBackup(legacyJson));
  const old = "math-fractions",
    retired = "archived-fractions";
  document.references.conceptIds = document.references.conceptIds.map((id) =>
    id === old ? retired : id,
  );
  for (const e of document.references.exercises)
    e.conceptIds = e.conceptIds.map((id) => (id === old ? retired : id));
  for (const a of document.state.attempts)
    a.conceptIds = a.conceptIds.map((id) => (id === old ? retired : id));
  const mastery = document.state.mastery[old]!;
  delete document.state.mastery[old];
  document.state.mastery[retired] = { ...mastery, conceptId: retired };
  const review = document.state.reviews[old]!;
  delete document.state.reviews[old];
  document.state.reviews[retired] = { ...review, conceptId: retired };
  document.references.lessonIds = document.references.lessonIds.map((id) =>
    id === "math-fractions-lesson" ? "archived-lesson" : id,
  );
  document.state.completedLessonIds = ["archived-lesson"];
  document.references.exercises[0]!.id = "archived-exercise-unused";
  const json = serializeDocument(document);
  assert.deepEqual(parseBackup(json), document.state);
  assert.equal(document.state.xp, 80);
  const db = new DatabaseSync(":memory:");
  try {
    seed(db, json);
    const repo = new SQLiteRepository(port(db));
    assert.deepEqual(await repo.load(), document.state);
    const next = await repo.update((s) => ({
      ...s,
      settings: { ...s.settings, name: "Continuar" },
    }));
    assert.equal(next.mastery[retired]!.score, 1);
    assert.equal(next.xp, 80);
    assert.equal(
      readDocument(await repo.export()).document.references.conceptIds.includes(
        retired,
      ),
      true,
    );
  } finally {
    db.close();
  }
});

test("documento: no comparte referencias mutables del registro histórico entre lecturas", () => {
  const a = readDocument(legacyJson).document;
  a.references.exercises[0]!.conceptIds = ["changed"];
  assert.deepEqual(parseBackup(legacyJson), legacy);
});

test("documento: rechaza forma de respuesta, referencias, duplicados, fechas y versiones inválidos", () => {
  const source = createDocument(parseBackup(legacyJson));
  const changes = [
    (d: typeof source) => {
      d.state.attempts[0]!.answer = { value: "0.75", unit: "invented" };
    },
    (d: typeof source) => {
      d.state.attempts.push({ ...d.state.attempts[0]! });
    },
    (d: typeof source) => {
      d.references.exercises = d.references.exercises.filter(
        (e) => e.id !== "math-fractions-q1",
      );
    },
    (d: typeof source) => {
      d.state.mastery["math-fractions"]!.evidenceDays = ["2026-02-30"];
    },
    (d: typeof source) => {
      d.state.xp = 81;
    },
    (d: typeof source) => {
      d.references.exercises[0]!.type = "unknown" as never;
    },
  ];
  for (const change of changes) {
    const d = structuredClone(source);
    change(d);
    assert.throws(() => parseBackup(JSON.stringify(d)));
  }
  for (const version of [4, 99])
    assert.throws(
      () => parseBackup(JSON.stringify({ ...source, version })),
      /Versión/,
    );
  assert.throws(
    () =>
      parseBackup(
        JSON.stringify({
          ...source,
          references: { ...source.references, version: 2 },
        }),
      ),
    /Versión/,
  );
});

test("tamaño UTF-8: emoji, tildes y límite en bytes real", () => {
  for (const s of ["abc", "Ángela", "🧬", "a\ud800b", "实验"])
    assert.equal(utf8ByteLength(s), new TextEncoder().encode(s).length);
  assert.throws(() => parseBackup("é".repeat(5_000_001)), /10 MB/);
});

test("SQLite: migración 2→3 conserva el original exacto y no duplica copias al reabrir", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db, legacyJson);
    const first = new SQLiteRepository(port(db));
    assert.deepEqual(await first.load(), legacy);
    assert.equal(db.prepare("PRAGMA user_version").get()!.user_version, 3);
    const rescue = JSON.parse(await first.exportRescue());
    assert.equal(rescue.copies.length, 1);
    assert.equal(rescue.copies[0].payload, legacyJson);
    assert.equal(readDocument(payload(db)).legacy, false);
    const second = new SQLiteRepository(port(db));
    assert.deepEqual(await second.load(), legacy);
    assert.equal(JSON.parse(await second.exportRescue()).copies.length, 1);
  } finally {
    db.close();
  }
});

test("SQLite: fallo tras copiar y antes de convertir revierte esquema, perfil y copia", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db, legacyJson);
    const base = port(db);
    const faulty: SqlPort = {
      ...base,
      runAsync: async (sql, ...p) => {
        if (sql.startsWith("UPDATE user_state"))
          throw new Error("interrupted migration");
        return base.runAsync(sql, ...p);
      },
    };
    const repo = new SQLiteRepository(faulty);
    await assert.rejects(repo.load(), /interrupted/);
    assert.equal(payload(db), legacyJson);
    assert.equal(db.prepare("PRAGMA user_version").get()!.user_version, 2);
    assert.equal(
      db
        .prepare("SELECT name FROM sqlite_master WHERE name='profile_recovery'")
        .get(),
      undefined,
    );
    assert.equal(
      JSON.parse(await repo.exportRescue()).current.payload,
      legacyJson,
    );
    assert.deepEqual(await new SQLiteRepository(base).load(), legacy);
  } finally {
    db.close();
  }
});

test("SQLite: perfil corrupto permite rescate y restauración explícita con copia original", async () => {
  for (const raw of ["", "{incomplete"]) {
    const db = new DatabaseSync(":memory:");
    try {
      seed(db, raw);
      const repo = new SQLiteRepository(port(db));
      await assert.rejects(repo.load());
      assert.equal(payload(db), raw);
      assert.equal(JSON.parse(await repo.exportRescue()).current.payload, raw);
      assert.deepEqual(await repo.restore(legacyJson), legacy);
      const rescue = JSON.parse(await repo.exportRescue());
      assert.equal(rescue.copies.at(-1).payload, raw);
      assert.deepEqual(await repo.load(), legacy);
    } finally {
      db.close();
    }
  }
});

test("SQLite: fallo de restauración no deja reemplazo parcial ni copia incompleta", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db, "broken");
    const base = port(db);
    let fail = true;
    const faulty: SqlPort = {
      ...base,
      runAsync: async (sql, ...p) => {
        if (fail && sql.includes("ON CONFLICT"))
          throw new Error("interrupted restore");
        return base.runAsync(sql, ...p);
      },
    };
    const repo = new SQLiteRepository(faulty);
    await assert.rejects(repo.load());
    await assert.rejects(repo.restore(legacyJson), /interrupted/);
    assert.equal(payload(db), "broken");
    assert.equal(JSON.parse(await repo.exportRescue()).copies.length, 0);
    fail = false;
    assert.deepEqual(await repo.restore(legacyJson), legacy);
  } finally {
    db.close();
  }
});

test("SQLite: restaurar una fila ausente es explícito y no se confunde con crear perfil inicial", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    db.exec(
      "CREATE TABLE user_state(id INTEGER PRIMARY KEY,payload TEXT NOT NULL); PRAGMA user_version=2;",
    );
    const repo = new SQLiteRepository(port(db));
    await assert.rejects(repo.load(), /perfil/);
    assert.equal(JSON.parse(await repo.exportRescue()).current.present, false);
    assert.deepEqual(await repo.restore(legacyJson), legacy);
  } finally {
    db.close();
  }
});

test("SQLite: base futura solo permite rescate sin escrituras, migración ni restauración", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db, legacyJson, 99);
    const base = port(db);
    let writes = 0;
    const watched: SqlPort = {
      ...base,
      execAsync: async (sql) => {
        writes++;
        return base.execAsync(sql);
      },
      runAsync: async (sql, ...p) => {
        writes++;
        return base.runAsync(sql, ...p);
      },
    };
    const repo = new SQLiteRepository(watched);
    await assert.rejects(repo.load(), /más reciente/);
    assert.equal(
      JSON.parse(await repo.exportRescue()).current.payload,
      legacyJson,
    );
    await assert.rejects(repo.restore(legacyJson), /más reciente/);
    assert.equal(writes, 0);
    assert.equal(db.prepare("PRAGMA user_version").get()!.user_version, 99);
    assert.equal(payload(db), legacyJson);
  } finally {
    db.close();
  }
});

test("SQLite: documento de versión futura permanece intacto incluso al intentar restaurar", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    const raw = JSON.stringify({
      ...createDocument(parseBackup(legacyJson)),
      version: 99,
    });
    seed(db, raw);
    const repo = new SQLiteRepository(port(db));
    await assert.rejects(repo.load(), /Versión/);
    await assert.rejects(repo.restore(legacyJson), /Versión/);
    assert.equal(payload(db), raw);
    assert.equal(JSON.parse(await repo.exportRescue()).copies.length, 0);
  } finally {
    db.close();
  }
});

test("Web: migración repetible, exportación y rescate conservan perfil y texto original", async () => {
  await web(legacyJson, async ({ data }) => {
    const repo = await openWeb();
    assert.deepEqual(await repo.load(), legacy);
    assert.equal(
      JSON.parse(data.get(WEB_RECOVERY_KEY)!)[0].payload,
      legacyJson,
    );
    assert.deepEqual(parseBackup(await repo.export()), legacy);
    const again = await openWeb();
    await again.load();
    assert.equal(JSON.parse(data.get(WEB_RECOVERY_KEY)!).length, 1);
  });
});

test("Web: restauración desde corrupción conserva bytes y la última copia válida es recuperable", async () => {
  await web("broken", async ({ data }) => {
    const repo = await openWeb();
    await assert.rejects(repo.load());
    assert.deepEqual(await repo.restore(legacyJson), legacy);
    const recovered = JSON.parse(await repo.exportRescue());
    assert.equal(recovered.copies[0].payload, "broken");
    assert.equal(latestValidRecoveryCopy(await repo.exportRescue()), null);
    const next = await repo.update((s) => ({
      ...s,
      settings: { ...s.settings, name: "Nuevo" },
    }));
    await repo.restore(legacyJson);
    const copy = latestValidRecoveryCopy(await repo.exportRescue());
    assert.equal(copy!.state.settings.name, next.settings.name);
    assert.equal(data.has(WEB_PROFILE_KEY), true);
  });
});

test("Web: cuota al copiar bloquea reemplazo y permite exportar texto original", async () => {
  await web(
    legacyJson,
    async ({ data }) => {
      const repo = await openWeb();
      await assert.rejects(repo.load(), /quota/);
      assert.equal(data.get(WEB_PROFILE_KEY), legacyJson);
      assert.equal(
        JSON.parse(await repo.exportRescue()).current.payload,
        legacyJson,
      );
    },
    (key) => key === WEB_RECOVERY_KEY,
  );
  await web(
    "broken",
    async ({ data }) => {
      const repo = await openWeb();
      await assert.rejects(repo.load());
      await assert.rejects(repo.restore(legacyJson), /quota/);
      assert.equal(data.get(WEB_PROFILE_KEY), "broken");
    },
    (key) => key === WEB_RECOVERY_KEY,
  );
});

test("Web: fallo al escribir perfil tras copia deja original recuperable y permite reintentar", async () => {
  let fail = true;
  await web(
    "broken",
    async ({ data }) => {
      const repo = await openWeb();
      await assert.rejects(repo.load());
      await assert.rejects(repo.restore(legacyJson), /write failure/);
      assert.equal(data.get(WEB_PROFILE_KEY), "broken");
      assert.equal(
        JSON.parse(data.get(WEB_RECOVERY_KEY)!)[0].payload,
        "broken",
      );
      fail = false;
      assert.deepEqual(await repo.restore(legacyJson), legacy);
    },
    (key) => fail && key === WEB_PROFILE_KEY,
  );
});

test("Web: perfil futuro no se sobrescribe por un respaldo anterior", async () => {
  const raw = JSON.stringify({
    ...createDocument(parseBackup(legacyJson)),
    version: 99,
  });
  await web(raw, async ({ data }) => {
    const repo = await openWeb();
    await assert.rejects(repo.load(), /Versión/);
    await assert.rejects(repo.restore(legacyJson), /Versión/);
    assert.equal(data.get(WEB_PROFILE_KEY), raw);
    assert.equal(data.has(WEB_RECOVERY_KEY), false);
  });
});

test("Web: colección de rescate corrupta no impide exportar el perfil y el texto de la colección", async () => {
  await web("broken", async ({ data }) => {
    data.set(WEB_RECOVERY_KEY, "{invalid copies");
    const repo = await openWeb();
    await assert.rejects(repo.load());
    const rescue = JSON.parse(await repo.exportRescue());
    assert.equal(rescue.current.payload, "broken");
    assert.equal(rescue.unreadableCopies, "{invalid copies");
    await assert.rejects(repo.restore(legacyJson));
    assert.equal(data.get(WEB_PROFILE_KEY), "broken");
  });
});

test("SQLite: metadatos futuros de copia no impiden rescatar el perfil accesible", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db, legacyJson, 99);
    db.exec("CREATE TABLE profile_recovery(unrecognized TEXT);");
    const repo = new SQLiteRepository(port(db));
    await assert.rejects(repo.load());
    const rescued = JSON.parse(await repo.exportRescue());
    assert.equal(rescued.current.payload, legacyJson);
    assert.ok(rescued.copiesError);
  } finally {
    db.close();
  }
});

test("historial numérico: conserva una entrada larga incorrecta que la UI anterior podía guardar", () => {
  const previous = structuredClone(legacy);
  previous.attempts[0].answer = { value: "1".repeat(2000), unit: "" };
  previous.attempts[0].correct = false;
  assert.deepEqual(parseBackup(JSON.stringify(previous)), previous);
});

import { recordAttempt } from "../src/domain/learning";
test("nuevos intentos siguen usando la solución vigente sin recalificar intentos guardados", () => {
  const e = exerciseById["math-fractions-q1"]!;
  if (e.type !== "numeric") return;
  const previous = e.correct;
  try {
    e.correct = 99;
    const state = parseBackup(legacyJson);
    const next = recordAttempt(state, {
      ...state.attempts[0]!,
      id: "new-session:math-fractions-q1:0",
      at: "2026-10-24T15:00:00Z",
    });
    assert.equal(next.attempts[0]!.correct, true);
    assert.equal(next.attempts.at(-1)!.correct, false);
    assert.equal(next.xp, 80);
    assert.deepEqual(
      parseBackup(serializeDocument(createDocument(next))),
      next,
    );
  } finally {
    e.correct = previous;
  }
});

test("Web: reintentar migración tras fallo de escritura no duplica la copia original", async () => {
  let fail = true;
  await web(
    legacyJson,
    async ({ data }) => {
      const first = await openWeb();
      await assert.rejects(first.load(), /write failure/);
      assert.equal(data.get(WEB_PROFILE_KEY), legacyJson);
      assert.equal(JSON.parse(data.get(WEB_RECOVERY_KEY)!).length, 1);
      fail = false;
      const again = await openWeb();
      assert.deepEqual(await again.load(), legacy);
      assert.equal(JSON.parse(data.get(WEB_RECOVERY_KEY)!).length, 1);
    },
    (key) => fail && key === WEB_PROFILE_KEY,
  );
});

test("documento: rechaza claves reservadas que colisionan con prototipos", () => {
  for (const id of ["constructor", "__proto__", "toString", "prototype"]) {
    const doc = createDocument(parseBackup(legacyJson));
    doc.references.exercises[0]!.id = id;
    assert.throws(() => parseBackup(JSON.stringify(doc)));
  }
});
