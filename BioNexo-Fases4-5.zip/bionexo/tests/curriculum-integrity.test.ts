import test from "node:test";
import assert from "node:assert/strict";
import { catalog } from "../src/content";
import graph from "../src/content/prerequisites.json";
import { validateCatalog } from "../src/domain/validation";
import { validatePrerequisiteGraph } from "../src/domain/curriculum-integrity";
test("integración: grafo incluido coincide exactamente y no acepta nodos ausentes/duplicados/divergentes", () => {
  assert.deepEqual(validatePrerequisiteGraph(graph, catalog), []);
  for (const input of [
    null,
    {},
    graph.slice(1),
    [...graph, graph[0]],
    graph.map((r, i) => (i === 0 ? { ...r, requires: ["bio-cells"] } : r)),
    [{ conceptId: "unknown", requires: [] }],
    [{ conceptId: "bio-life", requires: "other" }],
  ])
    assert.ok(validatePrerequisiteGraph(input, catalog).length > 0);
});
test("integración: catálogo malformado devuelve errores recuperables en lugar de lanzar", () => {
  for (const data of [
    null,
    {},
    [],
    { ...catalog, lessons: null },
    { ...catalog, concepts: [null] },
    { ...catalog, transferActivities: [{ id: "broken" }] },
  ])
    assert.doesNotThrow(() => assert.ok(validateCatalog(data).length > 0));
});
test("integración: referencias de materia/curso/unidad y fuentes se validan además de los ejercicios", () => {
  const mutations = [
    (c: typeof catalog) => {
      c.sources[0]!.url = "not-a-source";
    },
    (c: typeof catalog) => {
      c.subjects[0]!.title = "";
    },
    (c: typeof catalog) => {
      c.courses[0]!.subjectId = "missing" as never;
    },
    (c: typeof catalog) => {
      c.units[0]!.subjectId = "integrated";
    },
    (c: typeof catalog) => {
      c.concepts[0]!.subjectId = "missing" as never;
    },
  ];
  for (const mutate of mutations) {
    const data = structuredClone(catalog);
    mutate(data);
    assert.ok(validateCatalog(data).length > 0);
  }
  assert.deepEqual(validateCatalog(), []);
});
