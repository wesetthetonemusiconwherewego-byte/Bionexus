import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  mkdirSync,
  writeFileSync,
  rmSync,
  symlinkSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import {
  inspectExport,
  sourcePaths,
  forbiddenDependencies,
} from "../scripts/security/bundles";

function map(sources = ["/src/ui/provider.tsx"]) {
  return { version: 3, sources, names: [], mappings: "AAAA" };
}
function fixture(run: (dir: string) => void) {
  const dir = mkdtempSync(join(tmpdir(), "bionexo-bundles-"));
  try {
    run(dir);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
function bundle(dir: string, name: string, data: unknown = map()) {
  const file = join(dir, name);
  writeFileSync(file, "bundled-code");
  writeFileSync(file + ".map", JSON.stringify(data));
}

test("seguridad: exportación limpia inspecciona todos los bundles y vincula sus hashes", () => {
  fixture((dir) => {
    bundle(dir, "entry.hbc");
    mkdirSync(join(dir, "nested"));
    bundle(
      join(dir, "nested"),
      "chunk.js",
      map(["/node_modules/react/index.js"]),
    );
    const report = inspectExport(dir);
    assert.equal(report.bundles.length, 2);
    assert.equal(report.sourceCount, 2);
    assert.deepEqual(report.matches, []);
    for (const item of report.bundles) {
      assert.match(item.bundleSha256, /^[a-f0-9]{64}$/);
      assert.match(item.mapSha256, /^[a-f0-9]{64}$/);
    }
    writeFileSync(join(dir, "entry.hbc"), "changed-code");
    assert.notEqual(
      inspectExport(dir).bundles[0]!.bundleSha256,
      report.bundles[0]!.bundleSha256,
    );
  });
});

test("seguridad: detecta raíces vulnerables incluso en rutas Windows, anidadas o con sourceRoot", () => {
  const paths = sourcePaths(
    map([
      "/node_modules/braces/lib/compile.js",
      "C:\\app\\node_modules\\node-forge\\lib\\rsa.js",
      "/node_modules/parent/node_modules/braces/index.js",
    ]),
  );
  assert.deepEqual(
    forbiddenDependencies(paths).map((x) => x.dependency),
    ["braces", "node-forge", "braces"],
  );
  assert.equal(
    forbiddenDependencies(
      sourcePaths({
        ...map(["lib/rsa.js"]),
        sourceRoot: "/node_modules/node-forge",
      }),
    )[0]?.dependency,
    "node-forge",
  );
});

test("seguridad: no confunde nombres similares ni texto de código con dependencias", () => {
  const data = {
    ...map([
      "/src/braces.ts",
      "/node_modules/braces-extra/index.js",
      "/node_modules/node-forgery/index.js",
    ]),
    sourcesContent: ["require('node-forge')"],
  };
  assert.deepEqual(forbiddenDependencies(sourcePaths(data)), []);
});

test("seguridad: mapas indexados inspeccionan todas las secciones", () => {
  const data = {
    version: 3,
    sections: [
      { offset: { line: 0, column: 0 }, map: map() },
      {
        offset: { line: 1, column: 0 },
        map: map(["/node_modules/node-forge/lib/rsa.js"]),
      },
    ],
  };
  assert.equal(forbiddenDependencies(sourcePaths(data)).length, 1);
});

test("seguridad: mapa ausente, vacío, corrupto o desconocido nunca aprueba por omisión", () => {
  for (const data of [
    null,
    {},
    { ...map(), version: 4 },
    map([]),
    { ...map(), sources: [null] },
    { ...map(), sourceRoot: 2 },
    { version: 3, sections: [] },
    { version: 3, sections: [{ url: "remote.map" }] },
  ]) {
    assert.throws(() => sourcePaths(data));
  }
  fixture((dir) => {
    assert.throws(() => inspectExport(dir), /bundles/);
    writeFileSync(join(dir, "entry.js"), "code");
    assert.throws(() => inspectExport(dir), /map/i);
    writeFileSync(join(dir, "entry.js.map"), "invalid-json");
    assert.throws(() => inspectExport(dir));
  });
});

test("seguridad: un chunk sin mapa no queda cubierto por el mapa de otro bundle", () => {
  fixture((dir) => {
    bundle(dir, "entry.js");
    writeFileSync(join(dir, "lazy.js"), "code");
    assert.throws(() => inspectExport(dir), /lazy.js/);
  });
});

test("seguridad: limita secciones recursivas sin desbordar la pila", () => {
  let data: unknown = map();
  for (let i = 0; i < 40; i++) data = { version: 3, sections: [{ map: data }] };
  assert.throws(() => sourcePaths(data), /profundidad/);
});

test("seguridad: rechaza enlaces simbólicos y bundles vacíos", () => {
  fixture((dir) => {
    bundle(dir, "entry.js");
    writeFileSync(join(dir, "entry.js"), "");
    assert.throws(() => inspectExport(dir), /vacío/);
    writeFileSync(join(dir, "entry.js"), "code");
    // Directory junctions also exercise this guard on Windows without needing
    // the privilege required to create file symlinks there.
    symlinkSync(dir, join(dir, "linked"), "junction");
    assert.throws(() => inspectExport(dir), /simbólico/);
  });
});

test("seguridad CLI: falla al detectar inclusión real y ante errores; limpio produce informe", () => {
  fixture((dir) => {
    const run = (...args: string[]) =>
      spawnSync(
        process.execPath,
        ["--import", "tsx", "scripts/check-bundle-dependencies.ts", ...args],
        { encoding: "utf8" },
      );
    assert.equal(run().status, 1);
    bundle(dir, "entry.js");
    const clean = run(dir);
    assert.equal(clean.status, 0, clean.stderr);
    assert.equal(JSON.parse(clean.stdout).exports[0].bundles.length, 1);
    bundle(dir, "entry.js", map(["/node_modules/braces/index.js"]));
    const unsafe = run(dir);
    assert.equal(unsafe.status, 1);
    assert.equal(
      JSON.parse(unsafe.stdout).exports[0].matches[0].dependency,
      "braces",
    );
    assert.equal(run(join(dir, "missing")).status, 1);
  });
});
