import { test } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { parseBackup } from "../src/domain/validation";
import { recordAttempt } from "../src/domain/learning";
import {
  MIGRATIONS,
  SQLiteRepository,
  type SqlPort,
} from "../src/storage/repository";
import { openRepository as openWebRepository } from "../src/storage/open.web";

// Frozen data captured with commit 0a5451d. Do not regenerate this fixture with
// a changed domain engine: an old user's data must survive new implementations.
const legacyJson = readFileSync(
  join(process.cwd(), "tests/fixtures/progress-v0.1.0.json"),
  "utf8",
);
const legacy = JSON.parse(legacyJson);
const KEY = "bionexo-state-v1";
function port(db: DatabaseSync): SqlPort {
  return {
    execAsync: async (sql) => {
      db.exec(sql);
    },
    runAsync: async (sql, ...params) => {
      db.prepare(sql).run(...params);
    },
    getFirstAsync: async <T>(
      sql: string,
      ...params: (string | number | null)[]
    ) => (db.prepare(sql).get(...params) as T | undefined) ?? null,
  };
}
function seed(db: DatabaseSync, payload: string, version = 2) {
  db.exec(MIGRATIONS[0]!);
  if (version === 2) db.exec(MIGRATIONS[1]!);
  db.prepare("INSERT INTO user_state(id,payload) VALUES (1,?)").run(payload);
  db.exec(`PRAGMA user_version=${version};`);
}
function payload(db: DatabaseSync) {
  return db.prepare("SELECT payload FROM user_state WHERE id=1").get()!.payload;
}
async function withWebStorage(
  value: string | null,
  run: (
    inspect: () => {
      value: string | null;
      writes: number;
      recovery: string | null;
    },
  ) => Promise<void>,
) {
  const previous = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
  let current = value,
    writes = 0;
  let recovery: string | null = null;
  const storage = {
    getItem: (key: string) => (key === KEY ? current : recovery),
    setItem: (key: string, next: string) => {
      if (key === KEY) {
        current = next;
        writes++;
      } else {
        assert.equal(key, "bionexo-recovery-v1");
        recovery = next;
      }
    },
  };
  Object.defineProperty(globalThis, "localStorage", {
    value: storage,
    configurable: true,
  });
  try {
    await run(() => ({ value: current, writes, recovery }));
  } finally {
    if (previous) Object.defineProperty(globalThis, "localStorage", previous);
    else Reflect.deleteProperty(globalThis, "localStorage");
  }
}

test("v0.1.0: contrato histórico conserva intentos, XP, dominio, repasos, ajustes, diagnóstico y laboratorio", () => {
  const actual = parseBackup(legacyJson);
  assert.deepEqual(actual, legacy);
  assert.equal(actual.attempts.length, 18);
  assert.equal(actual.xp, 80);
  assert.equal(actual.settings.name, "Perfil histórico · Ángela");
  assert.equal(actual.diagnostic!.results.math!.correct, 6);
  assert.equal(actual.labs[0]!.points.length, 2);
});

test("SQLite: perfil completo v0.1.0 migra de esquema 1 a 3 y sobrevive reapertura", async () => {
  const dir = mkdtempSync(join(tmpdir(), "bionexo-compat-"));
  const path = join(dir, "legacy.db");
  let db = new DatabaseSync(path);
  try {
    seed(db, legacyJson, 1);
    db.close();
    db = new DatabaseSync(path);
    const repo = new SQLiteRepository(port(db));
    assert.deepEqual(await repo.load(), legacy);
    assert.equal(
      db.prepare("PRAGMA user_version").get()!.user_version,
      MIGRATIONS.length,
    );
    assert.deepEqual(
      await repo.update((s) => recordAttempt(s, s.attempts[0]!)),
      legacy,
    );
    db.close();
    db = new DatabaseSync(path);
    assert.deepEqual(await new SQLiteRepository(port(db)).load(), legacy);
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});

test("SQLite: fallo de migración revierte metadatos y conserva bytes del perfil anterior", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db, legacyJson, 1);
    const base = port(db);
    const failed: SqlPort = {
      ...base,
      execAsync: async (sql) => {
        if (sql.includes("CREATE TABLE IF NOT EXISTS repository_metadata"))
          throw new Error("simulated migration failure");
        return base.execAsync(sql);
      },
    };
    await assert.rejects(
      new SQLiteRepository(failed).load(),
      /simulated migration failure/,
    );
    assert.equal(db.prepare("PRAGMA user_version").get()!.user_version, 1);
    assert.equal(payload(db), legacyJson);
    assert.deepEqual(await new SQLiteRepository(base).load(), legacy);
  } finally {
    db.close();
  }
});

test("SQLite: datos corruptos no se reemplazan por un perfil vacío", async () => {
  for (const raw of [
    "",
    "{incomplete",
    JSON.stringify({ ...legacy, xp: -1 }),
  ]) {
    const db = new DatabaseSync(":memory:");
    try {
      seed(db, raw);
      await assert.rejects(new SQLiteRepository(port(db)).load());
      assert.equal(payload(db), raw);
    } finally {
      db.close();
    }
  }
});

test("SQLite: importar datos inválidos no altera un perfil completo; el respaldo válido restaura todo", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db, legacyJson);
    const repo = new SQLiteRepository(port(db));
    await repo.load();
    const migratedPayload = payload(db);
    assert.deepEqual(parseBackup(String(migratedPayload)), legacy);
    const rescue = JSON.parse(await repo.exportRescue());
    assert.equal(rescue.copies[0].payload, legacyJson);
    await assert.rejects(async () =>
      repo.restore(JSON.stringify({ ...legacy, version: 99 })),
    );
    assert.equal(payload(db), migratedPayload);
    await assert.rejects(repo.update((s) => ({ ...s, xp: -1 })));
    assert.equal(payload(db), migratedPayload);
    await repo.update((s) => ({
      ...s,
      settings: { ...s.settings, name: "Nombre nuevo" },
    }));
    assert.deepEqual(await repo.restore(legacyJson), legacy);
    assert.deepEqual(parseBackup(await repo.export()), legacy);
  } finally {
    db.close();
  }
});

test("Web: un perfil histórico migra sin perder datos y un respaldo inválido conserva el documento", async () => {
  await withWebStorage(legacyJson, async (inspect) => {
    const repo = await openWebRepository();
    assert.deepEqual(await repo.load(), legacy);
    const migrated = inspect().value;
    assert.deepEqual(parseBackup(migrated!), legacy);
    assert.equal(inspect().writes, 1);
    assert.equal(JSON.parse(inspect().recovery!)[0].payload, legacyJson);
    await assert.rejects(async () => repo.restore('{"version":99}'));
    assert.equal(inspect().value, migrated);
    assert.equal(inspect().writes, 1);
  });
});

test("Web: una clave ausente permite crear un perfil nuevo", async () => {
  await withWebStorage(null, async (inspect) => {
    const repo = await openWebRepository();
    const state = await repo.load();
    assert.equal(state.xp, 0);
    assert.equal(state.onboarded, false);
    assert.equal(inspect().writes, 1);
  });
});

test("Web: una clave presente pero vacía es corrupción, no un perfil nuevo", async () => {
  await withWebStorage("", async (inspect) => {
    const repo = await openWebRepository();
    await assert.rejects(repo.load());
    assert.deepEqual(inspect(), { value: "", writes: 0, recovery: null });
  });
});
