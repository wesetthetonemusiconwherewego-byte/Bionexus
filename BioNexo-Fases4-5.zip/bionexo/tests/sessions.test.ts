import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { catalog } from "../src/content";
import type { Exercise, UserState } from "../src/domain/models";
import { initialState, remediation } from "../src/domain/learning";
import { correctAnswer } from "../src/domain/answers";
import {
  beginLessonSession,
  saveLessonCheckpoint,
  submitLessonAnswer,
  advanceLessonSession,
  discardLessonSession,
  emptyCheckpoint,
  sessionMatchesLesson,
} from "../src/domain/sessions";
import {
  createDocument,
  parseBackup,
  readDocument,
  serializeDocument,
} from "../src/domain/progress-document";
import {
  SQLiteRepository,
  MIGRATIONS,
  type SqlPort,
} from "../src/storage/repository";
import {
  openRepository as openWeb,
  WEB_PROFILE_KEY,
  WEB_RECOVERY_KEY,
} from "../src/storage/open.web";
const lesson = catalog.lessons.find((l) => l.id === "math-fractions-lesson")!;
const at = "2026-10-22T10:00:00.000Z",
  id = "lesson-durable";
const previousJson = readFileSync(
  "tests/fixtures/progress-p0-03-v2.json",
  "utf8",
);
const previous = JSON.parse(previousJson).state;
function begin(s = initialState()) {
  return beginLessonSession(s, lesson, id, at);
}
function draft(
  s: UserState,
  e: Exercise = lesson.exercises[0]!,
  answer = correctAnswer(e),
  hinted = false,
) {
  const session = s.lessonSessions![lesson.id]!;
  return saveLessonCheckpoint(
    s,
    lesson,
    id,
    session.index,
    { ...session.card, answer, hintCount: Number(hinted) },
    at,
  );
}
function submit(s: UserState) {
  const session = s.lessonSessions![lesson.id]!,
    e = lesson.exercises[session.index]!;
  return submitLessonAnswer(
    s,
    lesson,
    id,
    session.index,
    e,
    session.card.answer,
    session.card.hintCount > 0 || session.card.attemptNo > 0,
    String(session.card.attemptNo),
    at,
  );
}
function port(db: DatabaseSync): SqlPort {
  return {
    execAsync: async (sql) => db.exec(sql),
    runAsync: async (sql, ...args) => db.prepare(sql).run(...args),
    getFirstAsync: async <T>(
      sql: string,
      ...args: (string | number | null)[]
    ) => (db.prepare(sql).get(...args) as T | undefined) ?? null,
  };
}
function seed(db: DatabaseSync) {
  for (const sql of MIGRATIONS) db.exec(sql);
  db.exec("PRAGMA user_version=3;");
  db.prepare("INSERT INTO user_state VALUES(1,?)").run(previousJson);
}
test("sesiones: ambos formatos anteriores conservan exactamente el perfil sin inventar sesiones", () => {
  assert.deepEqual(parseBackup(previousJson), previous);
  assert.equal(readDocument(previousJson).sourceVersion, 2);
  assert.equal(readDocument(previousJson).document.version, 3);
  assert.equal(readDocument(previousJson).legacy, true);
  assert.deepEqual(
    parseBackup(readFileSync("tests/fixtures/progress-v0.1.0.json", "utf8")),
    previous,
  );
});
test("sesiones: inicio idempotente, borrador y pistas sobreviven serialización sin crear intentos", () => {
  const s = draft(
    begin(),
    lesson.exercises[0],
    { value: "1/2", unit: "" },
    true,
  );
  const loaded = parseBackup(serializeDocument(createDocument(s)));
  assert.deepEqual(loaded, s);
  assert.strictEqual(beginLessonSession(s, lesson, "ignored", at), s);
  assert.equal(loaded.attempts.length, 0);
  assert.equal(loaded.xp, 0);
  assert.equal(loaded.lessonSessions![lesson.id]!.card.hintCount, 1);
});
test("sesiones: confirmación atómica e idempotente conserva XP, dominio y calendario", () => {
  const s = submit(draft(begin()));
  assert.equal(s.attempts.length, 1);
  assert.equal(
    s.lessonSessions![lesson.id]!.card.submittedAttemptId,
    s.attempts[0]!.id,
  );
  assert.strictEqual(submit(s), s);
  assert.equal(s.xp, 10);
  assert.deepEqual(parseBackup(serializeDocument(createDocument(s))), s);
  assert.throws(() =>
    submitLessonAnswer(
      s,
      lesson,
      id,
      0,
      lesson.exercises[0]!,
      { value: "999", unit: "" },
      false,
      "0",
      at,
    ),
  );
});
test("sesiones: avanzar una vez, no saltar por doble toque y rechazar borradores tardíos", () => {
  const s = submit(draft(begin()));
  const next = advanceLessonSession(s, lesson, id, 0, at);
  assert.equal(next.lessonSessions![lesson.id]!.index, 1);
  assert.strictEqual(advanceLessonSession(next, lesson, id, 0, at), next);
  assert.throws(() =>
    saveLessonCheckpoint(
      next,
      lesson,
      id,
      0,
      s.lessonSessions![lesson.id]!.card,
      at,
    ),
  );
  assert.throws(() => advanceLessonSession(next, lesson, id, 1, at));
});
test("sesiones: finalizar registra premio y elimina solo esa sesión, sin duplicarlo", () => {
  const other = catalog.lessons.find((l) => l.id !== lesson.id)!;
  let s = beginLessonSession(begin(), other, "other-session", at);
  for (let i = 0; i < lesson.exercises.length; i++) {
    s = submit(draft(s, lesson.exercises[i]));
    s = advanceLessonSession(s, lesson, id, i, at);
  }
  assert.equal(s.xp, 80);
  assert.ok(!s.lessonSessions![lesson.id]);
  assert.ok(s.lessonSessions![other.id]);
  assert.strictEqual(advanceLessonSession(s, lesson, id, 5, at), s);
  assert.deepEqual(parseBackup(serializeDocument(createDocument(s))), s);
});
test("sesiones: descartar preserva historial y otras sesiones; un ID antiguo no elimina una nueva", () => {
  const other = catalog.lessons.find((l) => l.id !== lesson.id)!;
  const s = beginLessonSession(
    submit(draft(begin())),
    other,
    "other-session",
    at,
  );
  const next = discardLessonSession(s, lesson.id, id);
  assert.deepEqual(next.attempts, s.attempts);
  assert.deepEqual(next.reviews, s.reviews);
  assert.equal(next.xp, s.xp);
  assert.ok(next.lessonSessions![other.id]);
  const again = beginLessonSession(next, lesson, "new-session", at);
  assert.strictEqual(discardLessonSession(again, lesson.id, id), again);
});
test("sesiones: validar referencias, feedback, cursor, versiones y borradores inválidos", () => {
  const source = createDocument(submit(draft(begin())));
  const changes = [
    (d: typeof source) => {
      d.state.lessonSessions![lesson.id]!.index = 9;
    },
    (d: typeof source) => {
      d.state.lessonSessions![lesson.id]!.card.submittedAttemptId = "missing";
    },
    (d: typeof source) => {
      d.state.lessonSessions![lesson.id]!.card.answer = {
        value: "different",
        unit: "",
      };
    },
    (d: typeof source) => {
      d.state.lessonSessions![lesson.id]!.card.hintCount = -1;
    },
    (d: typeof source) => {
      d.state.lessonSessions![lesson.id]!.exerciseIds[0] = "missing";
    },
    (d: typeof source) => {
      Object.assign(d.state.lessonSessions![lesson.id]!, { version: 99 });
    },
    (d: typeof source) => {
      Object.assign(d, { version: 2 });
    },
    (d: typeof source) => {
      Object.assign(d, { version: 99 });
    },
  ];
  for (const mutate of changes) {
    const d = structuredClone(source);
    mutate(d);
    assert.throws(() => parseBackup(JSON.stringify(d)));
  }
});
test("sesiones: cambios académicos conservan historial pero requieren decisión explícita para reanudar", () => {
  const s = submit(draft(begin()));
  const corrected = structuredClone(lesson);
  corrected.explanation += " Revisión.";
  assert.equal(
    sessionMatchesLesson(s.lessonSessions![lesson.id]!, corrected),
    false,
  );
  assert.throws(() =>
    saveLessonCheckpoint(
      s,
      corrected,
      id,
      0,
      s.lessonSessions![lesson.id]!.card,
      at,
    ),
  );
  assert.deepEqual(parseBackup(serializeDocument(createDocument(s))), s);
});
test("sesiones: cambiar el ejercicio de apoyo también invalida la reanudación sin borrar datos", () => {
  const l = catalog.lessons.find((l) => l.id === "math-factor-lesson")!;
  const s = beginLessonSession(initialState(), l, "support-revision", at);
  const easier = remediation(s, l.exercises[0]!).easier!;
  const explanation = easier.explanation.correct;
  try {
    easier.explanation.correct += " Revisión del apoyo.";
    assert.equal(sessionMatchesLesson(s.lessonSessions![l.id]!, l), false);
    assert.deepEqual(parseBackup(serializeDocument(createDocument(s))), s);
  } finally {
    easier.explanation.correct = explanation;
  }
});
test("sesiones: apoyo interrumpido conserva respuesta, contador y retorno al original", () => {
  const l = catalog.lessons.find((l) => l.id === "math-factor-lesson")!,
    e = l.exercises[0]!;
  let s = initialState();
  for (const sid of ["wrong-first", "wrong-second"]) {
    s = beginLessonSession(s, l, sid, at);
    const c = s.lessonSessions![l.id]!.card;
    const wrong =
      "options" in e && typeof e.correct === "string"
        ? e.options.find((o) => o.id !== e.correct)!.id
        : "wrong";
    s = saveLessonCheckpoint(s, l, sid, 0, { ...c, answer: wrong }, at);
    s = submitLessonAnswer(s, l, sid, 0, e, wrong, false, "0", at);
    if (sid === "wrong-first") s = discardLessonSession(s, l.id, sid);
  }
  const easier = remediation(s, e).easier!,
    root = s.lessonSessions![l.id]!.card;
  s = saveLessonCheckpoint(
    s,
    l,
    "wrong-second",
    0,
    {
      ...root,
      bridge: { exerciseId: easier.id, card: emptyCheckpoint(easier) },
    },
    at,
  );
  let card = s.lessonSessions![l.id]!.card;
  s = saveLessonCheckpoint(
    s,
    l,
    "wrong-second",
    0,
    {
      ...card,
      bridge: {
        exerciseId: easier.id,
        card: { ...card.bridge!.card, answer: correctAnswer(easier) },
      },
    },
    at,
  );
  s = submitLessonAnswer(
    s,
    l,
    "wrong-second",
    0,
    easier,
    correctAnswer(easier),
    false,
    "bridge-0-0",
    at,
  );
  assert.deepEqual(parseBackup(serializeDocument(createDocument(s))), s);
  card = s.lessonSessions![l.id]!.card;
  s = saveLessonCheckpoint(
    s,
    l,
    "wrong-second",
    0,
    { ...card, bridge: null, bridgeDone: true },
    at,
  );
  card = s.lessonSessions![l.id]!.card;
  s = saveLessonCheckpoint(
    s,
    l,
    "wrong-second",
    0,
    {
      ...card,
      attemptNo: 1,
      submittedAttemptId: null,
      answer: correctAnswer(e),
    },
    at,
  );
  s = submitLessonAnswer(
    s,
    l,
    "wrong-second",
    0,
    e,
    correctAnswer(e),
    true,
    "1",
    at,
  );
  assert.equal(s.attempts.at(-1)!.hinted, true);
  assert.deepEqual(parseBackup(serializeDocument(createDocument(s))), s);
});
test("SQLite: envoltorio 2 migra con original exacto; checkpoint confirmado sobrevive cierre y reapertura", async () => {
  const dir = mkdtempSync(join(tmpdir(), "bionexo-session-"));
  const file = join(dir, "progress.db");
  let db = new DatabaseSync(file);
  try {
    seed(db);
    let repo = new SQLiteRepository(port(db));
    assert.deepEqual(await repo.load(), previous);
    assert.equal(
      JSON.parse(await repo.exportRescue()).copies[0].payload,
      previousJson,
    );
    await repo.update((s) => draft(begin(s)));
    const committed = await repo.update(submit);
    db.close();
    db = new DatabaseSync(file);
    repo = new SQLiteRepository(port(db));
    assert.deepEqual(await repo.load(), committed);
    assert.deepEqual(await repo.update(submit), committed);
    assert.equal(JSON.parse(await repo.exportRescue()).copies.length, 1);
    assert.deepEqual(await repo.restore(await repo.export()), committed);
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
test("SQLite: fallo antes del commit revierte juntos intento y checkpoint; reintentar no duplica", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    const base = port(db);
    let fail = false;
    const repo = new SQLiteRepository({
      ...base,
      execAsync: async (sql) => {
        if (fail && sql === "COMMIT;")
          throw new Error("interrupted before commit");
        return base.execAsync(sql);
      },
    });
    const before = await repo.update((s) => draft(begin(s)));
    fail = true;
    await assert.rejects(repo.update(submit), /interrupted/);
    fail = false;
    assert.deepEqual(await repo.load(), before);
    const committed = await repo.update(submit);
    assert.equal(committed.attempts.length, 1);
    assert.deepEqual(await repo.update(submit), committed);
  } finally {
    db.close();
  }
});
test("SQLite: conversión 2→3 fallida conserva payload y copias sin cambios", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db);
    const base = port(db);
    const repo = new SQLiteRepository({
      ...base,
      runAsync: async (sql, ...args) => {
        if (sql.startsWith("UPDATE user_state"))
          throw new Error("conversion interrupted");
        return base.runAsync(sql, ...args);
      },
    });
    await assert.rejects(repo.load(), /interrupted/);
    assert.equal(
      db.prepare("SELECT payload FROM user_state").get()!.payload,
      previousJson,
    );
    assert.equal(
      db.prepare("SELECT count(*) AS n FROM profile_recovery").get()!.n,
      0,
    );
  } finally {
    db.close();
  }
});
test("Web: migración anterior, checkpoint y cuota preservan original y progreso confirmado", async () => {
  const before = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
  const data = new Map([[WEB_PROFILE_KEY, previousJson]]);
  let fail = false;
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: {
      getItem: (key: string) => data.get(key) ?? null,
      setItem: (key: string, value: string) => {
        if (fail && key === WEB_PROFILE_KEY) throw new Error("quota");
        data.set(key, value);
      },
    },
  });
  try {
    let repo = await openWeb();
    assert.deepEqual(await repo.load(), previous);
    assert.equal(
      JSON.parse(data.get(WEB_RECOVERY_KEY)!)[0].payload,
      previousJson,
    );
    const checkpoint = await repo.update((s) => draft(begin(s)));
    fail = true;
    await assert.rejects(repo.update(submit), /quota/);
    fail = false;
    assert.deepEqual(await repo.load(), checkpoint);
    const confirmed = await repo.update(submit);
    repo = await openWeb();
    assert.deepEqual(await repo.load(), confirmed);
    assert.deepEqual(await repo.update(submit), confirmed);
    assert.deepEqual(await repo.restore(previousJson), previous);
  } finally {
    if (before) Object.defineProperty(globalThis, "localStorage", before);
    else Reflect.deleteProperty(globalThis, "localStorage");
  }
});

test("SQLite: envíos concurrentes y fallo al finalizar no duplican premio ni pierden checkpoint", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    const base = port(db);
    let fail = false;
    const repo = new SQLiteRepository({
      ...base,
      execAsync: async (sql) => {
        if (fail && sql === "COMMIT;") throw new Error("finish interrupted");
        return base.execAsync(sql);
      },
    });
    await repo.update((s) => draft(begin(s)));
    await Promise.all([repo.update(submit), repo.update(submit)]);
    assert.equal((await repo.load()).attempts.length, 1);
    await Promise.all([
      repo.update((s) => advanceLessonSession(s, lesson, id, 0, at)),
      repo.update((s) => advanceLessonSession(s, lesson, id, 0, at)),
    ]);
    assert.equal((await repo.load()).lessonSessions![lesson.id]!.index, 1);
    for (let i = 1; i < lesson.exercises.length; i++) {
      await repo.update((s) => submit(draft(s, lesson.exercises[i])));
      if (i < 5)
        await repo.update((s) => advanceLessonSession(s, lesson, id, i, at));
    }
    const before = await repo.load();
    assert.equal(before.xp, 60);
    fail = true;
    await assert.rejects(
      repo.update((s) => advanceLessonSession(s, lesson, id, 5, at)),
      /interrupted/,
    );
    fail = false;
    assert.deepEqual(await repo.load(), before);
    const finished = await repo.update((s) =>
      advanceLessonSession(s, lesson, id, 5, at),
    );
    assert.equal(finished.xp, 80);
    assert.equal(finished.lessonSessions![lesson.id], undefined);
    assert.deepEqual(
      await repo.update((s) => advanceLessonSession(s, lesson, id, 5, at)),
      finished,
    );
  } finally {
    db.close();
  }
});
test("SQLite: checkpoint de versión futura permite rescate pero bloquea restauración anterior", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    seed(db);
    const doc = createDocument(begin());
    Object.assign(doc.state.lessonSessions![lesson.id]!, { version: 99 });
    const raw = JSON.stringify(doc);
    db.prepare("UPDATE user_state SET payload=?").run(raw);
    const repo = new SQLiteRepository(port(db));
    await assert.rejects(repo.load(), /más reciente/);
    assert.equal(JSON.parse(await repo.exportRescue()).current.payload, raw);
    await assert.rejects(repo.restore(previousJson), /más reciente/);
    assert.equal(
      db.prepare("SELECT payload FROM user_state").get()!.payload,
      raw,
    );
  } finally {
    db.close();
  }
});
test("Web: reintentar conversión del envoltorio 2 tras cuota no duplica la copia original", async () => {
  const before = Object.getOwnPropertyDescriptor(globalThis, "localStorage");
  const data = new Map([[WEB_PROFILE_KEY, previousJson]]);
  let fail = true;
  Object.defineProperty(globalThis, "localStorage", {
    configurable: true,
    value: {
      getItem: (k: string) => data.get(k) ?? null,
      setItem: (k: string, v: string) => {
        if (fail && k === WEB_PROFILE_KEY) throw new Error("quota");
        data.set(k, v);
      },
    },
  });
  try {
    const first = await openWeb();
    await assert.rejects(first.load(), /quota/);
    assert.equal(
      JSON.parse(await first.exportRescue()).current.payload,
      previousJson,
    );
    fail = false;
    const next = await openWeb();
    assert.deepEqual(await next.load(), previous);
    const copies = JSON.parse(data.get(WEB_RECOVERY_KEY)!);
    assert.equal(copies.length, 1);
    assert.equal(copies[0].reason, "migrate-document-v2");
    assert.equal(copies[0].payload, previousJson);
  } finally {
    if (before) Object.defineProperty(globalThis, "localStorage", before);
    else Reflect.deleteProperty(globalThis, "localStorage");
  }
});
