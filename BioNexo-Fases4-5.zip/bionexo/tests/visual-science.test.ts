import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { graphContext, graphParameters } from "../src/ui/graph-context";
import { plotGeometry, plotTick } from "../src/ui/plot-geometry";
import { ENZYMES, enzymeActivity, enzymeCurve } from "../src/domain/laboratory";
import { exerciseById, lessonById } from "../src/content";
import { grade } from "../src/domain/answers";
import {
  parseBackup,
  createDocument,
  serializeDocument,
} from "../src/domain/progress-document";
import { sessionMatchesLesson } from "../src/domain/sessions";
test("diagrama: selección espacial y textual conservan IDs y corrección académica", () => {
  const e = exerciseById["bio-cells-q4"]!;
  for (const region of ["a", "b", "c"])
    assert.equal(grade(e, region), region === "a");
});
test("gráfico: contexto válido recorre todos los pH y modelos sin perder precisión", () => {
  for (let step = 0; step <= 140; step++)
    for (const selected of [0, 1])
      for (const comparison of [false, true]) {
        const context = { ph: step / 10, selected, comparison };
        assert.deepEqual(graphContext(graphParameters(context)), context);
      }
});
test("gráfico: URLs vacías, arrays, negativos, no finitos y fuera de dominio usan valores seguros", () => {
  for (const ph of [
    undefined,
    [],
    ["4"],
    "-1",
    "15",
    "NaN",
    "Infinity",
    "1e2",
    "3.45",
    "7evil",
  ])
    assert.equal(graphContext({ ph }).ph, 7);
  assert.deepEqual(graphContext({ model: ["acid"], compare: ["1"] }), {
    ph: 7,
    selected: 0,
    comparison: false,
  });
  assert.deepEqual(graphContext({ ph: "4.0", model: "acid", compare: "1" }), {
    ph: 4,
    selected: 1,
    comparison: true,
  });
});
test("gráfico: lectura, curva y coordenadas coinciden en ambos modelos y extremos", () => {
  for (const e of ENZYMES) {
    const curve = enzymeCurve(e.optimum, e.width),
      g = plotGeometry(curve)!;
    assert.equal(g.minX, 0);
    assert.equal(g.maxX, 14);
    assert.equal(g.minY, 0);
    assert.equal(g.maxY, 100);
    for (const p of curve) {
      assert.equal(p.y, enzymeActivity(p.x, e.optimum, e.width));
      assert.ok(g.x(p.x) >= 44 && g.x(p.x) <= 324);
      assert.ok(g.y(p.y) >= 40 && g.y(p.y) <= 170);
    }
    assert.equal(g.y(enzymeActivity(e.optimum, e.optimum, e.width)), 40);
  }
  assert.ok(enzymeActivity(4, 4, 1.2) > enzymeActivity(4, 7, 1.5));
  assert.ok(enzymeActivity(7, 7, 1.5) > enzymeActivity(7, 4, 1.2));
});
test("gráfico: datos vacíos/no finitos no producen SVG inválido y constantes tienen proyección finita", () => {
  assert.equal(plotGeometry([]), null);
  assert.equal(plotGeometry([{ x: Infinity, y: 2 }]), null);
  assert.equal(plotGeometry([{ x: 1, y: 2 }], [{ x: 2, y: NaN }]), null);
  const g = plotGeometry([{ x: 3, y: -2 }])!;
  assert.ok(Number.isFinite(g.x(3)));
  assert.ok(Number.isFinite(g.y(-2)));
  const comparison = plotGeometry([{ x: 0, y: 1 }], [{ x: 5, y: 4 }])!;
  assert.equal(comparison.maxX, 5);
  assert.equal(comparison.maxY, 4);
});
test("Fase 2: fixture congelada conserva resultados, XP, sesiones, variantes y transferencia exactamente", () => {
  const raw = readFileSync("tests/fixtures/progress-phase2-v3.json", "utf8");
  assert.equal(
    createHash("sha256").update(raw).digest("hex"),
    "3f7be3e76a11bd9f5894ffca01dc235b10d9d2770bc2b71ff4667d7ba13ffc84",
  );
  const state = parseBackup(raw);
  assert.deepEqual(state, JSON.parse(raw).state);
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(state))),
    state,
  );
  assert.equal(
    state.attempts.find((a) => a.id === "pre-phase2-overflow")!.correct,
    true,
  );
  assert.ok(
    state.attempts.some((a) => a.exerciseId.startsWith("factor-trinomial-v1")),
  );
  for (const session of Object.values(state.lessonSessions ?? {}))
    assert.equal(
      sessionMatchesLesson(session, lessonById[session.lessonId]!),
      true,
    );
});

test("gráfico: etiquetas conservan pasos fraccionarios, signo y escalas pequeñas", () => {
  assert.equal(plotTick(0.5), "0,5");
  assert.equal(plotTick(-0.5), "-0,5");
  assert.equal(plotTick(0), "0");
  assert.equal(plotTick(0.0005), "5,00e-4");
  assert.equal(plotTick(10000), "1,00e+4");
});
