import test from "node:test";
import assert from "node:assert/strict";
import { palettes } from "../src/ui/palettes";
function luminance(hex: string) {
  const c = [1, 3, 5]
    .map((i) => Number.parseInt(hex.slice(i, i + 2), 16) / 255)
    .map((c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
  return 0.2126 * c[0]! + 0.7152 * c[1]! + 0.0722 * c[2]!;
}
function contrast(a: string, b: string) {
  const x = luminance(a),
    y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}
test("accesibilidad: texto activo y colores de énfasis mantienen contraste en ambos temas", () => {
  for (const p of Object.values(palettes)) {
    for (const bg of [p.bg, p.surface, p.raised])
      for (const fg of [p.text, p.muted, p.accent, p.warm, p.danger])
        assert.ok(contrast(fg, bg) >= 4.5, `${fg}/${bg} = ${contrast(fg, bg)}`);
    assert.ok(contrast(p.accentText, p.accent) >= 4.5);
  }
});
test("accesibilidad: borde de control e indicador de foco superan 3:1 sobre fondos activos", () => {
  for (const p of Object.values(palettes))
    for (const bg of [p.bg, p.surface, p.raised]) {
      assert.ok(contrast(p.muted, bg) >= 3);
      assert.ok(contrast(p.warm, bg) >= 3);
    }
});
