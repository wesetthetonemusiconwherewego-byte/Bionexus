import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { parseNumber, grade } from "../src/domain/answers";
import { exerciseById, lessonById } from "../src/content";
import {
  parseBackup,
  serializeDocument,
  createDocument,
} from "../src/domain/progress-document";
import { sessionMatchesLesson } from "../src/domain/sessions";
import type { Exercise } from "../src/domain/models";

test("números: operandos/resultados fuera de rango nunca se convierten silenciosamente en cero", () => {
  for (const input of [
    "1/1e309",
    "1e309",
    "-1e309",
    "1e309/1e309",
    "0/1e309",
    "1e-400",
    "-1e-400",
    "1e-400/1e-400",
    "1e-300/1e100",
    "1e308/1e-308",
    "1/0",
    "1/-0",
    "0/0",
  ])
    assert.equal(parseNumber(input), null, input);
});
test("números: se conservan coma, fracciones, exponentes, cero y valores finitos pequeños", () => {
  for (const [input, expected] of [
    [" 3/4 ", 0.75],
    ["1,5 / 0,5", 3],
    ["−2,5e+2", -250],
    ["+5E-3", 0.005],
    ["0e999", 0],
    [".25", 0.25],
    ["1.", 1],
    ["1e-300", 1e-300],
    ["5e-324", Number.MIN_VALUE],
    ["1e-300/1e-300", 1],
  ] as const)
    assert.equal(parseNumber(input), expected, input);
  assert.ok(parseNumber("-0") === 0);
});
test("números: gramática acotada rechaza código, ambigüedades y expresiones ajenas al alcance", () => {
  for (const input of [
    "Infinity",
    "NaN",
    "0x10",
    "2**3",
    "Math.sqrt(9)",
    "1/2/3",
    "1,2.3",
    "1 000",
    "1_000",
    "",
    " ",
    "1e",
    "1e+",
    "2 cm",
    "(1/2)",
    "1;globalThis.process.exit()",
    "1".repeat(101),
  ])
    assert.equal(parseNumber(input), null, input);
});
function numeric(correct: number, tolerance = 0): Exercise {
  return {
    ...exerciseById["phys-vectors-q3"]!,
    type: "numeric",
    correct,
    tolerance,
    unit: "m",
    acceptedUnits: { m: 1, cm: 0.01 },
  } as Exercise;
}
test("calificación: el error de operandos no finitos no acredita una respuesta cero", () => {
  const exercise = exerciseById["phys-vectors-q3"]!;
  assert.equal(grade(exercise, { value: "1/1e309", unit: "m" }), false);
  assert.equal(grade(exercise, { value: "0", unit: "m" }), true);
});
test("calificación: tolerancia absoluta y margen relativo no ocultan errores de escala", () => {
  assert.equal(grade(numeric(1e-20), { value: "0", unit: "m" }), false);
  assert.equal(grade(numeric(1e-20), { value: "1e-20", unit: "m" }), true);
  assert.equal(grade(numeric(0), { value: "1e-20", unit: "m" }), false);
  assert.equal(
    grade(numeric(0.3), { value: "0.30000000000000004", unit: "m" }),
    true,
  );
  assert.equal(grade(numeric(10, 0.01), { value: "10.009", unit: "m" }), true);
  assert.equal(grade(numeric(10, 0.01), { value: "10.011", unit: "m" }), false);
});
test("unidades: conversión explícita, propiedades propias y resultados representables", () => {
  assert.equal(grade(numeric(0.5), { value: "50", unit: "cm" }), true);
  for (const answer of [
    { value: ".5", unit: "kg" },
    { value: "50", unit: "m" },
    { value: "0", unit: "__proto__" },
    { value: "0", unit: "toString" },
  ])
    assert.equal(grade(numeric(0.5), answer), false);
  assert.equal(grade(numeric(0), { value: "5e-324", unit: "cm" }), false);
  const overflow = {
    ...numeric(0),
    acceptedUnits: { m: 1, huge: 1e308 },
  } as Exercise;
  assert.equal(grade(overflow, { value: "1e308", unit: "huge" }), false);
});
test("compatibilidad: el resultado antiguo se preserva sin volver a evaluarlo, con checkpoints intactos", () => {
  const raw = readFileSync("tests/fixtures/progress-phase1-v3.json", "utf8");
  assert.equal(
    createHash("sha256").update(raw).digest("hex"),
    "89b43a23c06ef1c5851db0ddb395d649874a5c71dbccdf03fdef2d215c83528c",
  );
  const original = JSON.parse(raw).state;
  const state = parseBackup(raw);
  assert.deepEqual(state, original);
  assert.equal(state.attempts.at(-1)!.correct, true);
  assert.equal(
    grade(exerciseById["phys-vectors-q3"]!, state.attempts.at(-1)!.answer),
    false,
  );
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(state))),
    original,
  );
  for (const session of Object.values(state.lessonSessions!))
    assert.equal(
      sessionMatchesLesson(session, lessonById[session.lessonId]!),
      true,
    );
});
