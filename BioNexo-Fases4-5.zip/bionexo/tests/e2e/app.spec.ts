import { test, expect, type Page } from "@playwright/test";
import { catalog } from "../../src/content";
import type { Exercise } from "../../src/domain/models";
async function enter(page: Page) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: /Hola,/ })).toBeVisible();
}
async function solve(page: Page, e: Exercise, wrong = false) {
  switch (e.type) {
    case "numeric":
      await page
        .getByRole("textbox", { name: "Respuesta numérica", exact: true })
        .fill(wrong ? "99999" : String(e.correct));
      break;
    case "text":
      await page
        .getByRole("textbox", { name: "Completa con el término", exact: true })
        .fill(wrong ? "incorrecto" : e.correct[0]!);
      break;
    case "multi":
      for (const id of e.correct) {
        const o = e.options.find((o) => o.id === id)!;
        await page.getByRole("checkbox").filter({ hasText: o.text }).click();
      }
      break;
    case "order":
      for (const id of e.correct) {
        const o = e.items.find((o) => o.id === id)!;
        await page.getByRole("button", { name: o.text, exact: true }).click();
      }
      break;
    case "match":
      for (const l of e.left) {
        const r = e.right.find((r) => r.id === e.correct[l.id])!;
        await page
          .getByRole("button", { name: `${l.text}: ${r.text}`, exact: true })
          .click();
      }
      break;
    default: {
      const o = e.options.find((o) =>
        wrong ? o.id !== e.correct : o.id === e.correct,
      )!;
      await page.getByRole("radio").filter({ hasText: o.text }).click();
    }
  }
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: wrong ? "Una oportunidad para conectar" : "Bien razonado",
      exact: true,
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
}
test("onboarding, lección real, recarga, progreso e interfaz offline", async ({
  page,
  context,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await enter(page);
  await page.getByRole("tab", { name: "Aprender", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Tu mapa científico" }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Comenzar lección", exact: true })
    .first()
    .click();
  await page
    .getByRole("button", { name: "Comenzar los retos", exact: true })
    .click();
  const lesson = catalog.lessons.find((l) => l.id === "math-fractions-lesson")!;
  for (const e of lesson.exercises) await solve(page, e);
  await expect(
    page.getByRole("heading", { name: "Expedición completada" }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Ver mi progreso", exact: true })
    .click();
  await expect(page.getByText("80 XP", { exact: true })).toBeVisible();
  await page.reload();
  await expect(page.getByText("80 XP", { exact: true })).toBeVisible();
  await context.setOffline(true);
  await page.getByRole("tab", { name: "Laboratorio", exact: true }).click();
  await expect(page.getByRole("heading", { name: /Una enzima/ })).toBeVisible();
  await page.getByRole("tab", { name: "Aprender", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Tu mapa científico" }),
  ).toBeVisible();
  expect(errors).toEqual([]);
});
test("diagnóstico de doce preguntas completo y persistido", async ({
  page,
}) => {
  await enter(page);
  await page
    .getByRole("button", { name: "Hacer diagnóstico", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Comenzar diagnóstico", exact: true })
    .click();
  for (const e of catalog.diagnostic) await solve(page, e);
  await expect(
    page.getByRole("heading", { name: "Tu punto de partida está listo" }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Ver mi progreso", exact: true })
    .click();
  await expect(
    page.getByText("Matemáticas: 6/6", { exact: true }),
  ).toBeVisible();
  await expect(page.getByText("0 XP", { exact: true })).toBeVisible();
  await page.reload();
  await expect(
    page.getByText("Matemáticas: 6/6", { exact: true }),
  ).toBeVisible();
});
test("laboratorio interactivo, cuaderno persistente y cambio de tema", async ({
  page,
}) => {
  await enter(page);
  await page.getByRole("tab", { name: "Laboratorio", exact: true }).click();
  await page
    .getByRole("textbox", { name: "Tu hipótesis", exact: true })
    .fill("La actividad disminuirá al alejarse de pH 7.");
  await page
    .getByRole("button", { name: "Registrar condición actual", exact: true })
    .click();
  await page.getByRole("button", { name: "+0,5 pH", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "pH 7.5", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Registrar condición actual", exact: true })
    .click();
  await page
    .getByRole("textbox", {
      name: "¿Qué observaste? ¿Apoya tu hipótesis?",
      exact: true,
    })
    .fill("A pH 7,5 la actividad fue menor en el modelo.");
  await page
    .getByRole("button", { name: "Guardar sesión", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Sesiones guardadas · 1", exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Sesiones guardadas · 1", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Abrir configuración", exact: true })
    .click();
  await page.getByRole("button", { name: "Claro", exact: true }).click();
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Configuración", exact: true }),
  ).toBeVisible();
  const stored = await page.evaluate(() =>
    JSON.parse(localStorage.getItem("bionexo-state-v1")!),
  );
  expect(stored.format).toBe("bionexo-progress");
  expect(stored.state.settings.theme).toBe("light");
  expect(stored.state.labs[0].points.length).toBe(2);
});
test("errores generan repaso y la exportación e importación preservan perfil", async ({
  page,
}) => {
  await enter(page);
  await page.goto("/lesson/math-fractions-lesson");
  await page
    .getByRole("button", { name: "Comenzar los retos", exact: true })
    .click();
  await solve(
    page,
    catalog.lessons.find((l) => l.id === "math-fractions-lesson")!
      .exercises[0]!,
    true,
  );
  await page.getByRole("button", { name: "Salir", exact: true }).click();
  await page.getByRole("tab", { name: "Practicar", exact: true }).click();
  await page
    .getByRole("button", { name: "Revisar errores", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: catalog.lessons.find((l) => l.id === "math-fractions-lesson")!
        .exercises[0]!.prompt,
      exact: true,
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Salir", exact: true }).click();
  await page
    .getByRole("button", { name: "Abrir configuración", exact: true })
    .click();
  const downloadPromise = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Exportar progreso", exact: true })
    .click();
  const download = await downloadPromise;
  expect(download.suggestedFilename()).toBe("bionexo-respaldo.json");
  const chooserPromise = page.waitForEvent("filechooser");
  await page
    .getByRole("button", { name: "Importar respaldo", exact: true })
    .click();
  const chooser = await chooserPromise;
  await chooser.setFiles((await download.path())!);
  await page
    .getByRole("button", {
      name: "Confirmar reemplazo del progreso",
      exact: true,
    })
    .click();
  await expect(
    page.getByText("Progreso restaurado.", { exact: true }),
  ).toBeVisible();
});

test("formatos interactivos: selección múltiple, completar, parejas, orden, diagrama, predicción y gráfico", async ({
  page,
}) => {
  await enter(page);
  for (const id of [
    "bio-life-lesson",
    "bio-evidence-lesson",
    "bio-cells-lesson",
    "bio-water-lesson",
    "phys-speed-lesson",
  ]) {
    const lesson = catalog.lessons.find((l) => l.id === id)!;
    await page.goto("/lesson/" + id);
    await page
      .getByRole("button", {
        name: /^(Comenzar los retos|Practicar igualmente)$/,
      })
      .click();
    for (const e of lesson.exercises) await solve(page, e);
    await expect(
      page.getByRole("heading", { name: "Expedición completada", exact: true }),
    ).toBeVisible();
  }
});

test("apoyo adaptativo lleva al prerrequisito y permite volver al problema original", async ({
  page,
}) => {
  await enter(page);
  const lesson = catalog.lessons.find((l) => l.id === "math-factor-lesson")!;
  await page.goto("/lesson/" + lesson.id);
  await page
    .getByRole("button", { name: "Practicar igualmente", exact: true })
    .click();
  await solve(page, lesson.exercises[0]!, true);
  await page
    .getByRole("button", { name: "Descartar sesión", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Confirmar descarte de sesión", exact: true })
    .click();
  await page.goto("/lesson/" + lesson.id);
  await page
    .getByRole("button", { name: "Practicar igualmente", exact: true })
    .click();
  const e = lesson.exercises[0]!;
  if ("options" in e && typeof e.correct === "string")
    await page
      .getByRole("radio")
      .filter({ hasText: e.options.find((o) => o.id !== e.correct)!.text })
      .click();
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Resolver un paso más sencillo", exact: true })
    .click();
  await page
    .getByRole("textbox", { name: "Respuesta numérica", exact: true })
    .fill("4");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
  await page
    .getByRole("button", { name: "Volver al problema original", exact: true })
    .click();
  await solve(page, e);
  await expect(
    page.getByRole("heading", {
      name: lesson.exercises[1]!.prompt,
      exact: true,
    }),
  ).toBeVisible();
});
