import { test, expect, type Page } from "@playwright/test";
import { lessonById } from "../../src/content";
async function enter(page: Page) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: /Hola,/ })).toBeVisible();
}
async function graph(page: Page) {
  await page.getByRole("tab", { name: "Laboratorio", exact: true }).click();
  await expect(page.getByRole("heading", { name: /Una enzima/ })).toBeVisible();
}
async function profileState(page: Page) {
  return page.evaluate(
    () => JSON.parse(localStorage.getItem("bionexo-state-v1")!).state,
  );
}
test("diagrama: señalar, alternativa textual, reanudación y confirmación sin duplicar premios", async ({
  page,
}) => {
  await enter(page);
  await page.goto("/lesson/bio-cells-lesson");
  await page
    .getByRole("button", {
      name: /^(Comenzar los retos|Practicar igualmente)$/,
    })
    .click();
  for (const e of lessonById["bio-cells-lesson"]!.exercises.slice(0, 3)) {
    if (e.type === "multi")
      for (const id of e.correct)
        await page
          .getByRole("checkbox", {
            name: e.options.find((o) => o.id === id)!.text,
            exact: true,
          })
          .click();
    else if ("options" in e)
      await page
        .getByRole("radio", {
          name: e.options.find((o) => o.id === e.correct)!.text,
          exact: true,
        })
        .click();
    await page
      .getByRole("button", { name: "Comprobar respuesta", exact: true })
      .click();
    await expect(
      page.getByRole("heading", { name: "Bien razonado", exact: true }),
    ).toBeVisible();
    await page.getByRole("button", { name: "Continuar", exact: true }).click();
  }
  const region = page.getByRole("button", {
    name: "Señalar región B",
    exact: true,
  });
  await region.click();
  await expect(region).toHaveAttribute("aria-pressed", "true");
  await expect(
    page.getByRole("radio", { name: "Región B", exact: true }),
  ).toHaveAttribute("aria-checked", "true");
  await expect(
    page.getByText("Cambios guardados", { exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(
    page.getByText("Región seleccionada: B", { exact: true }),
  ).toBeVisible();
  await page.getByRole("radio", { name: "Región A", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Señalar región A", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Señalar región A", exact: true }),
  ).toBeDisabled();
  const before = await profileState(page);
  expect(before.xp).toBe(40);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  const after = await profileState(page);
  expect(after.attempts).toEqual(before.attempts);
  expect(after.xp).toBe(before.xp);
});
test("gráfico: pH, curva y comparación se conservan al navegar, recargar y usar interfaz sin red", async ({
  page,
  context,
}) => {
  await enter(page);
  await page.goto("/?tab=lab&ph=4.0&model=acid&compare=1");
  await expect(
    page.getByRole("heading", { name: "pH 4.0", exact: true }),
  ).toBeVisible();
  const reading = page.getByText(
    "Mismo pH 4.0: N 13.53 % · A 100.00 %. Diferencia N − A: -86.47 puntos porcentuales.",
    { exact: true },
  );
  await expect(reading).toBeVisible();
  await page.getByRole("tab", { name: "Practicar", exact: true }).click();
  await graph(page);
  await expect(reading).toBeVisible();
  await page.reload();
  await expect(reading).toBeVisible();
  await page
    .getByRole("button", { name: "Modelo N · óptimo 7", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Ir al óptimo del modelo", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "pH 7.0", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText(
      "Mismo pH 7.0: N 100.00 % · A 4.39 %. Diferencia N − A: 95.61 puntos porcentuales.",
      { exact: true },
    ),
  ).toBeVisible();
  await context.setOffline(true);
  await page.getByRole("tab", { name: "Mi progreso", exact: true }).click();
  await graph(page);
  await expect(
    page.getByRole("heading", { name: "pH 7.0", exact: true }),
  ).toBeVisible();
  const state = await profileState(page);
  expect(state.xp).toBe(0);
  expect(state.labs).toEqual([]);
});
test("gráfico: entrada de URL inválida y extremos no permiten salir del modelo", async ({
  page,
}) => {
  await enter(page);
  await page.goto("/?tab=lab&ph=Infinity&model=desconocido&compare=si");
  await expect(
    page.getByRole("heading", { name: "pH 7.0", exact: true }),
  ).toBeVisible();
  await page.goto("/?tab=lab&ph=0&model=acid&compare=1");
  await expect(
    page.getByRole("heading", { name: "pH 0.0", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "−0,5 pH", exact: true }),
  ).toBeDisabled();
  await page.getByRole("button", { name: "+0,5 pH", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "pH 0.5", exact: true }),
  ).toBeVisible();
  await page.goto("/?tab=lab&ph=14");
  await expect(
    page.getByRole("button", { name: "+0,5 pH", exact: true }),
  ).toBeDisabled();
});
test("accesibilidad: teclado, foco visible, estados de pestañas y preferencia efectiva de movimiento", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await enter(page);
  await graph(page);
  const control = page.getByRole("button", { name: "+0,5 pH", exact: true });
  await control.focus();
  await expect(control).toBeFocused();
  await expect(control).toHaveCSS("outline-style", "solid");
  await expect(control).toHaveCSS("outline-width", "3px");
  await page.keyboard.press("Enter");
  await expect(
    page.getByRole("heading", { name: "pH 7.5", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("tab", { name: "Laboratorio", exact: true }),
  ).toHaveAttribute("aria-selected", "true");
  await page
    .getByRole("button", { name: "Abrir configuración", exact: true })
    .click();
  await expect(
    page.getByText("Movimiento reducido: activo.", { exact: true }),
  ).toBeVisible();
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await expect(
    page.getByText("Movimiento reducido: inactivo.", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("switch", { name: "Reducir animaciones", exact: true })
    .click();
  await expect(
    page.getByText("Movimiento reducido: activo.", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Claro", exact: true }).click();
  await page.reload();
  await expect(
    page.getByText("Movimiento reducido: activo.", { exact: true }),
  ).toBeVisible();
  const state = await profileState(page);
  expect(state.settings.theme).toBe("light");
  expect(state.settings.reduceMotion).toBe(true);
});
test("accesibilidad: laboratorio a 320 px con texto y altura de línea ampliados al 200%", async ({
  page,
}) => {
  await page.setViewportSize({ width: 320, height: 915 });
  await enter(page);
  await graph(page);
  await page.evaluate(() => {
    for (const el of document.querySelectorAll<HTMLElement>("div,span,input")) {
      if (
        el.childElementCount === 0 &&
        (el.textContent?.trim() || el.tagName === "INPUT")
      ) {
        const style = getComputedStyle(el),
          size = parseFloat(style.fontSize),
          line = parseFloat(style.lineHeight);
        el.style.fontSize = `${size * 2}px`;
        if (Number.isFinite(line)) el.style.lineHeight = `${line * 2}px`;
      }
    }
  });
  await page.evaluate(
    () =>
      new Promise((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(resolve)),
      ),
  );
  const overflow = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>("div,input")]
      .filter(
        (e) =>
          e.checkVisibility() &&
          e.getBoundingClientRect().width > 0 &&
          e.getBoundingClientRect().left >= 0 &&
          e.getBoundingClientRect().right > innerWidth + 1,
      )
      .map((e) => ({
        role: e.getAttribute("role"),
        text: e.textContent?.slice(0, 70),
        right: e.getBoundingClientRect().right,
      })),
  );
  expect(overflow).toEqual([]);
  for (const name of [
    "Modelo N · óptimo 7",
    "Modelo A · óptimo 4",
    "−0,5 pH",
    "+0,5 pH",
    "Registrar condición actual",
  ]) {
    const rect = await page
      .getByRole("button", { name, exact: true })
      .boundingBox();
    expect(rect!.height).toBeGreaterThanOrEqual(48);
    expect(rect!.width).toBeGreaterThanOrEqual(48);
  }
});
