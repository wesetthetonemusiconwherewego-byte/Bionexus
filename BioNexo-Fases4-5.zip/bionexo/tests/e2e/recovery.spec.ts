import { test, expect, type Page } from "@playwright/test";
import { readFileSync } from "node:fs";
import { readFile } from "node:fs/promises";
const original = readFileSync("tests/fixtures/progress-v0.1.0.json", "utf8");
const KEY = "bionexo-state-v1",
  COPIES = "bionexo-recovery-v1";
async function seed(page: Page, raw: string) {
  await page.goto("/");
  await expect(
    page.getByRole("button", { name: "Explorar sin diagnóstico", exact: true }),
  ).toBeVisible();
  await page.evaluate(({ key, raw }) => localStorage.setItem(key, raw), {
    key: KEY,
    raw,
  });
  await page.reload();
}
async function choose(page: Page, raw: string) {
  const event = page.waitForEvent("filechooser");
  await page
    .getByRole("button", {
      name: "Elegir respaldo para restaurar",
      exact: true,
    })
    .click();
  await (
    await event
  ).setFiles({
    name: "perfil.json",
    mimeType: "application/json",
    buffer: Buffer.from(raw),
  });
}

test("recuperación: exportar corrupción, rechazar respaldo inválido, cancelar y restaurar con confirmación", async ({
  page,
}) => {
  const raw = "{incomplete";
  await seed(page, raw);
  await expect(
    page.getByRole("heading", { name: "Recupera tu cuaderno", exact: true }),
  ).toBeVisible();
  const event = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Exportar datos de rescate", exact: true })
    .click();
  const download = await event;
  expect(download.suggestedFilename()).toBe("bionexo-rescate.json");
  const rescue = JSON.parse(await readFile((await download.path())!, "utf8"));
  expect(rescue.current.payload).toBe(raw);
  await choose(page, '{"version":99}');
  await expect(
    page.getByRole("button", {
      name: "Confirmar restauración del respaldo",
      exact: true,
    }),
  ).toHaveCount(0);
  expect(await page.evaluate((key) => localStorage.getItem(key), KEY)).toBe(
    raw,
  );
  await choose(page, original);
  await expect(
    page.getByRole("heading", {
      name: "Confirma el perfil que recuperarás",
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Cancelar restauración", exact: true })
    .click();
  expect(await page.evaluate((key) => localStorage.getItem(key), KEY)).toBe(
    raw,
  );
  await choose(page, original);
  await page
    .getByRole("button", {
      name: "Confirmar restauración del respaldo",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Hola, Perfil histórico · Ángela.",
      exact: true,
    }),
  ).toBeVisible();
  const data = await page.evaluate(
    ({ key, copies }) => ({
      document: JSON.parse(localStorage.getItem(key)!),
      copies: JSON.parse(localStorage.getItem(copies)!),
    }),
    { key: KEY, copies: COPIES },
  );
  expect(data.document.version).toBe(3);
  expect(data.document.state).toEqual(JSON.parse(original));
  expect(data.copies.at(-1).payload).toBe(raw);
  await page.reload();
  await expect(
    page.getByRole("heading", {
      name: "Hola, Perfil histórico · Ángela.",
      exact: true,
    }),
  ).toBeVisible();
});

test("recuperación: migración 0.1.0 deja copia local reutilizable después de una corrupción", async ({
  page,
}) => {
  await seed(page, original);
  await expect(
    page.getByRole("heading", {
      name: "Hola, Perfil histórico · Ángela.",
      exact: true,
    }),
  ).toBeVisible();
  await page.evaluate((key) => localStorage.setItem(key, "broken"), KEY);
  await page.reload();
  await page
    .getByRole("button", { name: "Buscar copia local anterior", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Confirma el perfil que recuperarás",
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", {
      name: "Confirmar restauración del respaldo",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Hola, Perfil histórico · Ángela.",
      exact: true,
    }),
  ).toBeVisible();
  const state = await page.evaluate(
    (key) => JSON.parse(localStorage.getItem(key)!).state,
    KEY,
  );
  expect(state).toEqual(JSON.parse(original));
});

test("recuperación: perfil futuro permite rescate pero no reemplazo por versión anterior", async ({
  page,
}) => {
  await page.goto("/");
  await expect(
    page.getByRole("button", { name: "Explorar sin diagnóstico", exact: true }),
  ).toBeVisible();
  const raw = await page.evaluate((key) => {
    const doc = JSON.parse(localStorage.getItem(key)!);
    doc.version = 99;
    const value = JSON.stringify(doc);
    localStorage.setItem(key, value);
    return value;
  }, KEY);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Recupera tu cuaderno", exact: true }),
  ).toBeVisible();
  await choose(page, original);
  await page
    .getByRole("button", {
      name: "Confirmar restauración del respaldo",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("heading", { name: "Recupera tu cuaderno", exact: true }),
  ).toBeVisible();
  expect(await page.evaluate((key) => localStorage.getItem(key), KEY)).toBe(
    raw,
  );
  expect(
    await page.evaluate((key) => localStorage.getItem(key), COPIES),
  ).toBeNull();
});

test("recuperación: clave vacía sigue intacta tras reintentar y admite rescate", async ({
  page,
}) => {
  await seed(page, "");
  await expect(
    page.getByRole("heading", { name: "Recupera tu cuaderno", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Reintentar apertura", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Recupera tu cuaderno", exact: true }),
  ).toBeVisible();
  expect(await page.evaluate((key) => localStorage.getItem(key), KEY)).toBe("");
  const event = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Exportar datos de rescate", exact: true })
    .click();
  const result = JSON.parse(
    await readFile((await (await event).path())!, "utf8"),
  );
  expect(result.current).toEqual({ present: true, payload: "" });
});
