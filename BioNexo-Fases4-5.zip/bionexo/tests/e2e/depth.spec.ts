import { test, expect, type Page } from "@playwright/test";
import { readFileSync } from "node:fs";
import { lessonById } from "../../src/content";
const pilot = lessonById["math-factor-lesson"]!;
const profileKey = "bionexo-state-v1";
async function enter(page: Page) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
    .click();
}
test("piloto progresivo: completar, reanudar tramo y transferir con unidades", async ({
  page,
  context,
}) => {
  await enter(page);
  await page.goto("/lesson/" + pilot.id);
  await expect(
    page.getByText("12 MIN · 8 RETOS", { exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Practicar igualmente", exact: true })
    .click();
  for (let i = 0; i < pilot.exercises.length; i++) {
    const exercise = pilot.exercises[i]!;
    if (i === 2) {
      await page.getByRole("button", { name: "Salir", exact: true }).click();
      await page
        .getByRole("button", { name: "Reanudar lección", exact: true })
        .click();
      await expect(page).toHaveURL(new RegExp(`/lesson/${pilot.id}$`));
      await expect(
        page.getByText("TRAMO 2 DE 4", { exact: true }),
      ).toBeVisible();
      await page.reload();
    }
    await expect(
      page.getByText(`TRAMO ${Math.floor(i / 2) + 1} DE 4`, { exact: true }),
    ).toBeVisible();
    if (i === 6) await context.setOffline(true);
    if (exercise.type === "numeric") {
      await page
        .getByRole("textbox", { name: "Respuesta numérica", exact: true })
        .fill(String(exercise.correct));
    } else if (exercise.type === "multi") {
      for (const option of exercise.options.filter((o) =>
        exercise.correct.includes(o.id),
      ))
        await page
          .getByRole("checkbox")
          .filter({ hasText: new RegExp(`^${option.text}$`) })
          .click();
    } else if ("options" in exercise) {
      const option = exercise.options.find((o) => o.id === exercise.correct)!;
      await page.getByRole("radio").filter({ hasText: option.text }).click();
    }
    await page
      .getByRole("button", { name: "Comprobar respuesta", exact: true })
      .click();
    await expect(
      page.getByRole("heading", { name: "Bien razonado", exact: true }),
    ).toBeVisible();
    await page.getByRole("button", { name: "Continuar", exact: true }).click();
  }
  await expect(
    page.getByRole("heading", { name: "Expedición completada", exact: true }),
  ).toBeVisible();
  const state = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    profileKey,
  );
  expect(state.xp).toBe(100);
  expect(state.attempts).toHaveLength(8);
  expect(state.completedLessonIds).toContain(pilot.id);
  expect(state.lessonSessions[pilot.id]).toBeUndefined();
  // One session cannot grant independent evidence across two days.
  expect(state.mastery["math-factor"].evidenceDays).toHaveLength(1);
});
test("actualización del piloto conserva respaldo, gate y descarte explícito sin perder historial", async ({
  page,
}) => {
  const raw = readFileSync("tests/fixtures/progress-p1-01-v3.json", "utf8");
  await page.goto("/");
  await page.evaluate(({ key, raw }) => localStorage.setItem(key, raw), {
    key: profileKey,
    raw,
  });
  await page.goto("/lesson/" + pilot.id);
  await expect(
    page.getByRole("heading", { name: "La lección cambió", exact: true }),
  ).toBeVisible();
  expect(await page.evaluate((k) => localStorage.getItem(k), profileKey)).toBe(
    raw,
  );
  await page
    .getByRole("button", { name: "Descartar sesión anterior", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Conservar sesión", exact: true })
    .click();
  expect(await page.evaluate((k) => localStorage.getItem(k), profileKey)).toBe(
    raw,
  );
  await page
    .getByRole("button", { name: "Descartar sesión anterior", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Confirmar descarte de sesión", exact: true })
    .click();
  const state = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    profileKey,
  );
  const before = JSON.parse(raw).state;
  expect(state.attempts).toEqual(before.attempts);
  expect(state.xp).toBe(before.xp);
  expect(state.completedLessonIds).toEqual(before.completedLessonIds);
  expect(state.lessonSessions["math-fractions-lesson"]).toEqual(
    before.lessonSessions["math-fractions-lesson"],
  );
});

test("pistas escalonadas: ejemplo oculto hasta la tercera, reanudación y evidencia con ayuda", async ({
  page,
}) => {
  await enter(page);
  await page.goto("/lesson/" + pilot.id);
  await page
    .getByRole("button", { name: "Practicar igualmente", exact: true })
    .click();
  const example = page.getByRole("heading", {
    name: pilot.exercises[0]!.hintExample!.title,
    exact: true,
  });
  await expect(example).toHaveCount(0);
  await page
    .getByRole("button", { name: "Ver pista 1 de 3", exact: true })
    .click();
  await expect(example).toHaveCount(0);
  await expect(
    page.getByText("Esta respuesta contará como práctica con ayuda.", {
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Ver pista 2 de 3", exact: true })
    .click();
  await expect(example).toHaveCount(0);
  await page
    .getByRole("button", { name: "Ver pista 3 de 3", exact: true })
    .click();
  await expect(example).toBeVisible();
  await page.reload();
  await expect(example).toBeVisible();
  const exercise = pilot.exercises[0]!;
  if (!("options" in exercise)) throw new Error("Se esperaba selección");
  await page
    .getByRole("radio")
    .filter({
      hasText: exercise.options.find((o) => o.id === exercise.correct)!.text,
    })
    .click();
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByText(
      "Intento con ayuda: suma práctica, no evidencia independiente.",
      { exact: true },
    ),
  ).toBeVisible();
  await page.reload();
  const state = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    profileKey,
  );
  expect(state.attempts).toHaveLength(1);
  expect(state.attempts[0].hinted).toBe(true);
  expect(state.xp).toBe(10);
  expect(state.mastery["math-factor"].evidenceDays).toEqual([]);
  expect(state.mastery["math-factor"].score).toBe(0.08);
});

test("feedback del piloto responde al distractor y una lección con errores permite continuar", async ({
  page,
}) => {
  await enter(page);
  await page.goto("/lesson/" + pilot.id);
  await page
    .getByRole("button", { name: "Practicar igualmente", exact: true })
    .click();
  for (const exercise of pilot.exercises) {
    let expected = exercise.explanation.misconception;
    if ("options" in exercise) {
      const correct = Array.isArray(exercise.correct)
        ? exercise.correct
        : [exercise.correct];
      const option = exercise.options.find((o) => !correct.includes(o.id))!;
      await page
        .getByRole(exercise.type === "multi" ? "checkbox" : "radio")
        .filter({ hasText: option.text })
        .click();
      expected = exercise.explanation.distractors![option.id]!;
    } else if (exercise.type === "numeric") {
      await page
        .getByRole("textbox", { name: "Respuesta numérica", exact: true })
        .fill("999");
    }
    await page
      .getByRole("button", { name: "Comprobar respuesta", exact: true })
      .click();
    await expect(page.getByText(expected, { exact: true })).toBeVisible();
    await page.getByRole("button", { name: "Continuar", exact: true }).click();
  }
  await expect(
    page.getByRole("heading", { name: "Expedición completada", exact: true }),
  ).toBeVisible();
  const state = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    profileKey,
  );
  expect(state.attempts).toHaveLength(8);
  expect(state.attempts.every((a: { correct: boolean }) => !a.correct)).toBe(
    true,
  );
  expect(state.mastery["math-factor"].score).toBe(0);
  expect(state.mastery["math-factor"].evidenceDays).toEqual([]);
  // Completion XP motivates participation; it is never a mastery credential.
  expect(state.xp).toBe(20);
});
