import { test, expect, type Page } from "@playwright/test";
import { catalog } from "../../src/content";
import type { Exercise } from "../../src/domain/models";
const key = "bionexo-state-v1";
const fractions = catalog.lessons.find(
  (l) => l.id === "math-fractions-lesson",
)!;
async function state(page: Page) {
  return page.evaluate((k) => JSON.parse(localStorage.getItem(k)!).state, key);
}
async function enter(page: Page) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
    .click();
}
async function start(page: Page, id = fractions.id) {
  await page.goto("/lesson/" + id);
  await page
    .getByRole("button", {
      name: /^(Comenzar los retos|Practicar igualmente)$/,
    })
    .click();
  const count = catalog.lessons.find((lesson) => lesson.id === id)!.exercises
    .length;
  await expect(
    page.getByText(`RETO 1 DE ${count}`, { exact: true }),
  ).toBeVisible();
}
async function answer(page: Page, e: Exercise, wrong = false) {
  if (e.type === "numeric")
    await page
      .getByRole("textbox", { name: "Respuesta numérica", exact: true })
      .fill(wrong ? "999" : String(e.correct));
  else if ("options" in e && typeof e.correct === "string")
    await page
      .getByRole("radio")
      .filter({
        hasText: e.options.find((o) =>
          wrong ? o.id !== e.correct : o.id === e.correct,
        )!.text,
      })
      .click();
  else throw new Error("El helper solo cubre numérico y elección del piloto.");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: wrong ? "Una oportunidad para conectar" : "Bien razonado",
      exact: true,
    }),
  ).toBeVisible();
}
async function discard(page: Page) {
  await page
    .getByRole("button", { name: "Descartar sesión", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Confirmar descarte de sesión", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: /Hola,/ })).toBeVisible();
}
test("reanudación: borrador, pista, respuesta confirmada y doble toque conservan el mismo intento", async ({
  page,
  context,
}) => {
  await enter(page);
  await start(page);
  await page
    .getByRole("textbox", { name: "Respuesta numérica", exact: true })
    .fill("3/4");
  await page
    .getByRole("button", { name: "Ver pista 1 de 2", exact: true })
    .click();
  await expect
    .poll(
      async () =>
        (await state(page)).lessonSessions[fractions.id].card.hintCount,
    )
    .toBe(1);
  await page.reload();
  await expect(
    page.getByRole("textbox", { name: "Respuesta numérica", exact: true }),
  ).toHaveValue("3/4");
  await expect(
    page.getByRole("button", { name: "Ver pista 2 de 2", exact: true }),
  ).toBeVisible();
  expect((await state(page)).attempts).toHaveLength(0);
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .evaluate((el) => {
      (el as HTMLElement).click();
      (el as HTMLElement).click();
    });
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  const confirmed = await state(page);
  expect(confirmed.attempts).toHaveLength(1);
  expect(confirmed.attempts[0].hinted).toBe(true);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  expect(await state(page)).toEqual(confirmed);
  await page
    .getByRole("button", { name: "Continuar", exact: true })
    .evaluate((el) => {
      (el as HTMLElement).click();
      (el as HTMLElement).click();
    });
  await expect(page.getByText("RETO 2 DE 6", { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Salir", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Reanudar lección", exact: true }),
  ).toBeVisible();
  await page.close();
  const reopened = await context.newPage();
  await reopened.goto("/");
  await reopened
    .getByRole("button", { name: "Reanudar lección", exact: true })
    .click();
  await expect(
    reopened.getByText("RETO 2 DE 6", { exact: true }),
  ).toBeVisible();
  expect((await state(reopened)).attempts).toEqual(confirmed.attempts);
  expect((await state(reopened)).reviews).toEqual(confirmed.reviews);
});
test("reanudación: último feedback sobrevive recarga y finalizar limpia checkpoint con premio único", async ({
  page,
}) => {
  await enter(page);
  await start(page);
  for (let i = 0; i < fractions.exercises.length; i++) {
    await answer(page, fractions.exercises[i]!);
    if (i === 5) {
      await page.reload();
      await expect(
        page.getByRole("heading", { name: "Bien razonado", exact: true }),
      ).toBeVisible();
    }
    await page.getByRole("button", { name: "Continuar", exact: true }).click();
  }
  await expect(
    page.getByRole("heading", { name: "Expedición completada", exact: true }),
  ).toBeVisible();
  const completed = await state(page);
  expect(completed.xp).toBe(80);
  expect(completed.attempts).toHaveLength(6);
  expect(completed.lessonSessions[fractions.id]).toBeUndefined();
  await page.reload();
  await expect(
    page.getByRole("button", { name: "Comenzar los retos", exact: true }),
  ).toBeVisible();
  expect(await state(page)).toEqual(completed);
});
test("reanudación: cancelar o confirmar descarte conserva otras sesiones y todo el progreso", async ({
  page,
}) => {
  await enter(page);
  await start(page);
  await answer(page, fractions.exercises[0]!);
  await page.getByRole("button", { name: "Salir", exact: true }).click();
  await start(page, "bio-life-lesson");
  await page.getByRole("button", { name: "Salir", exact: true }).click();
  await page.goto("/lesson/" + fractions.id);
  const before = await state(page);
  await page
    .getByRole("button", { name: "Descartar sesión", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Conservar sesión", exact: true })
    .click();
  expect(await state(page)).toEqual(before);
  await discard(page);
  const after = await state(page);
  const sessions = { ...before.lessonSessions };
  delete sessions[fractions.id];
  expect(after).toEqual({ ...before, lessonSessions: sessions });
  await expect(
    page.getByRole("button", { name: "Reanudar lección", exact: true }),
  ).toHaveCount(1);
});
test("reanudación: paso de apoyo y retorno conservan su borrador, feedback y contador", async ({
  page,
}) => {
  const l = catalog.lessons.find((l) => l.id === "math-factor-lesson")!;
  await enter(page);
  await start(page, l.id);
  await answer(page, l.exercises[0]!, true);
  await discard(page);
  await start(page, l.id);
  await answer(page, l.exercises[0]!, true);
  await page
    .getByRole("button", { name: "Resolver un paso más sencillo", exact: true })
    .click();
  await page
    .getByRole("textbox", { name: "Respuesta numérica", exact: true })
    .fill("4");
  await expect
    .poll(
      async () =>
        (await state(page)).lessonSessions[l.id].card.bridge?.card.answer.value,
    )
    .toBe("4");
  await page.reload();
  await expect(
    page.getByRole("textbox", { name: "Respuesta numérica", exact: true }),
  ).toHaveValue("4");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  const before = await state(page);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  expect((await state(page)).attempts).toEqual(before.attempts);
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
  await page
    .getByRole("button", { name: "Volver al problema original", exact: true })
    .click();
  await expect
    .poll(async () => (await state(page)).lessonSessions[l.id].card.attemptNo)
    .toBe(1);
  expect((await state(page)).lessonSessions[l.id].card.answer).toBe(
    before.lessonSessions[l.id].card.answer,
  );
  await page.reload();
  await answer(page, l.exercises[0]!);
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
  await expect(page.getByText("RETO 2 DE 8", { exact: true })).toBeVisible();
  expect((await state(page)).attempts).toHaveLength(4);
  expect((await state(page)).attempts.at(-1).hinted).toBe(true);
});
test("reanudación: fallo de escritura no confirma respuesta ni cambia XP; reintentar no duplica", async ({
  page,
}) => {
  await enter(page);
  await start(page);
  await page.evaluate((k) => {
    const original = Storage.prototype.setItem;
    Reflect.set(window, "bionexoWriteBlocked", true);
    Storage.prototype.setItem = function (key, value) {
      if (key === k && Reflect.get(window, "bionexoWriteBlocked"))
        throw new Error("simulated quota");
      return original.call(this, key, value);
    };
  }, key);
  await page
    .getByRole("textbox", { name: "Respuesta numérica", exact: true })
    .fill("0.75");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByText(
      "No se confirmó la respuesta. Reintenta; no se duplicará un intento ya guardado.",
      { exact: true },
    ),
  ).toBeVisible();
  expect((await state(page)).attempts).toHaveLength(0);
  expect((await state(page)).xp).toBe(0);
  await page.evaluate(() => Reflect.set(window, "bionexoWriteBlocked", false));
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  await expect(page.getByText("simulated quota", { exact: true })).toHaveCount(
    0,
  );
  expect((await state(page)).attempts).toHaveLength(1);
  expect((await state(page)).xp).toBe(10);
});
test("reanudación: contenido cambiado mantiene checkpoint hasta un descarte explícito", async ({
  page,
}) => {
  await enter(page);
  await start(page);
  await page.evaluate(
    ({ key, id }) => {
      const data = JSON.parse(localStorage.getItem(key)!);
      data.state.lessonSessions[id].contentSignature =
        "content-v1-00000000-00000000-1";
      localStorage.setItem(key, JSON.stringify(data));
    },
    { key, id: fractions.id },
  );
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "La lección cambió", exact: true }),
  ).toBeVisible();
  expect((await state(page)).lessonSessions[fractions.id]).toBeDefined();
  await page
    .getByRole("button", { name: "Descartar sesión anterior", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Confirmar descarte de sesión", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: /Hola,/ })).toBeVisible();
  expect((await state(page)).lessonSessions[fractions.id]).toBeUndefined();
});
