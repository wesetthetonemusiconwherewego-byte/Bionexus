import { test, expect, type Page } from "@playwright/test";
import fs from "node:fs";
import { catalog } from "../../src/content";
import type { Exercise } from "../../src/domain/models";
const key = "bionexo-state-v1";
async function enter(page: Page) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: /Hola,/ })).toBeVisible();
}
async function state(page: Page) {
  return page.evaluate((k) => JSON.parse(localStorage.getItem(k)!).state, key);
}
async function solve(page: Page, e: Exercise) {
  await expect(
    page.getByRole("heading", { name: e.prompt, exact: true }),
  ).toBeVisible();
  if (e.type === "numeric") {
    // Exercise both declared unit conversions through the real UI.
    const alternate = e.id.endsWith("q2")
      ? "L"
      : e.id.endsWith("q3")
        ? "células/L"
        : null;
    if (alternate)
      await page.getByRole("button", { name: alternate, exact: true }).click();
    const value =
      alternate === "L"
        ? "0,005"
        : alternate === "células/L"
          ? "2e5"
          : String(e.correct);
    await page
      .getByRole("textbox", { name: "Respuesta numérica", exact: true })
      .fill(value);
  } else if (e.type === "multi") {
    for (const id of e.correct)
      await page
        .getByRole("checkbox", {
          name: e.options.find((o) => o.id === id)!.text,
          exact: true,
        })
        .click();
  } else if ("options" in e)
    await page
      .getByRole("radio", {
        name: e.options.find((o) => o.id === e.correct)!.text,
        exact: true,
      })
      .click();
  else throw Error("Formato inesperado");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
}
test("BioLab: predicción, control mínimo, duplicados, guardado y reapertura sin XP", async ({
  page,
  context,
}) => {
  await enter(page);
  await page.getByRole("tab", { name: "Laboratorio", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Diseña una comparación", exact: true }),
  ).toBeVisible();
  const contrast = page.getByRole("button", {
    name: "Contrastar predicción",
    exact: true,
  });
  await expect(contrast).toBeDisabled();
  await page
    .getByRole("button", { name: "Predicción: Mayor", exact: true })
    .click();
  await contrast.click();
  await expect(
    page.getByText(/La predicción coincide con este cálculo.*19.93 puntos/),
  ).toBeVisible();
  await page
    .getByRole("textbox", { name: "pH de la segunda condición", exact: true })
    .fill("6");
  await contrast.click();
  await expect(
    page.getByText("Usa dos pH distintos para contrastar la predicción.", {
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("textbox", { name: "Tu hipótesis", exact: true })
    .fill("El modelo N disminuye al alejarse de 7.");
  await page
    .getByRole("textbox", {
      name: "¿Qué observaste? ¿Apoya tu hipótesis?",
      exact: true,
    })
    .fill("Se compara el mismo modelo; son valores simulados.");
  const register = page.getByRole("button", {
    name: "Registrar condición actual",
    exact: true,
  });
  const save = page.getByRole("button", {
    name: "Guardar sesión",
    exact: true,
  });
  await register.click();
  await expect(save).toBeDisabled();
  await register.click();
  await expect(
    page.getByText(/Esta condición ya está registrada/),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Modelo A · óptimo 4", exact: true })
    .click();
  await register.click();
  await expect(save).toBeDisabled();
  await page
    .getByRole("button", { name: "Modelo N · óptimo 7", exact: true })
    .click();
  await page.getByRole("button", { name: "+0,5 pH", exact: true }).click();
  await register.click();
  await expect(save).toBeEnabled();
  await save.click();
  await expect(
    page.getByRole("heading", { name: "Sesiones guardadas · 1", exact: true }),
  ).toBeVisible();
  await expect(save).toBeDisabled();
  const before = await state(page);
  expect(before.xp).toBe(0);
  expect(before.labs).toHaveLength(1);
  expect(before.labs[0].points).toHaveLength(3);
  await page.reload();
  await page
    .getByRole("button", { name: "Abrir registro guardado", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Registro del laboratorio",
      exact: true,
    }),
  ).toBeVisible();
  await expect(
    page.getByText(/diferencia guardada segunda − primera: -5.404 puntos/),
  ).toBeVisible();
  await context.setOffline(true);
  await page
    .getByRole("button", { name: "Lecturas del modelo A", exact: true })
    .click();
  await expect(
    page.getByText(`2. A · pH 7 · ${before.labs[0].points[1].activity} %`, {
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Volver al laboratorio", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "pH 7.5", exact: true }),
  ).toBeVisible();
  expect(await state(page)).toEqual(before);
});
test("cuaderno: dato histórico original y registro inexistente se conservan sin recalcular", async ({
  page,
}) => {
  const raw = fs.readFileSync(
    "tests/fixtures/progress-pre-phase45-v3.json",
    "utf8",
  );
  await page.goto("/");
  await page.evaluate(({ key, raw }) => localStorage.setItem(key, raw), {
    key,
    raw,
  });
  await page.goto("/lab-session/pre-phase45-single");
  await expect(
    page.getByText("1. N · pH 6 · 12.345 %", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText(/Registro previo sin dos pH distintos/),
  ).toBeVisible();
  expect(await page.evaluate((k) => localStorage.getItem(k), key)).toBe(raw);
  await page.reload();
  await expect(
    page.getByText("1. N · pH 6 · 12.345 %", { exact: true }),
  ).toBeVisible();
  await page.goto("/lab-session/no-existe");
  await expect(
    page.getByRole("heading", { name: "Registro no encontrado", exact: true }),
  ).toBeVisible();
  expect(await page.evaluate((k) => localStorage.getItem(k), key)).toBe(raw);
});
test("proyecto: ruta integrada, unidades, continuación, conclusión, offline y premios únicos", async ({
  page,
  context,
}) => {
  await enter(page);
  await page.getByRole("tab", { name: "Aprender", exact: true }).click();
  await page
    .getByRole("button", { name: "Biotecnología integrada", exact: true })
    .click();
  await page
    .getByRole("button", {
      name: "Abrir proyecto interdisciplinario",
      exact: true,
    })
    .click();
  const activity = catalog.transferActivities!.find(
    (a) => a.id === "project-dilution-v1",
  )!;
  await expect(
    page.getByRole("heading", { name: activity.title, exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Continuar proyecto", exact: true })
    .click();
  await solve(page, activity.exercises[0]!);
  await page.reload();
  await expect(page.getByText(/1 de 6 retos contestados/)).toBeVisible();
  await page
    .getByRole("button", { name: "Continuar proyecto", exact: true })
    .click();
  await context.setOffline(true);
  for (const e of activity.exercises.slice(1)) await solve(page, e);
  await expect(
    page.getByRole("heading", { name: "Expedición completada", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Ver mi progreso", exact: true })
    .click();
  await page
    .getByRole("button", {
      name: "Volver al proyecto interdisciplinario",
      exact: true,
    })
    .click();
  await expect(
    page.getByText(/Última conclusión: reconoce los límites del modelo/),
  ).toBeVisible();
  await page
    .getByRole("button", {
      name: "Practicar el proyecto de nuevo",
      exact: true,
    })
    .click();
  for (const e of activity.exercises) await solve(page, e);
  const after = await state(page);
  expect(after.xp).toBe(60);
  expect(after.attempts).toHaveLength(12);
  await context.setOffline(false);
  await page.reload();
  await expect(page.getByText(/6 de 6 retos contestados/)).toBeVisible();
  expect((await state(page)).attempts).toEqual(after.attempts);
});
