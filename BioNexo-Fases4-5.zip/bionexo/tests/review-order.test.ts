import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { allExercises } from "../src/content";
import { reviewQueue, initialState } from "../src/domain/learning";
import { phase2ReviewQueue } from "./helpers/review-queue-phase2";
import { parseBackup } from "../src/domain/progress-document";
import type { Attempt } from "../src/domain/models";
test("repaso indexado: idéntico al selector Fase 2, con límites, empates, diagnósticos y fechas desordenadas", () => {
  let seed = 317;
  const random = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed;
  };
  for (let sample = 0; sample < 30; sample++) {
    const state = initialState();
    state.attempts = Array.from({ length: sample * 37 }, (_, i) => {
      const e = allExercises[random() % allExercises.length]!;
      const a: Attempt = {
        id: `s${sample}-${i}`,
        exerciseId: e.id,
        conceptIds: e.conceptIds,
        answer: "a",
        correct: random() % 3 === 0,
        hinted: false,
        at: new Date(Date.UTC(2026, 9, 20 + (random() % 3), 12)).toISOString(),
        mode: i % 5 === 0 ? "diagnostic" : "review",
      };
      return a;
    });
    for (const a of state.attempts)
      for (const id of a.conceptIds)
        state.reviews[id] = {
          conceptId: id,
          step: 0,
          intervalDays: 1,
          dueAt:
            sample % 2
              ? "2026-10-21T12:00:00.000Z"
              : "2026-10-23T12:00:00.000Z",
          lapses: 0,
        };
    const before = structuredClone(state);
    for (const limit of [0, 1, 8, 500])
      for (const at of [
        "2026-10-21T11:59:59.999Z",
        "2026-10-21T12:00:00.000Z",
        "2026-10-24T12:00:00.000Z",
      ])
        assert.deepEqual(
          reviewQueue(state, new Date(at), limit),
          phase2ReviewQueue(state, new Date(at), limit),
        );
    assert.deepEqual(state, before);
  }
});
test("repaso indexado: perfiles históricos y Fase 2 intactos, mismo orden y calendarios", () => {
  for (const file of [
    "progress-v0.1.0.json",
    "progress-p0-03-v2.json",
    "progress-phase1-v3.json",
    "progress-phase2-v3.json",
  ]) {
    const state = parseBackup(readFileSync(`tests/fixtures/${file}`, "utf8")),
      before = structuredClone(state);
    assert.deepEqual(
      reviewQueue(state, new Date("2027-01-01T00:00:00Z")),
      phase2ReviewQueue(state, new Date("2027-01-01T00:00:00Z")),
    );
    assert.deepEqual(state, before);
  }
});
