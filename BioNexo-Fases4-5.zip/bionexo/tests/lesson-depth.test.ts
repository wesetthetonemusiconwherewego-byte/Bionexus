import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import { catalog, lessonById } from "../src/content";
import { stageAt } from "../src/domain/lesson-stages";
import { validateCatalog } from "../src/domain/validation";
import {
  parseBackup,
  serializeDocument,
  createDocument,
} from "../src/domain/progress-document";
import {
  sessionMatchesLesson,
  discardLessonSession,
  beginLessonSession,
} from "../src/domain/sessions";
import { correctAnswer, grade } from "../src/domain/answers";

const pilot = lessonById["math-factor-lesson"]!;
test("piloto: cuatro tramos con evaluación completa y posición derivada al reanudar", () => {
  assert.equal(pilot.stages?.length, 4);
  assert.equal(pilot.exercises.length, 8);
  for (let i = 0; i < 8; i++) {
    const position = stageAt(pilot, i)!;
    assert.equal(position.index, Math.floor(i / 2));
    assert.ok(position.stage.example.steps.length >= 3);
    assert.ok(position.stage.exerciseIds.includes(pilot.exercises[i]!.id));
    assert.equal(
      grade(pilot.exercises[i]!, correctAnswer(pilot.exercises[i]!)),
      true,
    );
  }
  for (const cursor of [-1, 0.5, 8, NaN])
    assert.equal(stageAt(pilot, cursor), undefined);
  assert.equal(stageAt(lessonById["bio-life-lesson"]!, 0), undefined);
});
test("integridad: rechaza tramos sin evaluación, desordenados, duplicados o sin fuentes", () => {
  for (const damage of [
    (l: typeof pilot) => {
      l.stages![0]!.exerciseIds = [];
    },
    (l: typeof pilot) => {
      l.stages![0]!.exerciseIds.reverse();
    },
    (l: typeof pilot) => {
      l.stages![1]!.id = l.stages![0]!.id;
    },
    (l: typeof pilot) => {
      l.stages![0]!.example.steps = [""];
    },
    (l: typeof pilot) => {
      l.stages![0]!.sourceIds = ["missing"];
    },
  ]) {
    const copy = structuredClone(catalog);
    damage(copy.lessons.find((l) => l.id === pilot.id)!);
    assert.ok(validateCatalog(copy).length > 0);
  }
});
test("compatibilidad: respaldo v3 anterior intacto; piloto bloqueado y sesión ajena reanudable", () => {
  const raw = readFileSync("tests/fixtures/progress-p1-01-v3.json", "utf8");
  assert.equal(
    createHash("sha256").update(raw).digest("hex"),
    "6a54f58649415aefe2d00f5232f05f412e93c8c2a7438d14889915221fbc5ad8",
  );
  const old = JSON.parse(raw).state;
  const state = parseBackup(raw);
  assert.deepEqual(state, old);
  assert.deepEqual(parseBackup(serializeDocument(createDocument(state))), old);
  assert.equal(
    sessionMatchesLesson(state.lessonSessions![pilot.id]!, pilot),
    false,
  );
  const fractions = lessonById["math-fractions-lesson"]!;
  assert.equal(
    sessionMatchesLesson(state.lessonSessions![fractions.id]!, fractions),
    true,
  );
  const updated = beginLessonSession(
    discardLessonSession(state, pilot.id, state.lessonSessions![pilot.id]!.id),
    pilot,
    "new-pilot",
    "2026-10-22T13:00:00Z",
  );
  assert.deepEqual(updated.attempts, old.attempts);
  assert.deepEqual(updated.completedLessonIds, old.completedLessonIds);
  assert.equal(updated.xp, old.xp);
  assert.deepEqual(
    updated.lessonSessions![fractions.id],
    old.lessonSessions[fractions.id],
  );
});
test("transferencia: área y conversiones coherentes, no aceptar longitud como área", () => {
  const area = pilot.exercises[7]!;
  assert.equal(grade(area, { value: "18", unit: "cm²" }), true);
  assert.equal(grade(area, { value: "1800", unit: "mm²" }), true);
  for (const answer of [
    { value: "9", unit: "cm²" },
    { value: "18", unit: "cm" },
    { value: "18", unit: "mm²" },
    { value: "0", unit: "cm²" },
  ])
    assert.equal(grade(area, answer), false);
  // Independent expansion and positive side lengths over the stated model domain.
  for (const s of [0, 0.5, 2, 5]) {
    assert.equal((s + 1) * (s + 4), s * s + 5 * s + 4);
    assert.ok(s + 1 > 0 && s + 4 > 0);
  }
});
test("identidades y restricciones: casos con signos y producto cero, respuestas originales estables", () => {
  for (const x of [-5, -3, -2, 0, 2, 3, 6]) {
    assert.ok((x - 3) * (x + 3) === x * x - 9);
    assert.equal(3 * (x + 2), 3 * x + 6);
    assert.ok((x + 2) * (x + 3) === x * x + 5 * x + 6);
    if (x !== 3) assert.ok((x * x - 9) / (x - 3) === x + 3);
  }
  assert.ok(Number.isNaN((3 * 3 - 9) / (3 - 3)));
  assert.equal(grade(pilot.exercises[3]!, ["a"]), false);
  assert.equal(grade(pilot.exercises[3]!, ["a", "b"]), true);
  assert.equal(grade(pilot.exercises[4]!, "c"), false);
  assert.equal(grade(pilot.exercises[4]!, "a"), true);
  assert.deepEqual(
    pilot.exercises.slice(0, 6).map((e) => e.id),
    Array.from({ length: 6 }, (_, i) => `math-factor-q${i + 1}`),
  );
});
