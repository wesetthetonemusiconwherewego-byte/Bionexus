import { test } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { catalog, allExercises } from "../src/content";
import type {
  Answer,
  Attempt,
  Exercise,
  UserState,
} from "../src/domain/models";
import { correctAnswer, grade, parseNumber } from "../src/domain/answers";
import {
  completeLesson,
  dayKey,
  diagnosticResult,
  initialState,
  isMastered,
  missingPrerequisites,
  recordAttempt,
  remediation,
  reviewQueue,
  schedule,
  streak,
  weeklyChallenge,
} from "../src/domain/learning";
import { enzymeActivity, enzymeCurve } from "../src/domain/laboratory";
import { parseBackup, validateCatalog } from "../src/domain/validation";
import {
  SQLiteRepository,
  MIGRATIONS,
  type SqlPort,
} from "../src/storage/repository";
function attempt(
  e: Exercise,
  answer: Answer = correctAnswer(e),
  at = "2026-10-22T15:00:00.000Z",
  prefix = "s",
): Attempt {
  return {
    id: `${prefix}:${e.id}:0`,
    exerciseId: e.id,
    answer,
    conceptIds: e.conceptIds,
    correct: grade(e, answer),
    at,
    mode: "lesson",
    hinted: false,
  };
}
const first = catalog.lessons.find((l) => l.id === "math-fractions-lesson")!;
function port(db: DatabaseSync): SqlPort {
  return {
    execAsync: async (s) => {
      db.exec(s);
    },
    runAsync: async (s, ...params) => {
      db.prepare(s).run(...params);
    },
    getFirstAsync: async <T>(
      s: string,
      ...params: (string | number | null)[]
    ) => (db.prepare(s).get(...params) as T) ?? null,
  };
}
test("catálogo: 24 lecciones, 146 ejercicios, cuatro rutas completas y 10 tipos", () => {
  assert.deepEqual(validateCatalog(), []);
  assert.equal(catalog.lessons.length, 24);
  assert.equal(catalog.lessons.flatMap((l) => l.exercises).length, 146);
  for (const s of catalog.subjects.slice(0, 4)) {
    assert.equal(catalog.units.filter((u) => u.subjectId === s.id).length, 3);
    assert.equal(catalog.lessons.filter((l) => l.subjectId === s.id).length, 6);
  }
  assert.equal(new Set(allExercises.map((e) => e.type)).size, 10);
  assert.equal(catalog.diagnostic.length, 12);
});
test("validador detecta duplicados, ciclos, referencias faltantes y soluciones inválidas", () => {
  const data = structuredClone(catalog);
  data.lessons[0]!.id = data.lessons[1]!.id;
  data.concepts[0]!.prerequisites = [data.concepts[0]!.id, "absent"];
  const q = data.lessons[0]!.exercises[0]!;
  if ("options" in q && typeof q.correct === "string")
    q.correct = "not-an-option";
  const errors = validateCatalog(data).join(" ");
  assert.match(errors, /duplicado/);
  assert.match(errors, /Ciclo/);
  assert.match(errors, /inexistente/);
  assert.match(errors, /solución/);
});
test("validador rechaza tolerancias y factores de unidad inconsistentes", () => {
  const data = structuredClone(catalog);
  const q = data.lessons
    .flatMap((l) => l.exercises)
    .find((e) => e.type === "numeric")!;
  if (q.type === "numeric") {
    q.tolerance = -1;
    q.acceptedUnits[q.unit] = 3;
  }
  assert.match(validateCatalog(data).join(" "), /fórmula\/unidad/);
});
test("todas las soluciones del catálogo son aceptadas por su evaluador", () => {
  for (const e of allExercises)
    assert.equal(grade(e, correctAnswer(e)), true, e.id);
});
test("parser numérico acepta equivalencias y rechaza código, infinitos y división por cero", () => {
  for (const [s, n] of [
    ["0,5", 0.5],
    ["1/2", 0.5],
    ["5e-1", 0.5],
    ["−2", -2],
    [".25", 0.25],
  ] as const)
    assert.equal(parseNumber(s), n);
  for (const s of [
    "1/0",
    "Infinity",
    "NaN",
    "2+2",
    "alert(1)",
    "1,2,3",
    "1e999",
    "3 kg",
    "1/2/3",
    "",
  ])
    assert.equal(parseNumber(s), null);
});
test("respuestas numéricas convierten unidades y respetan tolerancias explícitas", () => {
  const q = allExercises.find((e) => e.id === "phys-units-q1")!;
  assert.equal(grade(q, { value: "250", unit: "mL" }), true);
  assert.equal(grade(q, { value: "1/4", unit: "L" }), true);
  assert.equal(grade(q, { value: "250", unit: "L" }), false);
  assert.equal(grade(q, { value: "0.25", unit: "kg" }), false);
  assert.equal(grade(q, { value: "0.251", unit: "L" }), false);
});
test("selección múltiple rechaza duplicados y emparejar exige todas las relaciones", () => {
  const q = allExercises.find((e) => e.type === "multi")!;
  assert.ok(Array.isArray(q.correct));
  assert.equal(grade(q, [...q.correct, q.correct[0]!]), false);
  const m = allExercises.find((e) => e.type === "match")!;
  assert.equal(grade(m, {}), false);
  for (const a of [null, undefined, 42, {}, ["invalid"]])
    assert.equal(grade(allExercises[0]!, a), false);
});
test("auditoría independiente de resultados numéricos y científicos clave", () => {
  const expected: Record<string, number> = {
    "math-fractions-q1": 0.75,
    "math-fractions-q4": 2,
    "math-powers-q1": 32,
    "math-equations-q3": -4,
    "math-factor-q6": 20,
    "math-linear-q1": 11,
    "math-quadratic-q1": 5,
    "chem-change-q3": 10,
    "chem-atom-q2": 8,
    "chem-atom-q3": 10,
    "chem-mole-q1": 0.5,
    "phys-measure-q5": 2.6,
    "phys-speed-q2": -2,
    "phys-force-q3": 30,
    "phys-energy-q2": 9,
  };
  for (const [id, value] of Object.entries(expected)) {
    const q = allExercises.find((e) => e.id === id)!;
    assert.equal(q.correct, value, id);
  }
});
test("motor no confía en el booleano de respuesta enviado por la interfaz", () => {
  const e = first.exercises[0]!;
  const a = attempt(e, { value: "999", unit: "" });
  a.correct = true;
  const state = recordAttempt(initialState(), a);
  assert.equal(state.attempts[0]!.correct, false);
  assert.equal(state.xp, 0);
});
test("XP y registro son idempotentes; practicar de nuevo no duplica recompensas", () => {
  let s = initialState();
  const a = attempt(first.exercises[0]!);
  s = recordAttempt(s, a);
  assert.equal(s.xp, 10);
  s = recordAttempt(s, a);
  assert.equal(s.attempts.length, 1);
  s = recordAttempt(
    s,
    attempt(first.exercises[0]!, undefined, undefined, "s2"),
  );
  assert.equal(s.xp, 10);
});
test("lección exige todos los ejercicios; completarla otra vez no duplica XP", () => {
  let s = initialState();
  assert.throws(() => completeLesson(s, first, "s"));
  for (const e of first.exercises) s = recordAttempt(s, attempt(e));
  s = completeLesson(s, first, "s");
  assert.equal(s.xp, 80);
  assert.deepEqual(s.completedLessonIds, [first.id]);
  assert.equal(completeLesson(s, first, "s").xp, 80);
});
test("diagnóstico completo produce recomendaciones sin contaminar dominio o XP", () => {
  let s = initialState();
  const diagnostics = catalog.diagnostic.map((e, i) => ({
    ...attempt(e, i === 0 ? { value: "0", unit: "" } : correctAnswer(e)),
    mode: "diagnostic" as const,
  }));
  for (const a of diagnostics) s = recordAttempt(s, a);
  s = {
    ...s,
    diagnostic: diagnosticResult(s.attempts, "2026-10-22T15:00:00Z"),
  };
  assert.equal(s.xp, 0);
  assert.equal(Object.keys(s.mastery).length, 0);
  assert.equal(Object.keys(s.reviews).length, 0);
  assert.ok(s.diagnostic!.weakConceptIds.includes("math-fractions"));
  assert.equal(s.diagnostic!.results.math!.total, 6);
  assert.throws(() => diagnosticResult([], new Date().toISOString()));
});
test("repaso determinista: correcto 1→3 días; error a 10 minutos; ayuda a 12 horas", () => {
  const now = new Date("2026-10-22T15:00:00Z");
  const r = schedule(undefined, "c", true, false, now);
  assert.equal(r.intervalDays, 1);
  assert.equal(schedule(r, "c", true, false, now).intervalDays, 3);
  assert.equal(
    new Date(schedule(r, "c", false, false, now).dueAt).getTime() -
      now.getTime(),
    600000,
  );
  assert.equal(schedule(r, "c", true, true, now).intervalDays, 0.5);
});
test("un mismo día no recorre los intervalos; un fallo siempre adelanta revisión", () => {
  let s = initialState();
  for (const e of first.exercises) s = recordAttempt(s, attempt(e));
  assert.equal(s.reviews["math-fractions"]!.step, 0);
  const failed = {
    ...attempt(
      first.exercises[0]!,
      { value: "99", unit: "" },
      "2026-10-22T15:05:00Z",
      "wrong",
    ),
    correct: false,
  };
  s = recordAttempt(s, failed);
  assert.equal(s.reviews["math-fractions"]!.dueAt, "2026-10-22T15:15:00.000Z");
  s = recordAttempt(
    s,
    attempt(first.exercises[0]!, undefined, "2026-10-22T15:06:00Z", "try"),
  );
  assert.equal(s.reviews["math-fractions"]!.dueAt, "2026-10-22T15:15:00.000Z");
});
test("dominio necesita evidencia sin ayuda en varios días, independiente del XP", () => {
  let s = initialState();
  for (const e of first.exercises) s = recordAttempt(s, attempt(e));
  assert.equal(isMastered(s.mastery["math-fractions"]), false);
  s = recordAttempt(
    s,
    attempt(first.exercises[0]!, undefined, "2026-10-23T15:00:00Z", "next-day"),
  );
  assert.equal(isMastered(s.mastery["math-fractions"]), true);
});
test("prerrequisitos se desbloquean por progreso con evidencia suficiente", () => {
  let s = initialState();
  const powers = catalog.lessons.find((l) => l.id === "math-powers-lesson")!;
  assert.deepEqual(missingPrerequisites(s, powers), ["math-fractions"]);
  for (const e of first.exercises) s = recordAttempt(s, attempt(e));
  s = completeLesson(s, first, "s");
  assert.deepEqual(missingPrerequisites(s, powers), []);
});
test("repaso mezcla conceptos y prioriza ejercicios fallados", () => {
  let s = initialState();
  const b = catalog.lessons.find((l) => l.id === "bio-life-lesson")!;
  s = recordAttempt(s, attempt(first.exercises[0]!, { value: "99", unit: "" }));
  s = recordAttempt(s, attempt(b.exercises[0]!, "a"));
  const q = reviewQueue(s, new Date("2026-10-24T15:00:00Z"));
  assert.equal(q[0]!.id, first.exercises[0]!.id);
  assert.notEqual(q[0]!.conceptIds[0], q[1]!.conceptIds[0]);
  assert.equal(new Set(q.map((e) => e.id)).size, q.length);
});
test("adaptación propone explicación alternativa y ejercicio con base relacionada", () => {
  let s = initialState();
  const e = catalog.lessons.find((l) => l.id === "math-factor-lesson")!
    .exercises[0]!;
  s = recordAttempt(s, attempt(e, "b", undefined, "one"));
  s = recordAttempt(s, attempt(e, "b", undefined, "two"));
  const r = remediation(s, e);
  assert.equal(r.needed, true);
  assert.ok(r.prerequisiteIds.includes("math-equations"));
  assert.ok(r.easier?.conceptIds.includes("math-equations"));
  assert.ok(r.explanation);
});
test("rachas respetan días locales e incluyen ayer; desafío comienza el lunes", () => {
  let s = initialState();
  s.studyDays = { "2026-10-20": 1, "2026-10-21": 2 };
  const now = new Date(2026, 9, 22, 12);
  assert.equal(streak(s, now), 2);
  assert.equal(dayKey(now), "2026-10-22");
  assert.equal(weeklyChallenge(s, now).studied, 2);
  assert.equal(streak(s, new Date(2026, 9, 24, 12)), 0);
});
test("modelo enzimático: máximo, simetría, valores conocidos y dominio", () => {
  assert.equal(enzymeActivity(7), 100);
  assert.ok(Math.abs(enzymeActivity(8.5) - 60.653065971263345) < 1e-10);
  assert.equal(enzymeActivity(5.5), enzymeActivity(8.5));
  assert.equal(enzymeCurve().length, 57);
  for (const p of enzymeCurve()) assert.ok(p.y >= 0 && p.y <= 100);
  for (const args of [
    [-1, 7, 1],
    [15, 7, 1],
    [7, 7, 0],
    [NaN, 7, 1],
  ] as const)
    assert.throws(() => enzymeActivity(args[0], args[1], args[2]));
});
test("respaldo válido restaura todo el estado y rechaza corrupción y versiones futuras", () => {
  let s = recordAttempt(initialState(), attempt(first.exercises[0]!));
  assert.deepEqual(parseBackup(JSON.stringify(s)), s);
  for (const change of [
    { version: 99 },
    { xp: -1 },
    { rewardedExerciseIds: ["absent"] },
    { settings: { ...s.settings, dailyGoal: 0 } },
    { reviews: { bad: { dueAt: "bad" } } },
    { labs: [{}] },
    { diagnostic: {} },
  ])
    assert.throws(() => parseBackup(JSON.stringify({ ...s, ...change })));
  assert.throws(() => parseBackup("x".repeat(10_000_001)));
});
test("SQLite: perfil se conserva al cerrar y reabrir archivo real", async () => {
  const dir = mkdtempSync(join(tmpdir(), "bionexo-"));
  const path = join(dir, "test.db");
  let db = new DatabaseSync(path);
  try {
    let repo = new SQLiteRepository(port(db));
    let s = await repo.load();
    assert.equal(s.onboarded, false);
    await repo.update((state) => ({
      ...recordAttempt(state, attempt(first.exercises[0]!)),
      onboarded: true,
      settings: { ...state.settings, theme: "light" },
    }));
    db.close();
    db = new DatabaseSync(path);
    repo = new SQLiteRepository(port(db));
    s = await repo.load();
    assert.equal(s.xp, 10);
    assert.equal(s.settings.theme, "light");
    assert.equal(s.attempts.length, 1);
    assert.equal(s.onboarded, true);
    const json = await repo.export();
    await repo.update(() => initialState());
    await repo.restore(json);
    assert.equal((await repo.load()).xp, 10);
  } finally {
    db.close();
    rmSync(dir, { recursive: true, force: true });
  }
});
test("SQLite: transacciones serializan escrituras concurrentes y revierten un fallo", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    const repo = new SQLiteRepository(port(db));
    await repo.load();
    await Promise.all(
      first.exercises.map((e) =>
        repo.update((s) => recordAttempt(s, attempt(e))),
      ),
    );
    assert.equal((await repo.load()).attempts.length, 6);
    await assert.rejects(repo.update((s) => ({ ...s, xp: -100 })));
    assert.equal((await repo.load()).xp, 60);
    await repo.update((s) => completeLesson(s, first, "s"));
    assert.equal((await repo.load()).xp, 80);
  } finally {
    db.close();
  }
});
test("SQLite: migración desde v1 preserva datos; versión futura se rechaza", async () => {
  const db = new DatabaseSync(":memory:");
  try {
    db.exec(
      "CREATE TABLE user_state(id INTEGER PRIMARY KEY,payload TEXT NOT NULL); PRAGMA user_version=1;",
    );
    const s = initialState();
    s.settings.name = "Jose";
    db.prepare("INSERT INTO user_state VALUES(1,?)").run(JSON.stringify(s));
    const repo = new SQLiteRepository(port(db));
    assert.equal((await repo.load()).settings.name, "Jose");
    assert.equal(
      db.prepare("PRAGMA user_version").get()!.user_version,
      MIGRATIONS.length,
    );
  } finally {
    db.close();
  }
  const future = new DatabaseSync(":memory:");
  try {
    future.exec("PRAGMA user_version=99;");
    const repo = new SQLiteRepository(port(future));
    await assert.rejects(repo.load(), /más reciente/);
  } finally {
    future.close();
  }
});
