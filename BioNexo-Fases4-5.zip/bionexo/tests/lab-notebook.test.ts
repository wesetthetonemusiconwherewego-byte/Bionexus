import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, mkdtempSync, rmSync } from "node:fs";
import { createHash } from "node:crypto";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import {
  addLabPoint,
  createLabSession,
  labComparisons,
  predictActivity,
  saveLabSession,
} from "../src/domain/lab-notebook";
import { enzymeActivity } from "../src/domain/laboratory";
import {
  parseBackup,
  createDocument,
  serializeDocument,
} from "../src/domain/progress-document";
import { initialState, recordAttempt } from "../src/domain/learning";
import { catalog, exerciseById } from "../src/content";
import { correctAnswer, grade } from "../src/domain/answers";
import { SQLiteRepository, type SqlPort } from "../src/storage/repository";
import type { LaboratorySession } from "../src/domain/models";
function record(): LaboratorySession {
  return {
    id: "lab-new-v1",
    at: "2026-10-22T22:00:00.000Z",
    hypothesis: "La segunda actividad aumentará.",
    observation: "Subió dentro del modelo N.",
    points: addLabPoint(addLabPoint([], 6, "neutral"), 7, "neutral"),
  };
}
test("BioLab: incremento de pH, disminución y simetría producen predicciones coherentes", () => {
  assert.equal(predictActivity("neutral", 6, 7).direction, "higher");
  assert.equal(predictActivity("neutral", 7, 8).direction, "lower");
  assert.equal(predictActivity("neutral", 6, 8).direction, "equal");
  const c = predictActivity("acid", 2, 4);
  assert.equal(c.second.activity, 100);
  assert.ok(c.delta > 0);
  assert.equal(Number(enzymeActivity(6).toFixed(2)), 80.07);
  assert.equal(
    Number(predictActivity("neutral", 6, 7).delta.toFixed(2)),
    19.93,
  );
});
test("BioLab: rechaza pH fuera de dominio, modelos inexistentes y condiciones iguales", () => {
  for (const ph of [NaN, Infinity, -1, 15])
    assert.throws(() => predictActivity("neutral", ph, 7));
  assert.throws(() => predictActivity("other", 6, 7));
  assert.throws(() => predictActivity("neutral", 7, 7));
});
test("BioLab: registrar dos veces no crea réplica ni muta el borrador anterior", () => {
  const points = addLabPoint([], 7, "neutral"),
    before = structuredClone(points);
  assert.deepEqual(addLabPoint(points, 7, "neutral"), points);
  assert.deepEqual(points, before);
  assert.equal(addLabPoint(points, 7, "acid").length, 2);
  assert.equal(labComparisons(addLabPoint(points, 7, "acid")).length, 0);
});
test("BioLab: un punto o dos modelos al mismo pH no habilitan comparación controlada", () => {
  const data = record();
  for (const points of [
    data.points.slice(0, 1),
    addLabPoint(addLabPoint([], 7, "neutral"), 7, "acid"),
    [data.points[0]!, data.points[0]!],
  ])
    assert.throws(() => createLabSession({ ...data, points }));
  assert.equal(createLabSession(data).points.length, 2);
});
test("BioLab: criterio nuevo valida coherencia, duplicados, notas y límites sin inventar observaciones", () => {
  const data = record();
  for (const change of [
    { hypothesis: "" },
    { observation: "   " },
    { id: "bad/id" },
    { id: "constructor" },
    { at: "yesterday" },
    { hypothesis: "a".repeat(2001) },
    { points: [data.points[0]!, { ...data.points[1]!, activity: 2 }] },
    { points: [...data.points, data.points[0]!] },
  ])
    assert.throws(() => createLabSession({ ...data, ...change }));
  const copy = createLabSession({
    ...data,
    hypothesis: " " + data.hypothesis + " ",
  });
  assert.equal(copy.hypothesis, data.hypothesis);
  copy.points[0]!.activity = 0;
  assert.notEqual(data.points[0]!.activity, 0);
});
test("BioLab: máximo de condiciones limita registros nuevos y no modifica historia anterior", () => {
  let points: LaboratorySession["points"] = [];
  for (let n = 0; n < 100; n++) points = addLabPoint(points, n / 10, "neutral");
  assert.throws(() => addLabPoint(points, 10, "neutral"));
  assert.equal(addLabPoint(points, 0, "neutral").length, 100);
});
test("BioLab: comparación usa lecturas guardadas, orden estable y modelos separados", () => {
  const points = [
    { ph: 6, activity: 12.345, enzyme: "neutral" },
    { ph: 7, activity: 22.345, enzyme: "neutral" },
    { ph: 8, activity: 1, enzyme: "neutral" },
    { ph: 4, activity: 20, enzyme: "acid" },
    { ph: 5, activity: 15, enzyme: "acid" },
  ];
  const before = structuredClone(points),
    result = labComparisons(points);
  assert.equal(result.length, 2);
  assert.ok(Math.abs(result[0]!.delta - 10) < 1e-12);
  assert.equal(result[1]!.delta, -5);
  assert.deepEqual(points, before);
});
test("BioLab: envío repetido es idempotente, conflicto conserva original y no otorga XP", () => {
  const initial = initialState(),
    data = record(),
    saved = saveLabSession(initial, data);
  assert.equal(saved.xp, initial.xp);
  assert.equal(saved.labs.length, 1);
  assert.equal(
    saveLabSession(saved, { ...data, hypothesis: " " + data.hypothesis + " " }),
    saved,
  );
  assert.throws(() =>
    saveLabSession(saved, { ...data, observation: "Otra observación." }),
  );
  assert.equal(saved.labs[0]!.observation, data.observation);
  assert.equal(initial.labs.length, 0);
});
test("BioLab: fixture 18eb63a conserva una condición no recalculada, XP y checkpoints exactos", () => {
  const raw = readFileSync(
    "tests/fixtures/progress-pre-phase45-v3.json",
    "utf8",
  );
  assert.equal(
    createHash("sha256").update(raw).digest("hex"),
    "cb2ce6187f255f63d761f5371d9701b55186e7c3f66b308f9d483a68f828c8dc",
  );
  const state = parseBackup(raw);
  assert.deepEqual(state, JSON.parse(raw).state);
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(state))),
    state,
  );
  const old = state.labs.find((l) => l.id === "pre-phase45-single")!;
  assert.equal(old.points[0]!.activity, 12.345);
  assert.equal(labComparisons(old.points).length, 0);
  const saved = saveLabSession(state, record());
  assert.deepEqual(saved.labs.slice(0, -1), state.labs);
  assert.deepEqual(saved.lessonSessions, state.lessonSessions);
  assert.equal(saved.xp, state.xp);
});
test("SQLite BioLab: registro previo y comparación nueva sobreviven escritura/reapertura/restauración", async (t) => {
  const root = mkdtempSync(join(tmpdir(), "bionexo-lab-"));
  t.after(() => rmSync(root, { recursive: true, force: true }));
  const path = join(root, "lab.db");
  const open = () => {
    const db = new DatabaseSync(path);
    const port: SqlPort = {
      execAsync: async (q) => {
        db.exec(q);
      },
      runAsync: async (q, ...p) => db.prepare(q).run(...p),
      getFirstAsync: async <T>(q: string, ...p: (string | number | null)[]) =>
        (db.prepare(q).get(...p) as T | undefined) ?? null,
    };
    return { db, repo: new SQLiteRepository(port) };
  };
  let { db, repo } = open();
  await repo.restore(
    readFileSync("tests/fixtures/progress-pre-phase45-v3.json", "utf8"),
  );
  const before = await repo.load();
  await repo.update((s) => saveLabSession(s, record()));
  const exported = await repo.export();
  db.close();
  ({ db, repo } = open());
  const reopened = await repo.load();
  assert.equal(reopened.labs.length, before.labs.length + 1);
  assert.equal(reopened.xp, before.xp);
  assert.equal(
    reopened.labs.find((l) => l.id === "pre-phase45-single")!.points[0]!
      .activity,
    12.345,
  );
  await repo.restore(exported);
  assert.deepEqual(await repo.load(), reopened);
  db.close();
});
test("Proyecto integrado: seis preguntas originales con bases implementadas y unidades coherentes", () => {
  const project = catalog.transferActivities!.find(
    (p) => p.id === "project-dilution-v1",
  )!;
  assert.equal(project.exercises.length, 6);
  assert.equal(new Set(project.exercises.map((e) => e.id)).size, 6);
  for (const e of project.exercises) {
    assert.ok(
      e.prerequisites.every((id) =>
        catalog.concepts.some((c) => c.id === id && c.status === "implemented"),
      ),
    );
    assert.equal(grade(e, correctAnswer(e)), true);
  }
  const concentration = exerciseById["project-dilution-v1-q3"]!;
  assert.equal(
    grade(concentration, { value: "200000", unit: "células/L" }),
    true,
  );
  assert.equal(
    grade(concentration, { value: "200", unit: "células/L" }),
    false,
  );
  assert.equal(
    grade(exerciseById["project-dilution-v1-q2"]!, {
      value: "0,005",
      unit: "L",
    }),
    true,
  );
  assert.equal(grade(exerciseById["project-dilution-v1-q6"]!, "a"), false);
});
test("Proyecto integrado: referencias exportables y XP no repetido al practicar otra vez", () => {
  const project = catalog.transferActivities!.find(
    (p) => p.id === "project-dilution-v1",
  )!;
  let state = initialState();
  for (let round = 0; round < 2; round++)
    for (const e of project.exercises)
      state = recordAttempt(state, {
        id: `project-${round}-${e.id}`,
        exerciseId: e.id,
        conceptIds: e.conceptIds,
        answer: correctAnswer(e),
        correct: true,
        hinted: false,
        at: "2026-10-22T22:00:00.000Z",
        mode: "review",
      });
  assert.equal(state.xp, 60);
  assert.equal(state.attempts.length, 12);
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(state))),
    state,
  );
});
