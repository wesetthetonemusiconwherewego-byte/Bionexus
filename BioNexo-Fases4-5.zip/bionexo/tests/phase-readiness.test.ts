import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  writeFileSync,
  mkdirSync,
  rmSync,
  readFileSync,
  symlinkSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { execFileSync, spawnSync } from "node:child_process";
import {
  NATIVE_CHECKS,
  validateNativeAcceptance,
  applicationFingerprint,
  sha256File,
  applicationFile,
} from "../scripts/readiness/native";
const fingerprint = "a".repeat(64),
  now = new Date("2026-10-22T23:00:00.000Z");
function sandbox(t: { after: (fn: () => void) => void }) {
  const root = mkdtempSync(join(tmpdir(), "bionexo-readiness-"));
  t.after(() => rmSync(root, { recursive: true, force: true }));
  return root;
}
function synthetic(root: string) {
  writeFileSync(
    join(root, "observations.txt"),
    "Synthetic validator fixture. Not Android test results.",
  );
  writeFileSync(
    join(root, "artifact.apk"),
    "Synthetic fixture only, not an APK.",
  );
  const evidence = {
    path: "observations.txt",
    sha256: sha256File(join(root, "observations.txt")),
  };
  return {
    format: "bionexo-native-acceptance",
    version: 1,
    applicationFingerprint: fingerprint,
    commit: "b".repeat(40),
    verifiedAt: "2026-10-22T18:00:00-03:00",
    device: {
      kind: "physical",
      model: "SYNTHETIC UNIT TEST",
      androidVersion: "test",
      apiLevel: 36,
      talkBackVersion: "synthetic",
      fontScales: [1, 1.5, 2],
      orientations: ["portrait", "landscape"],
    },
    build: {
      kind: "apk",
      package: "org.bionexo.learning",
      appVersion: "0.1.0",
      versionCode: 1,
      certificateSha256: "c".repeat(64),
      artifact: {
        path: "artifact.apk",
        sha256: sha256File(join(root, "artifact.apk")),
      },
    },
    checks: NATIVE_CHECKS.map((id) => ({
      id,
      status: "PASS",
      notes: "Synthetic test of completeness only; not a manual device result.",
      evidence: [{ ...evidence }],
    })),
    performance: [100, 1000, 10000].map((attempts) => ({
      attempts,
      method: "Synthetic unit test only",
      startupColdMs: [1, 2, 3],
      startupWarmMs: [1, 2, 3],
      practiceMs: [1, 2, 3],
    })),
  };
}
test("puerta: plantilla PENDING y datos desconocidos nunca habilitan Fase 4", (t) => {
  const root = sandbox(t),
    template = JSON.parse(
      readFileSync("docs/evidence/android-acceptance.template.json", "utf8"),
    );
  assert.equal(
    validateNativeAcceptance(template, fingerprint, root, now).ready,
    false,
  );
  for (const value of [
    null,
    [],
    {},
    "PASS",
    { format: "bionexo-native-acceptance", version: 2 },
  ])
    assert.equal(
      validateNativeAcceptance(value, fingerprint, root, now).ready,
      false,
    );
  assert.deepEqual(
    template.checks.map((c: { id: string }) => c.id),
    NATIVE_CHECKS,
  );
  assert.ok(
    template.checks.every(
      (c: { status: string; evidence: unknown[] }) =>
        c.status === "PENDING" && c.evidence.length === 0,
    ),
  );
});
test("puerta: registro SINTÉTICO completo comprueba integridad sin certificar ejecución humana", (t) => {
  const root = sandbox(t),
    report = synthetic(root),
    before = structuredClone(report);
  const result = validateNativeAcceptance(report, fingerprint, root, now);
  assert.equal(result.ready, true);
  assert.deepEqual(result.issues, []);
  assert.match(result.scope, /no certifica/);
  assert.deepEqual(report, before);
});
test("puerta: huella obsoleta, commit ausente o fecha futura/ilegible impiden aceptar", (t) => {
  const root = sandbox(t),
    report = synthetic(root);
  for (const change of [
    { applicationFingerprint: "d".repeat(64) },
    { commit: "f23fc84" },
    { verifiedAt: "mañana" },
    { verifiedAt: "2026-10-23T12:00:00Z" },
    { verifiedAt: "2026-10-22T20:00:00" },
  ])
    assert.equal(
      validateNativeAcceptance({ ...report, ...change }, fingerprint, root, now)
        .ready,
      false,
    );
});
test("puerta: no basta declarar PASS sin notas, resultados únicos y archivos íntegros", (t) => {
  const root = sandbox(t),
    base = synthetic(root);
  for (const mutate of [
    (r: typeof base) => {
      r.checks[0]!.status = "PENDING";
    },
    (r: typeof base) => {
      r.checks[0]!.notes = "TODO";
    },
    (r: typeof base) => {
      r.checks[0]!.evidence = [];
    },
    (r: typeof base) => {
      r.checks.pop();
    },
    (r: typeof base) => {
      r.checks.push(r.checks[0]!);
    },
    (r: typeof base) => {
      r.checks[0]!.evidence[0]!.sha256 = "0".repeat(64);
    },
  ]) {
    const report = structuredClone(base);
    mutate(report);
    assert.equal(
      validateNativeAcceptance(report, fingerprint, root, now).ready,
      false,
    );
  }
  writeFileSync(join(root, "observations.txt"), "changed");
  assert.equal(
    validateNativeAcceptance(base, fingerprint, root, now).ready,
    false,
  );
});
test("puerta: rechazo de rutas absolutas, traversal, symlink externo y archivos vacíos", (t) => {
  const root = sandbox(t),
    outside = sandbox(t),
    base = synthetic(root);
  writeFileSync(
    join(outside, "outside.txt"),
    "fixture outside evidence folder",
  );
  symlinkSync(join(outside, "outside.txt"), join(root, "escape.txt"));
  writeFileSync(join(root, "empty.txt"), "");
  for (const path of [
    join(outside, "outside.txt"),
    "../outside.txt",
    "escape.txt",
    "empty.txt",
    "missing.txt",
  ]) {
    const report = structuredClone(base);
    report.checks[0]!.evidence[0]!.path = path;
    assert.equal(
      validateNativeAcceptance(report, fingerprint, root, now).ready,
      false,
      path,
    );
  }
});
test("puerta: exige dispositivo, TalkBack, escalas, orientación e identidad de APK", (t) => {
  const root = sandbox(t),
    base = synthetic(root);
  for (const mutate of [
    (r: typeof base) => {
      r.device.talkBackVersion = "";
    },
    (r: typeof base) => {
      r.device.fontScales = [1];
    },
    (r: typeof base) => {
      r.device.orientations = ["portrait"];
    },
    (r: typeof base) => {
      r.device.apiLevel = 0;
    },
    (r: typeof base) => {
      r.build.package = "otro.paquete";
    },
    (r: typeof base) => {
      r.build.certificateSha256 = "";
    },
    (r: typeof base) => {
      r.build.artifact.path = "missing.apk";
    },
  ]) {
    const report = structuredClone(base);
    mutate(report);
    assert.equal(
      validateNativeAcceptance(report, fingerprint, root, now).ready,
      false,
    );
  }
});
test("puerta: rendimiento requiere muestras finitas positivas para los tres historiales", (t) => {
  const root = sandbox(t),
    base = synthetic(root);
  for (const samples of [
    [],
    [1],
    [1, 2, NaN],
    [1, 2, Infinity],
    [0, 1, 2],
    [-1, 1, 2],
  ]) {
    const report = structuredClone(base);
    report.performance[0]!.practiceMs = samples;
    assert.equal(
      validateNativeAcceptance(report, fingerprint, root, now).ready,
      false,
    );
  }
  base.performance.pop();
  assert.equal(
    validateNativeAcceptance(base, fingerprint, root, now).ready,
    false,
  );
});
test("huella: detecta fuentes nuevas/modificadas/borradas y excluye documentación/datos ajenos", (t) => {
  const root = sandbox(t);
  execFileSync("git", ["init", "-q"], { cwd: root });
  mkdirSync(join(root, "app"));
  mkdirSync(join(root, "docs"));
  writeFileSync(join(root, ".gitignore"), "node_modules/\n.env\n");
  writeFileSync(join(root, "app", "index.tsx"), "original");
  execFileSync("git", ["add", "app"], { cwd: root });
  const initial = applicationFingerprint(root);
  writeFileSync(join(root, "docs", "note.md"), "notes");
  writeFileSync(join(root, ".env"), "not read by fingerprint");
  assert.equal(applicationFingerprint(root), initial);
  writeFileSync(join(root, "app", "new.tsx"), "new");
  const extra = applicationFingerprint(root);
  assert.notEqual(extra, initial);
  writeFileSync(join(root, "app", "index.tsx"), "edited");
  const edited = applicationFingerprint(root);
  assert.notEqual(edited, extra);
  rmSync(join(root, "app", "index.tsx"));
  assert.notEqual(applicationFingerprint(root), edited);
  for (const path of [
    "app/_layout.tsx",
    "src/domain/laboratory.ts",
    "assets/icon.png",
    "metro.config.cjs",
    "package-lock.json",
    "app.json",
    "eas.json",
  ])
    assert.equal(applicationFile(path), true, path);
  for (const path of [
    "docs/PROGRESS.md",
    "scripts/check-phase4-readiness.ts",
    ".env",
    "tests/fixtures/profile.json",
    "node_modules/module.js",
  ])
    assert.equal(applicationFile(path), false, path);
});
test("CLI: la plantilla nativa pendiente produce JSON y exit 1, sin tocar configuración ni perfil", () => {
  const paths = [
    "app.json",
    "eas.json",
    "src/content/catalog.json",
    "tests/fixtures/progress-phase2-v3.json",
  ];
  const before = paths.map((p) => sha256File(p));
  const run = spawnSync(
    process.execPath,
    ["--import", "tsx", resolve("scripts/check-phase4-readiness.ts")],
    { encoding: "utf8", timeout: 30000 },
  );
  assert.equal(run.status, 1);
  const report = JSON.parse(run.stdout);
  assert.equal(report.status, "BLOCKED");
  assert.equal(report.ready, false);
  assert.ok(report.issues.length > 0);
  assert.deepEqual(
    paths.map((p) => sha256File(p)),
    before,
  );
});
test("preflight: SDK/JDK ausentes devuelven bloqueo JSON sin tocar dispositivos", (t) => {
  const root = sandbox(t);
  const run = spawnSync(
    process.execPath,
    ["--import", "tsx", resolve("scripts/android-preflight.ts")],
    {
      encoding: "utf8",
      timeout: 30000,
      env: {
        ...process.env,
        JAVA_HOME: join(root, "missing-jdk"),
        ANDROID_HOME: join(root, "missing-sdk"),
        ANDROID_SDK_ROOT: "",
      },
    },
  );
  assert.equal(run.status, 1);
  const report = JSON.parse(run.stdout);
  assert.equal(report.status, "BLOCKED");
  assert.equal(report.javac.available, false);
  assert.equal(report.adb.available, false);
  assert.ok(report.issues.length >= 4);
  assert.match(report.applicationFingerprint, /^[a-f\d]{64}$/);
});
test("preflight: carpetas SDK malformadas no se confunden con herramientas instaladas", (t) => {
  const root = sandbox(t);
  writeFileSync(join(root, "platforms"), "not a directory");
  writeFileSync(join(root, "build-tools"), "not a directory");
  const run = spawnSync(
    process.execPath,
    ["--import", "tsx", resolve("scripts/android-preflight.ts")],
    {
      encoding: "utf8",
      timeout: 30000,
      env: {
        ...process.env,
        JAVA_HOME: join(root, "missing-jdk"),
        ANDROID_HOME: root,
        ANDROID_SDK_ROOT: "",
      },
    },
  );
  assert.equal(run.status, 1);
  const report = JSON.parse(run.stdout);
  assert.equal(report.status, "BLOCKED");
  assert.deepEqual(report.platforms, []);
  assert.deepEqual(report.buildTools, []);
});
test("huella: funciona desde ZIP sin Git y mantiene equivalencia LF/CRLF sin alterar binarios", (t) => {
  const root = sandbox(t);
  mkdirSync(join(root, "src"));
  mkdirSync(join(root, "assets"));
  writeFileSync(join(root, "src", "a.ts"), "const n=1;\nexport {n};\n");
  writeFileSync(join(root, "assets", "a.png"), Buffer.from([1, 13, 10, 2]));
  const initial = applicationFingerprint(root);
  writeFileSync(join(root, "src", "a.ts"), "const n=1;\r\nexport {n};\r\n");
  assert.equal(applicationFingerprint(root), initial);
  writeFileSync(join(root, "assets", "a.png"), Buffer.from([1, 10, 2]));
  assert.notEqual(applicationFingerprint(root), initial);
});
