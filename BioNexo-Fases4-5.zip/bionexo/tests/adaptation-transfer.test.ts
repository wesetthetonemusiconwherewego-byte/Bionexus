import test from "node:test";
import assert from "node:assert/strict";
import {
  catalog,
  allExercises,
  exerciseById,
  conceptById,
  practiceExercises,
} from "../src/content";
import {
  matchingMisconceptions,
  misconceptionEvidence,
  transferEvidence,
} from "../src/domain/misconceptions";
import { correctAnswer, grade } from "../src/domain/answers";
import { initialState, recordAttempt } from "../src/domain/learning";
import { validateCatalog } from "../src/domain/validation";
import {
  createDocument,
  serializeDocument,
  parseBackup,
} from "../src/domain/progress-document";
import type { Answer, UserState } from "../src/domain/models";
const activity = catalog.transferActivities![0]!;
function attempt(
  state: UserState,
  id: string,
  exerciseId: string,
  answer: Answer,
  hinted = false,
  mode: "review" | "diagnostic" = "review",
) {
  return recordAttempt(state, {
    id,
    exerciseId,
    conceptIds: [],
    answer,
    hinted,
    correct: false,
    mode,
    at: "2026-10-22T15:30:00.000Z",
  });
}
test("reglas: distinguen suma/signos en lección y variantes sin etiquetar respuestas correctas", () => {
  assert.equal(
    matchingMisconceptions(exerciseById["math-factor-q3"]!, "b")[0]!.id,
    "factor-sum-v1",
  );
  assert.equal(
    matchingMisconceptions(exerciseById["math-factor-q3"]!, "c")[0]!.id,
    "factor-sign-v1",
  );
  for (const e of practiceExercises) {
    assert.equal(matchingMisconceptions(e, "b")[0]!.id, "variant-sign-v1");
    assert.equal(matchingMisconceptions(e, "c")[0]!.id, "variant-sum-v1");
  }
  for (const e of allExercises)
    assert.deepEqual(matchingMisconceptions(e, correctAnswer(e)), [], e.id);
});
test("reglas: omitir raíces no equivale a elegir una raíz inválida; números desconocidos sin diagnóstico", () => {
  const roots = exerciseById["math-factor-q4"]!;
  assert.equal(matchingMisconceptions(roots, ["a"])[0]!.id, "factor-roots-v1");
  assert.equal(
    matchingMisconceptions(roots, ["c"])[0]!.id,
    "factor-substitution-v1",
  );
  assert.deepEqual(matchingMisconceptions(roots, []), []);
  assert.deepEqual(matchingMisconceptions(roots, ["a", "a"]), []);
  assert.deepEqual(
    matchingMisconceptions(activity.exercises[1]!, {
      value: "999",
      unit: "UR",
    }),
    [],
  );
});
test("evidencia: repetición trazable a intentos, diagnóstico excluido y correcciones posteriores intactas", () => {
  let state = initialState();
  state = attempt(state, "first", "math-factor-q1", "c");
  state = attempt(state, "second", "math-factor-q1", "c");
  state = attempt(
    state,
    "diagnostic",
    "math-factor-q1",
    "c",
    false,
    "diagnostic",
  );
  const before = structuredClone(state);
  const evidence = misconceptionEvidence(state);
  assert.equal(evidence[0]!.count, 2);
  assert.equal(evidence[0]!.rule.id, "factor-square-v1");
  assert.deepEqual(evidence[0]!.rule.prerequisiteIds, ["math-powers"]);
  assert.deepEqual(state, before);
  assert.equal(state.xp, 0);
  state = attempt(state, "corrected", "math-factor-q1", "a", true);
  assert.equal(misconceptionEvidence(state)[0]!.count, 2); // Historical observations, not current diagnoses.
  assert.equal(state.xp, 10);
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(state))),
    state,
  );
});
test("reglas: las bases propuestas pertenecen al grafo previo y tienen fuentes/revisión explícitas", () => {
  const ancestors = (id: string, seen = new Set<string>()): Set<string> => {
    for (const prerequisite of conceptById[id]!.prerequisites) {
      if (seen.has(prerequisite)) continue;
      seen.add(prerequisite);
      ancestors(prerequisite, seen);
    }
    return seen;
  };
  for (const rule of catalog.errorRules!) {
    assert.ok(rule.sourceIds.length);
    assert.equal(rule.reviewStatus, "requires-human-review");
    for (const prerequisite of rule.prerequisiteIds)
      assert.ok(ancestors("math-factor").has(prerequisite));
  }
  assert.deepEqual(validateCatalog(), []);
});
test("validador: reglas con referencias ausentes/selectores correctos y transferencia sin modelo se rechazan", () => {
  for (const mutate of [
    (copy: typeof catalog) => {
      copy.errorRules![0]!.exerciseIds = ["missing"];
    },
    (copy: typeof catalog) => {
      copy.errorRules![0]!.selector = {
        type: "selected-option",
        optionIds: ["a"],
      };
    },
    (copy: typeof catalog) => {
      copy.errorRules![0]!.prerequisiteIds = ["missing"];
    },
    (copy: typeof catalog) => {
      copy.errorRules![0]!.sourceIds = [];
    },
    (copy: typeof catalog) => {
      copy.transferActivities![0]!.model = "";
    },
  ]) {
    const copy = structuredClone(catalog);
    mutate(copy);
    assert.ok(validateCatalog(copy).length);
  }
});
test("transferencia: primeras respuestas, ayuda y prácticas posteriores se separan sin duplicar premios", () => {
  let state = initialState();
  const [roots, value] = activity.exercises;
  assert.equal(transferEvidence(state, activity).answered, 0);
  state = attempt(
    state,
    "initial-root",
    roots!.id,
    correctAnswer(roots!),
    true,
  );
  state = attempt(state, "initial-value", value!.id, {
    value: "999",
    unit: "UR",
  });
  state = attempt(state, "later-root", roots!.id, correctAnswer(roots!));
  state = attempt(state, "later-value", value!.id, correctAnswer(value!));
  const evidence = transferEvidence(state, activity);
  assert.equal(evidence.answered, 2);
  assert.equal(evidence.firstIndependentCorrect, 0);
  assert.equal(evidence.firstHelped, 1);
  assert.equal(evidence.latestCorrect, 2);
  assert.equal(state.xp, 20);
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(state))),
    state,
  );
});
test("modelo supuesto: raíces, dominio temporal, valores negativos de diferencia y unidades coherentes", () => {
  const difference = (u: number) => u * u - 5 * u + 6;
  const roots = activity.exercises[0]!;
  assert.ok(roots.type === "multi");
  const valid = roots.options
    .filter((option) => {
      const time = Number(option.text.match(/\d+/)![0]);
      return time >= 0 && time <= 5 && difference(time) === 0;
    })
    .map((o) => o.id);
  assert.deepEqual(valid, ["a", "b"]);
  assert.equal(grade(roots, valid), true);
  assert.equal(difference(2.5), -0.25);
  assert.equal(difference(4), 2);
  assert.equal(grade(activity.exercises[1]!, { value: "2", unit: "UR" }), true);
  assert.equal(
    grade(activity.exercises[1]!, { value: "2", unit: "min" }),
    false,
  );
  for (const u of [0, 2, 2.5, 3, 4, 5])
    assert.ok(difference(u) === (u - 2) * (u - 3));
  assert.ok(activity.assumptions.some((a) => a.includes("no deriva")));
});
