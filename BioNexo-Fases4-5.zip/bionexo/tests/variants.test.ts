import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { catalog, practiceExercises, exerciseById } from "../src/content";
import {
  generateVariant,
  familyParameters,
  selectVariants,
} from "../src/domain/variants";
import { grade, correctAnswer } from "../src/domain/answers";
import {
  initialState,
  recordAttempt,
  reviewQueue,
} from "../src/domain/learning";
import { validateCatalog } from "../src/domain/validation";
import {
  createDocument,
  serializeDocument,
  parseBackup,
} from "../src/domain/progress-document";
import { SQLiteRepository, type SqlPort } from "../src/storage/repository";
import type { UserState } from "../src/domain/models";
const family = catalog.practiceFamilies![0]!;
const at = "2026-10-22T15:00:00.000Z";
function answer(state: UserState, seed: number, id = `variant-${seed}`) {
  const exercise = generateVariant(family, seed);
  return recordAttempt(state, {
    id,
    exerciseId: exercise.id,
    conceptIds: [],
    answer: correctAnswer(exercise),
    correct: false,
    hinted: false,
    mode: "review",
    at,
  });
}
test("familia v1: identidad/semilla estable, catorce pares distintos, exclusión del reto original", () => {
  const pairs = [
    [2, 4],
    [2, 5],
    [2, 6],
    [2, 7],
    [3, 4],
    [3, 5],
    [3, 6],
    [3, 7],
    [4, 5],
    [4, 6],
    [4, 7],
    [5, 6],
    [5, 7],
    [6, 7],
  ];
  assert.deepEqual(
    familyParameters(family).map(({ p, q }) => [p, q]),
    pairs,
  );
  assert.equal(practiceExercises.length, 14);
  for (let seed = 0; seed < pairs.length; seed++) {
    const variant = generateVariant(family, seed);
    assert.equal(variant.id, `factor-trinomial-v1-s${seed}`);
    assert.equal(variant.variant!.rewardId, "factor-trinomial-v1-s0");
    assert.deepEqual(variant, generateVariant(structuredClone(family), seed));
    assert.deepEqual(
      [variant.variant!.parameters.p, variant.variant!.parameters.q],
      pairs[seed],
    );
  }
  assert.equal(new Set(practiceExercises.map((e) => e.prompt)).size, 14);
});
test("familia: expansión independiente de las opciones verifica única solución para todas las semillas", () => {
  for (const exercise of practiceExercises) {
    assert.ok("options" in exercise);
    const coefficients = exercise.prompt.match(/x² \+ (\d+)x \+ (\d+)/)!;
    const expected = [1, Number(coefficients[1]), Number(coefficients[2])];
    for (const option of exercise.options) {
      const factors = [...option.text.matchAll(/x ([+−]) (\d+)/g)].map(
        (m) => Number(m[2]) * (m[1] === "−" ? -1 : 1),
      );
      const [p, q] = factors as [number, number];
      const valid =
        JSON.stringify([1, p + q, p * q]) === JSON.stringify(expected);
      assert.equal(grade(exercise, option.id), valid);
    }
    assert.equal(grade(exercise, correctAnswer(exercise)), true);
  }
});
test("familia: semillas fuera de dominio o definición v1 modificada se rechazan", () => {
  for (const seed of [-1, 14, NaN, Infinity, 0.5, Number.MAX_SAFE_INTEGER])
    assert.throws(() => generateVariant(family, seed));
  assert.throws(() =>
    generateVariant({ ...family, parameterValues: [1, 2, 3] }, 0),
  );
  const broken = structuredClone(catalog);
  broken.practiceFamilies![0]!.parameterValues.push(8);
  assert.match(
    validateCatalog(broken).join(" "),
    /Familia parametrizada inválida/,
  );
});
test("familia: todas las variantes comparten un premio; duplicación e importación no crean XP", () => {
  let state = initialState();
  for (let seed = 13; seed >= 0; seed--) state = answer(state, seed);
  assert.equal(state.xp, 10);
  assert.deepEqual(state.rewardedExerciseIds, ["factor-trinomial-v1-s0"]);
  assert.equal(state.attempts.length, 14);
  assert.equal(
    state.attempts.every((a) => a.correct),
    true,
  );
  assert.deepEqual(answer(state, 0), state);
  const restored = parseBackup(serializeDocument(createDocument(state)));
  assert.deepEqual(restored, state);
  assert.equal(answer(restored, 0, "another-session").xp, 10);
});
test("familia: la evaluación usa el registro instalado y rechaza respuestas/IDs ajenos", () => {
  const exercise = practiceExercises[0]!;
  const wrong = recordAttempt(initialState(), {
    id: "wrong-variant",
    exerciseId: exercise.id,
    conceptIds: ["bio-life"],
    answer: "b",
    correct: true,
    hinted: false,
    mode: "review",
    at,
  });
  assert.equal(wrong.attempts[0]!.correct, false);
  assert.deepEqual(wrong.attempts[0]!.conceptIds, ["math-factor"]);
  assert.equal(wrong.xp, 0);
  assert.throws(() =>
    recordAttempt(initialState(), {
      ...wrong.attempts[0]!,
      id: "bad-variant",
      exerciseId: "factor-trinomial-v1-s99",
    }),
  );
});
test("selección: primero inéditas, luego menos recientes; mismo estado produce la misma ronda", () => {
  const empty = initialState();
  assert.deepEqual(
    selectVariants(family, empty).map((e) => e.variant!.seed),
    [0, 1, 2],
  );
  let state = answer(empty, 0);
  state = answer(state, 1);
  assert.deepEqual(
    selectVariants(family, state).map((e) => e.variant!.seed),
    [2, 3, 4],
  );
  assert.deepEqual(
    selectVariants(family, state),
    selectVariants(family, structuredClone(state)),
  );
  assert.deepEqual(selectVariants(family, state, 0), []);
  assert.throws(() => selectVariants(family, state, -1));
});
test("repasos: una variante fallada pendiente aparece con su identidad y explicación originales", () => {
  const exercise = practiceExercises[7]!;
  const state = recordAttempt(initialState(), {
    id: "variant-error",
    exerciseId: exercise.id,
    conceptIds: [],
    answer: "c",
    correct: false,
    hinted: false,
    mode: "review",
    at,
  });
  const queue = reviewQueue(state, new Date("2026-10-22T15:10:00.000Z"));
  assert.equal(queue[0]!.id, exercise.id);
  assert.deepEqual(exerciseById[queue[0]!.id], exercise);
});
test("SQLite: perfil anterior conserva sus valores y las variantes sobreviven reapertura/restauración", async () => {
  const directory = mkdtempSync(join(tmpdir(), "bionexo-family-"));
  let db: DatabaseSync | undefined;
  const open = () => {
    db = new DatabaseSync(join(directory, "state.db"));
    const port: SqlPort = {
      execAsync: async (sql) => db!.exec(sql),
      runAsync: async (sql, ...args) => db!.prepare(sql).run(...args),
      getFirstAsync: async <T>(
        sql: string,
        ...args: (string | number | null)[]
      ) => (db!.prepare(sql).get(...args) as T | undefined) ?? null,
    };
    return new SQLiteRepository(port);
  };
  try {
    let repository = open();
    const raw = readFileSync("tests/fixtures/progress-phase1-v3.json", "utf8");
    await repository.restore(raw);
    assert.deepEqual(await repository.load(), JSON.parse(raw).state);
    const changed = await repository.update((s) => answer(s, 9));
    const exported = await repository.export();
    db!.close();
    repository = open();
    assert.deepEqual(await repository.load(), changed);
    await repository.restore(exported);
    assert.deepEqual(await repository.load(), changed);
    assert.deepEqual(
      changed.attempts.slice(0, -1),
      JSON.parse(raw).state.attempts,
    );
    assert.equal(changed.xp, JSON.parse(raw).state.xp + 10);
  } finally {
    db?.close();
    rmSync(directory, { recursive: true, force: true });
  }
});
