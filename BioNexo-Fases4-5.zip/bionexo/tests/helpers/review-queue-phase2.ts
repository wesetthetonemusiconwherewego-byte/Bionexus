/* Frozen selector from 6d5e92d, retained as a regression oracle. */
import { allExercises } from "../../src/content";
import type { UserState, Exercise } from "../../src/domain/models";
export function phase2ReviewQueue(
  state: UserState,
  now = new Date(),
  limit = 8,
): Exercise[] {
  const due = Object.values(state.reviews)
    .filter((r) => new Date(r.dueAt) <= now)
    .sort((a, b) => a.dueAt.localeCompare(b.dueAt));
  const pools = due.map((r) => {
    const candidates = allExercises.filter(
      (e) =>
        !e.id.startsWith("diagnostic-") && e.conceptIds.includes(r.conceptId),
    );
    return candidates.sort((a, b) => {
      const lastA = [...state.attempts]
        .reverse()
        .find((x) => x.exerciseId === a.id);
      const lastB = [...state.attempts]
        .reverse()
        .find((x) => x.exerciseId === b.id);
      return (
        Number(lastA?.correct ?? true) - Number(lastB?.correct ?? true) ||
        (lastA?.at ?? "").localeCompare(lastB?.at ?? "")
      );
    });
  });
  const output: Exercise[] = [];
  // Round-robin interleaves concepts instead of exhausting one skill first.
  for (
    let round = 0;
    output.length < limit && pools.some((p) => p[round]);
    round++
  )
    for (const pool of pools) {
      const item = pool[round];
      if (
        item &&
        output.length < limit &&
        !output.some((e) => e.id === item.id)
      )
        output.push(item);
    }
  return output;
}
