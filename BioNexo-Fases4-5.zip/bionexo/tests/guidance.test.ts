import test from "node:test";
import assert from "node:assert/strict";
import { exerciseById } from "../src/content";
import {
  initialState,
  recordAttempt,
  recommendations,
  reviewQueue,
} from "../src/domain/learning";
import {
  reviewGuidance,
  lessonGuidance,
  scheduleSource,
} from "../src/domain/guidance";
import { correctAnswer } from "../src/domain/answers";
import type { UserState } from "../src/domain/models";
const at = "2026-10-22T12:00:00.000Z";
const exercise = exerciseById["math-fractions-q1"]!;
function add(
  state: UserState,
  id: string,
  correct: boolean,
  hinted = false,
  when = at,
) {
  return recordAttempt(state, {
    id,
    exerciseId: exercise.id,
    conceptIds: [],
    answer: correct ? correctAnswer(exercise) : { value: "99", unit: "" },
    correct: !correct,
    hinted,
    at: when,
    mode: "review",
  });
}
test("razones: mantienen exactamente orden del repaso, reproducibilidad e inmutabilidad", () => {
  const state = add(initialState(), "error", false);
  const before = structuredClone(state),
    now = new Date("2026-10-22T12:11:00Z");
  const suggestions = reviewGuidance(state, now);
  assert.deepEqual(
    suggestions.map((s) => s.exercise.id),
    reviewQueue(state, now).map((e) => e.id),
  );
  assert.deepEqual(
    suggestions,
    reviewGuidance(structuredClone(state), new Date(now)),
  );
  assert.ok(
    suggestions.every(
      (s) => s.kind === "error" && s.sourceAttemptId === "error",
    ),
  );
  assert.equal(suggestions[0]!.intervalDays, 10 / 1440);
  assert.equal(suggestions[0]!.lapses, 1);
  assert.deepEqual(state, before);
});
test("razones: una corrección en el mismo día no se presenta como origen de una fecha anterior", () => {
  let state = add(initialState(), "wrong", false);
  state = add(state, "later-correct", true, false, "2026-10-22T12:05:00.000Z");
  const suggestion = reviewGuidance(
    state,
    new Date("2026-10-22T12:10:00Z"),
  )[0]!;
  assert.equal(suggestion.sourceAttemptId, "wrong");
  assert.equal(suggestion.kind, "error");
  assert.equal(suggestion.latestAttempt!.id, "later-correct");
  assert.equal(suggestion.latestAttempt!.correct, true);
  assert.equal(suggestion.dueAt, "2026-10-22T12:10:00.000Z");
});
test("razones: acierto con ayuda explica doce horas y respeta la frontera exacta del vencimiento", () => {
  const state = add(initialState(), "helped", true, true);
  assert.deepEqual(
    reviewGuidance(state, new Date("2026-10-22T23:59:59.999Z")),
    [],
  );
  const suggestion = reviewGuidance(
    state,
    new Date("2026-10-23T00:00:00Z"),
  )[0]!;
  assert.equal(suggestion.kind, "helped");
  assert.equal(suggestion.sourceAttemptId, "helped");
  assert.equal(suggestion.intervalDays, 0.5);
  assert.deepEqual(state.mastery["math-fractions"]!.evidenceDays, []);
});
test("razones: avances espaciados conservan pasos y evento responsable sin recalcular el calendario guardado", () => {
  let state = add(initialState(), "day-one", true);
  state = add(state, "day-two", true, false, "2026-10-23T12:00:00.000Z");
  const stored = structuredClone(state.reviews);
  const suggestion = reviewGuidance(
    state,
    new Date("2026-10-26T12:00:00Z"),
  )[0]!;
  assert.equal(suggestion.kind, "spaced");
  assert.equal(suggestion.intervalDays, 3);
  assert.equal(suggestion.sourceAttemptId, "day-two");
  assert.deepEqual(state.reviews, stored);
});
test("razones: calendario importado o historial incompleto se explican sin inventar una causa", () => {
  const state = add(initialState(), "one", true);
  state.reviews["math-fractions"] = {
    ...state.reviews["math-fractions"]!,
    dueAt: "2026-10-22T14:00:00Z",
    intervalDays: 30,
    step: 4,
  };
  const before = structuredClone(state);
  const suggestion = reviewGuidance(
    state,
    new Date("2026-10-23T12:00:00Z"),
  )[0]!;
  assert.equal(suggestion.kind, "stored-calendar");
  assert.equal(suggestion.sourceAttemptId, undefined);
  assert.deepEqual(state, before);
  state.attempts = [];
  assert.equal(
    scheduleSource(state, state.reviews["math-fractions"]!),
    undefined,
  );
});
test("razones: diagnóstico no origina ni desplaza el calendario de aprendizaje", () => {
  let state = add(initialState(), "learning", false);
  state = recordAttempt(state, {
    id: "diagnostic",
    exerciseId: "diagnostic-1",
    conceptIds: [],
    answer: { value: "99", unit: "" },
    correct: false,
    hinted: false,
    at: "2026-10-22T13:00:00.000Z",
    mode: "diagnostic",
  });
  assert.equal(
    reviewGuidance(state, new Date("2026-10-22T14:00:00Z"))[0]!.sourceAttemptId,
    "learning",
  );
});
test("zona local: medianoche en Santiago avanza una vez por día y cambio de zona no reescribe la fecha", () => {
  const previous = process.env.TZ;
  try {
    process.env.TZ = "America/Santiago";
    let state = add(
      initialState(),
      "before-midnight",
      true,
      false,
      "2026-10-23T02:55:00.000Z",
    );
    state = add(
      state,
      "after-midnight",
      true,
      false,
      "2026-10-23T03:05:00.000Z",
    );
    assert.equal(state.reviews["math-fractions"]!.step, 1);
    const stored = structuredClone(state.reviews);
    assert.equal(
      scheduleSource(state, state.reviews["math-fractions"]!)!.id,
      "after-midnight",
    );
    process.env.TZ = "UTC";
    assert.equal(
      reviewGuidance(state, new Date("2026-10-30T00:00:00Z"))[0]!.kind,
      "stored-calendar",
    );
    assert.deepEqual(state.reviews, stored);
  } finally {
    if (previous === undefined) delete process.env.TZ;
    else process.env.TZ = previous;
  }
});
function mastered(state: UserState, id: string) {
  return {
    ...state,
    mastery: {
      ...state.mastery,
      [id]: {
        conceptId: id,
        score: 0.8,
        correct: 5,
        wrong: 0,
        streak: 5,
        evidenceDays: ["2026-10-20", "2026-10-21"],
      },
    },
  };
}
test("lecciones: la razón respeta selección existente, prerrequisitos y diagnóstico como sondeo", () => {
  const state = mastered(initialState(), "math-equations");
  state.diagnostic = {
    completedAt: at,
    results: { math: { correct: 5, total: 6 } },
    weakConceptIds: ["math-factor"],
  };
  const guidance = lessonGuidance(state);
  assert.deepEqual(
    guidance.map((s) => s.lesson.id),
    recommendations(state).map((l) => l.id),
  );
  assert.equal(guidance[0]!.lesson.id, "math-factor-lesson");
  assert.equal(guidance[0]!.kind, "diagnostic");
  assert.deepEqual(guidance[0]!.prerequisiteIds, ["math-equations"]);
});
test("lecciones: una base recomendada puede explicar un patrón activo sin alterar la prioridad", () => {
  let state = mastered(initialState(), "math-fractions");
  state.completedLessonIds = ["math-fractions-lesson"];
  state.xp = 20;
  state = recordAttempt(state, {
    id: "square-error",
    exerciseId: "math-factor-q1",
    conceptIds: [],
    answer: "c",
    correct: false,
    hinted: false,
    mode: "review",
    at,
  });
  const suggestion = lessonGuidance(state)[0]!;
  assert.equal(suggestion.lesson.id, "math-powers-lesson");
  assert.equal(suggestion.relatedPattern!.attemptId, "square-error");
  assert.ok(suggestion.supportsConceptIds.includes("math-factor"));
  state = recordAttempt(state, {
    id: "square-correct",
    exerciseId: "math-factor-q1",
    conceptIds: [],
    answer: "a",
    correct: true,
    hinted: true,
    mode: "review",
    at,
  });
  assert.equal(lessonGuidance(state)[0]!.relatedPattern, undefined);
});
test("lecciones: sin pendientes disponibles ofrece exploración y nunca afirma que es una base nueva", () => {
  const state = initialState();
  state.completedLessonIds = recommendations(state).map((l) => l.id);
  // All other lessons remain locked because no evidence was acquired.
  assert.equal(recommendations(state).length, 0);
  assert.equal(lessonGuidance(state)[0]!.kind, "free-exploration");
  assert.deepEqual(
    lessonGuidance(state),
    lessonGuidance(structuredClone(state)),
  );
});
