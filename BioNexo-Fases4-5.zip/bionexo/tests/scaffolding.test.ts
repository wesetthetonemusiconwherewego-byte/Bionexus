import test from "node:test";
import assert from "node:assert/strict";
import { catalog, lessonById } from "../src/content";
import { misconceptionFeedback } from "../src/domain/feedback";
import { initialState } from "../src/domain/learning";
import {
  beginLessonSession,
  saveLessonCheckpoint,
  submitLessonAnswer,
} from "../src/domain/sessions";
import {
  parseBackup,
  serializeDocument,
  createDocument,
} from "../src/domain/progress-document";
import { validateCatalog } from "../src/domain/validation";

const lesson = lessonById["math-factor-lesson"]!;
const at = "2026-10-22T14:00:00.000Z";
test("ayudas: todos los retos del piloto tienen tres pistas distintas y ejemplo alternativo en pasos", () => {
  for (const exercise of lesson.exercises) {
    assert.equal(exercise.hints.length, 3);
    assert.equal(new Set(exercise.hints).size, 3);
    assert.ok(exercise.hintExample!.title.startsWith("Ejemplo alternativo"));
    assert.ok(exercise.hintExample!.steps.length >= 3);
    assert.ok(exercise.sourceIds.includes("factoring-ref"));
    if ("options" in exercise) {
      const correct = Array.isArray(exercise.correct)
        ? exercise.correct
        : [exercise.correct];
      const wrong = exercise.options.filter((o) => !correct.includes(o.id));
      assert.deepEqual(
        Object.keys(exercise.explanation.distractors!).sort(),
        wrong.map((o) => o.id).sort(),
      );
    }
  }
});
test("feedback: explica el distractor elegido y mantiene fallback para omisiones y respuestas numéricas", () => {
  const square = lesson.exercises[0]!;
  assert.deepEqual(misconceptionFeedback(square, "b"), [
    square.explanation.distractors!.b,
  ]);
  assert.deepEqual(misconceptionFeedback(square, "c"), [
    square.explanation.distractors!.c,
  ]);
  assert.notDeepEqual(
    misconceptionFeedback(square, "b"),
    misconceptionFeedback(square, "c"),
  );
  const roots = lesson.exercises[3]!;
  assert.equal(misconceptionFeedback(roots, ["c", "d"]).length, 2);
  assert.deepEqual(misconceptionFeedback(roots, ["a"]), [
    roots.explanation.misconception,
  ]);
  assert.deepEqual(
    misconceptionFeedback(lesson.exercises[7]!, { value: "9", unit: "cm²" }),
    [lesson.exercises[7]!.explanation.misconception],
  );
});
test("validación: rechaza distractores inexistentes/correctos, explicaciones vacías y ejemplos inválidos", () => {
  for (const damage of [
    (e: (typeof lesson.exercises)[number]) => {
      e.explanation.distractors = { a: "La correcta no es un distractor" };
    },
    (e: (typeof lesson.exercises)[number]) => {
      e.explanation.distractors = { z: "No existe" };
    },
    (e: (typeof lesson.exercises)[number]) => {
      e.explanation.distractors = { b: " " };
    },
    (e: (typeof lesson.exercises)[number]) => {
      e.hintExample!.steps = [""];
    },
    (e: (typeof lesson.exercises)[number]) => {
      e.hints = [" "];
    },
  ]) {
    const copy = structuredClone(catalog);
    damage(copy.lessons.find((l) => l.id === lesson.id)!.exercises[0]!);
    assert.ok(validateCatalog(copy).length > 0);
  }
});
test("ayuda persistida: no puede declararse independiente, no duplica XP y conserva repaso corto", () => {
  const exercise = lesson.exercises[0]!;
  let state = beginLessonSession(initialState(), lesson, "help-pilot", at);
  const card = state.lessonSessions![lesson.id]!.card;
  state = saveLessonCheckpoint(
    state,
    lesson,
    "help-pilot",
    0,
    { ...card, answer: "a", hintCount: 3 },
    at,
  );
  state = parseBackup(serializeDocument(createDocument(state)));
  assert.throws(() =>
    submitLessonAnswer(
      state,
      lesson,
      "help-pilot",
      0,
      exercise,
      "a",
      false,
      "0",
      at,
    ),
  );
  state = submitLessonAnswer(
    state,
    lesson,
    "help-pilot",
    0,
    exercise,
    "a",
    true,
    "0",
    at,
  );
  assert.equal(state.mastery["math-factor"]!.score, 0.08);
  assert.deepEqual(state.mastery["math-factor"]!.evidenceDays, []);
  assert.equal(state.reviews["math-factor"]!.dueAt, "2026-10-23T02:00:00.000Z");
  assert.equal(state.xp, 10);
  const again = submitLessonAnswer(
    state,
    lesson,
    "help-pilot",
    0,
    exercise,
    "a",
    true,
    "0",
    at,
  );
  assert.deepEqual(again, state);
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(state))),
    state,
  );
});
test("distractores algebraicos: las expansiones erróneas difieren de la identidad solicitada", () => {
  for (const x of [-2, 1, 4]) {
    assert.equal((x - 9) * (x + 1), x * x - 8 * x - 9);
    assert.equal((x - 3) ** 2, x * x - 6 * x + 9);
    assert.equal((x + 1) * (x + 6), x * x + 7 * x + 6);
    assert.equal((x - 2) * (x - 3), x * x - 5 * x + 6);
  }
  assert.equal(9 ** 2 - 9, 72);
  assert.equal(0 ** 2 - 9, -9);
});
