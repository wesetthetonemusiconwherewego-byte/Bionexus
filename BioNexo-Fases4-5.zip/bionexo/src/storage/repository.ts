import type { UserState } from "../domain/models";
import { initialState } from "../domain/learning";
import {
  createDocument,
  readDocument,
  serializeDocument,
  ProgressDataError,
  rescueDocument,
  type RecoveryCopy,
} from "../domain/progress-document";
export interface SqlPort {
  execAsync(sql: string): Promise<unknown>;
  runAsync(
    sql: string,
    ...params: (string | number | null)[]
  ): Promise<unknown>;
  getFirstAsync<T>(
    sql: string,
    ...params: (string | number | null)[]
  ): Promise<T | null>;
}
export interface ProgressRepository {
  load(): Promise<UserState>;
  update(change: (state: UserState) => UserState): Promise<UserState>;
  restore(json: string): Promise<UserState>;
  export(): Promise<string>;
  exportRescue(): Promise<string>;
}
export const MIGRATIONS = [
  "CREATE TABLE IF NOT EXISTS user_state (id INTEGER PRIMARY KEY CHECK (id = 1), payload TEXT NOT NULL);",
  "CREATE TABLE IF NOT EXISTS repository_metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL); INSERT OR IGNORE INTO repository_metadata(key,value) VALUES ('format','bionexo-v1');",
  "CREATE TABLE IF NOT EXISTS profile_recovery (id INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, reason TEXT NOT NULL, payload TEXT NOT NULL);",
];
export class SQLiteRepository implements ProgressRepository {
  private tail: Promise<unknown> = Promise.resolve();
  private ready: Promise<void>;
  constructor(private db: SqlPort) {
    this.ready = this.migrate();
  }
  private async hasTable(name: string) {
    return !!(await this.db.getFirstAsync<{ name: string }>(
      "SELECT name FROM sqlite_master WHERE type='table' AND name=?;",
      name,
    ));
  }
  private async raw() {
    if (!(await this.hasTable("user_state"))) return null;
    return (
      (
        await this.db.getFirstAsync<{ payload: string }>(
          "SELECT payload FROM user_state WHERE id=1;",
        )
      )?.payload ?? null
    );
  }
  private async copy(payload: string, reason: string) {
    await this.db.runAsync(
      "INSERT INTO profile_recovery(at,reason,payload) VALUES (?,?,?);",
      new Date().toISOString(),
      reason,
      payload,
    );
  }
  private async migrate() {
    const version =
      (
        await this.db.getFirstAsync<{ user_version: number }>(
          "PRAGMA user_version;",
        )
      )?.user_version ?? 0;
    if (version > MIGRATIONS.length)
      throw new Error(
        "La base de datos pertenece a una versión más reciente de BioNexo. Solo se permite exportar un rescate.",
      );
    const anyTable = await this.db.getFirstAsync<{ name: string }>(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' LIMIT 1;",
    );
    const fresh = version === 0 && !anyTable;
    if (!fresh && !(await this.hasTable("user_state")))
      throw new Error(
        "La base existente no contiene la tabla de perfil. No se inicializó ni modificó.",
      );
    await this.db.execAsync("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;");
    await this.db.execAsync("BEGIN IMMEDIATE;");
    try {
      for (let i = version; i < MIGRATIONS.length; i++) {
        await this.db.execAsync(MIGRATIONS[i]!);
        await this.db.execAsync(`PRAGMA user_version=${i + 1};`);
      }
      const raw = await this.raw();
      if (fresh) {
        await this.db.runAsync(
          "INSERT INTO user_state(id,payload) VALUES (1,?);",
          serializeDocument(createDocument(initialState())),
        );
      } else if (raw !== null) {
        let decoded: ReturnType<typeof readDocument> | null = null;
        try {
          decoded = readDocument(raw);
        } catch (e) {
          if (!(e instanceof ProgressDataError)) throw e;
        }
        // Corrupt/future documents remain byte-for-byte intact. load reports the
        // error, while the ready repository can still provide read-only rescue.
        if (decoded?.legacy) {
          await this.copy(
            raw,
            decoded.sourceVersion === 2
              ? "migrate-document-v2"
              : "migrate-legacy-v1",
          );
          await this.db.runAsync(
            "UPDATE user_state SET payload=? WHERE id=1;",
            serializeDocument(decoded.document),
          );
        }
      }
      await this.db.execAsync("COMMIT;");
    } catch (e) {
      await this.db.execAsync("ROLLBACK;");
      throw e;
    }
  }
  private enqueue<T>(work: () => Promise<T>): Promise<T> {
    const op = this.tail.then(work);
    this.tail = op.catch(() => undefined);
    return op;
  }
  private async document() {
    const raw = await this.raw();
    if (raw === null)
      throw new Error(
        "No se encontró el perfil en la base existente. No se creó uno nuevo. Puedes restaurar un respaldo.",
      );
    return readDocument(raw).document;
  }
  async load() {
    await this.ready;
    await this.tail;
    return (await this.document()).state;
  }
  update(change: (state: UserState) => UserState): Promise<UserState> {
    return this.enqueue(async () => {
      await this.ready;
      await this.db.execAsync("BEGIN IMMEDIATE;");
      try {
        const current = await this.document();
        const next = createDocument(change(current.state), current.references);
        await this.db.runAsync(
          "UPDATE user_state SET payload=? WHERE id=1;",
          serializeDocument(next),
        );
        await this.db.execAsync("COMMIT;");
        return next.state;
      } catch (e) {
        await this.db.execAsync("ROLLBACK;");
        throw e;
      }
    });
  }
  async restore(json: string): Promise<UserState> {
    const imported = readDocument(json).document;
    return this.enqueue(async () => {
      await this.ready;
      await this.db.execAsync("BEGIN IMMEDIATE;");
      try {
        const raw = await this.raw();
        if (raw !== null) {
          try {
            readDocument(raw);
          } catch (e) {
            if (e instanceof ProgressDataError && e.code === "future") throw e;
          }
          await this.copy(raw, "before-restore");
        }
        await this.db.runAsync(
          "INSERT INTO user_state(id,payload) VALUES (1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload;",
          serializeDocument(imported),
        );
        await this.db.execAsync("COMMIT;");
        return imported.state;
      } catch (e) {
        await this.db.execAsync("ROLLBACK;");
        throw e;
      }
    });
  }
  async export() {
    await this.ready;
    await this.tail;
    return JSON.stringify(await this.document(), null, 2);
  }
  async exportRescue() {
    await this.ready.catch(() => undefined);
    await this.tail;
    const raw = await this.raw();
    const copies: RecoveryCopy[] = [];
    try {
      if (await this.hasTable("profile_recovery")) {
        // SqlPort deliberately stays minimal; one JSON aggregate avoids coupling
        // recovery to a driver-specific getAllAsync signature.
        const result = await this.db.getFirstAsync<{ items: string }>(
          "SELECT json_group_array(json_object('at',at,'reason',reason,'payload',payload)) AS items FROM (SELECT at,reason,payload FROM profile_recovery ORDER BY id);",
        );
        if (result?.items)
          copies.push(...(JSON.parse(result.items) as RecoveryCopy[]));
      }
    } catch {
      return rescueDocument(raw, copies, {
        copiesError:
          "No se pudieron leer copias de esta base. Se conserva el perfil original accesible.",
      });
    }
    return rescueDocument(raw, copies);
  }
}
