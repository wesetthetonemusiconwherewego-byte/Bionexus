// TypeScript resolution target; Metro chooses open.native.ts or open.web.ts.
export { openRepository } from "./open.native";
