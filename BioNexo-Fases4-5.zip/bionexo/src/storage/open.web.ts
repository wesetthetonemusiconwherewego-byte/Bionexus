import { initialState } from "../domain/learning";
import type { UserState } from "../domain/models";
import {
  createDocument,
  readDocument,
  serializeDocument,
  recoveryCopy,
  rescueDocument,
  ProgressDataError,
  type RecoveryCopy,
} from "../domain/progress-document";
import type { ProgressRepository } from "./repository";
export const WEB_PROFILE_KEY = "bionexo-state-v1";
export const WEB_RECOVERY_KEY = "bionexo-recovery-v1";
/** Web preview adapter. Native Android/iOS always use SQLite. */
export async function openRepository(): Promise<ProgressRepository> {
  let tail: Promise<unknown> = Promise.resolve();
  const readCopies = (): RecoveryCopy[] => {
    const json = localStorage.getItem(WEB_RECOVERY_KEY);
    if (json === null) return [];
    const raw: unknown = JSON.parse(json);
    if (
      !Array.isArray(raw) ||
      raw.some(
        (x) =>
          typeof x !== "object" ||
          x === null ||
          typeof x.at !== "string" ||
          typeof x.reason !== "string" ||
          typeof x.payload !== "string",
      )
    )
      throw new Error(
        "La colección de rescate tiene datos inválidos. No se sobrescribió.",
      );
    return raw as RecoveryCopy[];
  };
  const copy = (payload: string, reason: string) => {
    const copies = readCopies();
    if (
      (reason === "migrate-legacy-v1" || reason === "migrate-document-v2") &&
      copies.some(
        (entry) => entry.reason === reason && entry.payload === payload,
      )
    )
      return;
    localStorage.setItem(
      WEB_RECOVERY_KEY,
      JSON.stringify([...copies, recoveryCopy(payload, reason)]),
    );
  };
  const ready = Promise.resolve().then(() => {
    const current = localStorage.getItem(WEB_PROFILE_KEY);
    if (current === null)
      localStorage.setItem(
        WEB_PROFILE_KEY,
        serializeDocument(createDocument(initialState())),
      );
    else {
      let decoded: ReturnType<typeof readDocument> | null = null;
      try {
        decoded = readDocument(current);
      } catch (e) {
        if (!(e instanceof ProgressDataError)) throw e;
      }
      if (decoded?.legacy) {
        copy(
          current,
          decoded.sourceVersion === 2
            ? "migrate-document-v2"
            : "migrate-legacy-v1",
        );
        localStorage.setItem(
          WEB_PROFILE_KEY,
          serializeDocument(decoded.document),
        );
      }
    }
  });
  const read = () => {
    const json = localStorage.getItem(WEB_PROFILE_KEY);
    if (json === null)
      throw new Error("El perfil ya no está disponible. No se creó uno nuevo.");
    return readDocument(json).document;
  };
  const enqueue = <T>(work: () => T): Promise<T> => {
    const op = tail.then(work);
    tail = op.catch(() => undefined);
    return op;
  };
  return {
    load: async () => {
      await ready;
      await tail;
      return read().state;
    },
    update: async (change) => {
      await ready;
      return enqueue(() => {
        const previous = read();
        const doc = createDocument(change(previous.state), previous.references);
        localStorage.setItem(WEB_PROFILE_KEY, serializeDocument(doc));
        return doc.state;
      });
    },
    restore: async (json) => {
      const doc = readDocument(json).document;
      await ready;
      return enqueue(() => {
        const raw = localStorage.getItem(WEB_PROFILE_KEY);
        if (raw !== null) {
          try {
            readDocument(raw);
          } catch (e) {
            if (e instanceof ProgressDataError && e.code === "future") throw e;
          }
          copy(raw, "before-restore");
        }
        localStorage.setItem(WEB_PROFILE_KEY, serializeDocument(doc));
        return doc.state;
      });
    },
    export: async () => {
      await ready;
      await tail;
      return JSON.stringify(read(), null, 2);
    },
    exportRescue: async () => {
      await ready.catch(() => undefined);
      await tail;
      const raw = localStorage.getItem(WEB_PROFILE_KEY);
      try {
        return rescueDocument(raw, readCopies());
      } catch {
        return rescueDocument(raw, [], {
          copiesError:
            "No se pudo interpretar la colección de copias. Su texto original se incluye intacto.",
          unreadableCopies: localStorage.getItem(WEB_RECOVERY_KEY) ?? "",
        });
      }
    },
  };
}
