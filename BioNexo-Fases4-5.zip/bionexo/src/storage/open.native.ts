import { openDatabaseAsync } from "expo-sqlite";
import { SQLiteRepository } from "./repository";
export async function openRepository() {
  return new SQLiteRepository(await openDatabaseAsync("bionexo.db"));
}
