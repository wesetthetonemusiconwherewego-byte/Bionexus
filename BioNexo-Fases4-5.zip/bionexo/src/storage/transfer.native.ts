import { File, Paths } from "expo-file-system";
import * as Sharing from "expo-sharing";
import * as DocumentPicker from "expo-document-picker";
export async function exportProgress(
  json: string,
  filename = "bionexo-respaldo.json",
) {
  const file = new File(Paths.cache, filename);
  file.write(json);
  if (!(await Sharing.isAvailableAsync()))
    throw new Error(
      "No hay una aplicación disponible para compartir el respaldo.",
    );
  await Sharing.shareAsync(file.uri, {
    mimeType: "application/json",
    dialogTitle: "Guardar respaldo BioNexo",
  });
}
export async function importProgress() {
  const result = await DocumentPicker.getDocumentAsync({
    type: ["application/json", "text/plain"],
    copyToCacheDirectory: true,
  });
  if (result.canceled) return null;
  const asset = result.assets[0];
  if (!asset) return null;
  if ((asset.size ?? 0) > 10_000_000)
    throw new Error("El respaldo supera 10 MB.");
  return new File(asset.uri).text();
}
