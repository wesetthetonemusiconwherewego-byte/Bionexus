import data from "./catalog.json";
import type {
  Concept,
  Course,
  Exercise,
  Lesson,
  Source,
  Subject,
  Unit,
  PracticeFamily,
  MisconceptionRule,
  TransferActivity,
} from "../domain/models";
import { buildPracticeBank } from "../domain/variants";
// Runtime validation runs in tests and at app startup; JSON is the offline content boundary.
export const catalog = data as unknown as {
  subjects: Subject[];
  courses: Course[];
  units: Unit[];
  concepts: Concept[];
  lessons: Lesson[];
  sources: Source[];
  diagnostic: Exercise[];
  practiceFamilies?: PracticeFamily[];
  errorRules?: MisconceptionRule[];
  transferActivities?: TransferActivity[];
};
// Validation reports broken definitions; keep recovery UI importable on a bad catalog.
export const practiceExercises = (() => {
  try {
    return buildPracticeBank(catalog.practiceFamilies ?? []);
  } catch {
    return [];
  }
})();
export const allExercises = [
  ...catalog.lessons.flatMap((l) => l.exercises),
  ...catalog.diagnostic,
  ...practiceExercises,
  ...(catalog.transferActivities ?? []).flatMap(
    (activity) => activity.exercises,
  ),
];
export const conceptById = Object.fromEntries(
  catalog.concepts.map((c) => [c.id, c]),
);
export const lessonById = Object.fromEntries(
  catalog.lessons.map((l) => [l.id, l]),
);
export const exerciseById = Object.fromEntries(
  allExercises.map((e) => [e.id, e]),
);
