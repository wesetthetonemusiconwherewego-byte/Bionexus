# Registro histórico de identidades

`v0.1.0-contracts.json` se capturó del catálogo del commit `41566ea` antes de implementar P0-03. Contiene IDs, conceptos y formas de respuesta, no soluciones científicas. Permite validar perfiles anteriores aunque el catálogo vigente cambie o retire elementos.

Es un registro congelado: no se regenera al ejecutar `scripts/build_content.py`. No lo actualices con contenido futuro ni reutilices un ID con otra forma de respuesta. Los documentos de progreso nuevos llevan referencias propias; las migraciones futuras deben conservar sus definiciones históricas y resultados declarados.

El registro no es una firma criptográfica ni acredita que un resultado académico sea auténtico. La política de lectura conserva datos históricos sin recalificarlos; la evaluación de nuevos intentos pertenece al motor actual.
