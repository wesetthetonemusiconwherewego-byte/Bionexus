import type { Answer, Exercise, UserState } from "./models";
import { catalog, allExercises } from "../content";
import legacyReferences from "../content/history/v0.1.0-contracts.json";

export const MAX_PROGRESS_BYTES = 10_000_000;
export interface ExerciseShape {
  id: string;
  type: Exercise["type"];
  conceptIds: string[];
  options?: string[];
  units?: string[];
  items?: string[];
  left?: string[];
  right?: string[];
}
export interface CatalogReferences {
  version: 1;
  subjectIds: string[];
  conceptIds: string[];
  lessonIds: string[];
  exercises: ExerciseShape[];
}
export interface ProgressDocument {
  format: "bionexo-progress";
  version: 3;
  evaluationPolicy: "recorded-outcome-v1";
  references: CatalogReferences;
  state: UserState;
}
export interface RecoveryCopy {
  at: string;
  reason: string;
  payload: string;
}
export interface RescueDocument {
  format: "bionexo-recovery";
  version: 1;
  at: string;
  current: { present: boolean; payload: string | null };
  copies: RecoveryCopy[];
  copiesError?: string;
  unreadableCopies?: string;
}
export class ProgressDataError extends Error {
  constructor(
    message: string,
    readonly code: "invalid" | "future" = "invalid",
  ) {
    super(message);
    this.name = "ProgressDataError";
  }
}
function invalid(): never {
  throw new ProgressDataError(
    "El respaldo tiene datos inválidos. No se modificó el progreso.",
  );
}
function object(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}
function finite(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}
function count(v: unknown): v is number {
  return finite(v) && Number.isSafeInteger(v) && v >= 0;
}
function text(v: unknown, max = 2000): v is string {
  return typeof v === "string" && v.length <= max;
}
function id(v: unknown): v is string {
  return (
    typeof v === "string" &&
    !Object.prototype.hasOwnProperty.call(Object.prototype, v) &&
    v !== "prototype" &&
    /^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,511}$/.test(v)
  );
}
function strings(v: unknown, allowEmpty = false): v is string[] {
  return (
    Array.isArray(v) &&
    new Set(v).size === v.length &&
    v.every((x) => (allowEmpty && x === "") || id(x))
  );
}
function date(v: unknown): v is string {
  return (
    typeof v === "string" &&
    /^\d{4}-\d{2}-\d{2}T/.test(v) &&
    Number.isFinite(Date.parse(v))
  );
}
function day(v: unknown): v is string {
  return (
    typeof v === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(v) &&
    Number.isFinite(Date.parse(v + "T00:00:00Z")) &&
    new Date(v + "T00:00:00Z").toISOString().slice(0, 10) === v
  );
}
export function utf8ByteLength(input: string): number {
  let n = 0;
  for (let i = 0; i < input.length; i++) {
    const c = input.charCodeAt(i);
    if (c < 0x80) n++;
    else if (c < 0x800) n += 2;
    else if (
      c >= 0xd800 &&
      c <= 0xdbff &&
      i + 1 < input.length &&
      input.charCodeAt(i + 1) >= 0xdc00 &&
      input.charCodeAt(i + 1) <= 0xdfff
    ) {
      n += 4;
      i++;
    } else n += 3;
  }
  return n;
}
function parseJson(input: string): unknown {
  if (
    input.length > MAX_PROGRESS_BYTES ||
    utf8ByteLength(input) > MAX_PROGRESS_BYTES
  )
    throw new ProgressDataError("El respaldo supera 10 MB.");
  try {
    return JSON.parse(input);
  } catch {
    return invalid();
  }
}
function assertReferences(raw: unknown): asserts raw is CatalogReferences {
  if (object(raw) && typeof raw.version === "number" && raw.version > 1)
    throw new ProgressDataError(
      "Versión de referencias no compatible.",
      "future",
    );
  if (
    !object(raw) ||
    raw.version !== 1 ||
    !strings(raw.subjectIds) ||
    !raw.subjectIds.length ||
    !strings(raw.conceptIds) ||
    !strings(raw.lessonIds) ||
    !Array.isArray(raw.exercises)
  )
    invalid();
  const concepts = new Set(raw.conceptIds),
    seen = new Set<string>();
  for (const e of raw.exercises) {
    if (
      !object(e) ||
      !id(e.id) ||
      seen.has(e.id) ||
      !strings(e.conceptIds) ||
      !e.conceptIds.length ||
      e.conceptIds.some((c) => !concepts.has(c))
    )
      invalid();
    seen.add(e.id);
    switch (e.type) {
      case "choice":
      case "multi":
      case "chart":
      case "diagram":
      case "case":
      case "prediction":
        if (!strings(e.options) || e.options.length < 2) invalid();
        break;
      case "numeric":
        if (
          !Array.isArray(e.units) ||
          !e.units.length ||
          new Set(e.units).size !== e.units.length ||
          e.units.some((u) => !text(u, 64))
        )
          invalid();
        break;
      case "order":
        if (!strings(e.items) || !e.items.length) invalid();
        break;
      case "match":
        if (
          !strings(e.left) ||
          !strings(e.right) ||
          !e.left.length ||
          e.left.length !== e.right.length
        )
          invalid();
        break;
      case "text":
        break;
      default:
        invalid();
    }
  }
}
function answerMatches(e: ExerciseShape, answer: unknown): answer is Answer {
  const subset = (v: unknown, allowed: string[]) =>
    strings(v) && v.every((x) => allowed.includes(x));
  switch (e.type) {
    case "numeric":
      return (
        object(answer) &&
        text(answer.value, 2000) &&
        typeof answer.unit === "string" &&
        !!e.units?.includes(answer.unit) &&
        Object.keys(answer).length === 2
      );
    case "text":
      return text(answer);
    case "multi":
      return subset(answer, e.options!);
    case "order":
      return subset(answer, e.items!);
    case "match":
      return (
        object(answer) &&
        Object.entries(answer).every(
          ([k, v]) =>
            e.left!.includes(k) &&
            typeof v === "string" &&
            e.right!.includes(v),
        )
      );
    default:
      return typeof answer === "string" && !!e.options?.includes(answer);
  }
}
function assertState(
  raw: unknown,
  refs: CatalogReferences,
): asserts raw is UserState {
  if (!object(raw)) invalid();
  if (raw.version !== 1)
    throw new ProgressDataError(
      "Versión de perfil no compatible.",
      typeof raw.version === "number" && raw.version > 1 ? "future" : "invalid",
    );
  if (
    !date(raw.createdAt) ||
    typeof raw.onboarded !== "boolean" ||
    !object(raw.settings)
  )
    invalid();
  const s = raw.settings;
  if (
    !text(s.name, 60) ||
    !["dark", "light", "system"].includes(String(s.theme)) ||
    typeof s.reduceMotion !== "boolean" ||
    !count(s.dailyGoal) ||
    s.dailyGoal < 1 ||
    s.dailyGoal > 50
  )
    invalid();
  const exercises = new Map(refs.exercises.map((e) => [e.id, e])),
    concepts = new Set(refs.conceptIds),
    lessons = new Set(refs.lessonIds);
  if (
    !strings(raw.completedLessonIds) ||
    raw.completedLessonIds.some((x) => !lessons.has(x)) ||
    !strings(raw.rewardedExerciseIds) ||
    raw.rewardedExerciseIds.some(
      (x) => !exercises.has(x) || x.startsWith("diagnostic-"),
    )
  )
    invalid();
  if (
    !count(raw.xp) ||
    raw.xp !==
      raw.rewardedExerciseIds.length * 10 + raw.completedLessonIds.length * 20
  )
    invalid();
  if (
    !Array.isArray(raw.attempts) ||
    !Array.isArray(raw.labs) ||
    !object(raw.mastery) ||
    !object(raw.reviews) ||
    !object(raw.studyDays)
  )
    invalid();
  const seen = new Set<string>();
  for (const a of raw.attempts) {
    if (
      !object(a) ||
      !id(a.id) ||
      seen.has(a.id) ||
      !id(a.exerciseId) ||
      !date(a.at) ||
      typeof a.correct !== "boolean" ||
      typeof a.hinted !== "boolean" ||
      !["lesson", "review", "diagnostic"].includes(String(a.mode)) ||
      !strings(a.conceptIds)
    )
      invalid();
    const e = exercises.get(a.exerciseId);
    if (
      !e ||
      e.conceptIds.join("|") !== a.conceptIds.join("|") ||
      !answerMatches(e, a.answer)
    )
      invalid();
    // Deliberately preserve recorded correctness. The current scientific grader
    // evaluates NEW attempts, never the meaning of a historical outcome.
    seen.add(a.id);
  }
  for (const [cid, m] of Object.entries(raw.mastery))
    if (
      !object(m) ||
      !concepts.has(cid) ||
      m.conceptId !== cid ||
      !finite(m.score) ||
      m.score < 0 ||
      m.score > 1 ||
      ![m.correct, m.wrong, m.streak].every(count) ||
      !Array.isArray(m.evidenceDays) ||
      new Set(m.evidenceDays).size !== m.evidenceDays.length ||
      !m.evidenceDays.every(day)
    )
      invalid();
  for (const [cid, r] of Object.entries(raw.reviews))
    if (
      !object(r) ||
      !concepts.has(cid) ||
      r.conceptId !== cid ||
      !date(r.dueAt) ||
      !finite(r.intervalDays) ||
      r.intervalDays <= 0 ||
      !count(r.step) ||
      r.step > 5 ||
      !count(r.lapses)
    )
      invalid();
  for (const [d, n] of Object.entries(raw.studyDays))
    if (!day(d) || !count(n) || n < 1) invalid();
  const labIds = new Set<string>();
  for (const l of raw.labs) {
    if (
      !object(l) ||
      !id(l.id) ||
      labIds.has(l.id) ||
      !date(l.at) ||
      !text(l.hypothesis) ||
      !text(l.observation) ||
      !Array.isArray(l.points) ||
      !l.points.length ||
      l.points.some(
        (p) =>
          !object(p) ||
          !finite(p.ph) ||
          p.ph < 0 ||
          p.ph > 14 ||
          !finite(p.activity) ||
          p.activity < 0 ||
          p.activity > 100 ||
          !["neutral", "acid"].includes(String(p.enzyme)),
      )
    )
      invalid();
    labIds.add(l.id);
  }
  if (raw.diagnostic !== null) {
    const d = raw.diagnostic;
    if (
      !object(d) ||
      !date(d.completedAt) ||
      !strings(d.weakConceptIds) ||
      d.weakConceptIds.some((c) => !concepts.has(c)) ||
      !object(d.results)
    )
      invalid();
    for (const [subject, r] of Object.entries(d.results))
      if (
        !refs.subjectIds.includes(subject) ||
        !object(r) ||
        !count(r.correct) ||
        !count(r.total) ||
        r.total < 1 ||
        r.correct > r.total
      )
        invalid();
  }
}
function assertSessions(raw: UserState, refs: CatalogReferences) {
  if (raw.lessonSessions === undefined) return;
  if (!object(raw.lessonSessions)) invalid();
  const lessons = new Set(refs.lessonIds),
    exercises = new Map(refs.exercises.map((e) => [e.id, e]));
  const attempts = new Map(raw.attempts.map((a) => [a.id, a]));
  const seen = new Set<string>();
  for (const [lessonId, session] of Object.entries(raw.lessonSessions)) {
    if (
      object(session) &&
      typeof session.version === "number" &&
      session.version > 1
    )
      throw new ProgressDataError(
        "La sesión requiere una versión más reciente de BioNexo.",
        "future",
      );
    if (
      !object(session) ||
      session.version !== 1 ||
      !id(lessonId) ||
      !lessons.has(lessonId) ||
      session.lessonId !== lessonId ||
      !id(session.id) ||
      seen.has(session.id) ||
      !text(session.contentSignature, 100) ||
      !/^content-v1-[0-9a-f]{8}-[0-9a-f]{8}-\d+$/.test(
        session.contentSignature,
      ) ||
      !strings(session.exerciseIds) ||
      !session.exerciseIds.length ||
      session.exerciseIds.some((x) => !exercises.has(x)) ||
      !count(session.index) ||
      session.index >= session.exerciseIds.length ||
      !date(session.startedAt) ||
      !date(session.updatedAt)
    )
      invalid();
    seen.add(session.id);
    const checkCard = (
      value: unknown,
      exerciseId: string,
      tokenPrefix: string,
      child: boolean,
    ) => {
      const e = exercises.get(exerciseId);
      if (
        !e ||
        !object(value) ||
        !count(value.hintCount) ||
        !count(value.attemptNo) ||
        typeof value.bridgeDone !== "boolean" ||
        !(value.submittedAttemptId === null || id(value.submittedAttemptId))
      )
        invalid();
      const emptyChoice =
        value.submittedAttemptId === null &&
        value.answer === "" &&
        !["numeric", "match", "order", "multi"].includes(e.type);
      if (!emptyChoice && !answerMatches(e, value.answer)) invalid();
      if (value.submittedAttemptId !== null) {
        const expected = `${session.id}:${exerciseId}:${tokenPrefix}${value.attemptNo}`;
        const attempt = attempts.get(value.submittedAttemptId);
        if (
          !attempt ||
          attempt.id !== expected ||
          attempt.exerciseId !== exerciseId ||
          attempt.mode !== "lesson" ||
          JSON.stringify(attempt.answer) !== JSON.stringify(value.answer) ||
          attempt.hinted !== (value.hintCount > 0 || value.attemptNo > 0)
        )
          invalid();
      }
      if (child && (value.bridge !== null || value.bridgeDone)) invalid();
      return value;
    };
    const card = checkCard(
      session.card,
      session.exerciseIds[session.index]!,
      "",
      false,
    );
    if (card.bridge !== null) {
      if (
        !object(card.bridge) ||
        !id(card.bridge.exerciseId) ||
        card.bridgeDone ||
        card.submittedAttemptId === null ||
        attempts.get(String(card.submittedAttemptId))?.correct !== false
      )
        invalid();
      checkCard(
        card.bridge.card,
        card.bridge.exerciseId,
        `bridge-${card.attemptNo}-`,
        true,
      );
    }
    for (const exerciseId of session.exerciseIds.slice(0, session.index))
      if (
        !raw.attempts.some(
          (a) =>
            a.exerciseId === exerciseId &&
            a.mode === "lesson" &&
            a.id.startsWith(session.id + ":"),
        )
      )
        invalid();
  }
}
function shape(e: Exercise): ExerciseShape {
  return {
    id: e.id,
    type: e.type,
    conceptIds: [...e.conceptIds],
    ...("options" in e ? { options: e.options.map((o) => o.id) } : {}),
    ...(e.type === "numeric" ? { units: Object.keys(e.acceptedUnits) } : {}),
    ...(e.type === "order" ? { items: e.items.map((o) => o.id) } : {}),
    ...(e.type === "match"
      ? { left: e.left.map((o) => o.id), right: e.right.map((o) => o.id) }
      : {}),
  };
}
export function createDocument(
  state: UserState,
  previous: CatalogReferences = JSON.parse(
    JSON.stringify(legacyReferences),
  ) as CatalogReferences,
): ProgressDocument {
  const union = (a: string[], b: string[]) => [...new Set([...a, ...b])];
  const current = allExercises.map(shape);
  const refs: CatalogReferences = {
    version: 1,
    subjectIds: union(
      previous.subjectIds,
      catalog.subjects.map((s) => s.id),
    ),
    conceptIds: union(
      previous.conceptIds,
      catalog.concepts.map((c) => c.id),
    ),
    lessonIds: union(
      previous.lessonIds,
      catalog.lessons.map((l) => l.id),
    ),
    exercises: [
      ...new Map(
        [...current, ...previous.exercises].map((e) => [e.id, e]),
      ).values(),
    ],
  };
  assertReferences(refs);
  assertState(state, refs);
  assertSessions(state, refs);
  return {
    format: "bionexo-progress",
    version: 3,
    evaluationPolicy: "recorded-outcome-v1",
    references: refs,
    state,
  };
}
export function readDocument(input: string): {
  document: ProgressDocument;
  legacy: boolean;
  sourceVersion: 1 | 2 | 3;
} {
  const raw = parseJson(input);
  if (object(raw) && raw.format === "bionexo-progress") {
    if (raw.version !== 2 && raw.version !== 3)
      throw new ProgressDataError(
        "Versión de respaldo no compatible.",
        typeof raw.version === "number" && raw.version > 3
          ? "future"
          : "invalid",
      );
    if (raw.evaluationPolicy !== "recorded-outcome-v1")
      throw new ProgressDataError(
        "La política histórica requiere una versión compatible de BioNexo.",
        "future",
      );
    assertReferences(raw.references);
    assertState(raw.state, raw.references);
    if (raw.version === 2 && raw.state.lessonSessions !== undefined) invalid();
    assertSessions(raw.state, raw.references);
    return {
      document: { ...raw, version: 3 } as unknown as ProgressDocument,
      legacy: raw.version === 2,
      sourceVersion: raw.version,
    };
  }
  if (object(raw) && "format" in raw) invalid();
  const historical: unknown = JSON.parse(JSON.stringify(legacyReferences));
  assertReferences(historical);
  assertState(raw, historical);
  if (raw.lessonSessions !== undefined) invalid();
  return {
    document: {
      format: "bionexo-progress",
      version: 3,
      evaluationPolicy: "recorded-outcome-v1",
      references: historical,
      state: raw,
    },
    legacy: true,
    sourceVersion: 1,
  };
}
export function parseBackup(input: string): UserState {
  return readDocument(input).document.state;
}
export function serializeDocument(document: ProgressDocument): string {
  const json = JSON.stringify(document);
  readDocument(json);
  return json;
}
export function recoveryCopy(payload: string, reason: string): RecoveryCopy {
  return { at: new Date().toISOString(), reason, payload };
}
export function rescueDocument(
  current: string | null,
  copies: RecoveryCopy[],
  extra: Pick<RescueDocument, "copiesError" | "unreadableCopies"> = {},
): string {
  return JSON.stringify(
    {
      format: "bionexo-recovery",
      version: 1,
      at: new Date().toISOString(),
      current: { present: current !== null, payload: current },
      copies,
      ...extra,
    } satisfies RescueDocument,
    null,
    2,
  );
}

/** Recovery exports are evidence containers, never silently treated as profiles. */
export function latestValidRecoveryCopy(
  input: string,
): { json: string; state: UserState } | null {
  const raw: unknown = JSON.parse(input);
  if (
    !object(raw) ||
    raw.format !== "bionexo-recovery" ||
    raw.version !== 1 ||
    !Array.isArray(raw.copies)
  )
    throw new ProgressDataError("El archivo no es un rescate compatible.");
  for (let i = raw.copies.length - 1; i >= 0; i--) {
    const copy = raw.copies[i];
    if (!object(copy) || typeof copy.payload !== "string") continue;
    try {
      return { json: copy.payload, state: parseBackup(copy.payload) };
    } catch {
      /* Keep the damaged copy in the export; try an older valid one. */
    }
  }
  return null;
}
