import type { Answer, Exercise } from "./models";

/** Authored explanations, not inferred diagnoses or a second grading engine. */
export function misconceptionFeedback(
  exercise: Exercise,
  answer: Answer,
): string[] {
  const chosen =
    typeof answer === "string" ? [answer] : Array.isArray(answer) ? answer : [];
  const messages = chosen.flatMap((id) => {
    const message = exercise.explanation.distractors?.[id];
    return message ? [message] : [];
  });
  return messages.length
    ? [...new Set(messages)]
    : [exercise.explanation.misconception];
}
