import { catalog, conceptById, exerciseById } from "../content";
import type {
  Attempt,
  Exercise,
  Lesson,
  ReviewSchedule,
  UserState,
} from "./models";
import { dayKey, recommendations, reviewQueue, schedule } from "./learning";
import {
  matchingMisconceptions,
  misconceptionEvidence,
} from "./misconceptions";

export interface ReviewSuggestion {
  exercise: Exercise;
  conceptId: string;
  dueAt: string;
  intervalDays: number;
  lapses: number;
  kind: "error" | "helped" | "spaced" | "stored-calendar";
  sourceAttemptId?: string;
  sourceAt?: string;
  latestAttempt?: Pick<Attempt, "id" | "at" | "correct" | "hinted">;
}
/** Replay recorded outcomes only to explain provenance; never writes/regrades. */
export function scheduleSource(
  state: UserState,
  stored: ReviewSchedule,
): Attempt | undefined {
  let reconstructed: ReviewSchedule | undefined,
    latest: Attempt | undefined,
    source: Attempt | undefined;
  for (const attempt of state.attempts) {
    if (
      attempt.mode === "diagnostic" ||
      !attempt.conceptIds.includes(stored.conceptId)
    )
      continue;
    const sameDay =
      latest && dayKey(new Date(latest.at)) === dayKey(new Date(attempt.at));
    if (!attempt.correct || !sameDay || !reconstructed) {
      reconstructed = schedule(
        reconstructed,
        stored.conceptId,
        attempt.correct,
        attempt.hinted,
        new Date(attempt.at),
      );
      source = attempt;
    }
    latest = attempt;
  }
  return reconstructed &&
    Date.parse(reconstructed.dueAt) === Date.parse(stored.dueAt) &&
    reconstructed.step === stored.step &&
    reconstructed.intervalDays === stored.intervalDays &&
    reconstructed.lapses === stored.lapses
    ? source
    : undefined;
}
export function reviewGuidance(
  state: UserState,
  now: Date,
  limit = 8,
): ReviewSuggestion[] {
  const due = Object.values(state.reviews)
    .filter((r) => new Date(r.dueAt) <= now)
    .sort((a, b) => a.dueAt.localeCompare(b.dueAt));
  const sources = new Map(
    due.map((r) => [r.conceptId, scheduleSource(state, r)]),
  );
  return reviewQueue(state, now, limit).map((exercise) => {
    const stored = due.find((r) => exercise.conceptIds.includes(r.conceptId))!;
    const source = sources.get(stored.conceptId);
    const latest = [...state.attempts]
      .reverse()
      .find(
        (a) =>
          a.mode !== "diagnostic" && a.conceptIds.includes(stored.conceptId),
      );
    return {
      exercise,
      conceptId: stored.conceptId,
      dueAt: stored.dueAt,
      intervalDays: stored.intervalDays,
      lapses: stored.lapses,
      kind: !source
        ? "stored-calendar"
        : !source.correct
          ? "error"
          : source.hinted
            ? "helped"
            : "spaced",
      ...(source ? { sourceAttemptId: source.id, sourceAt: source.at } : {}),
      ...(latest
        ? {
            latestAttempt: {
              id: latest.id,
              at: latest.at,
              correct: latest.correct,
              hinted: latest.hinted,
            },
          }
        : {}),
    };
  });
}
export interface LessonSuggestion {
  lesson: Lesson;
  kind:
    | "diagnostic"
    | "initial-goal"
    | "math-base"
    | "next-available"
    | "free-exploration";
  prerequisiteIds: string[];
  supportsConceptIds: string[];
  relatedPattern?: { title: string; attemptId: string };
}
function ancestors(id: string, seen = new Set<string>()): Set<string> {
  for (const prerequisite of conceptById[id]?.prerequisites ?? []) {
    if (seen.has(prerequisite)) continue;
    seen.add(prerequisite);
    ancestors(prerequisite, seen);
  }
  return seen;
}
export function lessonGuidance(state: UserState): LessonSuggestion[] {
  const selected = recommendations(state);
  const lessons = selected.length ? selected : [catalog.lessons[0]!];
  const weak = state.diagnostic?.weakConceptIds ?? [
    "math-factor",
    "math-equations",
  ];
  const patterns = misconceptionEvidence(state);
  return lessons.map((lesson) => {
    const direct = lesson.conceptIds.some((id) => weak.includes(id));
    const relevant = patterns.find(({ rule, exerciseId }) => {
      if (!rule.prerequisiteIds.some((id) => lesson.conceptIds.includes(id)))
        return false;
      const latest = [...state.attempts]
        .reverse()
        .find((a) => a.exerciseId === exerciseId && a.mode !== "diagnostic");
      const exercise = exerciseById[exerciseId];
      return (
        latest &&
        !latest.correct &&
        exercise &&
        matchingMisconceptions(exercise, latest.answer).some(
          (r) => r.id === rule.id,
        )
      );
    });
    const latestPatternAttempt =
      relevant &&
      [...state.attempts]
        .reverse()
        .find(
          (a) =>
            a.exerciseId === relevant.exerciseId && a.mode !== "diagnostic",
        );
    return {
      lesson,
      kind: !selected.length
        ? "free-exploration"
        : direct
          ? state.diagnostic
            ? "diagnostic"
            : "initial-goal"
          : lesson.subjectId === "math"
            ? "math-base"
            : "next-available",
      prerequisiteIds: lesson.prerequisites,
      supportsConceptIds: weak.filter((id) =>
        lesson.conceptIds.some((base) => ancestors(id).has(base)),
      ),
      ...(relevant && latestPatternAttempt
        ? {
            relatedPattern: {
              title: relevant.rule.title,
              attemptId: latestPatternAttempt.id,
            },
          }
        : {}),
    };
  });
}
