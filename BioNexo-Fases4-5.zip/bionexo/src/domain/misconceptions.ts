import { catalog, exerciseById } from "../content";
import type {
  Answer,
  Exercise,
  MisconceptionRule,
  TransferActivity,
  UserState,
} from "./models";

/** Explicit matches only; never a diagnosis of ability or a regrade of history. */
export function matchingMisconceptions(
  exercise: Exercise,
  answer: Answer,
): MisconceptionRule[] {
  return (catalog.errorRules ?? []).filter((rule) => {
    if (
      !rule.exerciseIds.includes(exercise.id) &&
      !(exercise.variant && rule.familyIds.includes(exercise.variant.familyId))
    )
      return false;
    if (rule.selector.type === "proper-subset")
      return (
        exercise.type === "multi" &&
        Array.isArray(answer) &&
        answer.length > 0 &&
        new Set(answer).size === answer.length &&
        answer.length < exercise.correct.length &&
        answer.every((id) => exercise.correct.includes(id))
      );
    const selected =
      typeof answer === "string"
        ? [answer]
        : Array.isArray(answer)
          ? answer
          : [];
    const options = rule.selector.optionIds;
    return selected.some((id) => options.includes(id));
  });
}
export function misconceptionEvidence(state: UserState) {
  const observations = new Map<
    string,
    {
      rule: MisconceptionRule;
      count: number;
      lastAt: string;
      exerciseId: string;
    }
  >();
  for (const attempt of state.attempts) {
    if (attempt.correct || attempt.mode === "diagnostic") continue;
    const exercise = exerciseById[attempt.exerciseId];
    if (!exercise) continue;
    for (const rule of matchingMisconceptions(exercise, attempt.answer)) {
      observations.set(rule.id, {
        rule,
        count: (observations.get(rule.id)?.count ?? 0) + 1,
        lastAt: attempt.at,
        exerciseId: exercise.id,
      });
    }
  }
  return [...observations.values()].sort(
    (a, b) =>
      b.count - a.count ||
      b.lastAt.localeCompare(a.lastAt) ||
      a.rule.id.localeCompare(b.rule.id),
  );
}
export function transferEvidence(state: UserState, activity: TransferActivity) {
  const results = activity.exercises.map((exercise) => {
    const attempts = state.attempts.filter(
      (a) => a.exerciseId === exercise.id && a.mode !== "diagnostic",
    );
    return {
      exerciseId: exercise.id,
      first: attempts[0],
      latest: attempts.at(-1),
    };
  });
  return {
    total: results.length,
    answered: results.filter((r) => r.first).length,
    firstIndependentCorrect: results.filter(
      (r) => r.first?.correct && !r.first.hinted,
    ).length,
    firstHelped: results.filter((r) => r.first?.hinted).length,
    latestCorrect: results.filter((r) => r.latest?.correct).length,
    results,
  };
}
