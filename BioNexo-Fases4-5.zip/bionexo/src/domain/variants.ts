import type { Exercise, PracticeFamily, UserState } from "./models";

/** v1 identities/math are frozen. Change version/IDs when extending this domain. */
export function familyParameters(family: PracticeFamily) {
  if (
    family.id !== "factor-trinomial" ||
    family.version !== 1 ||
    family.conceptId !== "math-factor" ||
    JSON.stringify(family.parameterValues) !== "[2,3,4,5,6,7]"
  )
    throw new Error("Familia o parámetros no compatibles con el generador v1.");
  return family.parameterValues.flatMap((p, i) =>
    family.parameterValues
      .slice(i + 1)
      .filter((q) => p !== 2 || q !== 3)
      .map((q) => ({ p, q })),
  );
}
export function generateVariant(
  family: PracticeFamily,
  seed: number,
): Exercise {
  const parameters = familyParameters(family);
  const pair =
    Number.isSafeInteger(seed) && seed >= 0 ? parameters[seed] : undefined;
  if (!pair) throw new Error("La semilla no pertenece al banco incluido.");
  const { p, q } = pair,
    b = p + q,
    c = p * q;
  return {
    id: `factor-trinomial-v1-s${seed}`,
    subjectId: "math",
    level: 1,
    conceptIds: [family.conceptId],
    prerequisites: family.prerequisites,
    sourceIds: family.sourceIds,
    type: "choice",
    prompt: `Factoriza x² + ${b}x + ${c}. Comprueba suma y producto.`,
    options: [
      { id: "a", text: `(x + ${p})(x + ${q})` },
      { id: "b", text: `(x − ${p})(x − ${q})` },
      { id: "c", text: `(x + 1)(x + ${c})` },
    ],
    correct: "a",
    explanation: {
      correct: `${p} + ${q} = ${b} y ${p}·${q} = ${c}. Expandir (x + ${p})(x + ${q}) da x² + ${b}x + ${c}.`,
      misconception:
        "Los dos números deben cumplir a la vez suma, producto y signos.",
      distractors: {
        b: `Los factores negativos dan término lineal −${b}x. El producto constante es correcto, pero el signo de la suma cambia.`,
        c: `1·${c} = ${c}, pero 1 + ${c} = ${c + 1}, no ${b}. Cumplir solo el producto no basta.`,
      },
    },
    hints: [
      "Al expandir (x + p)(x + q), compara el coeficiente lineal y el constante.",
      "Enumera parejas de factores del término constante y revisa su suma y sus signos.",
      "Aplica este procedimiento a otro trinomio y vuelve al reto.",
    ],
    hintExample: {
      title: "Ejemplo alternativo · z² + 11z + 24",
      steps: [
        "Busca suma 11 y producto 24.",
        "3 + 8 = 11 y 3·8 = 24.",
        "(z + 3)(z + 8) = z² + 11z + 24. Comprueba ambos coeficientes.",
      ],
    },
    variant: {
      familyId: family.id,
      version: 1,
      seed,
      parameters: pair,
      rewardId: "factor-trinomial-v1-s0",
    },
  };
}
export function buildPracticeBank(families: PracticeFamily[]): Exercise[] {
  return families.flatMap((family) =>
    familyParameters(family).map((_, seed) => generateVariant(family, seed)),
  );
}
export function selectVariants(
  family: PracticeFamily,
  state: UserState,
  limit = 3,
): Exercise[] {
  if (!Number.isSafeInteger(limit) || limit < 0)
    throw new Error("Límite de práctica inválido.");
  const latest = new Map(
    state.attempts
      .filter((a) => a.mode !== "diagnostic")
      .map((a) => [a.exerciseId, a]),
  );
  return buildPracticeBank([family])
    .sort((a, b) => {
      const left = latest.get(a.id),
        right = latest.get(b.id);
      return (
        Number(!!left) - Number(!!right) ||
        (left?.at ?? "").localeCompare(right?.at ?? "") ||
        a.variant!.seed - b.variant!.seed
      );
    })
    .slice(0, limit);
}
