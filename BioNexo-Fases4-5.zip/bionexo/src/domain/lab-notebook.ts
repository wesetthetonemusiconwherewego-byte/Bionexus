import type { LaboratorySession, UserState } from "./models";
import { ENZYMES, enzymeActivity } from "./laboratory";
export type LabPoint = LaboratorySession["points"][number];
export type Prediction = "higher" | "lower" | "equal";
export interface LabComparison {
  first: LabPoint;
  second: LabPoint;
  delta: number;
  direction: Prediction;
}
/** Stored readings are authoritative; this never re-evaluates historical values. */
export function labComparisons(points: readonly LabPoint[]): LabComparison[] {
  const firstByModel = new Map<string, LabPoint>(),
    result: LabComparison[] = [];
  const used = new Set<string>();
  for (const point of points) {
    const first = firstByModel.get(point.enzyme);
    if (!first) {
      firstByModel.set(point.enzyme, point);
      continue;
    }
    if (first.ph === point.ph || used.has(point.enzyme)) continue;
    const delta = point.activity - first.activity;
    result.push({
      first,
      second: point,
      delta,
      direction:
        Math.abs(delta) <= 1e-9 ? "equal" : delta > 0 ? "higher" : "lower",
    });
    used.add(point.enzyme);
  }
  return result;
}
export function addLabPoint(
  points: readonly LabPoint[],
  ph: number,
  modelId: string,
): LabPoint[] {
  const model = ENZYMES.find((e) => e.id === modelId);
  if (!model) throw Error("Modelo de enzima no disponible.");
  const activity = enzymeActivity(ph, model.optimum, model.width);
  if (points.some((p) => p.ph === ph && p.enzyme === modelId))
    return [...points];
  if (points.length >= 100)
    throw Error(
      "Este registro admite hasta 100 condiciones. Guarda antes de iniciar otro.",
    );
  return [...points, { ph, activity, enzyme: modelId }];
}
/** New records require a controlled pH comparison; old records remain readable. */
export function createLabSession(input: LaboratorySession): LaboratorySession {
  if (
    !/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,119}$/.test(input.id) ||
    ["__proto__", "prototype", "constructor"].includes(input.id) ||
    !/^\d{4}-\d\d-\d\dT/.test(input.at) ||
    !Number.isFinite(Date.parse(input.at))
  )
    throw Error("Identidad o fecha de registro inválida.");
  if (
    !input.hypothesis.trim() ||
    !input.observation.trim() ||
    input.hypothesis.length > 2000 ||
    input.observation.length > 2000
  )
    throw Error("Completa hipótesis y observación (hasta 2000 caracteres).");
  if (input.points.length > 100 || !labComparisons(input.points).length)
    throw Error(
      "Registra dos pH distintos de un mismo modelo antes de guardar la comparación.",
    );
  const seen = new Set<string>();
  for (const p of input.points) {
    const model = ENZYMES.find((e) => e.id === p.enzyme),
      key = `${p.enzyme}:${p.ph}`;
    if (
      !model ||
      !Number.isFinite(p.activity) ||
      seen.has(key) ||
      Math.abs(p.activity - enzymeActivity(p.ph, model.optimum, model.width)) >
        1e-9
    )
      throw Error(
        "Condición nueva duplicada o incoherente con el modelo simulado.",
      );
    seen.add(key);
  }
  return {
    ...input,
    hypothesis: input.hypothesis.trim(),
    observation: input.observation.trim(),
    points: input.points.map((p) => ({ ...p })),
  };
}
export function saveLabSession(
  state: UserState,
  session: LaboratorySession,
): UserState {
  const existing = state.labs.find((l) => l.id === session.id);
  if (existing) {
    if (
      existing.at !== session.at ||
      existing.hypothesis !== session.hypothesis.trim() ||
      existing.observation !== session.observation.trim() ||
      existing.points.length !== session.points.length ||
      existing.points.some((p, i) => {
        const q = session.points[i]!;
        return (
          p.ph !== q.ph || p.activity !== q.activity || p.enzyme !== q.enzyme
        );
      })
    )
      throw Error(
        "El identificador ya tiene otro registro. Se conservó el guardado.",
      );
    return state;
  }
  return { ...state, labs: [...state.labs, createLabSession(session)] };
}
export function predictActivity(
  modelId: string,
  firstPh: number,
  secondPh: number,
): LabComparison {
  const points = addLabPoint(
    addLabPoint([], firstPh, modelId),
    secondPh,
    modelId,
  );
  if (points.length !== 2)
    throw Error("Usa dos pH distintos para contrastar la predicción.");
  return labComparisons(points)[0]!;
}
