export type SubjectId =
  "biology" | "chemistry" | "physics" | "math" | "integrated";
export interface Subject {
  id: SubjectId;
  title: string;
  color: string;
  icon: string;
  subtitle: string;
}
export interface Course {
  id: string;
  subjectId: SubjectId;
  title: string;
  unitIds: string[];
}
export interface Prerequisite {
  conceptId: string;
  requires: string[];
}
export interface Concept {
  id: string;
  subjectId: SubjectId;
  title: string;
  english: string;
  prerequisites: string[];
  status: "implemented" | "planned";
  origin: "foundation" | "unab-aligned" | "mit-aligned" | "complementary";
  explanation: string;
  example: string;
  sourceIds: string[];
}
export interface Unit {
  id: string;
  subjectId: SubjectId;
  title: string;
  lessonIds: string[];
  prerequisites: string[];
}
export interface Explanation {
  correct: string;
  misconception: string;
  distractors?: Record<string, string>;
}
interface ExerciseBase {
  id: string;
  subjectId: SubjectId;
  level: number;
  conceptIds: string[];
  prerequisites: string[];
  prompt: string;
  explanation: Explanation;
  hints: string[];
  hintExample?: WorkedExample;
  sourceIds: string[];
  variant?: {
    familyId: string;
    version: 1;
    seed: number;
    parameters: { p: number; q: number };
    rewardId: string;
  };
}
export interface PracticeFamily {
  id: string;
  version: 1;
  title: string;
  objective: string;
  parameterValues: number[];
  conceptId: string;
  prerequisites: string[];
  sourceIds: string[];
  reviewStatus: "requires-human-review";
}
export interface MisconceptionRule {
  id: string;
  title: string;
  exerciseIds: string[];
  familyIds: string[];
  selector:
    | { type: "selected-option"; optionIds: string[] }
    | { type: "proper-subset" };
  explanation: string;
  prerequisiteIds: string[];
  example: WorkedExample;
  sourceIds: string[];
  reviewStatus: "requires-human-review";
}
export interface TransferActivity {
  id: string;
  title: string;
  objective: string;
  model: string;
  assumptions: string[];
  exercises: Exercise[];
  sourceIds: string[];
  reviewStatus: "requires-human-review";
}
export interface Option {
  id: string;
  text: string;
}
export type Exercise = ExerciseBase &
  (
    | {
        type: "choice" | "prediction" | "case";
        options: Option[];
        correct: string;
      }
    | {
        type: "chart";
        options: Option[];
        correct: string;
        chart: { x: number; y: number }[];
        xLabel: string;
        yLabel: string;
      }
    | { type: "diagram"; options: Option[]; correct: string; diagram: "cell" }
    | { type: "multi"; options: Option[]; correct: string[] }
    | { type: "text"; correct: string[] }
    | {
        type: "numeric";
        correct: number;
        tolerance: number;
        unit: string;
        acceptedUnits: Record<string, number>;
      }
    | { type: "order"; items: Option[]; correct: string[] }
    | {
        type: "match";
        left: Option[];
        right: Option[];
        correct: Record<string, string>;
      }
  );
export type Answer =
  string | string[] | Record<string, string> | { value: string; unit: string };
export interface WorkedExample {
  title: string;
  steps: string[];
}
export interface LessonStage {
  id: string;
  title: string;
  objective: string;
  explanation: string;
  example: WorkedExample;
  exerciseIds: string[];
  sourceIds: string[];
}
export interface Lesson {
  id: string;
  unitId: string;
  subjectId: SubjectId;
  title: string;
  minutes: number;
  objective: string;
  activation: string;
  conceptIds: string[];
  prerequisites: string[];
  explanation: string;
  example: string[];
  application: string;
  summary: string;
  exercises: Exercise[];
  sourceIds: string[];
  reviewStatus: "requires-human-review";
  stages?: LessonStage[];
}
export interface Attempt {
  id: string;
  exerciseId: string;
  conceptIds: string[];
  answer: Answer;
  correct: boolean;
  at: string;
  mode: "lesson" | "review" | "diagnostic";
  hinted: boolean;
}
export interface MasteryRecord {
  conceptId: string;
  score: number;
  correct: number;
  wrong: number;
  streak: number;
  evidenceDays: string[];
}
export interface ReviewSchedule {
  conceptId: string;
  dueAt: string;
  intervalDays: number;
  step: number;
  lapses: number;
}
export interface Achievement {
  id: string;
  title: string;
  description: string;
  earned: boolean;
}
export interface LaboratorySession {
  id: string;
  at: string;
  hypothesis: string;
  observation: string;
  points: { ph: number; activity: number; enzyme: string }[];
}
export interface UserSettings {
  theme: "dark" | "light" | "system";
  reduceMotion: boolean;
  dailyGoal: number;
  name: string;
}
export interface DiagnosticResult {
  completedAt: string;
  results: Record<string, { correct: number; total: number }>;
  weakConceptIds: string[];
}
export interface UserState {
  version: 1;
  createdAt: string;
  onboarded: boolean;
  settings: UserSettings;
  attempts: Attempt[];
  mastery: Record<string, MasteryRecord>;
  reviews: Record<string, ReviewSchedule>;
  completedLessonIds: string[];
  rewardedExerciseIds: string[];
  xp: number;
  studyDays: Record<string, number>;
  labs: LaboratorySession[];
  diagnostic: DiagnosticResult | null;
  lessonSessions?: Record<string, LessonSession>;
}
/** One durable UI checkpoint; feedback is read from its confirmed attempt. */
export interface ExerciseCheckpoint {
  answer: Answer;
  hintCount: number;
  attemptNo: number;
  submittedAttemptId: string | null;
  bridge: { exerciseId: string; card: ExerciseCheckpoint } | null;
  bridgeDone: boolean;
}
export interface LessonSession {
  version: 1;
  id: string;
  lessonId: string;
  contentSignature: string;
  exerciseIds: string[];
  index: number;
  startedAt: string;
  updatedAt: string;
  card: ExerciseCheckpoint;
}
export interface Source {
  id: string;
  title: string;
  url: string;
  note: string;
}
