import type { Answer, Exercise } from "./models";
export function normalize(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}
/** Bounded grammar, never eval: decimal comma, exponent, one division, Unicode minus. */
export function parseNumber(input: string): number | null {
  if (input.length > 100) return null;
  const value = input.trim().replace(/−/g, "-").replace(/,/g, ".");
  const atom = "[+-]?(?:\\d+(?:\\.\\d*)?|\\.\\d+)(?:e[+-]?\\d+)?";
  const pattern = new RegExp(`^(${atom})(?:\\s*/\\s*(${atom}))?$`, "i");
  const match = pattern.exec(value);
  if (!match) return null;
  const numerator = Number(match[1]);
  const denominator = match[2] === undefined ? 1 : Number(match[2]);
  const underflowed = (atom: string, parsed: number) =>
    parsed === 0 && /[1-9]/.test(atom.split(/e/i)[0]!);
  if (
    !Number.isFinite(numerator) ||
    !Number.isFinite(denominator) ||
    underflowed(match[1]!, numerator) ||
    (match[2] !== undefined && underflowed(match[2], denominator)) ||
    denominator === 0
  )
    return null;
  const result = numerator / denominator;
  return Number.isFinite(result) && !(numerator !== 0 && result === 0)
    ? result
    : null;
}
export function grade(exercise: Exercise, answer: unknown): boolean {
  switch (exercise.type) {
    case "numeric": {
      if (
        typeof answer !== "object" ||
        answer === null ||
        Array.isArray(answer) ||
        !("value" in answer) ||
        !("unit" in answer)
      )
        return false;
      if (typeof answer.value !== "string" || typeof answer.unit !== "string")
        return false;
      const numeric = parseNumber(answer.value);
      if (
        !Object.prototype.hasOwnProperty.call(
          exercise.acceptedUnits,
          answer.unit,
        )
      )
        return false;
      const factor = exercise.acceptedUnits[answer.unit];
      if (
        numeric === null ||
        factor === undefined ||
        !Number.isFinite(factor) ||
        factor <= 0
      )
        return false;
      const converted = numeric * factor;
      return (
        Number.isFinite(converted) &&
        !(numeric !== 0 && converted === 0) &&
        Math.abs(converted - exercise.correct) <=
          exercise.tolerance + Number.EPSILON * Math.abs(exercise.correct) * 8
      );
    }
    case "text":
      return (
        typeof answer === "string" &&
        exercise.correct.some((a) => normalize(a) === normalize(answer))
      );
    case "multi":
      return (
        Array.isArray(answer) &&
        new Set(answer).size === answer.length &&
        answer.length === exercise.correct.length &&
        answer.every(
          (a) => typeof a === "string" && exercise.correct.includes(a),
        )
      );
    case "order":
      return (
        Array.isArray(answer) &&
        answer.length === exercise.correct.length &&
        answer.every((a, i) => a === exercise.correct[i])
      );
    case "match":
      return (
        typeof answer === "object" &&
        answer !== null &&
        !Array.isArray(answer) &&
        Object.keys(answer).length === Object.keys(exercise.correct).length &&
        Object.entries(exercise.correct).every(
          ([k, v]) => (answer as Record<string, unknown>)[k] === v,
        )
      );
    default:
      return typeof answer === "string" && answer === exercise.correct;
  }
}
export function solution(exercise: Exercise): string {
  switch (exercise.type) {
    case "numeric":
      return `${exercise.correct.toLocaleString("es-CL", { maximumFractionDigits: 8 })} ${exercise.unit}`.trim();
    case "text":
      return exercise.correct[0] ?? "";
    case "multi":
      return exercise.options
        .filter((o) => exercise.correct.includes(o.id))
        .map((o) => o.text)
        .join(" · ");
    case "order":
      return exercise.correct
        .map((id) => exercise.items.find((o) => o.id === id)?.text)
        .join(" → ");
    case "match":
      return exercise.left
        .map(
          (l) =>
            `${l.text}: ${exercise.right.find((r) => r.id === exercise.correct[l.id])?.text}`,
        )
        .join(" · ");
    default:
      return (
        exercise.options.find((o) => o.id === exercise.correct)?.text ?? ""
      );
  }
}
export function correctAnswer(exercise: Exercise): Answer {
  if (exercise.type === "numeric")
    return { value: String(exercise.correct), unit: exercise.unit };
  if (exercise.type === "text") return exercise.correct[0] ?? "";
  return exercise.correct;
}
