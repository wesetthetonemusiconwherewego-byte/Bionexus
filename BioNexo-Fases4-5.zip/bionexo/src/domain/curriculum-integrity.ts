import type { catalog } from "../content";
/** Cross-check included graph against the catalogue; independent of learner progress. */
export function validatePrerequisiteGraph(
  graph: unknown,
  data: typeof catalog,
): string[] {
  const errors: string[] = [];
  if (!Array.isArray(graph))
    return ["Grafo: se esperaba una lista explícita de prerrequisitos."];
  const seen = new Set<string>();
  for (const row of graph) {
    if (
      !row ||
      typeof row !== "object" ||
      typeof row.conceptId !== "string" ||
      !Array.isArray(row.requires) ||
      row.requires.some((id: unknown) => typeof id !== "string")
    ) {
      errors.push("Grafo: nodo malformado.");
      continue;
    }
    const concept = data.concepts.find((c) => c.id === row.conceptId);
    if (
      seen.has(row.conceptId) ||
      !concept ||
      new Set(row.requires).size !== row.requires.length
    )
      errors.push(`Grafo: nodo duplicado o inexistente ${row.conceptId}.`);
    if (
      concept &&
      [...concept.prerequisites].sort().join("|") !==
        [...row.requires].sort().join("|")
    )
      errors.push(`Grafo: dependencias divergentes para ${row.conceptId}.`);
    seen.add(row.conceptId);
  }
  for (const c of data.concepts)
    if (!seen.has(c.id)) errors.push(`Grafo: falta ${c.id}.`);
  return errors;
}
