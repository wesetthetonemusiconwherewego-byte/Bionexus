import type {
  Answer,
  Exercise,
  ExerciseCheckpoint,
  Lesson,
  LessonSession,
  UserState,
} from "./models";
import { exerciseById } from "../content";
import {
  completeLesson,
  initialState,
  recordAttempt,
  remediation,
} from "./learning";
import { grade } from "./answers";

export function emptyCheckpoint(exercise: Exercise): ExerciseCheckpoint {
  return {
    answer:
      exercise.type === "numeric"
        ? { value: "", unit: exercise.unit }
        : exercise.type === "match"
          ? {}
          : exercise.type === "multi" || exercise.type === "order"
            ? []
            : "",
    hintCount: 0,
    attemptNo: 0,
    submittedAttemptId: null,
    bridge: null,
    bridgeDone: false,
  };
}
/** Content-change sentinel, not an authentication or cryptographic hash. */
export function lessonSignature(lesson: Lesson): string {
  const context = initialState(new Date(0));
  const source = JSON.stringify({
    lesson,
    support: lesson.exercises.map((e) => remediation(context, e)),
  });
  let a = 2166136261,
    b = 5381;
  for (let i = 0; i < source.length; i++) {
    a = Math.imul(a ^ source.charCodeAt(i), 16777619) >>> 0;
    b = (Math.imul(b, 33) ^ source.charCodeAt(i)) >>> 0;
  }
  return `content-v1-${a.toString(16).padStart(8, "0")}-${b.toString(16).padStart(8, "0")}-${source.length}`;
}
export function sessionMatchesLesson(session: LessonSession, lesson: Lesson) {
  return (
    session.contentSignature === lessonSignature(lesson) &&
    session.exerciseIds.join("|") ===
      lesson.exercises.map((e) => e.id).join("|")
  );
}
export function beginLessonSession(
  state: UserState,
  lesson: Lesson,
  id: string,
  at: string,
): UserState {
  if (state.lessonSessions?.[lesson.id]) return state;
  if (!lesson.exercises.length)
    throw new Error("La lección no tiene ejercicios.");
  return {
    ...state,
    lessonSessions: {
      ...state.lessonSessions,
      [lesson.id]: {
        version: 1,
        id,
        lessonId: lesson.id,
        contentSignature: lessonSignature(lesson),
        exerciseIds: lesson.exercises.map((e) => e.id),
        index: 0,
        startedAt: at,
        updatedAt: at,
        card: emptyCheckpoint(lesson.exercises[0]!),
      },
    },
  };
}
function active(
  state: UserState,
  lesson: Lesson,
  sessionId: string,
  index: number,
): LessonSession {
  const session = state.lessonSessions?.[lesson.id];
  if (!session || session.id !== sessionId || session.index !== index)
    throw new Error(
      "La sesión cambió. Vuelve a abrir la lección para continuar.",
    );
  if (!sessionMatchesLesson(session, lesson))
    throw new Error(
      "El contenido de esta lección cambió. Conservamos tu punto de reanudación para que puedas revisarlo o descartarlo.",
    );
  return session;
}
function put(state: UserState, session: LessonSession): UserState {
  return {
    ...state,
    lessonSessions: { ...state.lessonSessions, [session.lessonId]: session },
  };
}
export function saveLessonCheckpoint(
  state: UserState,
  lesson: Lesson,
  sessionId: string,
  index: number,
  card: ExerciseCheckpoint,
  at: string,
): UserState {
  const session = active(state, lesson, sessionId, index),
    previous = session.card;
  const retry =
    card.attemptNo === previous.attemptNo + 1 &&
    previous.bridgeDone &&
    previous.submittedAttemptId !== null &&
    !state.attempts.find((a) => a.id === previous.submittedAttemptId)
      ?.correct &&
    card.submittedAttemptId === null &&
    card.bridge === null;
  if (
    !retry &&
    (card.attemptNo !== previous.attemptNo ||
      card.submittedAttemptId !== previous.submittedAttemptId)
  )
    throw new Error("Un borrador no puede confirmar ni borrar un intento.");
  if (
    !retry &&
    previous.submittedAttemptId &&
    JSON.stringify(card.answer) !== JSON.stringify(previous.answer)
  )
    throw new Error("La respuesta confirmada no puede editarse.");
  if (card.hintCount < previous.hintCount)
    throw new Error("Las pistas utilizadas se conservan.");
  if (card.bridge && !previous.bridge) {
    const remedy = remediation(state, lesson.exercises[index]!);
    if (
      !previous.submittedAttemptId ||
      state.attempts.find((a) => a.id === previous.submittedAttemptId)
        ?.correct ||
      !remedy.needed ||
      remedy.easier?.id !== card.bridge.exerciseId ||
      previous.bridgeDone
    )
      throw new Error("El paso de apoyo no corresponde a este intento.");
  }
  if (
    previous.bridge &&
    !card.bridge &&
    (!previous.bridge.card.submittedAttemptId || !card.bridgeDone)
  )
    throw new Error("Completa el paso de apoyo antes de volver.");
  return put(state, { ...session, card, updatedAt: at });
}
export function submitLessonAnswer(
  state: UserState,
  lesson: Lesson,
  sessionId: string,
  index: number,
  exercise: Exercise,
  answer: Answer,
  hinted: boolean,
  token: string,
  at: string,
): UserState {
  const session = active(state, lesson, sessionId, index);
  const bridge = session.card.bridge;
  const isRoot = exercise.id === session.exerciseIds[index];
  const target = isRoot
    ? session.card
    : bridge?.exerciseId === exercise.id
      ? bridge.card
      : null;
  if (!target || (isRoot && bridge))
    throw new Error("El ejercicio no corresponde al paso actual.");
  const expected = isRoot
    ? String(target.attemptNo)
    : `bridge-${session.card.attemptNo}-${target.attemptNo}`;
  if (
    expected !== token ||
    hinted !== (target.hintCount > 0 || target.attemptNo > 0)
  )
    throw new Error("El contador o las pistas del intento no coinciden.");
  const id = `${session.id}:${exercise.id}:${token}`;
  const recorded = state.attempts.find((a) => a.id === id);
  if (
    recorded &&
    (JSON.stringify(recorded.answer) !== JSON.stringify(answer) ||
      recorded.hinted !== hinted)
  )
    throw new Error("Ese intento ya fue confirmado con otra respuesta.");
  if (JSON.stringify(target.answer) !== JSON.stringify(answer))
    throw new Error("Guarda el borrador antes de responder.");
  if (recorded && target.submittedAttemptId === id) return state;
  const next = recordAttempt(state, {
    id,
    exerciseId: exercise.id,
    conceptIds: exercise.conceptIds,
    answer,
    correct: grade(exercise, answer),
    hinted,
    mode: "lesson",
    at,
  });
  const submitted = { ...target, submittedAttemptId: id };
  return put(next, {
    ...session,
    updatedAt: at,
    card: isRoot
      ? submitted
      : {
          ...session.card,
          bridge: { exerciseId: exercise.id, card: submitted },
        },
  });
}
export function advanceLessonSession(
  state: UserState,
  lesson: Lesson,
  sessionId: string,
  index: number,
  at: string,
): UserState {
  const existing = state.lessonSessions?.[lesson.id];
  if (!existing) return state; // repeated final acknowledgement cannot award again
  if (existing.id === sessionId && existing.index > index) return state;
  const session = active(state, lesson, sessionId, index);
  if (!session.card.submittedAttemptId || session.card.bridge)
    throw new Error("Confirma la respuesta antes de avanzar.");
  if (index < session.exerciseIds.length - 1) {
    const next = exerciseById[session.exerciseIds[index + 1]!];
    if (!next) throw new Error("El siguiente ejercicio no está disponible.");
    return put(state, {
      ...session,
      index: index + 1,
      card: emptyCheckpoint(next),
      updatedAt: at,
    });
  }
  return discardLessonSession(
    completeLesson(state, lesson, sessionId),
    lesson.id,
    sessionId,
  );
}
export function discardLessonSession(
  state: UserState,
  lessonId: string,
  sessionId: string,
): UserState {
  if (state.lessonSessions?.[lessonId]?.id !== sessionId) return state;
  const sessions = { ...state.lessonSessions };
  delete sessions[lessonId];
  return { ...state, lessonSessions: sessions };
}
