import { correctAnswer, grade } from "./answers";
import { catalog, exerciseById } from "../content";
import { buildPracticeBank } from "./variants";
import { validatePrerequisiteGraph } from "./curriculum-integrity";
import prerequisiteGraph from "../content/prerequisites.json";
import biolab from "../content/biolab.json";
import type { Exercise } from "./models";
export function validateCatalog(data: unknown = catalog): string[] {
  try {
    const result = inspectCatalog(data as typeof catalog);
    if (data === catalog)
      result.push(...validatePrerequisiteGraph(prerequisiteGraph, catalog));
    return result;
  } catch {
    return [
      "Estructura del catálogo inválida: faltan listas, campos o formas de ejercicio requeridas. No se acepta contenido externo sin validar.",
    ];
  }
}
function inspectCatalog(data: typeof catalog): string[] {
  const errors: string[] = [];
  let practice: Exercise[] = [];
  try {
    practice = buildPracticeBank(data.practiceFamilies ?? []);
  } catch {
    errors.push("Familia parametrizada inválida");
  }
  const entities = [
    ...data.subjects,
    ...data.courses,
    ...data.units,
    ...data.concepts,
    ...data.lessons,
    ...data.lessons.flatMap((l) => l.exercises),
    ...data.diagnostic,
    ...data.sources,
    ...(data.practiceFamilies ?? []),
    ...practice,
    ...(data.transferActivities ?? []),
    ...(data.transferActivities ?? []).flatMap((a) => a.exercises),
    ...(data.errorRules ?? []),
  ];
  const hasText = (value: unknown) =>
    typeof value === "string" && !!value.trim();
  for (const subject of data.subjects)
    if (!hasText(subject.title) || !hasText(subject.id))
      errors.push("Materia incompleta");
  for (const source of data.sources)
    if (
      !hasText(source.title) ||
      !/^https:\/\//.test(source.url) ||
      !hasText(source.note)
    )
      errors.push(`Fuente incompleta: ${source.id}`);
  for (const course of data.courses)
    if (
      !data.subjects.some((s) => s.id === course.subjectId) ||
      !hasText(course.title)
    )
      errors.push(`Curso inválido: ${course.id}`);
  for (const unit of data.units)
    if (
      !data.subjects.some((s) => s.id === unit.subjectId) ||
      !hasText(unit.title) ||
      !data.courses.some(
        (c) => c.subjectId === unit.subjectId && c.unitIds.includes(unit.id),
      )
    )
      errors.push(`Unidad fuera de curso/materia: ${unit.id}`);
  for (const concept of data.concepts)
    if (
      !data.subjects.some((s) => s.id === concept.subjectId) ||
      !["implemented", "planned"].includes(concept.status)
    )
      errors.push(`Concepto fuera de materia/estado: ${concept.id}`);
  if (data === catalog) {
    if (
      !biolab.id ||
      biolab.reviewStatus !== "requires-human-review" ||
      !biolab.sourceIds.every((id) => data.sources.some((s) => s.id === id)) ||
      ![
        biolab.question,
        biolab.objective,
        biolab.facts,
        biolab.assumptions,
        ...biolab.steps,
        ...biolab.example,
      ].every(hasText)
    )
      errors.push("Guía BioLab incompleta o sin fuentes válidas");
  }
  const ids = new Set<string>();
  for (const entity of entities) {
    if (!entity.id || ids.has(entity.id))
      errors.push(`ID ausente o duplicado: ${entity.id}`);
    ids.add(entity.id);
  }
  const concepts = new Map(data.concepts.map((c) => [c.id, c]));
  const sources = new Set(data.sources.map((s) => s.id));
  const visited = new Set<string>(),
    active = new Set<string>();
  function visit(id: string) {
    if (active.has(id)) {
      errors.push(`Ciclo: ${id}`);
      return;
    }
    if (visited.has(id)) return;
    active.add(id);
    const c = concepts.get(id);
    if (!c) errors.push(`Concepto inexistente: ${id}`);
    else c.prerequisites.forEach(visit);
    active.delete(id);
    visited.add(id);
  }
  data.concepts.forEach((c) => visit(c.id));
  const checkRefs = (item: {
    id: string;
    sourceIds: string[];
    prerequisites?: string[];
    conceptIds?: string[];
  }) => {
    for (const id of [
      ...(item.prerequisites ?? []),
      ...(item.conceptIds ?? []),
    ])
      if (!concepts.has(id))
        errors.push(`${item.id}: prerrequisito/concepto inexistente ${id}`);
    if (
      !item.sourceIds?.length ||
      item.sourceIds.some((id) => !sources.has(id))
    )
      errors.push(`${item.id}: fuente inválida`);
  };
  for (const family of data.practiceFamilies ?? []) {
    checkRefs({ ...family, conceptIds: [family.conceptId] });
    if (
      !family.title?.trim() ||
      !family.objective?.trim() ||
      family.reviewStatus !== "requires-human-review"
    )
      errors.push(`${family.id}: familia incompleta`);
  }
  for (const c of data.concepts) {
    checkRefs(c);
    if (!c.title || !c.explanation || !c.english)
      errors.push(`${c.id}: datos obligatorios`);
  }
  const exercises = [
    ...data.lessons.flatMap((l) => l.exercises),
    ...data.diagnostic,
    ...practice,
    ...(data.transferActivities ?? []).flatMap((a) => a.exercises),
  ];
  for (const activity of data.transferActivities ?? []) {
    checkRefs(activity);
    if (
      !activity.title?.trim() ||
      !activity.objective?.trim() ||
      !activity.model?.trim() ||
      !activity.assumptions?.length ||
      activity.assumptions.some((a) => !a.trim()) ||
      !activity.exercises.length ||
      activity.reviewStatus !== "requires-human-review"
    )
      errors.push(`${activity.id}: transferencia incompleta`);
  }
  for (const rule of data.errorRules ?? []) {
    checkRefs({ ...rule, prerequisites: rule.prerequisiteIds });
    const targets = exercises.filter(
      (e) =>
        rule.exerciseIds.includes(e.id) ||
        (e.variant && rule.familyIds.includes(e.variant.familyId)),
    );
    if (
      !targets.length ||
      rule.exerciseIds.some((id) => !exercises.some((e) => e.id === id)) ||
      rule.familyIds.some(
        (id) => !data.practiceFamilies?.some((f) => f.id === id),
      ) ||
      !rule.title?.trim() ||
      !rule.explanation?.trim() ||
      !rule.example?.title?.trim() ||
      !rule.example?.steps?.length ||
      rule.example.steps.some((s) => !s.trim()) ||
      !rule.prerequisiteIds.length ||
      rule.reviewStatus !== "requires-human-review"
    )
      errors.push(
        `${rule.id}: regla conceptual incompleta o referencia inválida`,
      );
    for (const target of targets) {
      if (rule.selector.type === "proper-subset") {
        if (target.type !== "multi")
          errors.push(`${rule.id}: omisión requiere selección múltiple`);
      } else if (rule.selector.type === "selected-option") {
        const selected = rule.selector.optionIds;
        if (
          !("options" in target) ||
          !selected.length ||
          new Set(selected).size !== selected.length ||
          selected.some(
            (id) =>
              !("options" in target) ||
              !target.options.some((o) => o.id === id) ||
              (Array.isArray(target.correct)
                ? target.correct.includes(id)
                : target.correct === id),
          )
        )
          errors.push(`${rule.id}: selector conceptual fuera de distractores`);
      } else errors.push(`${rule.id}: selector conceptual inválido`);
    }
  }
  for (const lesson of data.lessons) {
    checkRefs(lesson);
    if (
      !lesson.objective ||
      !lesson.explanation ||
      !lesson.activation ||
      !lesson.example.length ||
      !lesson.application ||
      !lesson.summary ||
      lesson.exercises.length < 6
    )
      errors.push(`${lesson.id}: lección incompleta`);
    if (
      !data.units.some(
        (u) =>
          u.id === lesson.unitId &&
          u.subjectId === lesson.subjectId &&
          u.lessonIds.includes(lesson.id),
      )
    )
      errors.push(`${lesson.id}: unidad inválida`);
    if (lesson.stages !== undefined) {
      const stageIds = new Set<string>();
      const ordered = lesson.stages.flatMap((s) => s.exerciseIds);
      if (
        !lesson.stages.length ||
        ordered.join("|") !== lesson.exercises.map((e) => e.id).join("|")
      )
        errors.push(
          `${lesson.id}: tramos deben cubrir los retos una vez y en orden`,
        );
      for (const stage of lesson.stages) {
        if (
          !stage.id ||
          stageIds.has(stage.id) ||
          !stage.title?.trim() ||
          !stage.objective?.trim() ||
          !stage.explanation?.trim() ||
          !stage.example?.title?.trim() ||
          !stage.example?.steps?.length ||
          stage.example.steps.some((step) => !step.trim()) ||
          !stage.exerciseIds.length
        )
          errors.push(`${lesson.id}: tramo incompleto o duplicado`);
        stageIds.add(stage.id);
        checkRefs({
          id: `${lesson.id}/${stage.id}`,
          sourceIds: stage.sourceIds,
        });
      }
    }
  }
  for (const unit of data.units) {
    if (
      unit.lessonIds.length < 2 ||
      unit.lessonIds.some(
        (id) => !data.lessons.some((l) => l.id === id && l.unitId === unit.id),
      )
    )
      errors.push(`${unit.id}: referencias de lección inválidas`);
    for (const id of unit.prerequisites)
      if (!concepts.has(id))
        errors.push(`${unit.id}: prerrequisito inexistente`);
  }
  for (const course of data.courses)
    if (
      course.unitIds.some(
        (id) =>
          !data.units.some(
            (u) => u.id === id && u.subjectId === course.subjectId,
          ),
      )
    )
      errors.push(`${course.id}: unidad inexistente`);
  for (const exercise of exercises) {
    checkRefs(exercise);
    if (
      !exercise.prompt ||
      !exercise.explanation?.correct ||
      !exercise.explanation?.misconception ||
      !exercise.hints?.length ||
      exercise.hints.some((hint) => !hint.trim()) ||
      !exercise.conceptIds.length ||
      !data.subjects.some((s) => s.id === exercise.subjectId)
    )
      errors.push(`${exercise.id}: datos obligatorios`);
    if ("options" in exercise) {
      const options = exercise.options.map((o) => o.id);
      if (
        new Set(options).size !== options.length ||
        options.length < 2 ||
        exercise.options.some((o) => !o.text)
      )
        errors.push(`${exercise.id}: opciones inválidas`);
      const answers = Array.isArray(exercise.correct)
        ? exercise.correct
        : [exercise.correct];
      if (!answers.length || answers.some((a) => !options.includes(a)))
        errors.push(`${exercise.id}: solución fuera de opciones`);
    }
    if (
      exercise.hintExample &&
      (exercise.hints.length < 3 ||
        !exercise.hintExample.title?.trim() ||
        !exercise.hintExample.steps?.length ||
        exercise.hintExample.steps.some((s) => !s.trim()))
    )
      errors.push(`${exercise.id}: ejemplo de ayuda incompleto`);
    if (exercise.explanation.distractors !== undefined) {
      const correct = Array.isArray(exercise.correct)
        ? exercise.correct
        : [exercise.correct];
      if (
        !("options" in exercise) ||
        Object.entries(exercise.explanation.distractors).some(
          ([id, message]) =>
            !("options" in exercise) ||
            !exercise.options.some((o) => o.id === id) ||
            correct.some((answer) => answer === id) ||
            !message.trim(),
        )
      )
        errors.push(`${exercise.id}: distractor sin opción incorrecta válida`);
    }
    if (
      exercise.type === "numeric" &&
      (!Number.isFinite(exercise.correct) ||
        !Number.isFinite(exercise.tolerance) ||
        exercise.tolerance < 0 ||
        exercise.acceptedUnits[exercise.unit] !== 1 ||
        Object.values(exercise.acceptedUnits).some(
          (f) => !Number.isFinite(f) || f <= 0,
        ))
    )
      errors.push(`${exercise.id}: fórmula/unidad inválida`);
    if (
      exercise.type === "chart" &&
      (exercise.chart.length < 2 ||
        exercise.chart.some(
          (p) => !Number.isFinite(p.x) || !Number.isFinite(p.y),
        ) ||
        !exercise.xLabel ||
        !exercise.yLabel)
    )
      errors.push(`${exercise.id}: gráfico inválido`);
    if (exercise.type === "text" && !exercise.correct.length)
      errors.push(`${exercise.id}: sin solución`);
    if (
      exercise.type === "order" &&
      (new Set(exercise.correct).size !== exercise.items.length ||
        exercise.correct.length !== exercise.items.length ||
        exercise.items.some((i) => !exercise.correct.includes(i.id)))
    )
      errors.push(`${exercise.id}: orden inválido`);
    if (
      exercise.type === "match" &&
      (Object.keys(exercise.correct).length !== exercise.left.length ||
        new Set(Object.values(exercise.correct)).size !==
          exercise.right.length ||
        exercise.left.some(
          (l) => !exercise.right.some((r) => r.id === exercise.correct[l.id]),
        ))
    )
      errors.push(`${exercise.id}: parejas inválidas`);
    try {
      if (!grade(exercise, correctAnswer(exercise)))
        errors.push(`${exercise.id}: solución no validable`);
    } catch {
      errors.push(`${exercise.id}: solución inválida`);
    }
  }
  return errors;
}
// Persistence validates historical records independently of current solutions.
export { parseBackup } from "./progress-document";
