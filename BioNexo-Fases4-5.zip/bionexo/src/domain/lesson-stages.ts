import type { Lesson } from "./models";

/** Derived from the durable exercise cursor; no second navigation state. */
export function stageAt(lesson: Lesson, index: number) {
  const exercise = lesson.exercises[index];
  if (!exercise || !Number.isInteger(index) || index < 0) return undefined;
  const stageIndex =
    lesson.stages?.findIndex((stage) =>
      stage.exerciseIds.includes(exercise.id),
    ) ?? -1;
  const stage = lesson.stages?.[stageIndex];
  return stage
    ? { stage, index: stageIndex, total: lesson.stages!.length }
    : undefined;
}
