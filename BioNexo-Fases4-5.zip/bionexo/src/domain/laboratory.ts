export const ENZYMES = [
  {
    id: "neutral",
    title: "Modelo N · óptimo 7",
    optimum: 7,
    width: 1.5,
    color: "#4DDEC3",
  },
  {
    id: "acid",
    title: "Modelo A · óptimo 4",
    optimum: 4,
    width: 1.2,
    color: "#C3A0FF",
  },
] as const;
/** Relative activity, a didactic Gaussian. No clinical or experimental interpretation. */
export function enzymeActivity(ph: number, optimum = 7, width = 1.5): number {
  if (
    !Number.isFinite(ph) ||
    ph < 0 ||
    ph > 14 ||
    !Number.isFinite(optimum) ||
    optimum < 0 ||
    optimum > 14 ||
    !Number.isFinite(width) ||
    width <= 0
  )
    throw new Error("Parámetros fuera del dominio del modelo.");
  return 100 * Math.exp(-0.5 * ((ph - optimum) / width) ** 2);
}
export function enzymeCurve(optimum = 7, width = 1.5) {
  return Array.from({ length: 57 }, (_, i) => ({
    x: i / 4,
    y: enzymeActivity(i / 4, optimum, width),
  }));
}
