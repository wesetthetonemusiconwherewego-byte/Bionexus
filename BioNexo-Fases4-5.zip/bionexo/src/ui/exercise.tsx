import React, {
  forwardRef,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from "react";
import { AccessibilityInfo, Pressable, View } from "react-native";
import { router } from "expo-router";
import { CellDiagram } from "./cell-diagram";
import type {
  Answer,
  Attempt,
  Exercise,
  ExerciseCheckpoint,
} from "../domain/models";
import { solution } from "../domain/answers";
import { emptyCheckpoint } from "../domain/sessions";
import { misconceptionFeedback } from "../domain/feedback";
import { remediation } from "../domain/learning";
import { conceptById } from "../content";
import { useApp } from "./provider";
import { Button, Card, Chip, Field, Heading, Label, Plot } from "./components";
import { PatternSupport } from "./learning-evidence";
export function shuffle<T>(items: readonly T[], seed: string): T[] {
  let n = [...seed].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    n = (Math.imul(n, 1664525) + 1013904223) >>> 0;
    const j = n % (i + 1);
    [result[i], result[j]] = [result[j]!, result[i]!];
  }
  return result;
}
export interface ExerciseCardHandle {
  flush(): Promise<void>;
}
interface ExerciseCardProps {
  exercise: Exercise;
  onSubmit: (
    e: Exercise,
    answer: Answer,
    hinted: boolean,
    attemptNo: string,
  ) => Promise<Attempt>;
  onContinue: () => void | Promise<void>;
  canRemediate?: boolean;
  paused?: boolean;
  checkpoint?: ExerciseCheckpoint;
  onCheckpoint?: (value: ExerciseCheckpoint) => Promise<void>;
}
export const ExerciseCard = forwardRef<ExerciseCardHandle, ExerciseCardProps>(
  function RenderExerciseCard(
    {
      exercise,
      onSubmit,
      onContinue,
      canRemediate = true,
      checkpoint,
      onCheckpoint,
      paused = false,
    },
    ref,
  ) {
    const { theme, state } = useApp();
    const [card, setCard] = useState(
      () => checkpoint ?? emptyCheckpoint(exercise),
    );
    const local = useRef(card),
      pending = useRef<Promise<void>>(Promise.resolve());
    const bridgeRef = useRef<ExerciseCardHandle>(null),
      saveSequence = useRef(0);
    const [busy, setBusy] = useState(false),
      [saving, setSaving] = useState(false),
      [error, setError] = useState("");
    const lock = useRef(false);
    const edit = (
      change: (value: ExerciseCheckpoint) => ExerciseCheckpoint,
      persist = true,
    ): Promise<void> => {
      const next = change(local.current);
      local.current = next;
      setCard(next);
      if (!persist || !onCheckpoint) return Promise.resolve();
      const sequence = ++saveSequence.current;
      setSaving(true);
      const operation = pending.current
        .catch(() => undefined)
        .then(() => onCheckpoint(next));
      pending.current = operation;
      void operation.then(
        () => {
          if (saveSequence.current === sequence) {
            setSaving(false);
            setError("");
          }
        },
        () => {
          if (saveSequence.current === sequence) {
            setSaving(false);
            setError("No se guardaron los cambios. Reintenta antes de salir.");
          }
        },
      );
      return operation;
    };
    const change = (fn: (value: ExerciseCheckpoint) => ExerciseCheckpoint) => {
      void edit(fn).catch(() => {});
    };
    const flush = async () => {
      if (bridgeRef.current) await bridgeRef.current.flush();
      await edit((value) => value);
    };
    useImperativeHandle(ref, () => ({ flush }));
    const answer = card.answer,
      hintCount = card.hintCount,
      attemptNo = card.attemptNo;
    const bridge = card.bridge !== null,
      bridgeDone = card.bridgeDone;
    const feedback = card.submittedAttemptId
      ? (state?.attempts.find((a) => a.id === card.submittedAttemptId)
          ?.correct ?? null)
      : null;
    const setAnswer = (value: Answer) =>
      change((c) => ({ ...c, answer: value }));
    const options = useMemo(
      () =>
        shuffle(
          "options" in exercise
            ? exercise.options
            : exercise.type === "order"
              ? exercise.items
              : [],
          exercise.id,
        ),
      [exercise],
    );
    const right = useMemo(
      () =>
        shuffle(
          exercise.type === "match" ? exercise.right : [],
          exercise.id + "right",
        ),
      [exercise],
    );
    const remedy = state ? remediation(state, exercise) : null;
    const isArray = Array.isArray(answer);
    const map =
      typeof answer === "object" && !isArray
        ? (answer as Record<string, string>)
        : {};
    const ready =
      typeof answer === "string"
        ? answer.trim().length > 0
        : isArray
          ? answer.length > 0
          : exercise.type === "numeric"
            ? !!map.value?.trim()
            : exercise.type === "match"
              ? Object.keys(map).length === exercise.left.length
              : false;
    const choose = (id: string) => {
      if (feedback !== null || busy || paused) return;
      if (exercise.type === "multi") {
        const values = isArray ? answer : [];
        setAnswer(
          values.includes(id)
            ? values.filter((x) => x !== id)
            : [...values, id],
        );
      } else if (exercise.type === "order") {
        const values = isArray ? answer : [];
        if (!values.includes(id)) setAnswer([...values, id]);
      } else setAnswer(id);
    };
    async function submit() {
      if (lock.current || paused || !ready || feedback !== null) return;
      lock.current = true;
      setBusy(true);
      setError("");
      try {
        await flush();
        const attempt = await onSubmit(
          exercise,
          local.current.answer,
          local.current.hintCount > 0 || local.current.attemptNo > 0,
          String(local.current.attemptNo),
        );
        await edit((c) => ({ ...c, submittedAttemptId: attempt.id }), false);
        AccessibilityInfo.announceForAccessibility(
          attempt.correct
            ? "Respuesta correcta. Lee la explicación."
            : "Revisa la respuesta y su explicación.",
        );
      } catch {
        setError(
          "No se confirmó la respuesta. Reintenta; no se duplicará un intento ya guardado.",
        );
      } finally {
        setBusy(false);
        lock.current = false;
      }
    }
    async function continueQuestion() {
      if (lock.current || paused) return;
      lock.current = true;
      setBusy(true);
      try {
        await flush();
        await onContinue();
      } catch {
        setError("No se pudo guardar el siguiente paso. Reintenta.");
      } finally {
        lock.current = false;
        setBusy(false);
      }
    }
    return (
      <View style={{ gap: 16 }}>
        <Chip>
          {
            (
              {
                choice: "ELEGIR",
                multi: "SELECCIÓN MÚLTIPLE",
                text: "COMPLETAR",
                numeric: "CALCULAR",
                match: "CONECTAR",
                order: "ORDENAR",
                chart: "INTERPRETAR",
                diagram: "IDENTIFICAR",
                prediction: "PREDECIR",
                case: "ANALIZAR",
              } as const
            )[exercise.type]
          }
        </Chip>
        <Heading small>{exercise.prompt}</Heading>
        {exercise.variant && (
          <Label muted>
            Variante {exercise.variant.seed + 1} · mismo objetivo, nuevos datos.
          </Label>
        )}
        {exercise.type === "chart" && (
          <Card>
            <Plot
              points={exercise.chart}
              xLabel={exercise.xLabel}
              yLabel={exercise.yLabel}
            />
            <Label muted style={{ fontSize: 13 }}>
              Datos accesibles ·{" "}
              {exercise.chart.map((p) => `(${p.x}; ${p.y})`).join(" · ")}
            </Label>
          </Card>
        )}
        {exercise.type === "diagram" && (
          <CellDiagram
            value={card.answer}
            onSelect={setAnswer}
            disabled={feedback !== null || busy || paused}
          />
        )}
        {exercise.type === "numeric" ? (
          <>
            <Field
              testID="numeric-answer"
              editable={feedback === null && !busy && !paused}
              label="Respuesta numérica"
              value={map.value ?? ""}
              onChangeText={(value) =>
                setAnswer({ value, unit: map.unit ?? exercise.unit })
              }
              placeholder="Ej.: 0,5 · 1/2 · 5e-1"
            />
            <Label muted style={{ fontSize: 13 }}>
              Unidad de referencia: {exercise.unit || "sin unidad"}. Tolerancia:
              ±{exercise.tolerance}. Selecciona la unidad que usas.
            </Label>
            <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
              {Object.keys(exercise.acceptedUnits).map((unit) => (
                <Button
                  key={unit}
                  secondary={map.unit !== unit}
                  disabled={feedback !== null || busy || paused}
                  onPress={() => setAnswer({ value: map.value ?? "", unit })}
                >
                  {unit || "Sin unidad"}
                </Button>
              ))}
            </View>
          </>
        ) : exercise.type === "text" ? (
          <Field
            label="Completa con el término"
            editable={feedback === null && !busy && !paused}
            value={typeof answer === "string" ? answer : ""}
            onChangeText={(value) => {
              if (feedback === null) setAnswer(value);
            }}
          />
        ) : exercise.type === "match" ? (
          <View style={{ gap: 14 }}>
            {exercise.left.map((left) => (
              <Card key={left.id}>
                <Label style={{ fontWeight: "700" }}>{left.text}</Label>
                <View style={{ gap: 8 }}>
                  {right.map((r) => (
                    <Button
                      key={r.id}
                      secondary={map[left.id] !== r.id}
                      disabled={feedback !== null || busy || paused}
                      onPress={() => setAnswer({ ...map, [left.id]: r.id })}
                      label={`${left.text}: ${r.text}`}
                    >
                      {r.text}
                    </Button>
                  ))}
                </View>
              </Card>
            ))}
          </View>
        ) : (
          <View style={{ gap: 10 }}>
            {options.map((option) => {
              const selected = isArray
                ? answer.includes(option.id)
                : answer === option.id;
              return (
                <Pressable
                  accessibilityRole={
                    exercise.type === "multi"
                      ? "checkbox"
                      : exercise.type === "order"
                        ? "button"
                        : "radio"
                  }
                  accessibilityState={{
                    checked: selected,
                    disabled: feedback !== null || busy || paused,
                  }}
                  accessibilityLabel={option.text}
                  aria-checked={
                    exercise.type === "order" ? undefined : selected
                  }
                  disabled={feedback !== null || busy || paused}
                  key={option.id}
                  onPress={() => choose(option.id)}
                  style={({ pressed }) => ({
                    borderWidth: 1.5,
                    borderColor: selected ? theme.accent : theme.border,
                    backgroundColor: selected ? theme.raised : theme.surface,
                    padding: 17,
                    borderRadius: 16,
                    minHeight: 56,
                    opacity: pressed ? 0.8 : 1,
                    flexDirection: "row",
                    gap: 14,
                    alignItems: "center",
                  })}
                >
                  <View
                    style={{
                      borderRadius: exercise.type === "multi" ? 5 : 15,
                      borderWidth: 1,
                      borderColor: selected ? theme.accent : theme.muted,
                      width: 26,
                      height: 26,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Label style={{ fontSize: 12, color: theme.accent }}>
                      {exercise.type === "order" && isArray && selected
                        ? answer.indexOf(option.id) + 1
                        : selected
                          ? "✓"
                          : ""}
                    </Label>
                  </View>
                  <Label style={{ flex: 1 }}>{option.text}</Label>
                </Pressable>
              );
            })}
            {exercise.type === "order" && (
              <>
                <Label muted>
                  Tu secuencia:{" "}
                  {isArray && answer.length
                    ? answer
                        .map(
                          (id) => exercise.items.find((i) => i.id === id)?.text,
                        )
                        .join(" → ")
                    : "Toca los pasos en el orden que propones."}
                </Label>
                <Button
                  secondary
                  disabled={feedback !== null || busy || paused}
                  onPress={() => setAnswer([])}
                >
                  Vaciar secuencia
                </Button>
              </>
            )}
          </View>
        )}
        {feedback === null && (
          <>
            <Button
              secondary
              disabled={busy || paused || hintCount >= exercise.hints.length}
              onPress={() =>
                change((c) => ({ ...c, hintCount: c.hintCount + 1 }))
              }
            >
              Ver pista {Math.min(hintCount + 1, exercise.hints.length)} de{" "}
              {exercise.hints.length}
            </Button>
            {exercise.hints.slice(0, hintCount).map((hint, i) => (
              <Label key={i} muted style={{ fontSize: 14 }}>
                {exercise.hintExample ? `Pista ${i + 1}: ` : ""}
                {hint}
              </Label>
            ))}
            {exercise.hintExample && hintCount >= exercise.hints.length && (
              <Card>
                <Heading small>{exercise.hintExample.title}</Heading>
                {exercise.hintExample.steps.map((step, i) => (
                  <Label key={i}>
                    {i + 1}. {step}
                  </Label>
                ))}
              </Card>
            )}
            {exercise.hintExample && hintCount > 0 && (
              <Label muted>
                Esta respuesta contará como práctica con ayuda.
              </Label>
            )}
            <Button
              testID="check-answer"
              disabled={!ready || paused}
              busy={busy}
              onPress={() => void submit()}
            >
              Comprobar respuesta
            </Button>
          </>
        )}
        {onCheckpoint && (
          <Label muted style={{ fontSize: 12 }} accessibilityRole={undefined}>
            {saving
              ? "Guardando cambios…"
              : error
                ? "Cambios pendientes"
                : "Cambios guardados"}
          </Label>
        )}
        {!!error && <Label style={{ color: theme.danger }}>{error}</Label>}
        {feedback !== null && (
          <Card style={{ borderColor: feedback ? theme.accent : theme.warm }}>
            <Heading small>
              {feedback ? "Bien razonado" : "Una oportunidad para conectar"}
            </Heading>
            {!feedback && (
              <Label style={{ fontWeight: "700" }}>
                Solución: {solution(exercise)}
              </Label>
            )}
            {!feedback && (
              <>
                {misconceptionFeedback(exercise, answer).map((message, i) => (
                  <Label key={i}>{message}</Label>
                ))}
              </>
            )}
            <Label>{exercise.explanation.correct}</Label>
            {!feedback && (
              <PatternSupport exercise={exercise} answer={answer} />
            )}
            {(hintCount > 0 || attemptNo > 0) && (
              <Label muted>
                Intento con ayuda: suma práctica, no evidencia independiente.
              </Label>
            )}
            {canRemediate && !feedback && remedy?.needed && (
              <>
                <Label style={{ fontWeight: "700" }}>
                  Construyamos el puente
                </Label>
                <Label>{remedy.explanation}</Label>
                <Label muted>{remedy.example}</Label>
                {remedy.prerequisiteIds.map((id) => (
                  <Label key={id} muted>
                    Base relacionada: {conceptById[id]?.title}
                  </Label>
                ))}
                {remedy.easier && !bridge && !bridgeDone && (
                  <Button
                    secondary
                    disabled={busy || paused}
                    onPress={() => {
                      if (remedy?.easier)
                        change((c) => ({
                          ...c,
                          bridge: {
                            exerciseId: remedy.easier!.id,
                            card: emptyCheckpoint(remedy.easier!),
                          },
                        }));
                    }}
                  >
                    Resolver un paso más sencillo
                  </Button>
                )}
                {bridge && remedy.easier && (
                  <ExerciseCard
                    key={remedy.easier.id}
                    exercise={remedy.easier}
                    ref={bridgeRef}
                    paused={paused}
                    checkpoint={card.bridge?.card}
                    onCheckpoint={
                      onCheckpoint
                        ? async (child) => {
                            await edit((c) => ({
                              ...c,
                              bridge: {
                                exerciseId: remedy.easier!.id,
                                card: child,
                              },
                            }));
                          }
                        : undefined
                    }
                    onSubmit={async (e, a, h, n) => {
                      const result = await onSubmit(
                        e,
                        a,
                        h,
                        `bridge-${attemptNo}-${n}`,
                      );
                      await edit(
                        (c) => ({
                          ...c,
                          bridge: c.bridge
                            ? {
                                ...c.bridge,
                                card: {
                                  ...c.bridge.card,
                                  submittedAttemptId: result.id,
                                },
                              }
                            : null,
                        }),
                        false,
                      );
                      return result;
                    }}
                    canRemediate={false}
                    onContinue={async () => {
                      await edit((c) => ({
                        ...c,
                        bridge: null,
                        bridgeDone: true,
                      }));
                    }}
                  />
                )}
                {bridgeDone && (
                  <Button
                    secondary
                    disabled={busy || saving || paused}
                    onPress={() =>
                      change((c) => ({
                        ...c,
                        submittedAttemptId: null,
                        attemptNo: c.attemptNo + 1,
                      }))
                    }
                  >
                    Volver al problema original
                  </Button>
                )}
              </>
            )}
            {!bridge && (
              <Button
                testID="continue-question"
                disabled={paused}
                busy={busy}
                onPress={() => void continueQuestion()}
              >
                Continuar
              </Button>
            )}
          </Card>
        )}
      </View>
    );
  },
);
