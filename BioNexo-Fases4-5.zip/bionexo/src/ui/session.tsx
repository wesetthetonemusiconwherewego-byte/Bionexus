import React, { useRef, useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import type { Answer, Exercise, Lesson } from "../domain/models";
import {
  completeLesson,
  diagnosticResult,
  recordAttempt,
} from "../domain/learning";
import {
  advanceLessonSession,
  discardLessonSession,
  saveLessonCheckpoint,
  sessionMatchesLesson,
  submitLessonAnswer,
} from "../domain/sessions";
import { grade } from "../domain/answers";
import { stageAt } from "../domain/lesson-stages";
import type { ReviewSuggestion } from "../domain/guidance";
import { ReviewReason } from "./guidance";
import { conceptById } from "../content";
import { useApp } from "./provider";
import {
  Button,
  Card,
  Eyebrow,
  Heading,
  Label,
  Meter,
  Page,
  ScienceArt,
} from "./components";
import { ExerciseCard, type ExerciseCardHandle } from "./exercise";
export function StudySession({
  exercises,
  title,
  mode,
  lesson,
  reviewSuggestions,
}: {
  exercises: Exercise[];
  title: string;
  mode: "lesson" | "review" | "diagnostic";
  lesson?: Lesson;
  reviewSuggestions?: ReviewSuggestion[];
}) {
  const { state, update, theme, error } = useApp();
  const saved =
    mode === "lesson" && lesson
      ? state?.lessonSessions?.[lesson.id]
      : undefined;
  const [localIndex, setIndex] = useState(saved?.index ?? 0),
    [done, setDone] = useState(false),
    [finishing, setFinishing] = useState(false),
    [failed, setFailed] = useState(false);
  const session = useRef(
    saved?.id ?? `${mode}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  );
  const lock = useRef(false);
  const exerciseRef = useRef<ExerciseCardHandle>(null);
  const [cancel, setCancel] = useState(false),
    [exitError, setExitError] = useState("");
  const index = saved?.index ?? localIndex;
  const current = exercises[index];
  const stage = lesson ? stageAt(lesson, index) : undefined;
  const reviewSuggestion = reviewSuggestions?.find(
    (s) => s.exercise.id === current?.id,
  );
  const submit = async (
    e: Exercise,
    answer: Answer,
    hinted: boolean,
    attemptNo: string,
  ) => {
    const nextState = await update((s) =>
      mode === "lesson" && lesson
        ? submitLessonAnswer(
            s,
            lesson,
            session.current,
            index,
            e,
            answer,
            hinted,
            attemptNo,
            new Date().toISOString(),
          )
        : recordAttempt(s, {
            id: `${session.current}:${e.id}:${attemptNo}`,
            exerciseId: e.id,
            conceptIds: e.conceptIds,
            answer,
            correct: grade(e, answer),
            at: new Date().toISOString(),
            mode,
            hinted,
          }),
    );
    return nextState.attempts.find(
      (a) => a.id === `${session.current}:${e.id}:${attemptNo}`,
    )!;
  };
  const next = async () => {
    if (lock.current) return;
    lock.current = true;
    if (mode === "lesson" && lesson) {
      setFinishing(true);
      setFailed(false);
      try {
        await update((s) =>
          advanceLessonSession(
            s,
            lesson,
            session.current,
            index,
            new Date().toISOString(),
          ),
        );
        if (index === exercises.length - 1) setDone(true);
        else setIndex(index + 1);
      } catch {
        setFailed(true);
      } finally {
        setFinishing(false);
        lock.current = false;
      }
      return;
    }
    if (index < exercises.length - 1) {
      setIndex(index + 1);
      queueMicrotask(() => {
        lock.current = false;
      });
      return;
    }
    setFinishing(true);
    setFailed(false);
    try {
      await update((s) =>
        mode === "lesson" && lesson
          ? completeLesson(s, lesson, session.current)
          : mode === "diagnostic"
            ? {
                ...s,
                diagnostic: diagnosticResult(
                  s.attempts.filter((a) =>
                    a.id.startsWith(session.current + ":"),
                  ),
                  new Date().toISOString(),
                ),
              }
            : s,
      );
      setDone(true);
    } catch {
      setFailed(true);
    } finally {
      setFinishing(false);
      lock.current = false;
    }
  };
  const latest = exercises.map((e) =>
    [...(state?.attempts ?? [])]
      .reverse()
      .find(
        (a) => a.exerciseId === e.id && a.id.startsWith(session.current + ":"),
      ),
  );
  const exit = async (discard = false) => {
    if (lock.current) return;
    lock.current = true;
    setFinishing(true);
    setExitError("");
    try {
      if (discard) await exerciseRef.current?.flush().catch(() => undefined);
      else await exerciseRef.current?.flush();
      if (discard && lesson)
        await update((s) =>
          discardLessonSession(s, lesson.id, session.current),
        );
      router.replace("/");
    } catch {
      setExitError(
        "No se pudo guardar la salida. Reintenta; tu progreso confirmado se conserva.",
      );
    } finally {
      lock.current = false;
      setFinishing(false);
    }
  };
  if (lesson && saved && !sessionMatchesLesson(saved, lesson))
    return (
      <Page>
        <Heading>La lección cambió</Heading>
        <Label>
          Conservamos tu sesión anterior. Puedes exportarla desde Configuración
          o descartar solo su punto de reanudación; tus intentos y XP se
          mantienen.
        </Label>
        <Button secondary onPress={() => router.replace("/")}>
          Volver
        </Button>
        {!cancel ? (
          <Button secondary onPress={() => setCancel(true)}>
            Descartar sesión anterior
          </Button>
        ) : (
          <>
            <Button busy={finishing} onPress={() => void exit(true)}>
              Confirmar descarte de sesión
            </Button>
            <Button secondary onPress={() => setCancel(false)}>
              Conservar sesión
            </Button>
          </>
        )}
        {!!exitError && <Label>{exitError}</Label>}
      </Page>
    );
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }}>
      <Page>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Button secondary disabled={finishing} onPress={() => void exit()}>
            Salir
          </Button>
          <Label style={{ flex: 1, fontWeight: "700" }}>{title}</Label>
        </View>
        {mode === "lesson" && !done && (
          <>
            <Label muted>
              Al salir conservamos tu punto y las respuestas confirmadas.
            </Label>
            {!cancel ? (
              <Button
                secondary
                disabled={finishing}
                onPress={() => setCancel(true)}
              >
                Descartar sesión
              </Button>
            ) : (
              <Card>
                <Label>
                  Se eliminará solo este punto de reanudación. Tus intentos, XP
                  y otras lecciones se conservan.
                </Label>
                <Button disabled={finishing} onPress={() => void exit(true)}>
                  Confirmar descarte de sesión
                </Button>
                <Button secondary onPress={() => setCancel(false)}>
                  Conservar sesión
                </Button>
              </Card>
            )}
          </>
        )}
        {!!exitError && <Label>{exitError}</Label>}
        {error && (
          <Label accessibilityRole={undefined} style={{ color: theme.danger }}>
            {error}
          </Label>
        )}
        {done ? (
          <>
            <View style={{ alignItems: "center" }}>
              <ScienceArt compact />
            </View>
            <Eyebrow>UNA CONEXIÓN MÁS</Eyebrow>
            <Heading>
              {mode === "diagnostic"
                ? "Tu punto de partida está listo"
                : "Expedición completada"}
            </Heading>
            <Card>
              <Label>
                {latest.filter((a) => a?.correct).length} / {exercises.length}{" "}
                respuestas finales correctas.
              </Label>
              <Label muted>
                {mode === "diagnostic"
                  ? "Usaremos esta muestra breve para sugerir bases que conviene reforzar. No otorga dominio ni XP."
                  : "Tu progreso y calendario de repasos ya están guardados. Volver en otros días ayuda a consolidar las ideas."}
              </Label>
              {mode !== "diagnostic" && (
                <Label>
                  {state?.xp ?? 0} XP acumulado en tu perfil. Cada ejercicio
                  correcto otorga XP una sola vez; las variantes de una familia
                  comparten su premio.
                </Label>
              )}
            </Card>
            {mode === "lesson" && lesson && (
              <Card>
                <Heading small>Qué conectaste hoy</Heading>
                <Label>{lesson.summary}</Label>
                <Label muted>{lesson.application}</Label>
              </Card>
            )}
            {mode === "diagnostic" && state?.diagnostic && (
              <Card>
                <Heading small>Bases para reforzar</Heading>
                <Label>
                  {state.diagnostic.weakConceptIds.length
                    ? state.diagnostic.weakConceptIds
                        .map((id) => conceptById[id]?.title ?? id)
                        .join(" · ")
                    : "Esta muestra no detectó errores. Puedes explorar la ruta y comprobar tus bases con lecciones completas."}
                </Label>
                <Label muted>
                  El diagnóstico puede repetirse desde Configuración.
                </Label>
              </Card>
            )}
            <Button onPress={() => router.replace("/?tab=progress")}>
              Ver mi progreso
            </Button>
            <Button secondary onPress={() => router.replace("/?tab=learn")}>
              Volver al mapa
            </Button>
          </>
        ) : !current ? (
          <>
            <Heading>No hay ejercicios pendientes</Heading>
            <Label>
              Completa lecciones o vuelve cuando llegue tu próximo repaso.
            </Label>
            <Button onPress={() => router.replace("/?tab=practice")}>
              Volver a práctica
            </Button>
          </>
        ) : (
          <>
            <View style={{ gap: 8 }}>
              <Eyebrow>
                {mode === "diagnostic"
                  ? "ORIENTACIÓN INICIAL"
                  : mode === "review"
                    ? "PRÁCTICA INTERCALADA"
                    : "TU EXPEDICIÓN"}
              </Eyebrow>
              <Meter
                value={index / exercises.length}
                label="Progreso de la sesión"
              />
              <Label muted style={{ fontSize: 12 }}>
                RETO {index + 1} DE {exercises.length}
              </Label>
            </View>
            {stage && (
              <Card>
                <Eyebrow>
                  TRAMO {stage.index + 1} DE {stage.total}
                </Eyebrow>
                <Heading small>{stage.stage.title}</Heading>
                <Label>{stage.stage.objective}</Label>
                <Label muted>{stage.stage.explanation}</Label>
                <Heading small>{stage.stage.example.title}</Heading>
                {stage.stage.example.steps.map((step, i) => (
                  <Label key={i}>
                    {i + 1}. {step}
                  </Label>
                ))}
              </Card>
            )}
            {reviewSuggestion && <ReviewReason suggestion={reviewSuggestion} />}
            <ExerciseCard
              ref={exerciseRef}
              paused={finishing || cancel}
              key={`${session.current}:${current.id}`}
              checkpoint={saved?.card}
              onCheckpoint={
                mode === "lesson" && lesson && !done
                  ? async (card) => {
                      await update((s) =>
                        saveLessonCheckpoint(
                          s,
                          lesson,
                          session.current,
                          index,
                          card,
                          new Date().toISOString(),
                        ),
                      );
                    }
                  : undefined
              }
              exercise={current}
              onSubmit={submit}
              onContinue={() => void next()}
              canRemediate={mode !== "diagnostic"}
            />
            {finishing && <Label>Guardando resumen…</Label>}
            {failed && (
              <Button secondary onPress={() => void next()}>
                Reintentar guardar el resumen
              </Button>
            )}
          </>
        )}
      </Page>
    </SafeAreaView>
  );
}
