export interface PlotPoint {
  x: number;
  y: number;
}
/** Shared visual coordinates; no changes to scientific model data. */
export function plotGeometry(
  points: readonly PlotPoint[],
  comparison: readonly PlotPoint[] = [],
) {
  const all = [...points, ...comparison];
  if (
    !points.length ||
    all.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y))
  )
    return null;
  const minX = Math.min(...all.map((p) => p.x)),
    maxX = Math.max(...all.map((p) => p.x));
  const minY = Math.min(0, ...all.map((p) => p.y)),
    maxY = Math.max(1, ...all.map((p) => p.y));
  return {
    minX,
    maxX,
    minY,
    maxY,
    x: (n: number) => 44 + ((n - minX) / (maxX - minX || 1)) * 280,
    y: (n: number) => 170 - ((n - minY) / (maxY - minY || 1)) * 130,
  };
}
/** Avoid integer rounding that can turn a half-step into a false axis value. */
export function plotTick(value: number): string {
  if (value !== 0 && (Math.abs(value) < 0.01 || Math.abs(value) >= 10000))
    return value.toExponential(2).replace(".", ",");
  return value.toLocaleString("es-CL", { maximumSignificantDigits: 4 });
}
