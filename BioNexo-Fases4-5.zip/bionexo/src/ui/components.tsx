import React from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
  type TextStyle,
  type ViewStyle,
} from "react-native";
import Svg, {
  Circle,
  Ellipse,
  Line,
  Path,
  Polyline,
  Rect,
  Text as SvgText,
} from "react-native-svg";
import { useApp } from "./provider";
import { plotGeometry, plotTick } from "./plot-geometry";
export function Label({
  children,
  muted = false,
  style,
  accessibilityRole,
}: {
  children: React.ReactNode;
  muted?: boolean;
  style?: TextStyle;
  accessibilityRole?: "header";
}) {
  const { theme } = useApp();
  return (
    <Text
      accessibilityRole={accessibilityRole}
      style={{
        color: muted ? theme.muted : theme.text,
        fontSize: 16,
        lineHeight: 25,
        ...style,
      }}
    >
      {children}
    </Text>
  );
}
export function Heading({
  children,
  small = false,
}: {
  children: React.ReactNode;
  small?: boolean;
}) {
  return (
    <Label
      accessibilityRole="header"
      style={{
        fontSize: small ? 22 : 32,
        lineHeight: small ? 30 : 40,
        fontWeight: "700",
        letterSpacing: -0.7,
      }}
    >
      {children}
    </Label>
  );
}
export function Eyebrow({ children }: { children: React.ReactNode }) {
  const { theme } = useApp();
  return (
    <Label
      style={{
        fontSize: 11,
        fontWeight: "800",
        letterSpacing: 2,
        color: theme.accent,
      }}
    >
      {children}
    </Label>
  );
}
export function Button({
  children,
  onPress,
  secondary = false,
  disabled = false,
  busy = false,
  testID,
  style,
  label,
}: {
  children: React.ReactNode;
  onPress: () => void;
  secondary?: boolean;
  disabled?: boolean;
  busy?: boolean;
  testID?: string;
  style?: ViewStyle;
  label?: string;
}) {
  const { theme } = useApp();
  const [focused, setFocused] = React.useState(false);
  return (
    <Pressable
      testID={testID}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      accessibilityRole="button"
      accessibilityLabel={
        label ?? (typeof children === "string" ? children : undefined)
      }
      accessibilityState={{ disabled: disabled || busy, busy }}
      disabled={disabled || busy}
      onPress={onPress}
      style={({ pressed }) => ({
        minHeight: 50,
        maxWidth: "100%",
        flexShrink: 1,
        outlineStyle: "solid",
        outlineWidth: focused ? 3 : 0,
        outlineColor: theme.warm,
        paddingHorizontal: 20,
        paddingVertical: 12,
        borderRadius: 16,
        backgroundColor: secondary ? theme.raised : theme.accent,
        borderWidth: 1,
        borderColor: secondary ? theme.muted : theme.accent,
        opacity: disabled || busy ? 0.5 : pressed ? 0.8 : 1,
        alignItems: "center",
        justifyContent: "center",
        ...style,
      })}
    >
      {busy ? (
        <ActivityIndicator color={theme.text} />
      ) : (
        <Text
          style={{
            color: secondary ? theme.text : theme.accentText,
            fontSize: 15,
            fontWeight: "700",
            textAlign: "center",
          }}
        >
          {children}
        </Text>
      )}
    </Pressable>
  );
}
export function Card({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: ViewStyle;
}) {
  const { theme } = useApp();
  return (
    <View
      style={{
        backgroundColor: theme.surface,
        borderWidth: 1,
        borderColor: theme.border,
        borderRadius: 22,
        padding: 20,
        gap: 12,
        ...style,
      }}
    >
      {children}
    </View>
  );
}
export function Field({
  label,
  value,
  onChangeText,
  multiline = false,
  placeholder,
  maxLength = 2000,
  testID,
  editable = true,
}: {
  label: string;
  value: string;
  onChangeText: (x: string) => void;
  multiline?: boolean;
  placeholder?: string;
  maxLength?: number;
  testID?: string;
  editable?: boolean;
}) {
  const { theme } = useApp();
  return (
    <View style={{ gap: 8 }}>
      <Label style={{ fontSize: 14, fontWeight: "600" }}>{label}</Label>
      <TextInput
        testID={testID}
        accessibilityLabel={label}
        value={value}
        onChangeText={onChangeText}
        multiline={multiline}
        maxLength={maxLength}
        editable={editable}
        placeholder={placeholder}
        placeholderTextColor={theme.muted}
        style={{
          color: theme.text,
          backgroundColor: theme.bg,
          borderColor: theme.muted,
          borderWidth: 1,
          borderRadius: 14,
          padding: 15,
          minHeight: 50,
          textAlignVertical: multiline ? "top" : "center",
          ...(multiline ? { minHeight: 100 } : {}),
        }}
      />
    </View>
  );
}
export function Meter({
  value,
  label,
  color,
}: {
  value: number;
  label: string;
  color?: string;
}) {
  const { theme } = useApp();
  return (
    <View
      accessibilityRole="progressbar"
      accessibilityLabel={label}
      accessibilityValue={{
        min: 0,
        max: 100,
        now: Math.round(Math.max(0, Math.min(1, value)) * 100),
      }}
      style={{
        height: 7,
        backgroundColor: theme.raised,
        borderRadius: 8,
        overflow: "hidden",
      }}
    >
      <View
        style={{
          height: 7,
          width: `${Math.min(100, Math.max(0, value * 100))}%`,
          backgroundColor: color ?? theme.accent,
          borderRadius: 8,
        }}
      />
    </View>
  );
}
export function Chip({
  children,
  color,
}: {
  children: React.ReactNode;
  color?: string;
}) {
  const { theme } = useApp();
  return (
    <View
      style={{
        borderRadius: 8,
        maxWidth: "100%",
        flexShrink: 1,
        paddingHorizontal: 9,
        paddingVertical: 4,
        backgroundColor: theme.raised,
        alignSelf: "flex-start",
      }}
    >
      <Label
        style={{
          fontSize: 11,
          lineHeight: 18,
          fontWeight: "700",
          color: color ?? theme.accent,
        }}
      >
        {children}
      </Label>
    </View>
  );
}
export function Icon({
  name,
  size = 24,
  color,
}: {
  name: string;
  size?: number;
  color?: string;
}) {
  const { theme } = useApp();
  const stroke = color ?? theme.accent;
  const common = {
    stroke,
    strokeWidth: 1.7,
    fill: "none",
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  return (
    <Svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
    >
      {name === "home" ? (
        <>
          <Path d="M3 11 12 3 21 11M5 10v10h5v-6h4v6h5V10" {...common} />
        </>
      ) : name === "flask" || name === "lab" ? (
        <>
          <Path
            d="M9 3h6M10 3v6L4 19q-1 2 2 2h12q3 0 2-2L14 9V3M7 15h10"
            {...common}
          />
          <Circle cx="11" cy="17" r="1" fill={stroke} />
        </>
      ) : name === "cell" ? (
        <>
          <Ellipse cx="12" cy="12" rx="9" ry="8" {...common} />
          <Circle cx="12" cy="11" r="3" {...common} />
          <Path d="m5 13 2 2m9-8 2 2m-4 6 2 1" {...common} />
        </>
      ) : name === "orbit" ? (
        <>
          <Ellipse
            cx="12"
            cy="12"
            rx="10"
            ry="4"
            rotation="45"
            origin="12,12"
            {...common}
          />
          <Ellipse
            cx="12"
            cy="12"
            rx="10"
            ry="4"
            rotation="-45"
            origin="12,12"
            {...common}
          />
          <Circle cx="12" cy="12" r="2" fill={stroke} />
        </>
      ) : name === "function" ? (
        <>
          <Path d="M6 21c5 0 4-18 9-18h3M5 10h12" {...common} />
        </>
      ) : name === "route" ? (
        <>
          <Circle cx="6" cy="5" r="2" {...common} />
          <Circle cx="18" cy="19" r="2" {...common} />
          <Path d="M6 7v3c0 4 12 0 12 5v2" {...common} />
        </>
      ) : name === "practice" ? (
        <>
          <Path d="M19 8a8 8 0 1 0 1 7M19 3v5h-5" {...common} />
          <Path d="m9 12 2 2 4-4" {...common} />
        </>
      ) : name === "progress" ? (
        <>
          <Path d="M4 20V9m8 11V4m8 16v-7" {...common} />
        </>
      ) : name === "book" ? (
        <>
          <Path
            d="M12 5v16M3 4c4-1 7 0 9 1 3-2 6-2 9-1v15c-3-1-6-1-9 1-3-2-6-2-9-1Z"
            {...common}
          />
        </>
      ) : name === "settings" ? (
        <>
          <Circle cx="12" cy="12" r="4" {...common} />
          <Path
            d="M12 2v3m0 14v3M2 12h3m14 0h3M5 5l2 2m10 10 2 2M5 19l2-2M17 7l2-2"
            {...common}
          />
        </>
      ) : name === "check" ? (
        <Path d="m5 12 4 4L20 5" {...common} />
      ) : (
        <>
          <Path
            d="M8 3c13 5-5 13 8 18M16 3C3 8 21 16 8 21M8 6h8M7 11h10M7 16h10"
            {...common}
          />
        </>
      )}
    </Svg>
  );
}
export function ScienceArt({ compact = false }: { compact?: boolean }) {
  const { theme } = useApp();
  return (
    <Svg
      width={compact ? 130 : 220}
      height={compact ? 130 : 220}
      viewBox="0 0 240 240"
      accessibilityLabel="Ilustración de una célula en exploración"
    >
      <Circle
        cx="120"
        cy="120"
        r="104"
        stroke={theme.border}
        fill="none"
        strokeDasharray="3 9"
      />
      <Circle
        cx="120"
        cy="120"
        r="80"
        fill={theme.raised}
        stroke={theme.border}
      />
      <Ellipse
        cx="120"
        cy="120"
        rx="64"
        ry="48"
        rotation="-24"
        origin="120,120"
        fill="none"
        stroke={theme.accent}
        strokeWidth="2"
      />
      <Ellipse
        cx="116"
        cy="111"
        rx="24"
        ry="22"
        fill={theme.accent}
        opacity="0.16"
      />
      <Circle
        cx="116"
        cy="111"
        r="15"
        fill="none"
        stroke={theme.accent}
        strokeWidth="2"
      />
      <Path
        d="M79 125c5-7 11-2 12 4s-8 11-13 4m64-37c4-5 12 0 10 6s-10 7-13 2m-5 36c7-4 12 1 10 6"
        stroke={theme.bg === "#09151C" ? "#C3A0FF" : "#8051B0"}
        strokeWidth="3"
        fill="none"
      />
      <Circle cx="51" cy="50" r="6" fill={theme.accent} />
      <Circle cx="197" cy="148" r="8" fill="#C3A0FF" />
      <Circle cx="159" cy="211" r="4" fill="#FFC28D" />
      <Line x1="51" y1="50" x2="83" y2="80" stroke={theme.border} />
      <Line x1="180" y1="142" x2="211" y2="155" stroke={theme.border} />
      <SvgText x="181" y="50" fill={theme.muted} fontSize="10">
        01 / CELL
      </SvgText>
    </Svg>
  );
}
export function Plot({
  points,
  comparison,
  xLabel,
  yLabel,
  marker,
  color,
}: {
  points: { x: number; y: number }[];
  comparison?: { x: number; y: number }[];
  xLabel: string;
  yLabel: string;
  marker?: { x: number; y: number };
  color?: string;
}) {
  const { theme } = useApp();
  const geometry = plotGeometry(points, comparison);
  if (!geometry)
    return <Label>No hay datos válidos para representar este gráfico.</Label>;
  const { minX, maxX, minY, maxY, x, y } = geometry;
  return (
    <View>
      <Label muted style={{ fontSize: 14 }}>
        Eje horizontal: {xLabel}. Eje vertical: {yLabel}.
      </Label>
      <Svg
        width="100%"
        height={220}
        viewBox="0 0 360 220"
        accessibilityLabel={`${yLabel} en función de ${xLabel}`}
      >
        {[0, 0.5, 1].map((t) => (
          <React.Fragment key={t}>
            <Line
              x1="44"
              x2="324"
              y1={170 - t * 130}
              y2={170 - t * 130}
              stroke={theme.border}
              strokeDasharray="3 4"
            />
            <SvgText
              x="36"
              y={174 - t * 130}
              textAnchor="end"
              fill={theme.muted}
              fontSize="10"
            >
              {plotTick(minY + t * (maxY - minY))}
            </SvgText>
          </React.Fragment>
        ))}
        <Line x1="44" x2="324" y1="170" y2="170" stroke={theme.muted} />
        <Line x1="44" x2="44" y1="40" y2="170" stroke={theme.muted} />
        <Polyline
          points={points.map((p) => `${x(p.x)},${y(p.y)}`).join(" ")}
          fill="none"
          stroke={color ?? theme.accent}
          strokeWidth="3"
        />
        {comparison && (
          <Polyline
            points={comparison.map((p) => `${x(p.x)},${y(p.y)}`).join(" ")}
            fill="none"
            stroke={theme.bg === "#09151C" ? "#C3A0FF" : "#8051B0"}
            strokeWidth="2"
            strokeDasharray="5 4"
          />
        )}
        {marker && (
          <Line
            x1={x(marker.x)}
            x2={x(marker.x)}
            y1="40"
            y2="170"
            stroke={theme.muted}
            strokeDasharray="2 4"
          />
        )}
        {marker && (
          <Circle
            cx={x(marker.x)}
            cy={y(marker.y)}
            r="5"
            fill={theme.warm}
            stroke={theme.bg}
            strokeWidth="2"
          />
        )}
        <SvgText x="44" y="190" fill={theme.muted} fontSize="11">
          {minX}
        </SvgText>
        <SvgText
          x="324"
          y="190"
          textAnchor="end"
          fill={theme.muted}
          fontSize="11"
        >
          {maxX}
        </SvgText>
        <SvgText
          x="184"
          y="212"
          textAnchor="middle"
          fill={theme.muted}
          fontSize="11"
        >
          {xLabel}
        </SvgText>
        <SvgText x="44" y="23" fill={theme.muted} fontSize="11">
          {yLabel}
        </SvgText>
      </Svg>
      <Label muted style={{ fontSize: 14 }}>
        Rango horizontal: {minX} a {maxX}. Rango vertical: {minY} a {maxY}.
      </Label>
    </View>
  );
}
export function Page({ children }: { children: React.ReactNode }) {
  const { theme } = useApp();
  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: theme.bg }}
      contentContainerStyle={{
        padding: 20,
        paddingBottom: 48,
        alignSelf: "center",
        width: "100%",
        maxWidth: 850,
        gap: 20,
      }}
      keyboardShouldPersistTaps="handled"
    >
      {children}
    </ScrollView>
  );
}
