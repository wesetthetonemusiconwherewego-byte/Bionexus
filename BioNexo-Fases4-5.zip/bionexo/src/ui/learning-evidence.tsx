import React from "react";
import { router } from "expo-router";
import { catalog, conceptById, lessonById } from "../content";
import type { Answer, Exercise, TransferActivity } from "../domain/models";
import {
  matchingMisconceptions,
  misconceptionEvidence,
  transferEvidence,
} from "../domain/misconceptions";
import { useApp } from "./provider";
import { Button, Card, Heading, Label } from "./components";

export function PatternSupport({
  exercise,
  answer,
}: {
  exercise: Exercise;
  answer: Answer;
}) {
  const { state } = useApp();
  const rule = matchingMisconceptions(exercise, answer)[0];
  if (!rule || !state) return null;
  const count =
    misconceptionEvidence(state).find((e) => e.rule.id === rule.id)?.count ?? 0;
  return (
    <Card>
      <Heading small>Una idea para revisar: {rule.title}</Heading>
      <Label>{rule.explanation}</Label>
      {count >= 2 && (
        <Label>
          Esta regla coincide con {count} intentos incorrectos de tu historial.
          Puedes reconstruir la base antes de volver.
        </Label>
      )}
      <Label muted>
        Es una coincidencia con una regla educativa; no un diagnóstico de tu
        capacidad.
      </Label>
      {rule.example.steps.map((step, i) => (
        <Label key={i}>
          {i + 1}. {step}
        </Label>
      ))}
      {rule.prerequisiteIds
        .filter((id) => lessonById[id + "-lesson"])
        .map((id) => (
          <Button
            key={id}
            secondary
            onPress={() => router.push(`/lesson/${id}-lesson`)}
          >
            Revisar base: {conceptById[id]?.title}
          </Button>
        ))}
    </Card>
  );
}
export function PatternHistory() {
  const { state } = useApp();
  const observations = state ? misconceptionEvidence(state).slice(0, 4) : [];
  if (!observations.length) return null;
  return (
    <Card>
      <Heading small>Patrones de tus respuestas</Heading>
      <Label muted>
        Reglas actuales aplicadas a errores guardados; no cambian tus resultados
        ni miden tu capacidad actual.
      </Label>
      {observations.map(({ rule, count }) => (
        <Label key={rule.id}>
          {rule.title}: {count} {count === 1 ? "intento" : "intentos"} con
          coincidencia.
        </Label>
      ))}
      <Label muted>
        Fuentes de las reglas:{" "}
        {catalog.sources.find((s) => s.id === "factoring-ref")?.title}. Revisión
        humana pendiente.
      </Label>
    </Card>
  );
}
export function TransferEvidence({ activity }: { activity: TransferActivity }) {
  const { state } = useApp();
  if (!state) return null;
  const evidence = transferEvidence(state, activity);
  return (
    <Card>
      <Heading small>
        {activity.id === "project-dilution-v1"
          ? activity.title
          : "Transferencia: señales simuladas"}
      </Heading>
      <Label>
        Muestra inicial: {evidence.firstIndependentCorrect}/{evidence.total}{" "}
        retos resueltos sin pistas.
      </Label>
      <Label muted>
        {evidence.answered}/{evidence.total} respondidos ·{" "}
        {evidence.firstHelped} con ayuda en su primera respuesta ·{" "}
        {evidence.latestCorrect}/{evidence.total} respuestas más recientes
        correctas.
      </Label>
      <Label muted>
        La muestra conserva la primera respuesta de cada reto. Practicar después
        muestra tu avance sin reemplazarla. Este recorrido no mide capacidad
        universitaria ni garantizan dominio.
      </Label>
      <Button
        secondary
        onPress={() =>
          router.push(
            activity.id === "project-dilution-v1" ? "/project" : "/transfer",
          )
        }
      >
        {activity.id === "project-dilution-v1"
          ? "Volver al proyecto interdisciplinario"
          : "Practicar transferencia"}
      </Button>
    </Card>
  );
}
