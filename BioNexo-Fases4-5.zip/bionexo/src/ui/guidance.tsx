import React from "react";
import { View } from "react-native";
import { conceptById } from "../content";
import type { LessonSuggestion, ReviewSuggestion } from "../domain/guidance";
import { Card, Heading, Label } from "./components";

export function LessonReason({ suggestion }: { suggestion: LessonSuggestion }) {
  const texts = {
    diagnostic:
      "El diagnóstico breve sugirió reforzar este concepto y sus bases ya están disponibles.",
    "initial-goal":
      "Esta lección pendiente coincide con el objetivo inicial de reforzar álgebra.",
    "math-base":
      "Es una base matemática pendiente con sus prerrequisitos disponibles.",
    "next-available":
      "Es una lección pendiente con sus prerrequisitos disponibles.",
    "free-exploration":
      "No quedan lecciones pendientes con bases disponibles. Puedes volver por curiosidad o practicar otra área.",
  };
  return (
    <View style={{ gap: 6 }}>
      <Label style={{ fontWeight: "700" }}>Por qué esta lección</Label>
      <Label muted>{texts[suggestion.kind]}</Label>
      <Label muted>
        {suggestion.prerequisiteIds.length
          ? `Bases con evidencia suficiente según la regla de avance: ${suggestion.prerequisiteIds.map((id) => conceptById[id]?.title ?? id).join(" · ")}.`
          : "Puedes comenzar sin prerrequisitos en la app."}
      </Label>
      {!!suggestion.supportsConceptIds.length && (
        <Label muted>
          Esta base conecta con:{" "}
          {suggestion.supportsConceptIds
            .map((id) => conceptById[id]?.title ?? id)
            .join(" · ")}
          .
        </Label>
      )}
      {suggestion.relatedPattern && (
        <Label muted>
          También puede ayudarte a revisar «{suggestion.relatedPattern.title}»,
          observado en una respuesta aún pendiente de corregir.
        </Label>
      )}
    </View>
  );
}
function intervalLabel(days: number) {
  if (days >= 1) return `${days.toLocaleString("es-CL")} días`;
  if (days * 24 >= 1) return `${(days * 24).toLocaleString("es-CL")} horas`;
  return `${Math.round(days * 1440).toLocaleString("es-CL")} minutos`;
}
export function ReviewReason({ suggestion }: { suggestion: ReviewSuggestion }) {
  const texts = {
    error: "Un error registrado acortó este repaso.",
    helped: "Un acierto con ayuda propuso un intervalo corto.",
    spaced: "Un acierto sin pistas programó una práctica espaciada.",
    "stored-calendar":
      "La fecha proviene de tu calendario guardado; el historial disponible no permite atribuirla con certeza a un intento.",
  };
  return (
    <Card>
      <Heading small>Por qué aparece este repaso</Heading>
      <Label>
        {conceptById[suggestion.conceptId]?.title ?? suggestion.conceptId}:{" "}
        {texts[suggestion.kind]}
      </Label>
      <Label muted>
        Vencimiento al seleccionar:{" "}
        {new Date(suggestion.dueAt).toLocaleString("es-CL")}. Intervalo
        guardado: {intervalLabel(suggestion.intervalDays)}.
      </Label>
      {!!suggestion.sourceAt && (
        <Label muted>
          Intento que originó esta fecha:{" "}
          {new Date(suggestion.sourceAt).toLocaleString("es-CL")}.
        </Label>
      )}
      <Label muted>
        {suggestion.lapses} errores acumulados en el calendario.
      </Label>
      {suggestion.latestAttempt && (
        <Label muted>
          Respuesta más reciente del concepto:{" "}
          {suggestion.latestAttempt.correct ? "correcta" : "incorrecta"}
          {suggestion.latestAttempt.hinted ? " con ayuda" : " sin pistas"}.
          Puede ser posterior al intento que programó el repaso.
        </Label>
      )}
    </Card>
  );
}
