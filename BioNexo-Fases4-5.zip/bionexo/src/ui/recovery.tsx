import React, { useRef, useState } from "react";
import { View } from "react-native";
import { useApp } from "./provider";
import { Button, Card, Heading, Label } from "./components";
import {
  parseBackup,
  latestValidRecoveryCopy,
} from "../domain/progress-document";
import { exportProgress, importProgress } from "../storage/transfer";
import type { UserState } from "../domain/models";

export function RecoveryPanel() {
  const { error, repository, restore, retry } = useApp();
  const [pending, setPending] = useState<{
      json: string;
      state: UserState;
    } | null>(null),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  const actionLock = useRef(false);
  const action = async (work: () => Promise<void>) => {
    if (actionLock.current) return;
    actionLock.current = true;
    setBusy(true);
    try {
      await work();
    } catch (e) {
      setMessage(
        e instanceof Error
          ? e.message
          : "No se pudo completar la recuperación. Los datos no se han borrado.",
      );
    } finally {
      actionLock.current = false;
      setBusy(false);
    }
  };
  return (
    <View style={{ gap: 18 }}>
      <Heading small>Recupera tu cuaderno</Heading>
      <Label accessibilityRole={undefined}>{error}</Label>
      <Label muted>
        No se ha reiniciado tu progreso. Puedes guardar los datos originales y
        restaurar un respaldo válido. La restauración necesita confirmación y
        conserva una copia de lo reemplazado.
      </Label>
      <Button
        secondary
        disabled={busy || !repository}
        onPress={() =>
          void action(async () => {
            if (!repository) return;
            await exportProgress(
              await repository.exportRescue(),
              "bionexo-rescate.json",
            );
            setMessage(
              "Rescate preparado con los datos originales y las copias disponibles. Guárdalo antes de restaurar.",
            );
          })
        }
      >
        Exportar datos de rescate
      </Button>
      <Button
        secondary
        disabled={busy || !repository}
        onPress={() =>
          void action(async () => {
            setPending(null);
            const json = await importProgress();
            if (json !== null) {
              const state = parseBackup(json);
              setPending({ json, state });
              setMessage(
                "Respaldo válido. Revisa el perfil y confirma para restaurarlo.",
              );
            }
          })
        }
      >
        Elegir respaldo para restaurar
      </Button>
      <Button
        secondary
        disabled={busy || !repository}
        onPress={() =>
          void action(async () => {
            if (!repository) return;
            setPending(null);
            const candidate = latestValidRecoveryCopy(
              await repository.exportRescue(),
            );
            setPending(candidate);
            setMessage(
              candidate
                ? "Encontramos una copia local válida. Revisa el perfil y confirma."
                : "No hay copias locales válidas. Puedes elegir un respaldo guardado.",
            );
          })
        }
      >
        Buscar copia local anterior
      </Button>
      {!repository && (
        <Label muted>
          No se pudo abrir el almacenamiento. No se reemplazó el archivo local.
          Reintenta; si el archivo SQLite está físicamente dañado, necesita
          recuperación fuera de este flujo.
        </Label>
      )}
      {message && <Label>{message}</Label>}
      {pending && (
        <Card>
          <Heading small>Confirma el perfil que recuperarás</Heading>
          <Label>{pending.state.settings.name}</Label>
          <Label>
            {pending.state.xp} XP · {pending.state.attempts.length} intentos ·{" "}
            {pending.state.labs.length} sesiones de laboratorio
          </Label>
          <Label muted>
            El respaldo reemplazará el perfil actual. Su texto original quedará
            en una copia de rescate; no se fusionan perfiles.
          </Label>
          <Button
            busy={busy}
            onPress={() =>
              void action(async () => {
                await restore(pending.json);
              })
            }
          >
            Confirmar restauración del respaldo
          </Button>
          <Button
            secondary
            disabled={busy}
            onPress={() => {
              setPending(null);
              setMessage(
                "Restauración cancelada. Los datos originales siguen intactos.",
              );
            }}
          >
            Cancelar restauración
          </Button>
        </Card>
      )}
      <Button disabled={busy} onPress={retry}>
        Reintentar apertura
      </Button>
      <Label muted style={{ fontSize: 12 }}>
        El archivo de rescate conserva datos incluso dañados; no equivale a un
        respaldo validado. Puedes buscar una copia válida aquí. Los formatos de
        una versión futura requieren una versión compatible de BioNexo.
      </Label>
    </View>
  );
}
