import React from "react";
import { Pressable, View } from "react-native";
import Svg, { Circle, Ellipse, Line } from "react-native-svg";
import { useApp } from "./provider";
import { Label } from "./components";
const regions = [
  {
    id: "a",
    label: "A",
    description: "región circular central",
    top: 12,
    from: [110, 90],
  },
  {
    id: "b",
    label: "B",
    description: "espacio interior que rodea la región central",
    top: 82,
    from: [158, 120],
  },
  {
    id: "c",
    label: "C",
    description: "límite externo de la célula",
    top: 152,
    from: [180, 151],
  },
] as const;
/** Same answer IDs as the existing radios. No organelle name is disclosed. */
export function CellDiagram({
  value,
  onSelect,
  disabled,
}: {
  value: unknown;
  onSelect: (id: string) => void;
  disabled: boolean;
}) {
  const { theme } = useApp();
  const [focused, setFocused] = React.useState<string | null>(null);
  return (
    <View style={{ gap: 12 }}>
      <Label muted>
        Señala una región en el esquema o elige su opción debajo.
      </Label>
      <View
        style={{
          height: 220,
          position: "relative",
          width: "100%",
          maxWidth: 360,
          alignSelf: "center",
        }}
      >
        <Svg
          width="100%"
          height={220}
          viewBox="0 0 320 220"
          preserveAspectRatio="none"
          accessible={false}
          accessibilityElementsHidden
          importantForAccessibility="no-hide-descendants"
        >
          <Ellipse
            cx="105"
            cy="110"
            rx="90"
            ry="75"
            fill={theme.raised}
            stroke={value === "c" ? theme.text : theme.accent}
            strokeWidth={value === "c" ? 5 : 2}
          />
          {value === "b" && (
            <Ellipse
              cx="105"
              cy="110"
              rx="76"
              ry="61"
              fill="none"
              stroke={theme.text}
              strokeWidth={3}
              strokeDasharray="5 4"
            />
          )}
          <Circle
            cx="95"
            cy="110"
            r="27"
            fill={theme.surface}
            stroke={value === "a" ? theme.text : theme.accent}
            strokeWidth={value === "a" ? 5 : 2}
          />
          {regions.map((r) => (
            <Line
              key={r.id}
              x1={r.from[0]}
              y1={r.from[1]}
              x2="250"
              y2={r.top + 28}
              stroke={theme.muted}
              strokeWidth={value === r.id ? 3 : 1}
            />
          ))}
        </Svg>
        {regions.map((r) => (
          <Pressable
            key={r.id}
            onFocus={() => setFocused(r.id)}
            onBlur={() => setFocused(null)}
            accessibilityRole="button"
            accessibilityLabel={`Señalar región ${r.label}`}
            accessibilityHint={r.description}
            accessibilityState={{ selected: value === r.id, disabled }}
            aria-pressed={value === r.id}
            disabled={disabled}
            onPress={() => onSelect(r.id)}
            style={{
              position: "absolute",
              outlineStyle: "solid",
              outlineWidth: focused === r.id ? 3 : 0,
              outlineColor: theme.warm,
              right: 0,
              top: r.top,
              minWidth: 70,
              minHeight: 56,
              borderWidth: value === r.id ? 3 : 1,
              borderColor: value === r.id ? theme.accent : theme.muted,
              borderRadius: 14,
              backgroundColor: theme.surface,
              alignItems: "center",
              justifyContent: "center",
              padding: 8,
            }}
          >
            <Label style={{ fontWeight: "700" }}>
              {value === r.id ? "✓ " : ""}
              {r.label}
            </Label>
          </Pressable>
        ))}
      </View>
      <Label muted>
        Descripción equivalente: A, región circular central; B, espacio interior
        circundante; C, límite externo. Esquema eucarionte simplificado, sin
        escala; se omiten otros orgánulos.
      </Label>
      <Label>
        {regions.some((r) => r.id === value)
          ? `Región seleccionada: ${String(value).toUpperCase()}`
          : "Ninguna región seleccionada."}
      </Label>
    </View>
  );
}
