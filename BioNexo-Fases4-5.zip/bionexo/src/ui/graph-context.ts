/** Navigation-only graph state. Never stores private notes or changes UserState. */
export interface GraphContext {
  ph: number;
  selected: number;
  comparison: boolean;
}
type Parameter = string | string[] | undefined;
export function graphContext(params: {
  ph?: Parameter;
  model?: Parameter;
  compare?: Parameter;
}): GraphContext {
  const raw =
    typeof params.ph === "string" && /^\d{1,2}(?:\.\d)?$/.test(params.ph)
      ? Number(params.ph)
      : 7;
  return {
    ph: raw >= 0 && raw <= 14 ? raw : 7,
    selected: params.model === "acid" ? 1 : 0,
    comparison: params.compare === "1",
  };
}
export function graphParameters(context: GraphContext) {
  return {
    ph: context.ph.toFixed(1),
    model: context.selected === 1 ? "acid" : "neutral",
    compare: context.comparison ? "1" : "0",
  };
}
