import React, { useRef, useState } from "react";
import { Switch, View } from "react-native";
import Slider from "@react-native-community/slider";
import { router, useLocalSearchParams } from "expo-router";
import {
  graphContext,
  graphParameters,
  type GraphContext,
} from "./graph-context";
import { ENZYMES, enzymeActivity, enzymeCurve } from "../domain/laboratory";
import {
  addLabPoint,
  createLabSession,
  saveLabSession,
  labComparisons,
  predictActivity,
  type Prediction,
} from "../domain/lab-notebook";
import { parseNumber } from "../domain/answers";
import { useApp } from "./provider";
import {
  Button,
  Card,
  Chip,
  Eyebrow,
  Field,
  Heading,
  Label,
  Plot,
} from "./components";
import type { LaboratorySession } from "../domain/models";
import guide from "../content/biolab.json";
const sectionRow = {
  flexDirection: "row" as const,
  alignItems: "center" as const,
  justifyContent: "space-between" as const,
  gap: 12,
};
export function Laboratory() {
  const { state, update, theme } = useApp();
  const params = useLocalSearchParams<{
    ph?: string;
    model?: string;
    compare?: string;
  }>();
  const context = graphContext(params);
  const { ph, selected, comparison } = context;
  const setGraph = (change: Partial<GraphContext>) =>
    router.setParams(graphParameters({ ...context, ...change }));
  const setPh = (value: number) => setGraph({ ph: value });
  const [hypothesis, setHypothesis] = useState(""),
    [observation, setObservation] = useState(""),
    [points, setPoints] = useState<LaboratorySession["points"]>([]),
    [savedLimit, setSavedLimit] = useState(5),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  const lock = useRef(false);
  const draftId = useRef(
    `lab-v1-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  );
  const draftAt = useRef(new Date().toISOString());
  const comparisons = labComparisons(points);
  const canSave =
    comparisons.length > 0 && !!hypothesis.trim() && !!observation.trim();
  const enzyme = ENZYMES[selected]!;
  const activity = enzymeActivity(ph, enzyme.optimum, enzyme.width);
  const save = async () => {
    if (lock.current || !canSave) return;
    lock.current = true;
    setBusy(true);
    try {
      const session: LaboratorySession = {
        id: draftId.current,
        at: draftAt.current,
        hypothesis,
        observation,
        points,
      };
      await update((s) => saveLabSession(s, createLabSession(session)));
      draftId.current = `lab-v1-${Date.now()}-${Math.random().toString(36).slice(2)}`;
      draftAt.current = new Date().toISOString();
      setPoints([]);
      setMessage("Sesión guardada en tu cuaderno local.");
    } catch {
      setMessage("No se guardó la sesión. Tus datos siguen en pantalla.");
    } finally {
      lock.current = false;
      setBusy(false);
    }
  };
  return (
    <View style={{ gap: 20 }}>
      <Eyebrow>LABORATORIO VIRTUAL / 01</Eyebrow>
      <Heading>Una enzima.{"\n"}Muchos entornos.</Heading>
      <Label muted>
        Investiga cómo cambia una actividad simulada al modificar el pH.
      </Label>
      <Chip color={theme.warm}>MODELO DIDÁCTICO · DATOS SIMULADOS</Chip>
      <Card>
        <Heading small>Diseña una comparación</Heading>
        <Label>{guide.question}</Label>
        <Label muted>{guide.objective}</Label>
        {guide.variables.map((v) => (
          <View key={v.role}>
            <Label style={{ fontWeight: "700" }}>{v.role}</Label>
            <Label muted>{v.value}</Label>
          </View>
        ))}
        {guide.steps.map((step, i) => (
          <Label key={step}>
            {i + 1}. {step}
          </Label>
        ))}
      </Card>
      <PredictionPanel key={enzyme.id} modelId={enzyme.id} />
      <Card>
        <Heading small>Antes de mover el control</Heading>
        <Field
          label="Tu hipótesis"
          value={hypothesis}
          onChangeText={setHypothesis}
          multiline
          placeholder="Predigo que… porque…"
        />
      </Card>
      <Card>
        <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
          {ENZYMES.map((e, i) => (
            <Button
              key={e.id}
              secondary={i !== selected}
              onPress={() => setGraph({ selected: i })}
            >
              {e.title}
            </Button>
          ))}
        </View>
        <Plot
          points={enzymeCurve(enzyme.optimum, enzyme.width)}
          comparison={
            comparison
              ? enzymeCurve(
                  ENZYMES[1 - selected]!.optimum,
                  ENZYMES[1 - selected]!.width,
                )
              : undefined
          }
          xLabel="pH (sin unidad)"
          yLabel="Actividad relativa (%)"
          marker={{ x: ph, y: activity }}
        />
        <View style={{ ...sectionRow, flexWrap: "wrap" }}>
          <Heading small>pH {ph.toFixed(1)}</Heading>
          <Chip>{activity.toFixed(1)} % de actividad</Chip>
        </View>
        <Slider
          testID="ph-slider"
          accessibilityLabel="pH de la simulación"
          accessibilityValue={{ min: 0, max: 14, now: ph, text: ph.toFixed(1) }}
          minimumValue={0}
          maximumValue={14}
          step={0.1}
          value={ph}
          onValueChange={setPh}
          minimumTrackTintColor={theme.accent}
          maximumTrackTintColor={theme.border}
          thumbTintColor={theme.accent}
          style={{ height: 48 }}
        />
        <View style={{ flexDirection: "row", gap: 10, flexWrap: "wrap" }}>
          <Button
            secondary
            disabled={ph === 0}
            onPress={() => setPh(Math.max(0, Math.round((ph - 0.5) * 10) / 10))}
          >
            −0,5 pH
          </Button>
          <Button
            secondary
            disabled={ph === 14}
            onPress={() =>
              setPh(Math.min(14, Math.round((ph + 0.5) * 10) / 10))
            }
          >
            +0,5 pH
          </Button>
        </View>
        <View style={sectionRow}>
          <Label style={{ flex: 1 }}>
            Comparar segundo modelo (línea discontinua)
          </Label>
          <Switch
            accessibilityLabel="Comparar segundo modelo"
            value={comparison}
            onValueChange={(comparison) => setGraph({ comparison })}
          />
        </View>
        <Label muted>
          Curva continua: {enzyme.title}.{" "}
          {comparison
            ? `Curva discontinua: ${ENZYMES[1 - selected]!.title}.`
            : "Activa la comparación para leer ambos modelos."}
        </Label>
        {comparison && (
          <Label accessibilityRole="header">
            Mismo pH {ph.toFixed(1)}: N {enzymeActivity(ph, 7, 1.5).toFixed(2)}{" "}
            % · A {enzymeActivity(ph, 4, 1.2).toFixed(2)} %. Diferencia N − A:{" "}
            {(enzymeActivity(ph, 7, 1.5) - enzymeActivity(ph, 4, 1.2)).toFixed(
              2,
            )}{" "}
            puntos porcentuales.
          </Label>
        )}
        <Label muted>
          Explora: ¿el modelo con mayor actividad es el mismo en pH 4 y en pH 7?
          Usa los controles y compara las lecturas. Son predicciones simuladas.
        </Label>
        <Button secondary onPress={() => setGraph({ ph: enzyme.optimum })}>
          Ir al óptimo del modelo
        </Button>
        <Label muted>
          pH, modelo y comparación se conservan al navegar o recargar esta
          vista. Guarda la sesión antes de salir para conservar hipótesis,
          observaciones y condiciones registradas.
        </Label>
        <Button
          onPress={() => {
            try {
              const next = addLabPoint(points, ph, enzyme.id);
              setPoints(next);
              setMessage(
                next.length === points.length
                  ? "Esta condición ya está registrada. El cálculo repetido no crea una réplica experimental."
                  : "Condición simulada registrada.",
              );
            } catch (e) {
              setMessage(
                e instanceof Error
                  ? e.message
                  : "No se pudo registrar la condición.",
              );
            }
          }}
        >
          Registrar condición actual
        </Button>
        <Label muted style={{ fontSize: 13 }}>
          Lectura accesible: pH {ph.toFixed(1)} → {activity.toFixed(2)} % (
          {enzyme.title}). No es una medición real.
        </Label>
      </Card>
      <Card>
        <Heading small>Cuaderno de observaciones</Heading>
        {points.length ? (
          points.map((p, i) => (
            <Label key={i} style={{ fontSize: 14 }}>
              {i + 1}. Modelo {p.enzyme === "neutral" ? "N" : "A"} · pH{" "}
              {p.ph.toFixed(1)} → {p.activity.toFixed(2)} %
            </Label>
          ))
        ) : (
          <Label muted>
            Registra al menos dos condiciones para compararlas.
          </Label>
        )}
        <Label muted>
          {comparisons.length
            ? "Hay una comparación de pH dentro del mismo modelo."
            : "Para guardar, registra al menos dos pH distintos de un mismo modelo. Dos modelos al mismo pH responden otra pregunta."}
        </Label>
        {comparisons.map((c) => (
          <Label key={c.first.enzyme}>
            Modelo {c.first.enzyme === "neutral" ? "N" : "A"}: pH {c.first.ph} →{" "}
            {c.second.ph}; diferencia segunda − primera: {c.delta.toFixed(2)}{" "}
            puntos porcentuales. Es cálculo simulado, sin inferencia
            estadística.
          </Label>
        ))}
        <Field
          label="¿Qué observaste? ¿Apoya tu hipótesis?"
          value={observation}
          onChangeText={setObservation}
          multiline
        />
        <Button busy={busy} disabled={!canSave} onPress={() => void save()}>
          Guardar sesión
        </Button>
        {!!message && <Label>{message}</Label>}
      </Card>
      <Card>
        <Heading small>Qué representa el modelo</Heading>
        <Label>A(pH) = 100 × exp[−½((pH − pH óptimo)/σ)²]</Label>
        <Label muted>
          σ = {enzyme.width}. La temperatura, cantidad de enzima y concentración
          de sustrato se suponen constantes. La curva es simétrica por elección
          didáctica. El máximo siempre es 100 % relativo; no equivale a una
          velocidad absoluta.
        </Label>
        <Heading small>Hecho, supuesto y límite</Heading>
        <Label>{guide.facts}</Label>
        <Label muted>{guide.assumptions}</Label>
        <Heading small>Ejemplo desarrollado</Heading>
        {guide.example.map((step) => (
          <Label key={step}>{step}</Label>
        ))}
        <Label muted>
          Fuente: OpenStax Biology 2e §6.5. Redacción propia. Revisión académica
          humana pendiente.
        </Label>
        <Label muted>
          Enzimas reales pueden presentar asimetría, diferentes mecanismos de
          ionización, inactivación irreversible y efectos del entorno. Este
          modelo no los predice y no se ajustó a datos publicados.
        </Label>
      </Card>
      <Heading small>Sesiones guardadas · {state?.labs.length ?? 0}</Heading>
      {state?.labs
        .slice(-savedLimit)
        .reverse()
        .map((l) => (
          <Card key={l.id}>
            <Label style={{ fontWeight: "700" }}>
              {new Date(l.at).toLocaleString("es-CL")}
            </Label>
            <Label>Hipótesis: {l.hypothesis}</Label>
            <Label muted>{l.observation}</Label>
            <Button
              secondary
              onPress={() => router.push(`/lab-session/${l.id}`)}
            >
              Abrir registro guardado
            </Button>
            <Label muted>
              {labComparisons(l.points).length
                ? "Incluye dos pH distintos de un mismo modelo."
                : "Registro previo sin comparación controlada de pH; se conserva íntegro."}
            </Label>
            <Label muted style={{ fontSize: 13 }}>
              {l.points
                .slice(0, 8)
                .map(
                  (p) =>
                    `${p.enzyme} · pH ${p.ph} / ${p.activity.toFixed(1)} %`,
                )
                .join(" · ")}
              {l.points.length > 8
                ? ` · ${l.points.length} condiciones en el registro completo.`
                : ""}
            </Label>
          </Card>
        ))}
      {(state?.labs.length ?? 0) > savedLimit && (
        <Button secondary onPress={() => setSavedLimit((n) => n + 5)}>
          Mostrar 5 registros anteriores
        </Button>
      )}
    </View>
  );
}

function PredictionPanel({ modelId }: { modelId: string }) {
  const [first, setFirst] = useState("6"),
    [second, setSecond] = useState("7"),
    [choice, setChoice] = useState<Prediction | null>(null),
    [result, setResult] = useState("");
  const [revealed, setRevealed] = useState(false);
  const reset = () => {
    setResult("");
    setRevealed(false);
  };
  return (
    <Card>
      <Heading small>Predice antes de calcular</Heading>
      <Label>
        Dentro del modelo {modelId === "neutral" ? "N" : "A"}, ¿la segunda
        actividad será mayor, menor o igual? Elige antes de contrastar. No
        otorga XP ni certifica dominio.
      </Label>
      <Field
        label="pH de la primera condición"
        value={first}
        onChangeText={(v) => {
          setFirst(v);
          reset();
        }}
      />
      <Field
        label="pH de la segunda condición"
        value={second}
        onChangeText={(v) => {
          setSecond(v);
          reset();
        }}
      />
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
        {(
          [
            ["higher", "Mayor"],
            ["lower", "Menor"],
            ["equal", "Igual"],
          ] as const
        ).map(([id, title]) => (
          <Button
            key={id}
            secondary={choice !== id}
            onPress={() => {
              setChoice(id);
              reset();
            }}
            label={`Predicción: ${title}`}
          >
            {title}
            {choice === id ? " ✓" : ""}
          </Button>
        ))}
      </View>
      <Button
        disabled={!choice}
        onPress={() => {
          try {
            const a = parseNumber(first),
              b = parseNumber(second);
            if (a === null || b === null)
              throw Error("Escribe dos pH numéricos entre 0 y 14.");
            const c = predictActivity(modelId, a, b);
            setResult(
              `${choice === c.direction ? "La predicción coincide" : "La predicción no coincide"} con este cálculo. Primera: ${c.first.activity.toFixed(2)}%; segunda: ${c.second.activity.toFixed(2)}%; diferencia: ${c.delta.toFixed(2)} puntos porcentuales. Revisa la distancia al óptimo; esto no valida una enzima real.`,
            );
            setRevealed(true);
          } catch (e) {
            setResult(e instanceof Error ? e.message : "No se pudo calcular.");
            setRevealed(false);
          }
        }}
      >
        Contrastar predicción
      </Button>
      {!!result && <Label>{result}</Label>}
      {revealed && (
        <Label muted>
          Una coincidencia bajo los supuestos es evidencia sobre este modelo
          matemático. Para estudiar enzimas reales se necesitan datos, controles
          y análisis de incertidumbre.
        </Label>
      )}
    </Card>
  );
}
