# BioNexo · ciencia que se conecta

Aplicación móvil educativa **offline-first**, en español, orientada a construir bases para estudiar biotecnología. Android es el objetivo principal; el código también permite iOS. Esta entrega implementa un MVP: **24 lecciones, 146 ejercicios, 12 preguntas diagnósticas y un laboratorio de actividad enzimática/pH**, más práctica parametrizada y un proyecto integrado de seis retos. No es un producto oficial de UNAB, MIT ni OpenStax.

## Evolución a BioNexo 2.0

La aplicación conserva la versión 0.1.0. La Fase 0 incorpora recuperación segura y controles de dependencias; P1-01 añade reanudación persistente de lecciones. La Fase 1 está completada según el plan: P1-02 profundiza factorización en cuatro tramos y ocho retos, incluidos dos de transferencia a un modelo geométrico supuesto; P1-03 añade tres pistas por reto, ejemplos alternativos y feedback por distractor. Las otras 23 lecciones conservan su estructura inicial. La Fase 2 también está completada según el plan: agrega 14 variantes reproducibles, 10 reglas de errores, dos retos de transferencia y razones de repaso/recomendación, además de corregir el evaluador numérico. La Fase 3 añade diagrama celular seleccionable, lecturas comparadas de pH, contexto del gráfico al navegar/recargar y correcciones de foco/reajuste móvil; P3-01/02 DONE y P3-03 TESTING por validación Android pendiente. La Fase 4 agrega diseño experimental guiado, predicciones, cuaderno reabrible y un proyecto interdisciplinario de seis retos. Fase 5 integra regresiones y prepara el artefacto Android; su aceptación nativa y lanzamiento conservan los bloqueos documentados. No equivale a una versión 2.0 validada. Lee [AGENTS.md](AGENTS.md), el [plan por tareas](docs/DEVELOPMENT_PLAN.md), el [estado y evidencia actuales](docs/PROGRESS.md), los [riesgos](docs/RISKS.md), las [decisiones](docs/DECISIONS.md) y el [checklist de entrega](docs/RELEASE_CHECKLIST.md). La arquitectura canónica sigue en [ARQUITECTURA.md](docs/ARQUITECTURA.md), con [índice 2.0](docs/ARCHITECTURE.md).

El informe funcional 2.0 detallado no está incorporado: se usan las fases expresamente solicitadas y se registra lo que falta. Hay 19 entradas altas de dependencias abiertas: el lanzamiento público sigue bloqueado aunque las pruebas funcionales pasen. La revisión permite continuar desarrollo local con controles. Consulta [exposición, límites y comandos de seguridad](docs/DEPENDENCY_SECURITY.md). Compatibilidad de SDK y ausencia de alertas son controles diferentes. No ejecutes `npm audit fix --force` como sustituto de una actualización compatible. Las instrucciones de terminal siguientes son para un entorno de desarrollo; desde un teléfono Android puedes descargar el APK de prueba ARM64 que acompaña esta entrega. Su compilación/firma se verificaron; la instalación y pruebas nativas siguen pendientes.

## Empezar en Windows, Linux o macOS

Requisitos: Node.js 22.13 o superior (recomendado Node 24 LTS), npm y Python 3 solo si se regenera contenido. Instalar dependencias requiere conexión. Estudiar en una aplicación nativa instalada no la requiere.

```bash
npm ci
npm start
```

En PowerShell, si se bloquea `npm.ps1`, usa `npm.cmd ci` y `npm.cmd start` sin cambiar la política global del equipo.

Con Expo Go **compatible con SDK 58**, escanea el QR desde Android. El teléfono debe poder alcanzar el servidor de desarrollo (normalmente ambos equipos en la misma Wi-Fi). Si Expo Go no admite este SDK, utiliza una compilación de desarrollo o un APK local. El servidor de desarrollo necesita estar encendido: Expo Go no es la entrega offline definitiva.

```bash
npm run android       # abre un emulador/dispositivo conectado; requiere SDK Android/adb
npm run web           # vista adaptable en navegador
npm run check         # TypeScript + integridad académica + pruebas de dominio/SQLite
npm run export:android # valida el empaquetado JS y recursos Android; NO genera un APK
npm run export:web
npx playwright install chromium
npm run test:e2e      # pruebas de interfaz web en tamaños móvil y escritorio
```

En Codex Cloud se pueden instalar dependencias, editar, ejecutar pruebas y exportar bundles. Abrir un teléfono/emulador, firmar y distribuir una aplicación son pasos distintos. La vista web usa almacenamiento local del navegador; **Android e iOS usan expo-sqlite**.

## Preparar el paso a Fase 4

La preparación está en [PHASE4_HANDOFF.md](docs/PHASE4_HANDOFF.md), con guía Windows/Android y plantilla de resultados nativos. `npm run android:preflight` identifica herramientas faltantes; `npm run phase4:readiness -- RUTA_DEL_REGISTRO` comprueba su completitud/integridad. Sin pruebas reales debe devolver bloqueo. Este documento conserva la preparación anterior; la autorización posterior para Fases 4/5 está en ADR-013 y PROGRESS. P3-03 sigue TESTING hasta evidencia real. El prebuild incluye expo-system-ui para apariencia automática. El build final y el artefacto verificado están en PROGRESS.

## APK de prueba incluido

Se entrega por separado `BioNexo-Android-ARM64-Prueba.apk` (~32,0 MiB), Android ARM64/minSdk 24, versión 0.1.0/versionCode 1. Build local finalizado, firma v2, alineación 16 KB, contenido incluido y hash verificados; permisos overlay/micrófono/almacenamiento amplio ausentes. SHA-256 `76815af134ab5970269c42ee4153f5a647ad6184965ed9c6ab82ab627b8bbfc2`. Evidencia y certificado en [PROGRESS](docs/PROGRESS.md).

Desde Android, descarga el APK y ábrelo para el instalador del sistema. Es una firma pública de prueba; no es una entrega de producción ni se ha instalado/verificado aquí en un dispositivo. Si ya tienes BioNexo, exporta respaldo y comprueba firma/package compatibles antes de actualizar; conserva la app si aparece un conflicto, sin desinstalar para eludirlo. Pruebas nativas y revisión humana pendientes; las alertas abiertas siguen bloqueando publicación.

## Generar APK sin contratar un servicio

Instala Android Studio, el SDK Android correspondiente a la versión de React Native del proyecto, JDK compatible (consulta requisitos actuales), y configura `ANDROID_HOME` y `adb`. El primer prebuild/Gradle necesita descargar herramientas y dependencias. No se incluyen SDK ni binarios en el ZIP.

```bash
npm ci
npx expo prebuild --platform android
npx expo run:android --variant release
```

En Windows también puedes compilar directamente tras el prebuild:

```powershell
cd android
.\gradlew.bat assembleRelease --max-workers=2 --no-parallel -Pkotlin.compiler.execution.strategy=in-process
```

En Linux/macOS: `cd android` y `./gradlew assembleRelease --max-workers=2 --no-parallel -Pkotlin.compiler.execution.strategy=in-process`. Ejecuta pruebas de navegador y compilación por separado si el entorno tiene poca RAM. Para un APK solo ARM64 añade `-PreactNativeArchitectures=arm64-v8a`; no equivale a un binario universal. APK esperado: `android/app/build/outputs/apk/release/app-release.apk`. La configuración generada suele usar firma de desarrollo para pruebas locales; **no es una política de firma para publicar en Google Play**. Comprueba la firma generada y conserva una clave propia si decides distribuir versiones permanentes.

Alternativa EAS: `npx eas-cli build --platform android --profile preview`. Requiere cuenta Expo/autenticación, acceso de red y cuota disponible; los límites pueden cambiar. No es necesaria para desarrollar ni para usar Gradle local. `eas.json` ya define un APK de distribución interna; no incluye identificadores de cuenta ni secretos.

Para comprobar el APK en tu teléfono: instalar, completar una lección, cerrar completamente, volver a abrir, activar modo avión, estudiar otra lección y guardar una sesión del laboratorio. Estas comprobaciones nativas **quedan pendientes de dispositivo real/emulador** en esta entrega.

## Qué funciona

- Onboarding sin cuentas; diagnóstico opcional y repetible.
- Cuatro rutas con tres unidades y dos lecciones por unidad: 23 lecciones con seis retos y un piloto con ocho.
- Diez formatos: selección, selección múltiple, completar, emparejar, ordenar, numérico con unidades, gráfico, diagrama, predicción y caso.
- Respuestas con pistas, explicaciones y apoyo tras errores repetidos.
- Reanudación por lección: reto, borrador/unidades, pistas, feedback y paso de apoyo se conservan; salir pausa y descartar borra solo ese punto.
- Repasos por concepto, intercalado, práctica libre y revisión de errores; fechas/intervalos y razones basadas en eventos guardados.
- Práctica de trinomios: 14 variantes con IDs reproducibles y un premio de 10 XP compartido por toda la familia.
- Diez reglas educativas para distractores/omisiones, con bases y ejemplos; dos retos de transferencia a señales simuladas y evidencia inicial/reciente separada.
- Perfil local persistente, XP sin recompensas duplicadas, racha, objetivos, desafío semanal e insignias.
- Diagrama celular con regiones seleccionables, alternativa textual completa y respuesta reanudable.
- Laboratorio enzimático: pH, dos modelos, lecturas comparadas/curvas, óptimo, hipótesis, observaciones y cuaderno persistente. Controles del gráfico conservados en la navegación; guarda las notas antes de salir.
- Modos claro/oscuro/sistema, objetivos táctiles, etiquetas accesibles y movimiento reducido.
- Exportación/importación JSON validada con confirmación antes de reemplazar progreso.
- Recuperación desde fallo de apertura: exportar datos originales, elegir un respaldo o buscar copia local anterior y confirmar. Las versiones futuras se protegen contra reemplazo.

Todos los conceptos avanzados del mapa están identificados como **planificados**. No son ejercicios vacíos ni forman parte del conteo de 24 lecciones. Los porcentajes de dominio son heurísticos, no medidas psicométricas validadas. El contenido requiere revisión académica humana antes de utilizarse con fines formales.

## Respaldos y recuperación

SQLite migra al esquema 3 conservando una copia exacta del perfil anterior antes de convertirlo. Los respaldos antiguos 0.1.0 se aceptan; los nuevos usan un envoltorio 3 con referencias históricas y sesiones opcionales y conservan el perfil interno 1. Cambiar una solución o retirar un ejercicio no recalifica intentos guardados ni borra XP. El respaldo no certifica autenticidad de resultados.

Desde «Recupera tu cuaderno», exporta primero el rescate, elige un respaldo validado o busca una copia local anterior, revisa su resumen y confirma. Cancelar conserva el original. Un rescate contiene texto posiblemente corrupto y no equivale a un respaldo importable. Si SQLite no puede abrirse físicamente, este flujo no reconstruye el archivo. No hay reinicio automático ni purga de copias por falta de espacio.

El código anterior no entiende envoltorio 3 (SQLite sigue en esquema 3): exporta antes de cambiar de versión y usa una versión compatible; no hay downgrade automático. Más detalles en [arquitectura](docs/ARQUITECTURA.md) y ADR-006.

## Retomar una lección

En Inicio aparece «Expedición en pausa»: pulsa «Reanudar lección». Abrir la misma lección desde el mapa también recupera el reto. Si ya comprobaste una respuesta, vuelve su retroalimentación sin reenviar el intento. «Salir» espera el guardado y pausa; «Descartar sesión» exige confirmación y conserva intentos, XP, repasos y otras lecciones. Terminar elimina solo ese punto y otorga el premio una vez.

Los cambios se guardan al interactuar; espera «Cambios guardados» antes de cerrar. Si el proceso se interrumpe durante una escritura, se recupera la última operación confirmada. La migración conserva originales y los respaldos incluyen las sesiones. Si cambia el contenido o su apoyo, la sesión se conserva para revisión/descarte explícito. Diagnóstico y repaso todavía no reanudan su cursor. Validación nativa Android pendiente; las pruebas de interfaz realizadas usan navegador.

## Practicar con nuevos datos y comprender los repasos

En Practicar, «Practicar con nuevos datos» abre tres variantes de trinomios: primero las no respondidas, después las menos recientes. La familia completa comparte 10 XP; cambiar de semilla no da premios ilimitados. El historial de cada variante sí cuenta como práctica. La actividad «Practicar transferencia» usa una diferencia hipotética de lecturas, con dominio/unidades explícitos, sin datos experimentales. Mi progreso separa su primera respuesta de la más reciente y señala la ayuda.

Inicio explica la lección sugerida y Practicar muestra motivos del calendario. Cada repaso conserva su razón al iniciar. Si no se puede reconstruir qué evento originó una fecha, la app indica que proviene del calendario guardado; no inventa un error ni cambia el vencimiento. Práctica libre sigue disponible. Las rondas de variantes/transferencia son transitorias como otros repasos; sus respuestas confirmadas se conservan, pero salir no reanuda su cursor.

Las respuestas numéricas aceptan coma/punto, fracción simple y exponente. Rechazan operandos no finitos y resultados/conversiones que salen de rango o caen silenciosamente a cero. No es un solucionador algebraico general ni aritmética de precisión arbitraria. Solo los intentos nuevos usan esta corrección; resultados y XP anteriores se preservan.

## Interacciones y auditoría de Fase 3

La selección de una región celular se refleja en su opción de respuesta y en su punto de reanudación. En Laboratorio, activa comparación para leer N y A al mismo pH y la diferencia en puntos porcentuales; «Ir al óptimo del modelo» ajusta el control. La URL de esta navegación conserva pH/modelo/comparación al volver o recargar; una apertura nueva sin esos parámetros usa valores predeterminados. El respaldo conserva sesiones de cuaderno guardadas, no esos controles ni notas sin guardar.

Foco visible por teclado, bordes con mayor contraste y reajuste de controles/textos; Configuración muestra si movimiento reducido está activo por preferencia local o del sistema. La auditoría local y los comandos para repetir medidas están en [UX_AUDIT.md](docs/UX_AUDIT.md). P3-03 sigue TESTING hasta TalkBack/texto grande y rendimiento Android real. El APK de prueba final está identificado en PROGRESS; todavía no se probó en un teléfono.

## BioLab y proyecto interdisciplinario

En Laboratorio, formula una predicción antes de calcular y escribe una hipótesis. Para guardar, registra dos pH distintos del mismo modelo y completa la observación. Cambiar de modelo responde otra pregunta; registrar dos veces lo mismo no crea una réplica. “Abrir registro guardado” muestra lecturas originales, gráfico por modelo y observaciones; los registros antiguos de una condición siguen disponibles. “Mostrar 5 registros anteriores” permite recorrer el cuaderno completo. Notas/condiciones sin guardar se pierden al salir; el aviso está visible.

En Aprender → Biotecnología integrada → “Abrir proyecto interdisciplinario”, conecta dilución ideal, unidades y datos de recuento celular simulado en seis retos. Las bases ya existen; se puede explorar libremente. Cada primer acierto da 10 XP una sola vez. Las respuestas confirmadas se conservan y al volver continúan las pendientes; el borrador/cursor de esa ronda es transitorio. El recorrido completo no certifica dominio ni añade una lección ficticia a las 24 existentes.

Todos los datos de ambos recorridos son simulados. Fuentes, ecuaciones y límites en [revisión técnica académica](docs/ACADEMIC_REVIEW.md); revisión humana pendiente. SQL/documento/perfil/checkpoint permanecen 3/3/1/1 y los respaldos anteriores se conservan sin recalificar.

## Estructura

| Carpeta | Responsabilidad |
|---|---|
| `app/` | Rutas Expo Router y pantallas de sesión |
| `src/content/` | Catálogo JSON offline y grafo de prerrequisitos |
| `src/domain/` | Modelos, evaluación, repaso, progreso, validación y ciencia del laboratorio |
| `src/storage/` | SQLite, migraciones, serialización transaccional y transferencias |
| `src/ui/` | Componentes, tema, estado y pantallas |
| `scripts/` | Autoría de contenido, validación y servidor local de pruebas |
| `tests/` | Pruebas unitarias, de SQLite real y navegación web |
| `docs/` | Arquitectura, currículo, fuentes, estado y ampliación |

Documentación: [arquitectura](docs/ARQUITECTURA.md), [currículo](docs/CURRICULO.md), [pedagogía](docs/PEDAGOGIA.md), [fuentes](docs/FUENTES.md), [ampliación](docs/AMPLIAR.md), [estado y verificación](docs/ESTADO.md).

## Recuperar el historial del paquete de auditoría

El ZIP de Fases 4/5 incluye el código en `bionexo/` y `bionexo-history.bundle` junto a esa carpeta. Para continuar con los commits anteriores, ejecuta desde la carpeta extraída:

```bash
git clone bionexo-history.bundle bionexo-con-historial
cd bionexo-con-historial
```

Es una restauración local de Git, sin publicar en ningún servidor. Si solo quieres ejecutar el código, puedes usar directamente la carpeta `bionexo`. El bundle conserva el MVP original, auditoría, planificación y los incrementos de Fase 0 a Fase 4 y la integración local de Fase 5.

## Desarrollo reproducible

Dependencias fijadas en `package-lock.json`; usa `npm ci`. El SDK se verificó contra su matriz oficial y `expo/bundledNativeModules.json`: Expo 58, React Native 0.88 y React 19.3. `npx expo install --check` comprueba la compatibilidad instalada. No se fijan versiones beta/canary. `.github/workflows/ci.yml` ejecuta controles y exportaciones en cada push/PR. La aplicación no usa fuentes remotas, secretos, backend obligatorio ni claves API.

El código es MIT; los contenidos originales de `src/content` y `scripts/build_content.py` se ofrecen bajo CC BY-NC-SA 4.0 (ver `CONTENT_LICENSE.md`). Las referencias externas conservan sus condiciones. No se redistribuyen libros, logotipos ni ilustraciones de terceros.
