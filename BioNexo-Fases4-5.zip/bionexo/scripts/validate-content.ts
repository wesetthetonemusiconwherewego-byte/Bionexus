import { validateCatalog } from "../src/domain/validation";
import { catalog, practiceExercises } from "../src/content";
const errors = validateCatalog();
if (errors.length) {
  console.error(errors.join("\n"));
  process.exitCode = 1;
} else {
  console.log(
    `Catálogo válido: ${catalog.lessons.length} lecciones · ${catalog.lessons.reduce((n, l) => n + l.exercises.length, 0)} ejercicios · ${catalog.diagnostic.length} diagnóstico · ${practiceExercises.length} variantes · ${(catalog.transferActivities ?? []).reduce((n, a) => n + a.exercises.length, 0)} transferencia · ${catalog.errorRules?.length ?? 0} reglas · ${catalog.concepts.length} conceptos`,
  );
}
