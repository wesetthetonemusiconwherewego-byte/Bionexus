/** Local repeatable synthetic workload; not measurements on an Android device. */
import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { performance } from "node:perf_hooks";
import { cpus, platform, arch } from "node:os";
import { catalog } from "../src/content";
import {
  initialState,
  recordAttempt,
  reviewQueue,
} from "../src/domain/learning";
import { reviewGuidance, lessonGuidance } from "../src/domain/guidance";
import { correctAnswer } from "../src/domain/answers";
import {
  createDocument,
  serializeDocument,
  parseBackup,
} from "../src/domain/progress-document";
const exercises = catalog.lessons.flatMap((l) => l.exercises);
const now = new Date("2027-02-01T12:00:00.000Z");
let state = initialState(new Date("2026-01-01T12:00:00.000Z"));
function measure(fn: () => unknown) {
  fn();
  const samples = Array.from({ length: 7 }, () => {
    const t = performance.now();
    fn();
    return performance.now() - t;
  }).sort((a, b) => a - b);
  return { medianMs: samples[3], maxMs: samples[6], samplesMs: samples };
}
const workloads = [];
for (const count of [100, 1000, 10000]) {
  for (let i = state.attempts.length; i < count; i++) {
    const e = exercises[i % exercises.length]!;
    state = recordAttempt(state, {
      id: `synthetic-${i}`,
      exerciseId: e.id,
      conceptIds: [],
      answer: correctAnswer(e),
      correct: false,
      hinted: i % 4 === 0,
      at: new Date(Date.UTC(2026, 0, 1, 12) + i * 60000).toISOString(),
      mode: "review",
    });
  }
  const raw = serializeDocument(createDocument(state));
  if (process.env.BIONEXO_UX_PROFILE_DIR) {
    mkdirSync(process.env.BIONEXO_UX_PROFILE_DIR, { recursive: true });
    writeFileSync(
      join(process.env.BIONEXO_UX_PROFILE_DIR, `${count}.json`),
      raw,
    );
  }
  workloads.push({
    attempts: count,
    concepts: Object.keys(state.reviews).length,
    bytes: Buffer.byteLength(raw),
    reviewQueue: measure(() => reviewQueue(state, now)),
    reviewGuidance: measure(() => reviewGuidance(state, now)),
    homeGuidance: measure(() => lessonGuidance(state)),
    serialize: measure(() => serializeDocument(createDocument(state))),
    parse: measure(() => parseBackup(raw)),
  });
}
console.log(
  JSON.stringify(
    {
      date: new Date().toISOString(),
      runtime: process.version,
      platform: platform(),
      arch: arch(),
      cpu: cpus()[0]?.model,
      scope:
        "Node; synthetic correct attempts across 146 original exercises, 25% hinted; seven warm samples; not Android or student data",
      workloads,
    },
    null,
    2,
  ),
);
