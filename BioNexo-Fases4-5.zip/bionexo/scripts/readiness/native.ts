import { createHash } from "node:crypto";
import {
  readFileSync,
  realpathSync,
  existsSync,
  statSync,
  readdirSync,
} from "node:fs";
import { resolve, relative, isAbsolute, sep } from "node:path";
export const NATIVE_CHECKS = [
  "talkback-cell",
  "talkback-laboratory",
  "font-scales",
  "tab-legibility",
  "themes-contrast",
  "reduced-motion",
  "orientation",
  "sqlite-resume",
  "offline-cold-start",
  "backup-roundtrip",
  "device-performance",
] as const;
export type NativeCheck = (typeof NATIVE_CHECKS)[number];
export function applicationFile(path: string): boolean {
  return (
    /^(app|src|assets)\//.test(path) ||
    /^(package(-lock)?\.json|app\.json|eas\.json|tsconfig\.json|expo-env\.d\.ts|(babel|metro)\.config\.(js|cjs|mjs|ts))$/.test(
      path,
    )
  );
}
/** Works in a Git checkout or extracted source ZIP; LF-normalized text, raw binary. */
export function applicationFingerprint(root: string): string {
  const paths: string[] = [];
  const collect = (directory: string) => {
    for (const entry of readdirSync(resolve(root, directory), {
      withFileTypes: true,
    })) {
      const file = `${directory}/${entry.name}`;
      if (entry.isSymbolicLink())
        throw Error("Fuentes enlazadas no admitidas en la huella.");
      if (entry.isDirectory()) collect(file);
      else if (entry.isFile()) paths.push(file);
    }
  };
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    if (entry.isDirectory() && ["app", "src", "assets"].includes(entry.name))
      collect(entry.name);
    else if (applicationFile(entry.name)) {
      if (entry.isSymbolicLink())
        throw Error("Configuración enlazada no admitida en la huella.");
      if (entry.isFile()) paths.push(entry.name);
    }
  }
  const digest = createHash("sha256").update("bionexo-runtime-inputs-v1\0");
  for (const file of paths.sort()) {
    const raw = readFileSync(resolve(root, file));
    const content =
      /\.(?:[cm]?[jt]sx?|json|svg|css|xml|gradle|properties)$/i.test(file)
        ? raw.toString("utf8").replace(/\r\n/g, "\n")
        : raw;
    digest.update(file).update("\0").update(content).update("\0");
  }
  return digest.digest("hex");
}
export function sha256File(path: string): string {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}
type ObjectMap = Record<string, unknown>;
function object(value: unknown): ObjectMap | undefined {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? (value as ObjectMap)
    : undefined;
}
function text(value: unknown): value is string {
  return (
    typeof value === "string" &&
    value.trim().length > 0 &&
    !/^(TODO|TBD|PENDING|PENDIENTE|REEMPLAZAR)$/i.test(value.trim())
  );
}
function hash(value: unknown): value is string {
  return typeof value === "string" && /^[a-f\d]{64}$/i.test(value);
}
export interface NativeValidation {
  ready: boolean;
  issues: string[];
  scope: string;
}
/** A completeness/integrity gate, not certification of a manual observation. */
export function validateNativeAcceptance(
  value: unknown,
  expectedFingerprint: string,
  evidenceRoot: string,
  now = new Date(),
): NativeValidation {
  const issues: string[] = [];
  const fail = (message: string) => issues.push(message);
  const result = () => ({
    ready: issues.length === 0,
    issues,
    scope:
      "Completitud/integridad del registro manual; no certifica ejecución ni firma APK.",
  });
  const report = object(value);
  if (
    !report ||
    report.format !== "bionexo-native-acceptance" ||
    report.version !== 1
  ) {
    fail("Formato de aceptación nativa inválido o no soportado.");
    return result();
  }
  if (
    !hash(report.applicationFingerprint) ||
    report.applicationFingerprint !== expectedFingerprint
  )
    fail("La huella de la aplicación no coincide con las fuentes actuales.");
  if (
    typeof report.commit !== "string" ||
    !/^[a-f\d]{40}$/i.test(report.commit)
  )
    fail("Falta el commit completo del build probado.");
  const when =
    typeof report.verifiedAt === "string" ? Date.parse(report.verifiedAt) : NaN;
  if (
    !Number.isFinite(when) ||
    when > now.getTime() ||
    !/^\d{4}-\d\d-\d\dT.*(?:Z|[+-]\d\d:\d\d)$/.test(String(report.verifiedAt))
  )
    fail("Falta fecha válida de ejecución con zona horaria, no futura.");
  const device = object(report.device);
  if (
    !device ||
    !["physical", "emulator"].includes(String(device.kind)) ||
    !text(device.model) ||
    !text(device.androidVersion) ||
    !text(device.talkBackVersion) ||
    !Number.isInteger(device.apiLevel) ||
    Number(device.apiLevel) < 1
  )
    fail("Falta identificar Android, API, dispositivo y versión de TalkBack.");
  const scales = device?.fontScales;
  const orientations = device?.orientations;
  if (!Array.isArray(scales) || ![1, 1.5, 2].every((v) => scales.includes(v)))
    fail("Faltan escalas reales 100/150/200%.");
  if (
    !Array.isArray(orientations) ||
    !["portrait", "landscape"].every((v) => orientations.includes(v))
  )
    fail("Faltan orientaciones vertical y horizontal.");
  const verifyFile = (value: unknown, label: string, maxBytes = 20_000_000) => {
    const file = object(value);
    if (!file || !text(file.path) || !hash(file.sha256)) {
      fail(`${label}: falta ruta y SHA-256.`);
      return;
    }
    try {
      if (isAbsolute(file.path) || file.path.split(/[\\/]/).includes(".."))
        throw Error("fuera de carpeta");
      const root = realpathSync(evidenceRoot),
        path = realpathSync(resolve(root, file.path));
      const rel = relative(root, path);
      if (rel === ".." || rel.startsWith(".." + sep) || isAbsolute(rel))
        throw Error("fuera de carpeta");
      const stat = statSync(path);
      if (!stat.isFile() || stat.size === 0 || stat.size > maxBytes)
        throw Error("tamaño/tipo");
      if (sha256File(path).toLowerCase() !== file.sha256.toLowerCase())
        fail(`${label}: hash de evidencia distinto.`);
    } catch {
      fail(
        `${label}: archivo ausente, fuera de carpeta o tamaño/tipo no permitido.`,
      );
    }
  };
  const build = object(report.build);
  if (
    !build ||
    build.kind !== "apk" ||
    build.package !== "org.bionexo.learning" ||
    !text(build.appVersion) ||
    !Number.isInteger(build.versionCode) ||
    Number(build.versionCode) < 1 ||
    !hash(build.certificateSha256)
  )
    fail("Falta identificar APK, paquete, versión y huella del certificado.");
  verifyFile(build?.artifact, "APK", 250_000_000);
  const checks = Array.isArray(report.checks) ? report.checks : [];
  for (const id of NATIVE_CHECKS) {
    const found = checks.map(object).filter((c) => c?.id === id);
    if (found.length !== 1) {
      fail(`${id}: falta resultado único.`);
      continue;
    }
    const check = found[0]!;
    if (check.status !== "PASS") fail(`${id}: no está aprobado.`);
    if (!text(check.notes) || check.notes.trim().length < 12)
      fail(`${id}: faltan observaciones concretas.`);
    if (!Array.isArray(check.evidence) || check.evidence.length === 0)
      fail(`${id}: falta evidencia.`);
    else for (const evidence of check.evidence) verifyFile(evidence, id);
  }
  if (checks.some((c) => !NATIVE_CHECKS.includes(object(c)?.id as NativeCheck)))
    fail("Hay comprobaciones desconocidas; revisar formato.");
  const metrics = Array.isArray(report.performance) ? report.performance : [];
  for (const count of [100, 1000, 10000]) {
    const rows = metrics.map(object).filter((m) => m?.attempts === count);
    const row = rows.length === 1 ? rows[0] : undefined;
    if (
      !row ||
      !text(row.method) ||
      !["startupColdMs", "startupWarmMs", "practiceMs"].every(
        (key) =>
          Array.isArray(row[key]) &&
          row[key].length >= 3 &&
          row[key].every(
            (n: unknown) =>
              typeof n === "number" && Number.isFinite(n) && n > 0,
          ),
      )
    )
      fail(
        `Rendimiento ${count}: faltan método y tres muestras positivas por operación.`,
      );
  }
  return result();
}
