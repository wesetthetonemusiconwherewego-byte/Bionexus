import { inspectExport } from "./security/bundles";

try {
  const directories = process.argv.slice(2);
  if (!directories.length)
    throw new Error(
      "Uso: npm run security:bundles -- <exportación> [otra exportación]. Exporta con --source-maps.",
    );
  const exports = directories.map(inspectExport);
  const blocked = exports.some((item) => item.matches.length > 0);
  console.log(
    JSON.stringify(
      {
        format: "bionexo-bundle-dependencies",
        version: 1,
        scope:
          "JavaScript source-map paths only; not a native binary or full dependency audit",
        status: blocked ? "BLOCKED" : "PASS",
        exports,
      },
      null,
      2,
    ),
  );
  if (blocked) process.exitCode = 1;
} catch (e) {
  console.error(
    e instanceof Error ? e.message : "No se pudo inspeccionar la exportación.",
  );
  process.exitCode = 1;
}
