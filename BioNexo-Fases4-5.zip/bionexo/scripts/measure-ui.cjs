/* Reproducible local browser audit. Not an Android-device benchmark. */
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const { performance } = require("node:perf_hooks");
const { chromium } = require("@playwright/test");
const root = path.resolve(process.env.BIONEXO_WEB_ROOT ?? "dist");
const profileDirectory = process.env.BIONEXO_UX_PROFILE_DIR;
const screenshotDirectory = process.env.BIONEXO_UX_SCREENSHOT_DIR;
const mime = {
  ".html": "text/html",
  ".js": "application/javascript",
  ".css": "text/css",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".ttf": "font/ttf",
};
const median = (a) => [...a].sort((a, b) => a - b)[Math.floor(a.length / 2)];
async function main() {
  const server = http.createServer((req, res) => {
    let file = path.resolve(
      root,
      "." + new URL(req.url, "http://localhost").pathname,
    );
    if (!file.startsWith(root + path.sep) && file !== root) {
      res.writeHead(403).end();
      return;
    }
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory())
      file = path.join(root, "index.html");
    res.setHeader(
      "Content-Type",
      mime[path.extname(file)] ?? "application/octet-stream",
    );
    fs.createReadStream(file).pipe(res);
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  let browser;
  try {
    browser = await chromium.launch({
      executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH,
      args: [
        "--no-sandbox",
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--no-zygote",
      ],
    });
    const report = {
      date: new Date().toISOString(),
      scope:
        "Chromium headless on host; synthetic histories; not Android/TalkBack",
      browser: browser.version(),
      viewport: { width: 412, height: 915 },
      errors: [],
      performance: [],
    };
    const page = await browser.newPage({ viewport: report.viewport });
    page.on("pageerror", (error) => report.errors.push(error.message));
    await page.goto(base);
    await page
      .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
      .click();
    await page.getByRole("tab", { name: "Laboratorio", exact: true }).click();
    const button = page.getByRole("button", { name: "+0,5 pH", exact: true });
    await button.focus();
    report.focus = await button.evaluate((el) => ({
      focused: document.activeElement === el,
      outline: getComputedStyle(el).outline,
      border: getComputedStyle(el).border,
    }));
    await page.keyboard.press("Enter");
    await page.getByRole("heading", { name: "pH 7.5", exact: true }).waitFor();
    await page
      .getByRole("switch", { name: "Comparar segundo modelo", exact: true })
      .click();
    if (screenshotDirectory) {
      fs.mkdirSync(screenshotDirectory, { recursive: true });
      await page.screenshot({
        path: path.join(screenshotDirectory, "lab.png"),
      });
    }
    report.axes = await page
      .getByText(
        "Eje horizontal: pH (sin unidad). Eje vertical: Actividad relativa (%).",
        { exact: true },
      )
      .innerText();
    await page.setViewportSize({ width: 320, height: 915 });
    await page.evaluate(() => {
      for (const el of document.querySelectorAll("div,span,input")) {
        if (
          el.childElementCount === 0 &&
          (el.textContent?.trim() || el.tagName === "INPUT")
        ) {
          const s = getComputedStyle(el),
            font = parseFloat(s.fontSize),
            line = parseFloat(s.lineHeight);
          el.style.fontSize = `${font * 2}px`;
          if (Number.isFinite(line)) el.style.lineHeight = `${line * 2}px`;
        }
      }
    });
    await page.evaluate(
      () =>
        new Promise((resolve) =>
          requestAnimationFrame(() => requestAnimationFrame(resolve)),
        ),
    );
    report.largeText = await page.evaluate(() => ({
      method:
        "CSS leaf font-size and line-height x2, 320x915; not native fontScale",
      overflow: [...document.querySelectorAll("div,input")]
        .filter(
          (el) =>
            el.checkVisibility() &&
            el.getBoundingClientRect().width > 0 &&
            el.getBoundingClientRect().left >= 0 &&
            el.getBoundingClientRect().right > innerWidth + 1,
        )
        .map((el) => ({
          role: el.getAttribute("role"),
          text: el.textContent?.slice(0, 70),
          right: el.getBoundingClientRect().right,
        })),
    }));
    report.targets = [];
    for (const name of [
      "Modelo N · óptimo 7",
      "Modelo A · óptimo 4",
      "−0,5 pH",
      "+0,5 pH",
    ])
      report.targets.push({
        name,
        ...(await page
          .getByRole("button", { name, exact: true })
          .boundingBox()),
      });
    if (screenshotDirectory)
      await page.screenshot({
        path: path.join(screenshotDirectory, "lab-large.png"),
      });
    await page.setViewportSize({ width: 412, height: 915 });
    await page.goto(base + "/lesson/bio-cells-lesson");
    await page
      .getByRole("button", {
        name: /^(Comenzar los retos|Practicar igualmente)$/,
      })
      .click();
    const cells = require("../src/content/catalog.json").lessons.find(
      (l) => l.id === "bio-cells-lesson",
    );
    for (const exercise of cells.exercises.slice(0, 3)) {
      if (exercise.type === "multi")
        for (const id of exercise.correct)
          await page
            .getByRole("checkbox", {
              name: exercise.options.find((o) => o.id === id).text,
              exact: true,
            })
            .click();
      else
        await page
          .getByRole("radio", {
            name: exercise.options.find((o) => o.id === exercise.correct).text,
            exact: true,
          })
          .click();
      await page
        .getByRole("button", { name: "Comprobar respuesta", exact: true })
        .click();
      await page
        .getByRole("heading", { name: "Bien razonado", exact: true })
        .waitFor();
      await page
        .getByRole("button", { name: "Continuar", exact: true })
        .click();
    }
    await page
      .getByRole("button", { name: "Señalar región B", exact: true })
      .click();
    report.diagramTargets = [];
    for (const letter of ["A", "B", "C"])
      report.diagramTargets.push({
        region: letter,
        ...(await page
          .getByRole("button", {
            name: `Señalar región ${letter}`,
            exact: true,
          })
          .boundingBox()),
      });
    if (screenshotDirectory)
      await page.screenshot({
        path: path.join(screenshotDirectory, "cell.png"),
      });
    await page.close();
    if (profileDirectory)
      for (const count of [100, 1000, 10000]) {
        const data = JSON.parse(
          fs.readFileSync(path.join(profileDirectory, `${count}.json`), "utf8"),
        );
        data.state.onboarded = true;
        const raw = JSON.stringify(data),
          startup = [],
          practice = [];
        for (let i = 0; i < 3; i++) {
          const context = await browser.newContext({
            viewport: report.viewport,
          });
          await context.addInitScript(
            (raw) => localStorage.setItem("bionexo-state-v1", raw),
            raw,
          );
          const page = await context.newPage();
          page.on("pageerror", (error) => report.errors.push(error.message));
          let t = performance.now();
          await page.goto(base);
          await page.getByRole("heading", { name: /Hola,/ }).waitFor();
          startup.push(performance.now() - t);
          t = performance.now();
          await page
            .getByRole("tab", { name: "Practicar", exact: true })
            .click();
          await page
            .getByRole("heading", { name: "Fortalece tus bases", exact: true })
            .waitFor();
          practice.push(performance.now() - t);
          await context.close();
        }
        report.performance.push({
          attempts: count,
          bytes: Buffer.byteLength(raw),
          samples: 3,
          method:
            "Fresh browser context per sample; local HTTP; wall time to visible heading; includes storage validation, JS loading, layout and automation",
          startupMs: startup,
          startupMedianMs: median(startup),
          practiceMs: practice,
          practiceMedianMs: median(practice),
        });
      }
    console.log(JSON.stringify(report, null, 2));
    if (
      report.errors.length ||
      report.largeText.overflow.length ||
      !report.focus.focused ||
      report.focus.outline.includes(" none ")
    )
      process.exitCode = 1;
  } finally {
    if (browser) await browser.close();
    server.close();
  }
}
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
