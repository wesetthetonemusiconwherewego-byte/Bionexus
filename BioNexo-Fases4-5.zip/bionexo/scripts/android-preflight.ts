import { existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { applicationFingerprint } from "./readiness/native";
const root = process.cwd(),
  suffix = process.platform === "win32" ? ".exe" : "";
const sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT;
const probe = (command: string, args: string[]) => {
  const r = spawnSync(command, args, {
    encoding: "utf8",
    timeout: 15000,
    windowsHide: true,
  });
  return {
    available: !r.error && r.status === 0,
    version: (r.stdout || r.stderr || "")
      .trim()
      .split("\n")
      .slice(0, 2)
      .join(" "),
  };
};
const javaHome = process.env.JAVA_HOME;
const java = probe(javaHome ? join(javaHome, "bin", `java${suffix}`) : "java", [
    "-version",
  ]),
  javac = probe(javaHome ? join(javaHome, "bin", `javac${suffix}`) : "javac", [
    "-version",
  ]);
const adb = probe(sdk ? join(sdk, "platform-tools", `adb${suffix}`) : "adb", [
  "version",
]);
const entries = (name: string): string[] => {
  try {
    return sdk ? readdirSync(join(sdk, name)) : [];
  } catch {
    return [];
  }
};
const buildTools = entries("build-tools").filter((x) =>
  existsSync(
    join(
      sdk!,
      "build-tools",
      x,
      `apksigner${process.platform === "win32" ? ".bat" : ""}`,
    ),
  ),
);
const platforms = entries("platforms").filter((x) =>
  existsSync(join(sdk!, "platforms", x, "android.jar")),
);
const issues = [
  ...(!java.available ? ["Java no disponible."] : []),
  ...(!javac.available ? ["Falta JDK completo (javac)."] : []),
  ...(!sdk || !existsSync(sdk)
    ? ["Configura ANDROID_HOME o ANDROID_SDK_ROOT hacia un SDK instalado."]
    : []),
  ...(!adb.available ? ["Falta adb ejecutable en platform-tools."] : []),
  ...(!platforms.length ? ["Faltan plataformas del SDK."] : []),
  ...(!buildTools.length ? ["Faltan build-tools con apksigner."] : []),
];
console.log(
  JSON.stringify(
    {
      format: "bionexo-android-preflight",
      version: 1,
      at: new Date().toISOString(),
      applicationFingerprint: applicationFingerprint(root),
      status: issues.length ? "BLOCKED" : "TOOLS_PRESENT",
      java,
      javac,
      adb,
      sdkConfigured: !!sdk,
      buildTools,
      platforms,
      issues,
      scope:
        "Solo presencia/ejecución de herramientas locales. No compila, no accede a cuentas o dispositivos, no verifica compatibilidad Gradle/JDK/API ni acepta P3-03.",
    },
    null,
    2,
  ),
);
process.exitCode = issues.length ? 1 : 0;
