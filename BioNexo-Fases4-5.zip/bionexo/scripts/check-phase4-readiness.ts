import { readFileSync } from "node:fs";
import { resolve, dirname } from "node:path";
import {
  applicationFingerprint,
  validateNativeAcceptance,
} from "./readiness/native";
const input =
  process.argv[2] ?? "docs/evidence/android-acceptance.template.json";
let report;
try {
  report = validateNativeAcceptance(
    JSON.parse(readFileSync(resolve(input), "utf8")),
    applicationFingerprint(process.cwd()),
    dirname(resolve(input)),
  );
} catch {
  report = {
    ready: false,
    issues: ["No se pudo leer/validar el registro de aceptación."],
    scope: "Sin aceptación nativa comprobable.",
  };
}
console.log(
  JSON.stringify(
    {
      format: "bionexo-phase4-readiness",
      version: 1,
      at: new Date().toISOString(),
      status: report.ready ? "REVIEW_REQUIRED" : "BLOCKED",
      ...report,
      next: report.ready
        ? "Revisar evidencia humana y actualizar P3-03 antes de autorizar P4-01."
        : "Completar P3-03 con Android y evidencias reales; no iniciar Fase 4.",
      publicRelease:
        "R-04 conserva su bloqueo independiente; este comando no autoriza publicar.",
    },
    null,
    2,
  ),
);
process.exitCode = report.ready ? 0 : 1;
