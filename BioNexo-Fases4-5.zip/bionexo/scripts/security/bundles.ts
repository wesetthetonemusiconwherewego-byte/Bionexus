import { createHash } from "node:crypto";
import { readdirSync, readFileSync } from "node:fs";
import { join, relative, resolve, posix } from "node:path";

// This is a narrow regression guard for the two P0-04 roots, not an SBOM or a
// replacement for npm audit. Reject every version if it enters shipped JS.
const ROOTS = ["braces", "node-forge"] as const;
function object(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
export function sourcePaths(raw: unknown, depth = 0): string[] {
  if (depth > 32) throw new Error("Mapa supera la profundidad permitida.");
  if (!object(raw) || raw.version !== 3) throw new Error("Mapa no compatible.");
  if ("sections" in raw) {
    if (
      !Array.isArray(raw.sections) ||
      !raw.sections.length ||
      "sources" in raw
    )
      throw new Error("Secciones de mapa inválidas.");
    return raw.sections.flatMap((section) => {
      if (!object(section) || !("map" in section) || "url" in section)
        throw new Error("Se requiere un mapa local en cada sección.");
      return sourcePaths(section.map, depth + 1);
    });
  }
  if (
    !Array.isArray(raw.sources) ||
    !raw.sources.length ||
    raw.sources.some((s) => typeof s !== "string" || !s.trim()) ||
    typeof raw.mappings !== "string" ||
    (raw.sourceRoot !== undefined && typeof raw.sourceRoot !== "string")
  )
    throw new Error("Mapa sin fuentes válidas.");
  const root = typeof raw.sourceRoot === "string" ? raw.sourceRoot : "";
  return (raw.sources as string[]).map((s) =>
    posix.normalize((root ? root + "/" + s : s).replaceAll("\\", "/")),
  );
}
export function forbiddenDependencies(sources: string[]) {
  return sources.flatMap((source) =>
    ROOTS.filter((name) =>
      new RegExp(`(?:^|/)node_modules/${name}(?:/|$)`).test(source),
    ).map((dependency) => ({ dependency, source })),
  );
}
const hash = (bytes: Uint8Array) =>
  createHash("sha256").update(bytes).digest("hex");
export function inspectExport(directory: string) {
  const root = resolve(directory);
  const files: string[] = [];
  function visit(dir: string) {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const path = join(dir, entry.name);
      if (entry.isSymbolicLink())
        throw new Error(`Enlace simbólico no permitido: ${path}`);
      if (entry.isDirectory()) visit(path);
      else if (entry.isFile() && /\.(js|hbc)$/.test(entry.name))
        files.push(path);
    }
  }
  visit(root);
  if (!files.length)
    throw new Error(`No hay bundles JS/Hermes en ${directory}.`);
  const bundles = files.sort().map((file) => {
    const code = readFileSync(file);
    if (!code.length) throw new Error(`Bundle vacío: ${file}`);
    // Each chunk needs its own map; a single clean map cannot cover others.
    const bytes = readFileSync(file + ".map");
    const sources = sourcePaths(JSON.parse(bytes.toString("utf8")));
    return {
      file: relative(root, file).replaceAll("\\", "/"),
      bundleSha256: hash(code),
      mapSha256: hash(bytes),
      sourceCount: sources.length,
      matches: forbiddenDependencies(sources),
    };
  });
  return {
    directory,
    bundles,
    sourceCount: bundles.reduce((n, b) => n + b.sourceCount, 0),
    matches: bundles.flatMap((b) =>
      b.matches.map((m) => ({ file: b.file, ...m })),
    ),
  };
}
