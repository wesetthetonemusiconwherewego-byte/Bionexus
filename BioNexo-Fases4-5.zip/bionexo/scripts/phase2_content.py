"""Original rule-based feedback and a mathematical transfer activity (not real data)."""


def phase2_content():
    rules = []

    def rule(id, title, exercise_ids, options, prerequisite, explanation, example, families=None, subset=False):
        rules.append(dict(id=id, title=title, exerciseIds=exercise_ids, familyIds=families or [],
                          selector=dict(type='proper-subset') if subset else dict(type='selected-option', optionIds=options),
                          prerequisiteIds=prerequisite, explanation=explanation,
                          example=dict(title='Un ejemplo para reconstruir la idea', steps=example),
                          sourceIds=['factoring-ref', 'factor-equations-ref'], reviewStatus='requires-human-review'))

    rule('factor-expand-v1', 'Comprobar la expansión', ['math-factor-q1'], ['b'], ['math-equations'],
         'Tu elección es compatible con comprobar solo el término constante. Expande los cuatro productos y verifica también el término lineal.',
         ['(y − 4)(y + 2) = y² − 2y − 8.', 'El término −2y no desaparece.', 'Para recuperar una diferencia de cuadrados se requieren factores conjugados.'])
    rule('factor-square-v1', 'Distinguir cuadrados y conjugados', ['math-factor-q1'], ['c'], ['math-powers'],
         'Tu elección coincide con confundir un cuadrado de binomio con una diferencia de cuadrados. Puede ser un descuido; no demuestra por sí sola una dificultad estable.',
         ['(y − 5)² = y² − 10y + 25.', '(y − 5)(y + 5) = y² − 25.', 'El término central permite distinguir las dos identidades.'])
    rule('factor-common-v1', 'Distribuir sobre todos los términos', ['math-factor-q2'], ['b', 'c'], ['math-equations'],
         'La opción elegida no recupera todos los términos al distribuir. Revisa qué factor es común y divide cada término por él.',
         ['6y + 18 = 6·y + 6·3.', 'Extraer 6 deja 6(y + 3).', 'Distribuir de vuelta recupera 6y y 18.'])
    rule('factor-sum-v1', 'Verificar suma además de producto', ['math-factor-q3'], ['b'], ['math-equations'],
         'Tu elección cumple el producto, pero cambia la suma. Comprueba ambas condiciones antes de aceptar los factores.',
         ['Para z² + 11z + 24 se buscan suma 11 y producto 24.', '3 y 8 cumplen las dos condiciones.', '(z + 3)(z + 8) recupera el trinomio.'])
    rule('variant-sum-v1', 'Verificar suma además de producto', [], ['c'], ['math-equations'],
         'Tu elección cumple el producto constante, pero no el coeficiente lineal. Es un patrón compatible con revisar una sola condición.',
         ['Para z² + 11z + 24, 1·24 coincide con 24.', 'Pero 1 + 24 = 25, no 11.', '3 + 8 = 11 y 3·8 = 24: (z + 3)(z + 8).'], families=['factor-trinomial'])
    rule('factor-sign-v1', 'Conservar el signo de la suma', ['math-factor-q3'], ['c'], ['math-powers'],
         'Los dos factores negativos producen una suma negativa. Revisa el signo del término lineal aunque el producto constante sea positivo.',
         ['(z − 3)(z − 8) = z² − 11z + 24.', '(z + 3)(z + 8) = z² + 11z + 24.', 'El signo del término central cambia.'])
    rule('variant-sign-v1', 'Conservar el signo de la suma', [], ['b'], ['math-powers'],
         'La opción elegida cambia el signo del término lineal. El producto de dos negativos es positivo, pero su suma es negativa.',
         ['−3 − 8 = −11, mientras (−3)(−8) = 24.', 'Para coeficiente lineal positivo necesitas una suma positiva.', 'Compara las expansiones de factores con signos iguales.'], families=['factor-trinomial'])
    rule('factor-roots-v1', 'Buscar todas las raíces', ['math-factor-q4', 'factor-signal-v1-q1'], [], ['math-powers', 'math-equations'],
         'Seleccionaste solo parte de las raíces correctas. Igualar cada factor a cero por separado ayuda a encontrar todas; después aplica el dominio.',
         ['z² − 7z + 12 = (z − 3)(z − 4).', 'Si el producto es cero, z = 3 o z = 4.', 'Conserva todas las raíces que estén dentro del dominio indicado.'], subset=True)
    rule('factor-substitution-v1', 'Verificar raíces sustituyendo', ['math-factor-q4'], ['c', 'd'], ['math-equations'],
         'La opción elegida no anula la expresión. Sustituir cada propuesta evita confundir una constante con una solución.',
         ['En z² − 16 = 0, z = 16 da 240, no cero.', 'z = 4 y z = −4 sí anulan la expresión.', 'Una raíz debe satisfacer la ecuación original.'])
    rule('factor-domain-v1', 'Conservar el dominio original', ['math-factor-q5'], ['b', 'c'], ['math-equations'],
         'Tu selección no conserva la exclusión del denominador original. Simplificar no da un valor a una división por cero.',
         ['En (z² − 25)/(z − 5), primero excluye z = 5.', 'La forma simplificada z + 5 vale solo cuando z ≠ 5.', 'La exclusión permanece aunque se cancele el factor.'])

    source = ['factoring-ref', 'factor-equations-ref']
    base = dict(subjectId='math', level=1, conceptIds=['math-factor'], prerequisites=['math-equations'], sourceIds=source)
    transfer = dict(id='factor-signal-v1', title='De los factores a una señal simulada',
                    objective='Usar raíces y evaluación de un polinomio para interpretar coincidencias de dos señales hipotéticas.',
                    model='Suponemos D(u) = (u² − 5u + 6) UR, diferencia entre dos lecturas hipotéticas. u = t/(1 min) no tiene unidades, con 0 ≤ t ≤ 5 min. D = 0 significa que las lecturas coinciden.',
                    assumptions=['UR son unidades relativas, sin calibración a una magnitud física.',
                                 'Es una función matemática elegida para aprender: no deriva de un instrumento ni de una reacción real.',
                                 'La diferencia D puede ser negativa; no representa una actividad enzimática negativa.',
                                 'Se ignoran ruido, incertidumbre y dinámica biológica. No extrapoles fuera del dominio.'],
                    sourceIds=source, reviewStatus='requires-human-review', exercises=[
        dict(**base, id='factor-signal-v1-q1', type='multi',
             prompt='En el modelo D(u) = (u² − 5u + 6) UR, u = t/(1 min), 0 ≤ t ≤ 5 min. ¿En qué tiempos coinciden las dos lecturas? Selecciona todos.',
             options=[dict(id='a', text='t = 2 min'), dict(id='b', text='t = 3 min'), dict(id='c', text='t = 5 min'), dict(id='d', text='t = 6 min')], correct=['a', 'b'],
             explanation=dict(correct='D = 0 exige u² − 5u + 6 = (u − 2)(u − 3) = 0. u = 2 o 3, por tanto t = 2 min o 3 min; ambos pertenecen al dominio. Son predicciones del modelo supuesto.',
                              misconception='Busca todas las raíces y comprueba el intervalo. El coeficiente lineal y el constante no son automáticamente raíces.',
                              distractors={'c': 'Para t = 5 min, u = 5 y D = (25 − 25 + 6) UR = 6 UR: las lecturas no coinciden.',
                                           'd': 't = 6 min está fuera del dominio y tampoco anula el polinomio: D(6) = 12 UR.'}),
             hints=['Coincidir significa que la diferencia entre lecturas es cero.',
                    'Factoriza el polinomio, iguala cada factor a cero y después comprueba el dominio temporal.',
                    'Usa este modelo distinto como ejemplo, sin copiar sus tiempos.'],
             hintExample=dict(title='Ejemplo alternativo · E(v) = (v² − 9v + 20) UR', steps=[
                 'E = 0 equivale a (v − 4)(v − 5) = 0.', 'Las raíces son v = 4 y v = 5.',
                 'Si el dominio fuera 0 ≤ v ≤ 4, solo v = 4 pertenecería a él. El dominio es parte del modelo.'])),
        dict(**base, id='factor-signal-v1-q2', type='numeric',
             prompt='En el mismo modelo D(u) = (u² − 5u + 6) UR, u = t/(1 min). ¿Cuál es la diferencia D cuando t = 4 min? Escribe valor y unidad relativa.',
             correct=2, tolerance=1e-8, unit='UR', acceptedUnits={'UR': 1},
             explanation=dict(correct='t = 4 min da u = 4. D(4) = (16 − 20 + 6) UR = 2 UR. También (4 − 2)(4 − 3) = 2. No es una medición experimental ni una concentración.',
                              misconception='Convierte primero al parámetro sin unidades y sustituye en todos los términos. D se expresa en UR, no en minutos ni en cm².'),
             hints=['D es una diferencia de lecturas; distingue su unidad de la del tiempo.',
                    'Calcula u = t/(1 min) y reemplázalo en el polinomio completo, conservando signos.',
                    'Revisa una evaluación distinta antes de volver al problema.'],
             hintExample=dict(title='Ejemplo alternativo · E(v) = (v² − 9v + 20) UR, v = 2', steps=[
                 'Sustituye v = 2: (2² − 9·2 + 20) UR.', 'Respeta el orden: (4 − 18 + 20) UR = 6 UR.',
                 'Usando factores, (2 − 4)(2 − 5) = (−2)(−3) = 6. Las dos formas concuerdan.'])),
    ])
    return rules, transfer
