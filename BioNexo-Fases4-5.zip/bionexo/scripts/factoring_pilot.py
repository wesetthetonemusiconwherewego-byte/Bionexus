"""Original Spanish pilot. Additive metadata; never renumber historical IDs."""


def enrich_factorization(lessons, sources):
    source = 'factoring-ref'
    sources.append(dict(
        id=source,
        title='OpenStax · Algebra and Trigonometry 2e, 1.5 Factoring Polynomials',
        url='https://openstax.org/books/algebra-and-trigonometry-2e/pages/1-5-factoring-polynomials',
        note='Consulta 2026-10-22. Referencia de identidades y métodos; problemas y ejemplos originales de BioNexo. CC BY-NC-SA 4.0. No valida el modelo geométrico supuesto.'))
    lesson = next(l for l in lessons if l['id'] == 'math-factor-lesson')
    lesson.update(
        minutes=12,
        objective='Elegir y verificar tres métodos de factorización, resolver un producto nulo, conservar restricciones y aplicar factores a un área.',
        explanation='Factorizar escribe una suma como un producto equivalente. Primero reconoce factor común, diferencia de cuadrados o trinomio. Después comprueba expandiendo. Si buscas raíces, necesitas una ecuación igualada a cero; si simplificas un cociente, conserva las exclusiones del denominador original. Los ejemplos usan expresiones distintas de los retos para que puedas aplicar el procedimiento.',
        example=['Para x² + 6x + 8, busca dos números de suma 6 y producto 8.',
                 '2 + 4 = 6 y 2·4 = 8: escribe (x + 2)(x + 4).',
                 'Comprueba expandiendo: x² + 4x + 2x + 8 = x² + 6x + 8.'],
        summary='Reconociste factor común, diferencia de cuadrados y trinomios; comprobaste productos, raíces y dominio. Usaste factores para interpretar un área en un modelo supuesto.',
        application='En una bandeja idealizada, factorizar un polinomio de área permite reconocer sus dimensiones. No es un modelo de crecimiento celular ni un experimento real.',
        sourceIds=['math-ref', source])
    lesson['stages'] = [
        dict(id='factor-recognize', title='Reconocer la estructura',
             objective='Distinguir diferencia de cuadrados y factor común verificando ambos términos.',
             explanation='Antes de operar, observa la forma. Una resta de dos cuadrados usa factores conjugados. Si todos los términos comparten un factor, extraerlo invierte la distributividad. Expandir permite detectar términos que sobran o faltan.',
             example=dict(title='Dos estructuras, dos decisiones', steps=[
                 'Para y² − 25, reconoce 25 = 5²: la estructura es y² − 5².',
                 'Escribe (y − 5)(y + 5). Al expandir: y² + 5y − 5y − 25 = y² − 25.',
                 'Para 4x + 12, ambos términos tienen factor 4: 4·x + 4·3.',
                 'Extrae 4: 4(x + 3). Comprueba multiplicando el 4 por cada término.']),
             exerciseIds=['math-factor-q1', 'math-factor-q2'], sourceIds=[source]),
        dict(id='factor-build', title='Construir y comprobar',
             objective='Encontrar factores de un trinomio y todas las raíces reales de un producto nulo.',
             explanation='En (x + p)(x + q), la distributividad produce x² + (p + q)x + pq. Hay que cumplir suma y producto al mismo tiempo. Factorizar una expresión no es resolver una ecuación: solo si el producto se iguala a cero puedes igualar cada factor a cero.',
             example=dict(title='Del trinomio a sus factores', steps=[
                 'Para x² + 7x + 10, busca dos números de suma 7 y producto 10.',
                 '2 y 5 cumplen ambas condiciones: (x + 2)(x + 5).',
                 'Verifica: x² + 5x + 2x + 10 = x² + 7x + 10.',
                 'En otra ecuación, z² − 16 = 0 equivale a (z − 4)(z + 4) = 0: z = 4 o z = −4.']),
             exerciseIds=['math-factor-q3', 'math-factor-q4'], sourceIds=[source]),
        dict(id='factor-domain', title='Conservar el significado',
             objective='Mantener valores excluidos del dominio y evaluar una expresión factorizada.',
             explanation='Solo puedes cancelar factores, no términos de una suma. Además, el denominador original determina exclusiones que siguen vigentes aunque su factor desaparezca al simplificar. Evaluar significa sustituir un valor permitido; no buscar raíces.',
             example=dict(title='Una expresión más corta con la misma restricción', steps=[
                 'En (y² − 16)/(y − 4), el denominador impone y ≠ 4.',
                 'Factoriza el numerador: (y − 4)(y + 4)/(y − 4).',
                 'Cancela el factor común solo para y ≠ 4: queda y + 4 con esa restricción.',
                 'En y = 2, ambas formas valen 6. En y = 4, la original sigue sin estar definida; no se puede asignarle 8.']),
             exerciseIds=['math-factor-q5', 'math-factor-q6'], sourceIds=[source]),
        dict(id='factor-transfer', title='Transferir a un diseño',
             objective='Interpretar factores como dimensiones y calcular un área con unidades coherentes.',
             explanation='Modelo supuesto: una bandeja rectangular ideal tiene lados (s + 1) cm y (s + 4) cm. s es un parámetro sin unidades con 0 ≤ s ≤ 5. Su área es (s² + 5s + 4) cm². Factorizar recupera las longitudes. No se consideran grosor, volumen, células ni variación experimental.',
             example=dict(title='Una bandeja distinta, sin datos reales', steps=[
                 'Otra bandeja tiene A = (r² + 7r + 12) cm², con r sin unidades y 0 ≤ r ≤ 5.',
                 '3 + 4 = 7 y 3·4 = 12: A = (r + 3)(r + 4) cm².',
                 'Interpreta lados (r + 3) cm y (r + 4) cm, positivos en ese intervalo.',
                 'Para r = 1, A = 4·5 = 20 cm². Multiplicar longitudes da área, no volumen.']),
             exerciseIds=['math-factor-transfer-q1', 'math-factor-transfer-q2'], sourceIds=[source]),
    ]
    base = dict(subjectId='math', level=1, conceptIds=['math-factor'],
                prerequisites=['math-equations'], sourceIds=[source],
                hints=['Piensa en la relación entre suma y producto al expandir dos factores.',
                       'El área de un rectángulo es el producto de sus lados; conserva las unidades.'])
    lesson['exercises'].extend([
        dict(**base, id='math-factor-transfer-q1', type='case',
             prompt='En el modelo de bandeja, A = (s² + 5s + 4) cm², 0 ≤ s ≤ 5, con s sin unidades. ¿Qué par de lados reproduce esa área?',
             options=[dict(id='a', text='(s + 1) cm y (s + 4) cm'),
                      dict(id='b', text='(s + 2) cm y (s + 2) cm'),
                      dict(id='c', text='s cm y (s + 5) cm')], correct='a',
             explanation=dict(correct='(s + 1)(s + 4) = s² + 5s + 4; cm·cm = cm². Las longitudes son positivas en el dominio supuesto.',
                              misconception='No basta con reproducir el término cuadrático: compara también el coeficiente de s y el término constante.')),
        dict(**base, id='math-factor-transfer-q2', type='numeric',
             prompt='En la misma bandeja ideal, los lados son (s + 1) cm y (s + 4) cm. Para s = 2, ¿qué área obtienes? Responde con unidad de área.',
             correct=18, tolerance=1e-8, unit='cm²', acceptedUnits={'cm²': 1, 'mm²': 0.01},
             explanation=dict(correct='Con s = 2, los lados miden 3 cm y 6 cm: A = 18 cm² = 1800 mm². El parámetro s no tiene unidades. Son valores calculados del modelo, no mediciones.',
                              misconception='Sumar los lados da una longitud. Multiplicarlos da área; 1 cm² = 100 mm².')),
    ])
    enrich_support(lesson)


def enrich_support(lesson):
    # Each example uses a different expression/value from the assessed problem.
    supports = [
        (['Observa la resta: ¿son ambos términos cuadrados?',
          'Identifica la raíz de cada cuadrado y busca factores conjugados; comprueba el término central.',
          'Compara con esta diferencia de cuadrados distinta. Después vuelve a tu expresión.'],
         'Ejemplo alternativo · y² − 49',
         ['49 = 7²: y² − 49 tiene forma a² − b².',
          'Usa (y − 7)(y + 7).',
          'Expande: y² + 7y − 7y − 49 = y² − 49. Los términos lineales se cancelan.'],
         {'b': '(x − 9)(x + 1) se expande a x² − 8x − 9: añade un término lineal que no existe en el enunciado.',
          'c': '(x − 3)² = x² − 6x + 9: no es una diferencia de cuadrados. Un cuadrado de binomio contiene término central.'}),
        (['Busca un factor que divida a todos los términos, incluido el constante.',
          'Divide cada término por el factor elegido antes de escribir el paréntesis.',
          'Revisa cómo la distributividad comprueba un factor común en otro ejemplo.'],
         'Ejemplo alternativo · 5y + 20',
         ['Ambos términos son múltiplos de 5.',
          '5y/5 = y y 20/5 = 4: queda 5(y + 4).',
          'Comprueba: 5·y + 5·4 = 5y + 20.'],
         {'b': '3(x + 6) = 3x + 18: el término constante cambia porque no se dividió el 6 por el factor común.',
          'c': 'x(3 + 6) = 9x. El 6 original no tiene factor x; no puedes extraerlo de ambos términos.'}),
        (['Al expandir (x + p)(x + q), ¿qué determina el término lineal y qué determina el constante?',
          'Escribe parejas de factores del término constante y comprueba también su suma y sus signos.',
          'Prueba el procedimiento con este trinomio diferente.'],
         'Ejemplo alternativo · z² + 9z + 20',
         ['Buscamos suma 9 y producto 20.',
          '4 + 5 = 9 y 4·5 = 20; queda (z + 4)(z + 5).',
          'Expandir da z² + 5z + 4z + 20 = z² + 9z + 20.'],
         {'b': '1·6 = 6, pero 1 + 6 = 7: (x + 1)(x + 6) produce x² + 7x + 6. Cumplir solo el producto no basta.',
          'c': '(−2)(−3) = 6, pero −2 − 3 = −5. Esa propuesta produce x² − 5x + 6.'}),
        (['Una ecuación con un producto igual a cero puede tener más de una solución.',
          'Factoriza la diferencia de cuadrados e iguala cada factor a cero por separado; comprueba ambos signos.',
          'Resuelve una ecuación análoga antes de seleccionar todas las raíces.'],
         'Ejemplo alternativo · z² − 25 = 0',
         ['Factoriza: (z − 5)(z + 5) = 0.',
          'z − 5 = 0 da z = 5; z + 5 = 0 da z = −5.',
          'Sustituyendo, 5² − 25 = 0 y (−5)² − 25 = 0. Selecciona ambas raíces.'],
         {'c': 'Si x = 9, x² − 9 = 81 − 9 = 72, no cero: el término constante no es automáticamente una raíz.',
          'd': 'Si x = 0, x² − 9 = −9, no cero. El producto nulo exige anular un factor, no elegir siempre cero.'}),
        (['Antes de simplificar, busca qué valor anula el denominador original.',
          'Factoriza el numerador y cancela factores solo en los valores donde la expresión original existe.',
          'Compara esta simplificación con una exclusión distinta.'],
         'Ejemplo alternativo · (y² − 25)/(y − 5)',
         ['El denominador exige y ≠ 5.',
          '(y² − 25)/(y − 5) = (y − 5)(y + 5)/(y − 5).',
          'Queda y + 5 para y ≠ 5. En y = 5, la expresión original sigue sin valor.'],
         {'b': 'x = 3 anula el denominador original; justamente ese valor está excluido, no es obligatorio.',
          'c': 'La cancelación no elimina la exclusión x = 3. La forma simplificada debe conservar x ≠ 3 para representar la original.'}),
        (['Evaluar es sustituir: primero calcula cada paréntesis, luego multiplica.',
          'Mantén los paréntesis al reemplazar x; sumar los dos resultados no representa su producto.',
          'Evalúa este producto distinto siguiendo el orden de las operaciones.'],
         'Ejemplo alternativo · (y + 1)(y + 4), y = 3',
         ['Sustituye: (3 + 1)(3 + 4).',
          'Calcula los factores: 4 y 7.',
          'Multiplica: 4·7 = 28. La forma expandida 3² + 5·3 + 4 también da 28.'], {}),
        (['El producto de los lados debe recuperar los tres términos del área.',
          'Busca dos constantes cuya suma sea el coeficiente lineal y cuyo producto sea el constante. Comprueba las unidades.',
          'Interpreta factores de otra área supuesta.'],
         'Ejemplo alternativo · A = (r² + 8r + 15) cm²',
         ['Con r sin unidades y 0 ≤ r ≤ 5, busca suma 8 y producto 15.',
          '3 y 5 cumplen ambas: A = (r + 3)(r + 5) cm².',
          'Los lados (r + 3) cm y (r + 5) cm son positivos en ese intervalo; su producto es un área.'],
         {'b': '(s + 2)² = s² + 4s + 4. El coeficiente lineal sería 4 y se requiere 5.',
          'c': 's(s + 5) = s² + 5s: falta el área constante de 4 cm² y en s = 0 un lado sería cero.'}),
        (['Sustituye el parámetro en ambos lados y distingue longitud de área.',
          'Multiplica las dos longitudes. Para pasar de cm² a mm² eleva al cuadrado el factor 10.',
          'Calcula el área de esta otra bandeja supuesta antes de volver.'],
         'Ejemplo alternativo · lados (r + 3) cm y (r + 5) cm, r = 1',
         ['Los lados miden (1 + 3) cm = 4 cm y (1 + 5) cm = 6 cm.',
          'Área: 4·6 = 24 cm².',
          '1 cm² = (10 mm)² = 100 mm², por tanto 24 cm² = 2400 mm². Son cálculos, no mediciones.'], {}),
    ]
    for exercise, (hints, title, steps, distractors) in zip(lesson['exercises'], supports, strict=True):
        if 'factoring-ref' not in exercise['sourceIds']:
            exercise['sourceIds'] = [*exercise['sourceIds'], 'factoring-ref']
        exercise['hints'] = hints
        exercise['hintExample'] = dict(title=title, steps=steps)
        if distractors:
            exercise['explanation']['distractors'] = distractors
        if exercise['id'] == 'math-factor-q4':
            exercise['explanation']['misconception'] = 'Comprueba todas las raíces: tanto 3 como −3 tienen cuadrado 9. Elegir solo una deja incompleta la solución.'
        if exercise['id'] == 'math-factor-q6':
            exercise['explanation']['misconception'] = 'Sustituye x en ambos paréntesis y multiplica sus valores; sumar factores o reemplazar x solo una vez cambia la expresión.'
