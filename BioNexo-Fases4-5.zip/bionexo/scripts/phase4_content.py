"""Original offline guided experiment and interdisciplinary case. Human review pending."""
def phase4_content():
    guide=dict(id='enzyme-ph-guide-v1',question='¿Cómo cambia la actividad relativa al cambiar solo el pH dentro del mismo modelo?',
      objective='Formular una predicción, comparar dos pH de un mismo modelo e interpretar la diferencia con sus límites.',
      variables=[dict(role='Variable independiente',value='pH, sin unidad, entre 0 y 14.'),dict(role='Respuesta calculada',value='Actividad relativa simulada, entre 0 y 100%.'),dict(role='Condiciones supuestas constantes',value='Temperatura, cantidad de enzima y concentración de sustrato no varían en este modelo.'),dict(role='Comparación controlada',value='Usa el mismo modelo y dos pH distintos. Cambiar de modelo cambia también óptimo y anchura: no aísla el efecto del pH.')],
      steps=['Escribe qué esperas observar y por qué. Una predicción equivocada también sirve para aprender.','Elige un modelo y registra al menos dos pH distintos. Repetir el mismo control devuelve el mismo cálculo: no es una réplica experimental.','Compara la segunda lectura con la primera en puntos porcentuales; una diferencia calculada no prueba significación estadística.','Redacta si las lecturas apoyan tu hipótesis dentro de los supuestos y qué datos reales necesitarías para contrastarla.'],
      example=['Modelo N: A(6) ≈ 80,07% y A(7) = 100%.','Al pasar de pH 6 a 7 la actividad calculada sube ≈19,93 puntos porcentuales.','La curva fue elegida para enseñar; este resultado no es una medición ni valida una enzima real.'],
      facts='El pH puede influir en la función enzimática y la ionización de grupos del sitio activo. Las respuestas reales dependen de la enzima y su entorno.',
      assumptions='BioNexo elige una gaussiana simétrica con máximo relativo 100%, óptimos 7 y 4 y anchuras fijas. No predice irreversibilidad, mecanismos de ionización específicos ni una velocidad absoluta.',
      sourceIds=['enzyme'],reviewStatus='requires-human-review')
    prerequisites=['bio-cells','bio-evidence','chem-matter','phys-units','math-fractions']
    sources=['bio','chem','phys','math-ref']
    def exercise(i,type,prompt,concepts,correct,why,**extra):
        return dict(id=f'project-dilution-v1-q{i}',type=type,prompt=prompt,subjectId='integrated',level=1,
          conceptIds=concepts,prerequisites=prerequisites,sourceIds=sources,correct=correct,
          explanation=dict(correct=why,misconception='Conserva la cantidad de células supuesta y comprueba unidades y alcance del modelo.'),
          hints=['Distingue cantidad total, volumen y concentración.','Usa las ecuaciones y datos de la introducción, sin atribuirlos a un experimento real.'],**extra)
    def options(*labels):return [dict(id=chr(97+i),text=text) for i,text in enumerate(labels)]
    qs=[exercise(1,'multi','¿Qué supuestos permiten conservar la cantidad al calcular esta dilución simulada?',['bio-evidence','chem-matter'],['a','b'],
          'Se supone que no se pierden, producen ni destruyen células y que los volúmenes se suman; transparencia no garantiza viabilidad.',
          options=options('No hay pérdida, producción ni destrucción de células durante la mezcla idealizada.','Los volúmenes son aditivos.','Toda célula contada es necesariamente viable.','Los datos simulados validan el procedimiento real.')),
        exercise(2,'numeric','Se modela 1 mL inicial más 4 mL de medio sin células. ¿Cuál es el volumen final supuesto?',['phys-units','math-fractions'],5,
          'Vf = 1 + 4 = 5 mL, suponiendo volúmenes aditivos.',unit='mL',tolerance=1e-9,acceptedUnits={'mL':1,'L':1000}),
        exercise(3,'numeric','La suspensión inicial tiene 1000 células/mL. Se usa 1 mL y se supone un volumen final de 5 mL. ¿Cuál es la concentración final?',['math-fractions','chem-matter'],200,
          'Cantidad inicial = 1000 células/mL × 1 mL = 1000 células. Concentración final = 1000/5 = 200 células/mL. No es molaridad.',unit='células/mL',tolerance=1e-8,acceptedUnits={'células/mL':1,'células/L':0.001}),
        exercise(4,'chart','Según el modelo de 200 células/mL mostrado, ¿qué representa aumentar el volumen observado de 0,1 a 0,2 mL?',['phys-units','math-fractions'],'b',
          'El recuento esperado aumenta de 20 a 40 células al duplicar el volumen; la concentración del modelo se mantiene.',
          chart=[dict(x=0.05,y=10),dict(x=0.1,y=20),dict(x=0.2,y=40)],xLabel='Volumen observado (mL)',yLabel='Recuento esperado (células)',
          options=options('La concentración necesariamente se duplica.','El recuento esperado se duplica manteniendo la concentración.','Cada muestra real debe contener exactamente 40 células.')),
        exercise(5,'numeric','Tres recuentos simulados de 0,1 mL son 18, 20 y 22. Calcula su promedio: suma los recuentos y divide por 3.',['math-fractions','bio-evidence'],20,
          '(18 + 20 + 22)/3 = 20 células por muestra de 0,1 mL. Promediar no elimina incertidumbre ni sesgos de muestreo.',unit='células',tolerance=1e-9,acceptedUnits={'células':1}),
        exercise(6,'case','El promedio simulado de 20 células en 0,1 mL coincide con la predicción de 200 células/mL. ¿Qué conclusión es defendible?',['bio-evidence','bio-cells'],'c',
          'Las cifras son coherentes con el modelo construido. No prueban homogeneidad real, viabilidad ni exactitud de un instrumento. Harían falta datos experimentales, controles y análisis de incertidumbre.',
          options=options('Demuestra que todas las células reales están vivas.','Valida cualquier dilución y cualquier instrumento.','Es coherente dentro del modelo; su validez real requiere evidencia y controles adicionales.'))]
    activity=dict(id='project-dilution-v1',title='Proyecto · Dilución y recuento celular simulado',
      objective='Relacionar mezcla, cantidad, volumen, proporciones y evidencia biológica mediante seis decisiones y una conclusión justificada.',
      model='Escenario computacional: una suspensión idealizada contiene 1000 células/mL. El modelo toma 1 mL y añade 4 mL de medio sin células. N = C₀V₀; Vf = V₀ + Vmedio; Cf = N/Vf; recuento esperado = Cf × volumen observado. Ejemplo distinto: 600 células/mL × 2 mL en 6 mL finales da 200 células/mL. Para un promedio, suma los recuentos y divide por su número.',
      assumptions=['Todo es cálculo y datos simulados; no hay instrucciones de manipulación de organismos.','Se supone mezcla uniforme a la escala de muestreo, volúmenes aditivos y ausencia de pérdida, producción o destrucción de células.','Una suspensión celular es una dispersión de partículas; células/mL expresa número por volumen, no mol/L.','18, 20 y 22 son cifras de autoría didáctica. No se ajustó una distribución ni un modelo de incertidumbre y no son réplicas experimentales reales.','El recuento no determina por sí solo viabilidad, identidad, precisión del instrumento o seguridad de una muestra.'],
      exercises=qs,sourceIds=sources,reviewStatus='requires-human-review')
    return guide,activity
