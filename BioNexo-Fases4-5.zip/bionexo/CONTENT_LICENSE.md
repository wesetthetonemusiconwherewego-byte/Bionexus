# Materiales educativos originales de BioNexo

Los textos, ejercicios, explicaciones y datos de currículo originales de BioNexo en `src/content`, sus fuentes de autoría `scripts/build_content.py`, `scripts/factoring_pilot.py`, `scripts/phase2_content.py`, `scripts/phase4_content.py`, y las plantillas educativas originales del generador `src/domain/variants.ts`, se ofrecen bajo Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0).

Atribución sugerida: «BioNexo, materiales educativos originales, 2026. CC BY-NC-SA 4.0. Adaptación: [describir cambios]».

Texto y condiciones de la licencia: https://creativecommons.org/licenses/by-nc-sa/4.0/

Las obras enlazadas, marcas y recursos de terceros mantienen sus licencias y no se incluyen en esta concesión. No se distribuyen libros ni imágenes de UNAB, MIT u OpenStax. Los algoritmos del generador y el resto del código están bajo MIT (LICENSE); esta distinción se refiere a los textos/materiales educativos.
