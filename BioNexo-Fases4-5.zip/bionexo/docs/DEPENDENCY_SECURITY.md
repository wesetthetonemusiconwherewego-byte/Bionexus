# P0-04 · Exposición y controles de dependencias

Revisión técnica: 22-10-2026. Base `bce4170`. Alcance: dependencias npm de BioNexo, herramientas instaladas y rutas presentes en mapas de fuentes de las exportaciones locales. **P0-04 finaliza por acotación, no por reparación de las vulnerabilidades. El lanzamiento público sigue bloqueado.** No se ejecutó un build remoto, publicaron artefactos ni probaron binarios Android.

## Hallazgos actuales

`npm audit --json` y el nuevo `npm run security:audit -- --json` devuelven exit 1: 19 entradas high, 0 critical. Son entradas propagadas desde dos avisos raíz. El análisis de exposición no elimina ni rebaja esas severidades.

| Raíz instalada | Ruta observada con `npm ls` | Uso inspeccionado | Mapas de la app |
|---|---|---|---|
| `braces@3.0.3` | Expo 58.0.17 → @expo/metro 58.0.0 → metro-file-map 0.87.1 → micromatch 4.0.8 → braces | Metro usa `micromatch.some` para patrones de archivos. Ese método llama a picomatch; las llamadas a `braces` están en otras APIs de micromatch (`parse`, `braces`, `braceExpand`). La instalación transitiva no demuestra que la ruta inspeccionada alcance las funciones vulnerables. | Ninguna ruta de este paquete en Android/web exportados. |
| `node-forge@1.4.0` | Expo → @expo/cli 58.1.14 → node-forge; también vía @expo/code-signing-certificates 0.0.7 | CLI maneja PEM, certificados, CSR y verificación de certificados autofirmados. Existe uso real de verificación en herramientas; no se afirma que sea imposible explotar el aviso. BioNexo no configura expo-updates ni certificados de actualización firmada. | Ninguna ruta de este paquete en Android/web exportados. |

No se reprodujo explotación de ninguno de los avisos. La conclusión para runtime es limitada a las rutas declaradas por mapas generados con Metro; no es un análisis de alcanzabilidad completo ni de binarios nativos. Algunos módulos de `@expo/cli`, como `metro-require`, sí aparecen en la exportación: no se afirma que todo paquete con nombre de herramienta quede fuera del bundle.

`npm audit --omit=dev` también devuelve las 19 high. Expo está declarado como dependencia de producción y arrastra herramientas Node: omitir devDependencies no permite inferir qué entra al JavaScript distribuido.

## Opciones evaluadas y decisión

Registro npm consultado: últimas estables `braces 3.0.3`, `node-forge 1.4.0`, `micromatch 4.0.8`, `metro 0.87.1`, `@expo/metro 58.0.0`, `@expo/cli 58.1.14`. Último parche estable de Expo 58: `58.0.17`, ya instalado. Los avisos oficiales consultados no indican versión corregida. No se encontró un parche estable compatible que elimine las dos raíces.

| Opción | Decisión y motivo |
|---|---|
| Actualizar dentro de versiones estables compatibles | No hay versiones nuevas de esas rutas consultadas que aporten la reparación; conservar lockfile. |
| `npm audit fix --force` | Rechazado: el informe propone Expo 44.0.6/RN 0.72.17, incompatible con el proyecto actual. No se ejecutó. |
| Override de una versión anterior | Rechazado: rangos afectados incluyen las versiones anteriores; no prueba reparación y puede romper consumidores. |
| Sustituir Metro/micromatch, usar fork o parche criptográfico propio | Fuera del cambio seguro acotado: cambia semántica/herramientas o exige revisión especializada y compatibilidad nativa. No se mantiene un fork de criptografía en BioNexo. |
| Mantener desarrollo local con controles y sin lanzamiento | Adoptado, ADR-007: vulnerabilidades abiertas, auditoría visible y roja; detectar inclusión de raíces en futuros bundles. No es aprobación de producción ni aceptación silenciosa de las alertas. |

## Controles implementados

```bash
npm run check
npm run security:audit                 # hoy exit 1 por las alertas reales
npm run export:android -- --source-maps --output-dir dist-security-android
npm run export:web -- --source-maps
npm run --silent security:bundles -- dist-security-android dist
npm run test:e2e
```

`security:audit` consulta el registro actual sin lista de excepciones, sin `--omit=dev` y sin cambiar dependencias. High/critical producen error; un fallo de red tampoco acredita aprobación. Requiere red. Para conservar JSON: `npm run --silent security:audit -- --json > npm-audit.json`. El umbral no oculta avisos de menor severidad.

`security:bundles` es una guarda offline para **dos nombres de paquete**, no una auditoría universal. Recorre los bundles `.js`/`.hbc` y exige un `.map` adyacente válido y con fuentes para cada uno. Rechaza directorios sin bundles, mapas ausentes/corruptos/desconocidos, bundles vacíos, enlaces simbólicos y secciones remotas o excesivamente anidadas. Inspecciona mapas planos/indexados, `sourceRoot` y rutas Windows. Una coincidencia de `node_modules/braces` o `node_modules/node-forge` produce exit 1. También rechaza versiones futuras de esos paquetes hasta revisar el control expresamente; no existe exclusión automática por número de versión.

El informe JSON incluye hashes SHA-256 de bundle y mapa, cantidad de fuentes y coincidencias. Un mapa limpio no autentica su correspondencia con un bundle arbitrario: ambos deben provenir de la misma exportación confiable. Los hashes vinculan evidencia, no prueban seguridad. No inspecciona Gradle/JAR, código nativo, dependencias con otro nombre, ejecución dinámica ni servicios de desarrollo. No distribuir los mapas generados como parte de un sitio público sin una decisión explícita.

CI conserva el trabajo de regresiones funcionales y añade `dependency-security` independiente. Ese job ejecuta la auditoría viva y guarda su JSON aun cuando falla. No usa `continue-on-error`. El job funcional inspecciona ambas exportaciones con mapas antes de E2E. **La ejecución completa de GitHub Actions no se probó aquí**; se verificaron estructura y comandos locales. No hay pipeline de publicación: el job rojo no impide ejecutar manualmente EAS/Gradle. Mantener la prohibición documental de lanzamiento y exigir este check en cualquier futura protección de rama/pipeline.

## Evidencia y seguimiento

- [Auditoría nueva](evidence/p0-04-audit-2026-10-22.json): resultado completo, sin sustituir el registro anterior.
- [Exposición y versiones](evidence/p0-04-exposure-2026-10-22.json): rutas, versiones publicadas, hashes de fuentes inspeccionadas y lockfile intacto.
- [Bundles comprobados](evidence/p0-04-bundles-2026-10-22.json): 1 bundle Android, 1.318 entradas de fuentes; 9 bundles web, 845 entradas; cero coincidencias de ambas raíces. Las cantidades suman entradas, no módulos únicos.
- [Resumen de verificación](evidence/p0-04-2026-10-22.json) y [PROGRESS](PROGRESS.md).

Mantener R-04 abierto. Antes de publicar o cambiar lockfile: volver a consultar avisos/versiones, rastrear rutas, aplicar solo soluciones compatibles y repetir auditoría, check, Doctor/matriz Expo, ambas exportaciones con mapas y E2E. Si no hay parche, no declarar remediación ni autorizar lanzamiento basándose en bundles limpios. Una nueva ruta de certificados, contenido externo o servidor cambia el alcance y exige revisión.

## Fuentes oficiales consultadas

- [Aviso braces](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm), afectado ≤3.0.3, sin parche indicado.
- [Seguimiento upstream braces](https://github.com/micromatch/braces/issues/73).
- [Aviso node-forge](https://github.com/advisories/GHSA-86w9-cpqp-85rv), afectado ≤1.4.0, sin parche indicado.
- [Actualizaciones Expo](https://docs.expo.dev/workflow/upgrading-expo-sdk-walkthrough/): mantener dependencias acordes al SDK y comprobar con Doctor.
- [Semántica de npm audit](https://docs.npmjs.com/cli/v11/commands/npm-audit/).
- [Artefactos de CI](https://github.com/actions/upload-artifact), interfaz v7 consultada para guardar el informe.

Las conclusiones de uso local son inferencias de fuentes instaladas y mapas; los avisos describen hechos externos. Esta revisión no acredita ausencia de vulnerabilidades en la aplicación o su cadena de construcción.
