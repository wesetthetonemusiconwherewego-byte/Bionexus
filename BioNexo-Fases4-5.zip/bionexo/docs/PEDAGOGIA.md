# Pedagogía implementada y límites

La revisión de Dunlosky et al. (2013, DOI: 10.1177/1529100612453266) califica práctica de recuperación y práctica distribuida con alta utilidad, y autoexplicación e intercalado con utilidad moderada. Esta evidencia orienta el diseño; no prueba la eficacia de BioNexo ni de sus parámetros concretos.

Cada lección combina objetivo, activación, explicación, ejemplo resuelto, al menos seis retos (ocho en el piloto de factorización), aplicación y resumen. Las duraciones son estimadas y requieren medir tiempos con usuarios. Hay ejercicios de transferencia, no solo definiciones. La comparación de hipótesis y observaciones se realiza en el cuaderno del laboratorio; las respuestas abiertas del cuaderno no reciben una calificación automática de calidad científica.

## Planificador determinista v1

Por concepto: historial, paso, intervalo, fecha y lapsos. Primera respuesta correcta sin pista: 1 día. Respuestas correctas en días posteriores avanzan por `[1,3,7,14,30,60]` días. Error: paso cero y repaso en 10 minutos; acierto con ayuda: retrocede un paso y propone 12 horas. Cada error puede adelantar la revisión; los aciertos de un mismo día no escalan varias veces. Esto evita completar toda la escala en una lección. Los instantes se guardan en ISO UTC, los días de evidencia y racha siguen el calendario local del dispositivo. Cambiar la hora del sistema puede alterar recomendaciones; no hay servidor de tiempo.

La cola usa round-robin entre conceptos pendientes, priorizando preguntas falladas y las menos recientes. El intercalado inicial se aplica a repasos, después de enseñar la habilidad dentro de su lección. Hay práctica libre antes de la fecha y revisión manual de errores. Los repasos no vencidos no desaparecen del historial. No hay notificaciones automáticas.

## Evidencia de dominio

Puntaje inicial 0; acierto sin ayuda +0,18, con ayuda +0,08 (máximo 1); error multiplica por 0,65. Etiqueta de dominio: puntaje al menos 0,75 y respuestas correctas sin ayuda en al menos dos días. Es una heurística visible, no una estimación validada de retención ni una acreditación. Preguntas repetidas pueden inflar puntaje: evaluar con ítems nuevos y calibrar parámetros son trabajos pendientes. XP es independiente: 10 por ejercicio respondido correctamente por primera vez, 20 por primera finalización de lección.

Las bases recomendadas se consideran suficientes al tener dominio o haber completado su lección con puntaje de al menos 0,6. Siempre se puede abrir la explicación y elegir practicar igualmente. No hay vidas ni pérdida de XP por error. El diagnóstico tiene seis ítems matemáticos y dos de cada otra ciencia; no asigna dominio ni XP. Sus errores priorizan recomendaciones y sus resultados no certifican capacidad universitaria.

## Apoyo tras errores

Tras al menos dos errores de un concepto se muestra una vía de explicación desde el ejemplo, sus bases relacionadas y un ejercicio sencillo de un prerrequisito (o de la misma habilidad si no hay uno). Al resolverlo puede volverse a intentar el problema original, con ayuda marcada para no confundirlo con recuerdo independiente. La adaptación es por reglas explícitas, sin IA ni inferencia psicológica. La progresión de apoyo usa contenido disponible; P2-01 añade una familia parametrizada acotada para practicar nuevas combinaciones.

## Validación futura

Revisión por profesores de ciencias; pruebas con estudiantes; medir comprensión diferida y transferencia; corregir distractores ambiguos; comparar planificadores con un diseño evaluable. No se afirma que el algoritmo sea óptimo o científicamente validado.

## Piloto de aprendizaje profundo · Fase 1

Solo factorización incorpora cuatro tramos de instrucción/ejemplo/evaluación: estructura, construcción, dominio y transferencia. La posición se deriva del cursor guardado; las otras 23 lecciones conservan su enseñanza inicial. Las expresiones de ejemplos iniciales y de ayuda difieren de los retos. La aplicación a una bandeja es geométrica y supuesta, con dominio y unidades explícitos; no es evidencia experimental ni enseñanza de un procedimiento biológico.

Cada reto del piloto tiene tres pistas: orientación conceptual, procedimiento y un ejemplo alternativo en pasos. El ejemplo no aparece antes de la tercera. La consulta persiste y cada intento posterior se registra con ayuda; un acierto aporta +0,08, sin día independiente, con repaso a 12 horas según el algoritmo existente. Un error mantiene la reducción por 0,65 y repaso en 10 minutos. La solución y explicación del distractor aparecen solo después de responder; una respuesta ya confirmada no cambia retroactivamente. Un retorno tras el puente conserva el borrador/elección y se registra con ayuda por su contador de reintentos. XP sigue separado de dominio. La enseñanza previa forma parte de la lección: un primer acierto sin pistas no demuestra retención y completar todos los retos en un día no satisface el criterio de dominio.

Los mensajes por opción son comentarios redactados, no un diagnóstico validado del estudiante; omisiones y entradas numéricas usan feedback específico general. Selección múltiple comenta distractores elegidos. P2-01/P2-03 añaden una familia parametrizada y reglas explícitas de errores. La medición psicométrica de transferencia sigue pendiente. Revisión humana y tiempos con estudiantes pendientes.

## Motor y adaptación · Fase 2

Catorce variantes de trinomios comparten un único premio de 10 XP. Mantienen los pesos y calendario previos: variar números no multiplica XP y acertar el mismo día no produce varios días de evidencia. Repetir preguntas puede inflar el puntaje heurístico; no es una medida validada de capacidad. Las diez reglas actuales vinculan distractores/omisiones con ideas y bases; no infieren causas psicológicas de un fallo aislado ni diagnostican errores numéricos desconocidos. Se muestran coincidencias históricas y un ejemplo/enlace de base, sin sobrescribir resultados anteriores.

Transferencia a una diferencia de señales: dos retos distintos del ejemplo geométrico, con modelo, unidades relativas, dominio y limitaciones explícitos. Se conserva la muestra inicial, separando pistas, y también la respuesta más reciente para mostrar aprendizaje posterior. No se atribuye validez universitaria a dos preguntas.

Las recomendaciones explican la selección y los repasos indican intervalo, lapsos, fecha y evento origen únicamente cuando puede reconstruirse. Una respuesta reciente y el evento que programó la fecha pueden ser distintos. Ante historial insuficiente/zona cambiada no se inventa una causa. Estas funciones son de lectura: no cambian los intervalos ni garantizan retención. Revisión humana y evaluación con estudiantes permanecen pendientes.

Límite de la marca de ayuda: las lecciones guardan sus pistas al interactuar. Las rondas de revisión/variantes/transferencia son transitorias; si se consulta una pista y se abandona antes de confirmar una respuesta, ese evento no se conserva. «Sin pistas» en sus resultados significa sin ayuda registrada en el intento, no independencia verificada fuera de él. La revisión de este comportamiento y la evaluación empírica quedan pendientes; la muestra no se presenta como una prueba validada.
