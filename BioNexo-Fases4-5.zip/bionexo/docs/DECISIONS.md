# Registro de decisiones

Cada entrada distingue una decisión adoptada de una propuesta pendiente. Cambios posteriores deben añadir contexto y evidencia, no reescribir la historia como si ya se hubiera implementado todo.

## ADR-001 · Conservar arquitectura y versión del MVP

**Estado:** ADOPTADA · 2026-10-22.

La base es el commit `0a5451d`, versión de aplicación 0.1.0. «BioNexo 2.0» nombra el objetivo evolutivo, no una versión ya terminada. Se conserva Expo 58, Router, TypeScript estricto, JSON de contenido y SQLite nativo; no se crea otro proyecto ni se duplican documentos equivalentes. `ARQUITECTURA.md` sigue canónico y `ARCHITECTURE.md` lo indexa. No se cambia `versionCode`, firma ni perfil EAS.

**Consecuencia:** los incrementos son pequeños y el MVP permanece ejecutable. Los números de versión futuros se decidirán al preparar la entrega correspondiente.

## ADR-002 · Abrir almacenamiento corrupto sin reinicializarlo

**Estado:** ADOPTADA · 2026-10-22.

Se reprodujo una clave web `bionexo-state-v1` presente con valor `""`: el código inicial la sobrescribía con un perfil nuevo por usar una comprobación booleana. Ahora solo `null` permite inicializar. Los bytes corruptos quedan intactos y `load()` falla de forma explícita.

**Impacto:** no cambia contrato ni esquema; no hace falta migración. Los valores válidos existentes siguen aceptándose, y una clave verdaderamente ausente crea perfil. La fixture `tests/fixtures/progress-v0.1.0.json` se capturó con el motor del commit base antes de cambios y no debe regenerarse con un motor modificado.

**Evidencia:** prueba nueva falló antes de la corrección y pasó después. Regresiones cubren perfil completo, migración SQLite 1→2, reapertura, rollback, rechazo de corrupción, importación y ausencia real.

**Recuperación:** conservar datos originales; no borrar almacenamiento. Un respaldo válido puede restaurarse mediante el repositorio. Si la apertura bloquea la UI completa, actualmente no existe un rescate desde ese estado: queda en P0-03. No se afirma que esta corrección añada ese flujo.

## ADR-003 · Aislar validación histórica del catálogo mutable

**Estado histórico:** PROPUESTA de auditoría, resuelta mediante ADR-006 en P0-03. Los párrafos siguientes conservan el diagnóstico previo.

`parseBackup` exige que cada ID exista y recalcula la corrección con el catálogo presente. Esa comprobación protege consistencia inmediata, pero acopla historia y autoría. Antes de mejorar contenido o dominio, definir una representación versionada que preserve el significado histórico de cada intento, permita migraciones y no recalcule retroactivamente XP/dominio sin política explícita.

**Criterios de decisión:** fixture anterior intacta, catálogo corregido/retirado sin pérdida de perfil, rechazo de datos inválidos, recuperación desde error y migración atómica/repetible. No se ha elegido aún un esquema nuevo ni se debe implementarlo implícitamente al editar una lección.

## ADR-004 · Registrar alertas sin reparaciones incompatibles a ciegas

**Estado histórico:** ADOPTADA para auditoría; P0-04 completado posteriormente por acotación según ADR-007. Remediación de avisos aún pendiente.

`npm audit` reporta 19 paquetes de severidad alta por propagación de dos avisos raíz (`braces` y `node-forge`). El informe está en `docs/evidence/dependency-audit-2026-10-22.json`. Los avisos consultados no indican versión corregida en esa fecha; las propuestas automáticas incluyen retroceder Expo a 44.0.6 y React Native a 0.72.17. No son una actualización compatible del proyecto.

No se ejecuta `npm audit fix --force`, no se agregan overrides no probados y no se equipara la presencia de una dependencia con explotación en el APK. P0-04 debe rastrear exposición en tooling/runtime, revisar soluciones mantenidas y probar cualquier cambio de lockfile contra la matriz Expo. Las alertas permanecen abiertas y no se autoriza lanzamiento por haber pasado Expo Doctor.

Referencias: [GHSA-vfj7-8cjw-p6xm](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm), [GHSA-86w9-cpqp-85rv](https://github.com/advisories/GHSA-86w9-cpqp-85rv). Son referencias de los avisos, no pruebas de explotación de BioNexo.

## ADR-005 · Separar fuentes de requisitos y nivel de evidencia

**Estado:** ADOPTADA · 2026-10-22.

Son vinculantes la especificación original visible y el sistema de fases de esta sesión. Se buscó el informe detallado anterior: no está en el repositorio. El contexto recuperado solo aporta un resumen de propuestas del asistente (mapa vivo, motor avanzado, BioLab, BioTutor, BioProjects), sin su texto completo ni decisiones adicionales comprobadas del usuario. BioTutor y cualquier detalle no presente no se convierten en requisitos. El plan identifica la falta como REQ-02; continúa la Fase 0 sin bloquear la auditoría por ello.

«Comprobado» requiere una prueba ejecutada con resultado; «observado» significa leído en código/configuración; «declarado» significa documentación o contexto sin verificación equivalente. Un bundle Android no es APK; un viewport móvil no es un dispositivo Android.

## ADR-006 · Contrato histórico y recuperación (P0-03)

**Estado:** ADOPTADA e IMPLEMENTADA; aceptación P0-03 comprobada · 2026-10-22.

Se conserva `UserState.version=1` y su significado académico (XP, dominio, intentos, repasos, diagnóstico y laboratorio). El almacenamiento/exportación pasa a un documento `format: bionexo-progress`, `version: 2`, con el perfil y un registro versionado de identidades y formas de respuesta. La validación de datos históricos comprueba estructura, referencias del propio documento e invariantes; no vuelve a calificar intentos con respuestas actuales ni cambia resultados/XP. La calificación de intentos nuevos sigue en el motor actual. El respaldo no tiene firma: conservar resultados declarados no acredita autenticidad ni exactitud científica.

Los perfiles antiguos sin envoltorio se interpretan usando un registro inmutable capturado del catálogo 0.1.0 antes de cambios. Nunca se regenerará ese registro con una versión futura para hacer pasar tests. Documentos nuevos incluyen sus propias referencias para conservar IDs retirados. Cambiar la estructura de respuesta de un mismo ID requiere otro ID o una migración explícita; corregir su solución no altera el historial.

SQLite añade esquema 3 con `profile_recovery` (texto original, fecha y motivo). La migración y conversión válidas son atómicas, conservan el payload anterior y son repetibles. Una base existente sin perfil no se inicializa silenciosamente. Datos corruptos o de formato futuro quedan intactos y se muestran como error; recuperar usa una importación válida y confirmación, preservando lo reemplazado. Una versión SQLite futura es de solo rescate: no se restaura sobre ella con este código.

Web conserva la clave original y crea copias de recuperación en una clave separada. Cada reemplazo escribe primero la copia; si falla por cuota, no reemplaza progreso. No elimina copias automáticamente. La exportación de rescate conserva texto original y copias (incluso cuando no son perfiles válidos). No reconstruye un archivo SQLite físicamente ilegible: si el driver no abre, se informa esa limitación.

La UI puede exportar rescate, elegir/validar un respaldo y confirmar restauración desde un error de apertura. También conserva esa capacidad si el catálogo falla su validación; en ese caso permite rescate pero no habilita estudio con contenido inválido. No hay reset automático ni se requiere red/cuenta. Una instalación anterior no entiende el esquema 3/envoltorio 2: antes de volver a ella hay que exportar y usar una versión compatible; las copias originales permiten recuperación manual, no downgrade automático.

**Evidencia final:** 57/57 pruebas de lógica/integración, 20/20 E2E web y exportaciones web/Android aprobadas. Fixture anterior intacta, corrupción, futuro, rollback y reintentos comprobados; límites nativos en PROGRESS. La revisión añadió deduplicación de copias automáticas web y rechazo de IDs reservados, con regresiones que fallaron antes del ajuste.

## ADR-007 · Acotar dependencias vulnerables sin degradar Expo (P0-04)

**Estado:** ADOPTADA y verificada para desarrollo local; lanzamiento público BLOQUEADO · 2026-10-22, base `bce4170`.

Auditoría actual: 19 entradas high propagadas desde `braces@3.0.3` y `node-forge@1.4.0`. Registro npm y avisos oficiales consultados: esas son las últimas versiones publicadas y no se indica corrección. Expo 58.0.17 ya es el último parche estable 58 consultado. No se aplica downgrade Expo 44/RN 0.72 propuesto por audit, override sin versión corregida ni parche criptográfico propio.

El incremento implementa controles reproducibles: auditoría viva que falla ante high/critical o error de consulta, e inspección de mapas de fuentes de las exportaciones para detectar si las dos raíces pasan al JavaScript distribuido. Se añadieron nueve pruebas de mapas inválidos, chunks incompletos, rutas y detección positiva/negativa, incluida la CLI. Ninguna comprobación de bundles convertirá una auditoría fallida en aprobación de lanzamiento. CI conservará evidencia y separará las regresiones funcionales del bloqueo de seguridad.

No cambia SQLite, formatos/IDs, contenido ni evaluador; no requiere migración de usuario. El alcance de fuentes JavaScript no acredita seguridad de binarios nativos, Gradle, dependencias omitidas por el mapa o servicios del tooling. Las alertas sin corrección quedan abiertas con restricción de distribución pública. Ver [informe técnico](DEPENDENCY_SECURITY.md), evidencia y PROGRESS.

**Revisión del alcance y cierre:** npm registry confirma que las versiones instaladas de ambas raíces y sus consumidores consultados ya son las últimas estables. Mapas actuales: Android 1 bundle/1.318 fuentes y web 9 bundles/845 fuentes, sin rutas de las raíces. La ruta Metro inspeccionada usa micromatch.some→picomatch; la verificación de certificados existe en CLI. No se infiere alcanzabilidad universal ni se demuestra explotación. También se verificó que omitir devDependencies mantiene las 19 high: no sustituye el análisis de runtime.

**Aceptación técnica:** P0-04 es DONE por acotación, no por reparación; Fase 0 termina su alcance local. Es razonable continuar desarrollo local conservando los controles y entradas confiables del repositorio. El lanzamiento público mantiene R-04 abierto y el nuevo job rojo. No se despliega ni se configura protección de rama remotamente. No existe un pipeline de publicación que impida manualmente EAS/Gradle; cualquier futuro pipeline deberá exigir ese check. Próxima fase requiere una nueva instrucción y no se implementó aquí.

**Pruebas:** 66/66 lógica/integración (57 previas + 9 nuevas), 20/20 E2E, TypeScript/catálogo, exportaciones Android/web, Doctor 20/20, npm ls sin problemas y matriz Expo offline aprobados. Consulta Expo online falló por proxy; se conserva ese límite. Auditoría exit 1 por 19 high confirmadas, no se presenta como PASS. Sin cambios de lockfile/versiones ni migración de usuario.

## ADR-008 · Checkpoints de lecciones con intento y cursor atómicos

**Estado:** ADOPTADA e IMPLEMENTADA; P1-01 verificado · 2026-10-22. Base `ff375cc`.

Antes de editar persistencia se captura `tests/fixtures/progress-p0-03-v2.json` desde el motor anterior: envoltorio 2, perfil 1, SQLite 3. Se conserva también la fixture 0.1.0 intacta. No cambia SQL ni se añade una tabla: el documento JSON pasa a envoltorio 3, mantiene perfil 1 con un campo opcional `lessonSessions` por ID de lección. Los perfiles anteriores conservan todos sus valores y no adquieren sesiones inventadas.

Cada checkpoint versionado lleva sesión/IDs estables, orden de ejercicios, índice, borrador (incluidas unidades), pistas, número de intento y referencia al intento confirmado. Incluye el paso de apoyo y su borrador si está abierto. Una firma no criptográfica de lección y contenido de apoyo detecta cambios del catálogo al reanudar; la lectura histórica valida referencias propias, sin recalificar. Un cambio incompatible ofrece descartar explícitamente el checkpoint, nunca lo elimina al abrir.

Cada respuesta y el checkpoint con su referencia se guardan en la misma mutación transaccional/localStorage. El ID de intento se deriva de sesión, ejercicio y contador; repetir una solicitud confirmada es idempotente. Avanzar guarda cursor; terminar guarda premio y elimina solo ese checkpoint en la misma mutación. Descartar una sesión no borra intentos/XP ni otras sesiones. Salir pausa y espera las escrituras pendientes; un cierre abrupto solo puede recuperar la última escritura confirmada, no una operación sin commit.

La migración de envoltorio 2→3 conserva el texto exacto antes de convertir. SQLite usa su transacción actual; web escribe primero la copia y deduplica reintentos automáticos. Versión de documento/BD futura queda protegida. El código anterior no entiende envoltorio 3; no hay downgrade automático. Exportar rescate permite conservar originales. El respaldo nuevo incluye sesiones; restaurar uno antiguo mantiene su perfil sin sesiones, con confirmación/copia del reemplazado.

Alcance: lecciones. Diagnóstico y repaso conservan su flujo existente, sin prometer reanudación. No cambian algoritmos de dominio, catálogo ni dependencias. Se mantienen controles P0-04. Antes de DONE: migración/rollback/reopen, interrupciones antes/después del commit, duplicación y E2E de borrador/feedback/apoyo/fin/cancelación.

**Evidencia de aceptación:** 83/83 pruebas (66 previas + 17 nuevas), 32/32 E2E (20 previos + 12 nuevos), TypeScript/catálogo, ambas exportaciones con mapas, guarda de dos raíces sin coincidencias y Doctor 20/20. Casos cubiertos: fixture raíz/v2 intacta, copia de migración exacta/rollback/reintento, SQLite en disco/reopen, concurrencia, interrupción antes de commit y después de confirmar, cuota, última respuesta/premio/limpieza atómicos, descarte aislado, sesiones futuras y contenido/apoyo cambiado. E2E comprueba borrador/pistas, feedback, doble toque, pestaña cerrada/reabierta, apoyo y retorno, fin/descarte y fallo de guardado con reintento.

Se actualizaron las aserciones de formato futuro (4 en vez de 3) y el E2E de práctica repetida usa descarte explícito: «Salir» ahora pausa y ya no reinicia la lección. No se eliminaron pruebas. La revisión añadió firma del apoyo, estado de inicio por ID de lección y limpieza del aviso tras una escritura exitosa. No se probó Android nativo; fuentes, límites y evidencia en PROGRESS.

## ADR-009 · Piloto progresivo y ayudas de factorización

**Estado:** ADOPTADA e IMPLEMENTADA; Fase 1 comprobada · 2026-10-22. Base `ae7a8ab`. El usuario autoriza toda la Fase 1, P1-02 y P1-03; no las fases posteriores.

El piloto es `math-factor-lesson`, según la prioridad visible de reforzar álgebra. Se añaden cuatro tramos didácticos: reconocer estructura, construir/comprobar, conservar dominio y transferir a un modelo geométrico de laboratorio. Cada tramo define objetivo, explicación, ejemplo en pasos y ejercicios. Los seis ejercicios originales conservan ID, orden, respuesta y forma; se agregan dos retos de transferencia con IDs nuevos. Las otras 23 lecciones permanecen accesibles. Los tramos son una decisión pedagógica local, no niveles exigidos por el informe 2.0 ausente ni nuevos cursos universitarios.

Los campos opcionales del catálogo no se almacenan en perfiles. La posición del tramo se deriva del cursor ya persistido; no se cambian SQL 3, envoltorio 3, perfil 1 ni checkpoint 1. La finalización anterior no se revoca ni pierde XP. Una sesión antigua del piloto tiene otra firma y conserva su punto de reanudación, bloqueado hasta descarte explícito/exportación, según ADR-008; no se reinterpretan respuestas antiguas. La fixture `tests/fixtures/progress-p1-01-v3.json` se capturó con el código `ae7a8ab` antes de editar contenido, a partir del respaldo v2 histórico más borradores/pista de factorización y fracciones. SHA-256: `6a54f58649415aefe2d00f5232f05f412e93c8c2a7438d14889915221fbc5ad8`. Nunca regenerarla. Verificar perfil exacto, sesión ajena compatible, gate del piloto y recuperación sin pérdida. No hace falta migración de representación; la transición de contenido es explícita.

P1-03 reutilizará `hintCount` para tres pistas graduadas, con ejemplo alternativo en la última, y explicaciones ligadas a distractores. Consultarlas cuenta como ayuda en el intento; feedback posterior no modifica un intento ya confirmado. Reintentar después de ver solución conserva borrador y cuenta como ayuda por `attemptNo`. La enseñanza de un tramo ocurre antes de sus retos y no acredita por sí sola dominio: se mantiene la exigencia de evidencia independiente en dos días; no se añade una validación psicométrica. No se cambian los algoritmos de dominio/repaso ni se evalúan expresiones con eval.

Fuente matemática verificada: OpenStax, *Algebra and Trigonometry 2e*, 1.5 Factoring Polynomials, https://openstax.org/books/algebra-and-trigonometry-2e/pages/1-5-factoring-polynomials (consulta 2026-10-22). Ejemplos y problemas de nueva autoría; no se copian pasajes ni figuras. Licencia oficial consultada: CC BY-NC-SA 4.0. Las identidades algebraicas son hechos; el diseño de bandeja es un modelo geométrico supuesto, sin datos experimentales ni inferencias biológicas. Revisión académica humana pendiente.

**Evidencia final ADR-009:** 93/93 pruebas (83 previas + 10 nuevas), 40/40 E2E (32 previos + 8 nuevos), cero omitidos/flaky; ambas exportaciones, guardas de dos raíces, Doctor 20/20, matriz instalada offline y npm ls sin problemas. Fixture v3 intacta; gate/descartar preservan historial; sesión de fracciones reanuda; 23 lecciones, 144 contratos/soluciones previos y 12 diagnósticos conservados. Autoría determinista. Vista móvil sin desbordamiento. Ayuda afecta intentos futuros, no recalifica feedback guardado; volver del puente conserva elección. Sin cambios de SQL/formato/algoritmos/dependencias. Revisión humana y Android/APK pendientes; auditoría exit 1, 19 high/0 critical, lanzamiento público bloqueado. Ver evidencia de Fase 1.

## ADR-010 · Fase 2: evaluación vigente y práctica reproducible

**Estado:** ADOPTADA e IMPLEMENTADA; Fase 2 verificada · 2026-10-22. Base `d2a3258`. Autorizada toda Fase 2: P2-02 primero (R-06), P2-01, P2-03 y P2-04; no Fase 3.

Se congela `tests/fixtures/progress-phase1-v3.json` usando el motor anterior d2a3258: parte de la fixture v2 e incluye un intento de `phys-vectors-q3` con `1/1e309`, aceptado como cero por el evaluador antiguo, y checkpoints actuales de fracciones/factorización. SHA-256 `89b43a23c06ef1c5851db0ddb395d649874a5c71dbccdf03fdef2d215c83528c`. No regenerar. La lectura histórica conserva literalmente estado, corrección, XP, repasos y sesiones. Las nuevas respuestas usarán operandos finitos, sin underflow a cero ni overflow, unidades propias válidas y tolerancia absoluta declarada más margen relativo de punto flotante. No eval ni álgebra simbólica general.

La familia inicial será de trinomios mónicos: dos enteros distintos p,q de 2 a 7, catorce pares/semillas acotadas, excluyendo (2,3) porque ya es un reto original. La definición académica se incluye offline desde autoría; un generador TypeScript puro/versionado calcula enunciado, distractores y solución. Cada ID codifica familia, versión y semilla. Todos los IDs generados se registran en `allExercises` y en referencias del respaldo. Identidad y solución v1 serán inmutables; cambiar su matemática exige versión/IDs nuevos, no reinterpretar historial. La práctica no infla el conteo de las 24 lecciones.

No se añaden campos persistentes: ID del ejercicio identifica inequívocamente los parámetros del banco finito. Envoltorio 3/perfil 1/checkpoint 1/SQLite 3 permanecen: no hay representación que migrar. Las referencias existentes ya permiten incluir nuevos IDs con la forma de respuesta. Se conserva la política de 10 XP por cada ejercicio anterior y 20 por lección. Las variantes de esta familia comparten un solo premio de 10 XP, representado por su ID semilla 0 en `rewardedExerciseIds`, ya compatible con la validación de XP; variar semilla no crea XP infinito. La corrección se calcula por registro instalado, nunca por la instancia que mande la UI. El repaso parametrizado será transitorio como otros repasos, con identidad/historial exportables; no se promete reanudar su cursor.

P2-03 relacionará distractores concretos con reglas pedagógicas explícitas, bases y apoyo; no diagnosticará capacidad. Añadirá dos preguntas de transferencia a una diferencia de señales matemáticas simulada, distinta del ejemplo geométrico, con unidades relativas/dominio y limitaciones. La muestra de transferencia contará la primera respuesta de cada reto, separando ayuda y omisiones, sin sustituir dominio ni XP. El historial anterior no se reetiqueta como prueba independiente nueva.

P2-04 envolverá selección/revisión existentes con razones estructuradas derivadas de eventos, vencimientos y prerrequisitos reales. La misma entrada/instante produce mismo orden y motivos. No cambiar pesos, intervalos ni calendario guardado. Mantener práctica libre y explicar límites de las heurísticas. Los checkpoints de lecciones de Fase 1 deben seguir compatibles: no cambiar contenidos originales ni forma base/firma de apoyo sin necesidad; toda incompatibilidad se conserva para descarte explícito según ADR-008.

Fuentes: OpenStax, *Algebra and Trigonometry 2e*, §1.5 (métodos algebraicos, consulta 2026-10-22); especificación ECMAScript, Number.isFinite y Number (https://tc39.es/ecma262/multipage/numbers-and-dates.html). Redacción propia y modelo supuesto, sin datos experimentales; revisión humana pendiente. Sin dependencias ni servicios externos nuevos.

**Evidencia final ADR-010:** 125/125 pruebas (93 previas + 32 nuevas), 52/52 E2E (40 previos + 12 nuevos), sin omitidos/flaky; ambas exportaciones, guarda sin coincidencias de dos raíces y Doctor 20/20. Matriz instalada offline PASS con advertencia; npm ls sin problemas. Fixture previa exacta y checkpoints de Fase 1 compatibles; familia con 14 identidades/expansiones, premios compartidos y SQLite/reapertura/restauración verificados. Reglas y transferencia separan ayuda/primera/última respuesta sin falsear capacidad. Guía conserva selección y calendario; medianoche en Santiago/cambio de zona y procedencia desconocida cubiertos. Se corrigió el estado ARIA web observado por E2E. Inspección móvil sin desbordamientos. Salidas nuevas: Android 1/1328 fuentes, web 11/855, esta última con 42 archivos idénticos a los probados.

La auditoría sigue exit 1, 19 high/0 critical, sin dependencias nuevas. No hay APK ni Android nativo/TalkBack/revisión académica humana probados. SQL 3/envoltorio 3/perfil 1/checkpoint 1 intactos; no migración de representación ni recalificación histórica. Los resultados antiguos del evaluador se conservan aunque ahora se rechace la entrada. Fases 3–5 pendientes.

## ADR-011 · Interacciones accesibles y contexto del gráfico · Fase 3

**Estado:** ADOPTADA antes de editar; verificación en curso. Base `6d5e92d`, 2026-10-22. Alcance autorizado P3-01/02/03; no Fase 4.

El esquema celular conserva enunciado, IDs, opciones y solución. Añade regiones táctiles amplias y una alternativa textual equivalente: elegir una región usa el mismo borrador/respuesta/checkpoint que los radios existentes. No revela nombres/funciones antes de comprobar ni aporta ayuda adicional oculta. Después de comprobar sigue el feedback académico vigente. SVG original, simplificado y sin escala; no representa todos los orgánulos. Fuente conceptual verificada: OpenStax Biology 2e §4.3, https://openstax.org/books/biology-2e/pages/4-3-eukaryotic-cells (2026-10-22), sin copiar figuras ni pasajes; revisión humana pendiente.

El gráfico de laboratorio reutiliza exclusivamente `enzymeActivity`/`enzymeCurve`, sin cambiar parámetros, unidades ni interpretación científica. Controles y lectura accesible comparten el pH/modelo/comparación. Se conserva este contexto en parámetros de navegación primitivos y validados; cambiar pestaña o recargar conserva los controles, también con URLs inválidas normalizadas. Notas y puntos aún no guardados conservan su alcance transitorio anterior y se advierte; guardar cuaderno sigue siendo una acción explícita. No incluir observaciones ni datos personales en la URL. Este incremento no introduce diseño experimental nuevo ni modifica el motor del futuro P4-01.

Antes de optimizar se medirá selección/explicación/serialización con historiales sintéticos representativos. Una optimización solo podrá sustituir búsquedas repetidas por índices locales de lectura conservando exactamente orden estable, última aparición en el array, diagnósticos incluidos donde antes estaban incluidos, fechas y razones. Sin cambiar evaluador, dominio, calendarios, firmas ni datos guardados. Comprobar equivalencia contra el selector anterior e inmutabilidad.

Sin cambios de representación: SQL 3/envoltorio 3/perfil 1/checkpoint 1. No requiere migración ni reescritura; se preserva la recuperación existente. Fixture previa capturada con motor `6d5e92d`: `progress-phase2-v3.json`, incluye historial anterior, variante y transferencia; SHA-256 `3f7be3e76a11bd9f5894ffca01dc235b10d9d2770bc2b71ff4667d7ba13ffc84`. Nunca regenerar. Restauración/exportación deben conservar exactamente el perfil y checkpoints.

Auditoría web con tamaños/foco/contraste/movimiento y mediciones registradas no acredita TalkBack ni rendimiento de Android. P3-03 permanecerá TESTING si esos criterios nativos no pueden ejecutarse. R-04 y el bloqueo de lanzamiento público continúan. Sin dependencias, cuentas ni costes nuevos.

**Resultado local ADR-011:** diagrama controlado, contexto del gráfico en navegación y proyección/lecturas accesibles implementados. Índice local de repaso medido y contrastado con selector congelado; ningún cambio de semántica/persistencia. Foco, bordes, reajuste y marca sin colisión comprobados con regresiones de navegador. Matriz de pruebas/exportaciones y límites en PROGRESS/UX_AUDIT; P3-01/02 DONE y P3-03 TESTING hasta dispositivo. No se cierra Fase 3 ni se inicia Fase 4 automáticamente.

## ADR-012 · Preparación del paso a Fase 4 sin cerrar aceptación pendiente

**Estado:** ADOPTADA antes de editar herramientas; base `f23fc84`, 2026-10-22. El usuario autoriza preparativos para Fase 4; no autoriza declarar TalkBack/Android probados ni sustituir criterios de P3-03.

Se añaden herramientas locales, sin dependencias: preflight de entorno Android y comprobador de integridad/completitud de un registro manual de aceptación. No descargan SDK, no llaman EAS, no instalan/abren/desinstalan apps, no importan perfiles ni cambian preferencias del teléfono. La plantilla empieza íntegramente PENDING. Una ejecución sin SDK o sin resultados sale con código distinto de cero y genera diagnóstico, nunca un PASS fabricado.

La aceptación queda ligada a una huella SHA-256 de fuentes/configuración/recursos de aplicación, commit del build, APK identificado y evidencias locales con hash. La huella excluye documentos/herramientas para no invalidar pruebas al escribir el informe, pero detecta cambios de aplicación/dependencias/configuración. Comprobar el registro verifica su integridad y completitud, no autentica que una persona haya ejecutado TalkBack ni sustituye revisión humana, firma APK o verificación del dispositivo. Se impide leer evidencias fuera de la carpeta indicada, incluidas rutas por symlink.

P3-03 y Fase 3 conservan TESTING; Fase 4 PENDING. El bloqueo público R-04 no se confunde con el desarrollo local permitido por ADR-007. No cambia código de app, contenido, IDs, firmas de lecciones, SQL 3/envoltorio 3/perfil 1/checkpoint 1: no requiere migración ni nueva fixture de formato. Las fixtures anteriores y su motor continúan intactos. P4-01 se prepara para trabajar después de la puerta, sin ampliar ahora el modelo gaussiano ni el cuaderno.

**Hallazgo reproducido durante la preparación:** el prebuild Android aislado termina pero avisa que `userInterfaceStyle: automatic` requiere `expo-system-ui`, ausente. Se corrige únicamente esa dependencia nativa necesaria, mediante `expo install` y la matriz incluida (`~58.0.6`); no se actualiza Expo/RN ni se tocan datos. La huella de aplicación/lockfile cambia y deberá asociarse al futuro APK. Repetir prebuild, check, exportaciones/guardas, E2E y auditoría antes de entregar. No confundir desaparición de aviso con validación visual nativa. Esta corrección es parte de preparación, no BioLab.

**Resultado PREP-04:** 148/148 pruebas y 62/62 E2E, TypeScript/catálogo, exportaciones/guardas y Doctor 20/20 PASS. Generación nativa aislada sin el aviso reproducido; preflight/plantilla siguen BLOCKED/exit 1 por falta de entorno/resultados. Preparación DONE, P3-03/Fase 3 TESTING y Fase 4 PENDING. La huella normaliza LF/CRLF en texto y admite ZIP sin Git. Solo se añade expo-system-ui; no cambian datos ni modelos. R-04 continúa abierto, 19 high/0 critical; sin APK/EAS/dispositivo probado.

## ADR-013 · Desarrollo restante autorizado y cierre verificable

**Estado:** ADOPTADA antes de editar dominio/contenido. Base `18eb63a`; fecha local 2026-10-22. El usuario pide «lo que falta y la fase 5»: autoriza desarrollar P4-01/02/03 y verificaciones/integración P5-01, sin declarar resultados nativos no ejecutados. Se revisa la secuencia local anterior para continuar implementación mientras P3-03/P5-02/P5-03 permanecen pendientes por entorno/evidencia. No se anula el comprobador de aceptación ni el bloqueo público R-04.

Se congela `progress-pre-phase45-v3.json` con el motor 18eb63a: incluye registros/checkpoints/XP anteriores y un laboratorio antiguo de una condición con lectura 12.345% que no se recalculará. SHA-256 `cb2ce6187f255f63d761f5371d9701b55186e7c3f66b308f9d483a68f828c8dc`; nunca regenerar. Nuevos registros exigirán al menos dos pH distintos de un mismo modelo para comparar; duplicar la condición no cuenta como réplica real ni evidencia independiente. Registros antiguos de una condición o modelos mezclados siguen visibles/exportables sin aplicar retroactivamente el requisito. Sus lecturas se representan tal como se guardaron, sin ajustar al motor actual.

No se añaden campos persistentes: se reutiliza LaboratorySession para hipótesis, observación y puntos; el diseño guiado/predicciones se deriva o permanece en la interacción. Reapertura es lectura de sesiones guardadas con gráfico/tablas y comparación tipada. Guardado con ID estable idempotente, sin XP nuevo por laboratorio. SQL 3/envoltorio 3/perfil 1/checkpoint 1 no cambian: no hay representación que migrar. No introducir borradores invisibles, meter proyectos en campos de texto ni reinterpretar historial.

P4-03 usará una segunda TransferActivity con seis retos de dilución/recuento celular matemático simulado, ruta propia y prerrequisitos ya implementados. Reutiliza ejercicios/registro/respaldo y XP actual; no se agrega lección/unidad vacía ni se finge implementar conceptos avanzados planificados. La primera actividad de transferencia y las 24 lecciones se conservan literalmente. La actividad final requiere una conclusión con límites, no solo memoria.

Autoría académica adicional en phase4_content.py incluida por build_content.py; guía y proyecto separados de UI. Fuentes primarias consultadas: OpenStax Biology 2e §6.5 y Chemistry 2e §3.3, https://openstax.org/books/biology-2e/pages/6-5-enzymes y https://openstax.org/books/chemistry-2e/pages/3-3-molarity (2026-10-22). La gaussiana, concentración celular idealizada, homogeneidad, volúmenes aditivos y muestras son supuestos/datos simulados de BioNexo, no validación experimental. No extrapolar molaridad a afirmar que células sean soluto molecular. Revisión humana pendiente; sin manipulación de organismos.

P5-01 reforzará integridad de currículo/grafo y tratamiento de catálogos malformados, con regresiones, fuentes y revisión automática documentada. Una revisión de código por el asistente no se etiqueta como revisión académica humana. Para P5-02/03 se comprueba viabilidad local; sin SDK/JDK/APK/driver/dispositivo, se deja evidencia del bloqueo y guía de entrega. No costes, cuentas o EAS sin nueva autorización específica; no bajar controles de seguridad para publicar.

**Resultado funcional ADR-013:** commit 3dcca6d implementa P4-01/02/03 y controles de integridad. `check` 163/163 y E2E final secuencial 68/68 PASS; contenido/grafo/fixtures previos exactos. Precarga del destino raíz corrige fallo reproducido al finalizar proyecto web tras recarga y sin red. No convierte la web en PWA. Revisión técnica de ecuaciones/unidades/límites en ACADEMIC_REVIEW, humana pendiente.

Se instalaron herramientas oficiales fuera de Git y se intentó Gradle local. La primera pasada concurrente llegó al límite de 8 GB del entorno y produjo timeout en un test anterior; se interrumpieron ambos procesos, se repitió la suite completa sin Gradle (68/68) y se limitó Gradle a dos trabajadores, sin paralelismo y Kotlin in-process. No se cambió timeout, SDK/RN/lockfile ni seguridad para forzar un PASS. El resultado final de APK y los pendientes se registran en PROGRESS; no se confunden presencia de herramientas o hashes con prueba nativa humana.

**Hallazgo de inspección del primer APK:** la plantilla fusiona SYSTEM_ALERT_WINDOW aunque BioNexo no usa superposiciones. Se bloquea explícitamente en app.json, conservando package/versionCode/firma y progreso; no cambia contenido ni representación. Se requiere regenerar manifiesto, recompilar y comprobar que el permiso no figura en el APK final. El primer APK no es el artefacto definitivo de entrega.

**Cierre de compilación ADR-013:** 83eb426 bloquea overlay. CNG regenerado y build offline final con Gradle 9.4.1, dos trabajadores, sin paralelismo, Kotlin in-process: exit 0/BUILD SUCCESSFUL in 5m 41s; 643 tareas. Firma v2, certificado idéntico, ZIP/alineación 16 KB, ABI ARM64, versión/package y Hermes/contenido nuevo comprobados; permisos bloqueados ausentes. P5-03 TESTING/P5-02 BLOCKED/P3-03 TESTING por instalación y aceptación reales pendientes. Web final idéntica en todos sus archivos a la suite de 68 E2E aprobada; check 163/163 y Doctor 20/20 repetidos después del ajuste nativo. Evidencia y SHA del APK en PROGRESS.
