# Estado de BioNexo 0.1.0

Este archivo conserva el registro original de la entrega. Para la auditoría y evolución por fases iniciadas después, consulta [PROGRESS.md](PROGRESS.md) y [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md); los resultados actuales y riesgos no se deducen de este registro histórico.

Fecha de verificación: 22 de octubre de 2026. Entrega: código fuente del MVP. **No se entrega un APK ni se ha ejecutado en un dispositivo Android.**

## Fases y criterios

| Fase | Resultado | Evidencia |
|---|---|---|
| 1 · Fundaciones | Implementada | Proyecto Expo/Router, TypeScript estricto, modelos, tema, repositorio local, migraciones y pruebas. |
| 2 · Experiencia educativa | Implementada | Onboarding, diagnóstico, rutas, ciclo de lección con seis ejercicios, feedback y perfil persistente. |
| 3 · Aprendizaje adaptativo | Implementación inicial | Evidencia por concepto, calendario determinista, errores, intercalado, recomendaciones y puente con prerrequisito. Heurísticas sin validación empírica. |
| 4 · Laboratorio y contenido | Implementada para el MVP | Cuatro materias × tres unidades × dos lecciones × seis ejercicios = 24/144; 12 preguntas diagnósticas adicionales; laboratorio pH/enzima y cuaderno. |
| 5 · Calidad | Verificación automatizada realizada; revisión nativa/académica pendiente | TypeScript, validación, 24 pruebas de dominio/SQLite y 12 recorridos de interfaz web en tamaños móvil/escritorio. Exportaciones web y Android. |

## Pruebas ejecutadas

- `npm run check`: TypeScript, integridad del catálogo y 24 pruebas unitarias/integración, todas aprobadas.
- `npx expo install --check`: dependencias compatibles con el SDK.
- `npx expo-doctor`: 20/20 comprobaciones aprobadas.
- Exportación web: bundle y recursos generados correctamente.
- Exportación Android: bundle Hermes y recursos generados correctamente; esto **no es compilar un APK ni probar Android**.
- Playwright, Chromium local, dos tamaños: 12 recorridos aprobados. Onboarding; terminar lección y conservar progreso tras recarga; navegación de la interfaz ya cargada sin red; diagnóstico completo; laboratorio y cuaderno; tema; revisión de errores; exportación/importación; formatos de ejercicio; apoyo adaptativo y regreso al problema original.
- SQLite real con `node:sqlite`: creación, cierre y reapertura de archivo, migraciones v1→v2, rechazo de versión futura, restauración, rollback y escrituras concurrentes.
- Inspección visual de inicio móvil, laboratorio móvil y escritorio; se ajustó la composición de inicio para dejar más espacio a contenido y controles en pantallas estrechas.

Las pruebas de navegador usan el adaptador web; no verifican `expo-sqlite`, `expo-sharing`, selector de archivos o accesibilidad nativos. La navegación sin red verificada corresponde a una interfaz web ya cargada. La vista web no incluye service worker/PWA y no promete arrancar desde cero sin red.

## Funcionalidades terminadas

Siete secciones principales; 10 tipos de ejercicio; unidades y tolerancias numéricas; fuentes/glosario/fórmulas; XP idempotente; rachas por días locales; niveles; objetivos; desafíos semanales; insignias por criterios; evidencia separada de puntos; explicaciones abiertas; práctica libre; tema del sistema y movimiento reducido; respaldo validado con confirmación.

## Pendientes y límites concretos

1. **Validación Android:** APK local con Android SDK/JDK adecuado, instalación, cierre forzado/reapertura, modo avión, SQLite nativo, importación/exportación y TalkBack. Este entorno no dispone de Android SDK/adb/emulador.
2. **Revisión académica humana:** todo el contenido está marcado `requires-human-review`. El algoritmo y los tiempos de estudio requieren evaluación con estudiantes. No hay acreditación universitaria.
3. **73 conceptos planificados:** biología molecular avanzada, cálculo, bioquímica, estadística, bioinformática, IA y rutas integradas. El mapa contiene sus dependencias, pero no hay lecciones ejecutables de esos conceptos.
4. **Sesiones:** se conservan respuestas de sesiones interrumpidas, pero reiniciar una lección vuelve a su primer ejercicio. No hay reanudación exacta de pantalla ni fusión de respaldos.
5. **Gamificación:** los logros aparecen como estados en progreso/resumen. Hay ilustración estática y transición respetuosa del movimiento reducido; celebraciones animadas elaboradas y un icono de launcher propio quedan pendientes.
6. **Escala:** perfil JSON transaccional dentro de SQLite para el MVP; habrá que normalizar/indexar para historiales muy grandes. Límite de respaldo de 10 MB. El calendario confía en la hora local.
7. **Alcance externo:** sin cuentas, backend, tutor IA, notificaciones ni publicación en tiendas. iOS mantiene una base compatible pero no está empaquetado ni probado.

## Revisión manual recomendada para la primera instalación Android

Instalar → omitir o completar diagnóstico → estudiar una lección → cerrar proceso → abrir y comprobar progreso → modo avión → estudiar otra lección y guardar laboratorio → exportar → cambiar nombre → importar y confirmar → comprobar nombre/progreso restaurados. Probar también texto grande, TalkBack, orientación horizontal y modo claro.
