# Currículo y prerrequisitos

El mapa contiene 97 conceptos: 24 implementados con lección y 73 planificados. 23 lecciones tienen seis ejercicios y el piloto de factorización tiene ocho (146 en total); las doce preguntas del diagnóstico son adicionales. El archivo estructurado completo es `src/content/catalog.json`; el grafo de 97 nodos, incluyendo dependencias cruzadas, es `src/content/prerequisites.json`. No se requieren contenidos planificados para ejecutar el MVP.

## Relación con las referencias universitarias

| Área de BioNexo | Referencia de área universitaria | Interpretación |
|---|---|---|
| Biología | UNAB: Biología Celular, Genética, Biología Molecular, Microbiología General | Fundamentos escolares y progresión conceptual propuesta. |
| Química | UNAB: Química General, Orgánica, Analítica y Bioquímica General | El orden de cada microlección es propio de BioNexo. |
| Física | UNAB: Física Aplicada a las Biociencias, Fisicoquímica | Física introductoria y conexiones biofísicas. |
| Matemáticas | UNAB: Álgebra y Cálculo Elemental, Cálculo Avanzado, Bioestadística | El refuerzo previo de fracciones/factorización es propio de la app. |
| Programación/modelos | MIT: programación y ecuaciones diferenciales; UNAB: Bioinformática y Ciencia de Datos | Guía de integración; no equivalencia de asignaturas ni créditos. |
| Biología sintética/IA | Ampliaciones de BioNexo | Contenidos complementarios; no se afirma que aparezcan como cursos con ese nombre en la malla consultada. |

Los valores `unab-aligned` y `mit-aligned` indican afinidad temática con áreas de las referencias, no que cada subtema o arista sea un requisito oficial. `foundation` identifica andamiaje previo y `complementary` ampliaciones propuestas. Todas las aristas son decisiones didácticas de BioNexo.

## Contenido implementado

| Materia / unidad | Lecciones (6 retos; factorización: 8) |
|---|---|
| Biología / 01 · La lógica de la vida | ¿Qué hace vivo a un sistema? · Preguntar, medir, comparar |
| Biología / 02 · Materia viva | Agua, polaridad y puentes · Las piezas moleculares |
| Biología / 03 · Arquitectura celular | Un mapa de la célula · Fronteras en movimiento |
| Química / 01 · Observar la materia | Sustancias y mezclas · Cambios y conservación |
| Química / 02 · Identidad atómica | Dentro del átomo · Leer la tabla periódica |
| Química / 03 · Unir y contar | Enlaces e interacciones · Del mol a la masa |
| Física / 01 · Medir el mundo | Magnitudes y unidades · Medir también es estimar |
| Física / 02 · Describir movimiento | Dirección y desplazamiento · Leer el movimiento |
| Física / 03 · Fuerza y energía | Fuerza neta y cambio · Trabajo y energía |
| Matemáticas / 01 · Herramientas numéricas | Fracciones que significan algo · Potencias y escalas |
| Matemáticas / 02 · Álgebra con sentido | Ecuaciones en equilibrio · Factorizar es reconocer estructura |
| Matemáticas / 03 · Funciones para modelar | Funciones y cambio lineal · Curvas y raíces |

## Piloto progresivo de factorización · P1-02

`math-factor-lesson` conserva seis retos originales y añade `math-factor-transfer-q1/q2`. Cuatro tramos, cada uno con dos retos: reconocer estructura; construir/comprobar; conservar significado/dominio; transferir a un diseño. Objetivos, ejemplos en pasos y fuentes están en `stages` del catálogo. La autoría modular se encuentra en `scripts/factoring_pilot.py`, invocada por el generador principal. La duración de 12 minutos es una estimación sin validación con estudiantes.

La bandeja rectangular es un modelo geométrico supuesto: s sin unidades, 0 ≤ s ≤ 5; lados (s+1) cm y (s+4) cm; A=(s²+5s+4) cm². No representa crecimiento celular, volumen ni resultados experimentales. Las identidades y unidades tienen pruebas; la revisión pedagógica/científica humana sigue pendiente. Los tramos son una propuesta de BioNexo, no asignaturas UNAB/MIT. Las otras 23 lecciones mantienen su estructura inicial.

## Práctica y transferencia adicionales · Fase 2

Se mantienen las 24 lecciones y sus 146 ejercicios, así como 12 diagnósticos. Además: una familia de trinomios produce 14 variantes únicas por pares p<q de 2 a 7, excluyendo (2,3), ya evaluado en el piloto. Se registran aparte de las lecciones; fuentes y revisión humana pendiente. El banco v1 tiene IDs inmutables para reconstruir datos y soluciones. Las diez reglas de errores tienen selectores explícitos y bases del grafo; no son diagnósticos psicométricos.

`factor-signal-v1` contiene dos retos nuevos: interpretar todas las raíces dentro del dominio y evaluar con unidad relativa. Suponemos D(u)=(u²−5u+6) UR, u=t/(1 min), 0≤t≤5 min. D es diferencia de lecturas hipotéticas, no actividad enzimática ni concentración medida. Puede ser negativa; no hay ruido ni validación física. Es contenido complementario original de BioNexo, no asignatura/malla oficial. Autoría en `scripts/phase2_content.py`; modelo y unidades tienen pruebas automáticas y revisión humana pendiente. Las bases matemáticas están en OpenStax §1.5/2.5; esa fuente no valida coeficientes del modelo ni eficacia educativa.

## BioLab y proyecto adicional · Fase 4

`biolab.json` contiene pregunta, cuatro pasos, variables/controles y ejemplo desarrollado. El pH es independiente, la actividad relativa es respuesta calculada; temperatura/enzima/sustrato son constantes supuestas, sin controles nuevos que simulen efectos no modelados. La predicción exige elegir antes de calcular. Dos pH distintos del mismo modelo permiten comparar; duplicados no crean réplicas. La gaussiana no se valida contra datos experimentales y los registros antiguos no se recalculan.

`project-dilution-v1` añade seis ejercicios originales **fuera de las 24 lecciones**: identificar supuestos; calcular volumen total; conservar número de células al diluir; interpretar gráfico volumen/recuento esperado; media explícita de tres conteos; concluir con límites. Modelo ideal: 1 mL a 1.000 células/mL más 4 mL de medio sin células → 5 mL a 200 células/mL; una alícuota de 0,1 mL contiene un número esperado de 20 células. Recuentos ficticios 18/20/22 no representan mediciones reales ni validan un instrumento. No se interpreta concentración celular como molaridad.

Bases reales: bio-cells, bio-evidence, chem-matter, phys-units y math-fractions; todas implementadas. Las recomendaciones son explorables y no obligan a estudiar contenido futuro. Autoría en `scripts/phase4_content.py`; fuentes Biology 2e §6.5 y Chemistry 2e §3.3, más referencias escolares del catálogo. Revisión académica humana pendiente. La ruta integrada restante sigue planificada; no se declara completado el currículo avanzado ni validez universitaria.

## Grafo completo legible

No se atribuye este grafo a las universidades. `—` significa sin prerrequisitos en el mapa.

| ID | Concepto | Estado | Requiere |
|---|---|---|---|
| bio-life | ¿Qué hace vivo a un sistema? | Implementado | — |
| bio-evidence | Preguntar, medir, comparar | Implementado | bio-life |
| bio-water | Agua, polaridad y puentes | Implementado | bio-life |
| bio-macromolecules | Las piezas moleculares | Implementado | bio-water |
| bio-cells | Un mapa de la célula | Implementado | bio-macromolecules |
| bio-membranes | Fronteras en movimiento | Implementado | bio-cells, bio-water |
| chem-matter | Sustancias y mezclas | Implementado | — |
| chem-change | Cambios y conservación | Implementado | chem-matter |
| chem-atom | Dentro del átomo | Implementado | chem-matter |
| chem-periodic | Leer la tabla periódica | Implementado | chem-atom |
| chem-bonds | Enlaces e interacciones | Implementado | chem-periodic, bio-water |
| chem-mole | Del mol a la masa | Implementado | chem-atom, math-equations |
| phys-units | Magnitudes y unidades | Implementado | — |
| phys-measure | Medir también es estimar | Implementado | phys-units, math-fractions |
| phys-vectors | Dirección y desplazamiento | Implementado | phys-units |
| phys-speed | Leer el movimiento | Implementado | phys-vectors, math-linear |
| phys-force | Fuerza neta y cambio | Implementado | phys-speed, math-equations |
| phys-energy | Trabajo y energía | Implementado | phys-force |
| math-fractions | Fracciones que significan algo | Implementado | — |
| math-powers | Potencias y escalas | Implementado | math-fractions |
| math-equations | Ecuaciones en equilibrio | Implementado | math-powers |
| math-factor | Factorizar es reconocer estructura | Implementado | math-equations |
| math-linear | Funciones y cambio lineal | Implementado | math-equations |
| math-quadratic | Curvas y raíces | Implementado | math-factor, math-linear |
| bio-homeostasis | Homeostasis | Planificado | bio-membranes |
| bio-cycle | Ciclo celular y mitosis | Planificado | bio-cells |
| bio-meiosis | Meiosis | Planificado | bio-cycle |
| bio-signaling | Señalización celular | Planificado | bio-membranes |
| bio-enzymes | Enzimas | Planificado | bio-macromolecules, chem-bonds |
| bio-atp | Metabolismo y ATP | Planificado | bio-enzymes |
| bio-photosynthesis | Fotosíntesis | Planificado | bio-atp |
| bio-respiration | Respiración celular | Planificado | bio-atp |
| bio-dna | ADN y ARN | Planificado | bio-macromolecules |
| bio-replication | Replicación | Planificado | bio-dna |
| bio-expression | Transcripción y traducción | Planificado | bio-dna |
| bio-mutation | Mutaciones | Planificado | bio-replication, bio-expression |
| bio-regulation | Regulación génica | Planificado | bio-expression |
| bio-genetics | Genética mendeliana y molecular | Planificado | bio-meiosis, bio-dna, math-probability |
| bio-micro | Microbiología | Planificado | bio-cells, bio-atp |
| bio-immunology | Inmunología | Planificado | bio-signaling, bio-expression |
| bio-protein | Biología de proteínas | Planificado | bio-expression, chem-enzyme |
| bio-physiology | Fisiología | Planificado | bio-homeostasis, bio-signaling |
| bio-plant | Biotecnología vegetal | Planificado | bio-photosynthesis, bio-genetics |
| bio-synthetic | Biología sintética conceptual | Planificado | bio-regulation, bio-evidence |
| chem-reactions | Reacciones y estequiometría | Planificado | chem-mole, chem-change |
| chem-solutions | Disoluciones y concentración | Planificado | chem-mole, math-fractions |
| chem-dilution | Diluciones | Planificado | chem-solutions, math-equations |
| chem-gases | Gases | Planificado | chem-mole, phys-temperature |
| chem-equilibrium | Equilibrio químico | Planificado | chem-reactions |
| chem-ph | Ácidos, bases y pH | Planificado | chem-equilibrium, math-log |
| chem-buffer | Sistemas amortiguadores | Planificado | chem-ph |
| chem-thermo | Termodinámica química | Planificado | phys-thermo, chem-reactions |
| chem-kinetics | Cinética química | Planificado | chem-reactions, math-linear |
| chem-redox | Oxidación y reducción | Planificado | chem-atom, chem-reactions |
| chem-organic | Química orgánica | Planificado | chem-bonds |
| chem-proteins | Aminoácidos y proteínas | Planificado | chem-organic, bio-macromolecules |
| chem-lipids | Carbohidratos y lípidos | Planificado | chem-organic |
| chem-enzyme | Cinética enzimática | Planificado | bio-enzymes, chem-kinetics, math-functions-rational |
| chem-metabolism | Metabolismo y bioenergética | Planificado | chem-thermo, chem-redox, bio-atp |
| chem-analytical | Técnicas analíticas conceptuales | Planificado | chem-solutions, phys-optics |
| phys-fluids | Fluidos y presión | Planificado | phys-force |
| phys-temperature | Temperatura y calor | Planificado | phys-energy |
| phys-thermo | Termodinámica | Planificado | phys-temperature |
| phys-electric | Electricidad | Planificado | phys-force, math-equations |
| phys-waves | Ondas | Planificado | phys-speed, math-trig |
| phys-optics | Óptica e instrumentos | Planificado | phys-waves |
| phys-diffusion | Difusión | Planificado | phys-measure, math-linear |
| phys-osmosis | Ósmosis y transporte | Planificado | phys-diffusion, bio-membranes, chem-solutions |
| phys-surface | Fenómenos de superficie | Planificado | bio-water, phys-fluids |
| phys-heat | Transferencia de calor | Planificado | phys-thermo |
| phys-instruments | Fundamentos de instrumentos | Planificado | phys-optics, phys-electric, phys-measure |
| math-polynomial | Polinomios | Planificado | math-factor, math-quadratic |
| math-functions-rational | Funciones racionales | Planificado | math-polynomial |
| math-exp | Funciones exponenciales | Planificado | math-powers, math-linear |
| math-log | Logaritmos | Planificado | math-exp |
| math-trig | Trigonometría esencial | Planificado | math-equations |
| math-limits | Límites | Planificado | math-functions-rational, math-factor |
| math-continuity | Continuidad | Planificado | math-limits |
| math-derivative | Derivadas | Planificado | math-continuity |
| math-app-derivative | Aplicaciones de derivadas | Planificado | math-derivative |
| math-integral | Integrales | Planificado | math-derivative |
| math-ode | Ecuaciones diferenciales sencillas | Planificado | math-integral, math-exp |
| math-probability | Probabilidad | Planificado | math-fractions |
| math-stat | Estadística descriptiva | Planificado | math-fractions |
| math-inference | Inferencia estadística | Planificado | math-probability, math-stat |
| math-regression | Regresión | Planificado | math-stat, math-linear |
| math-matrix | Matrices | Planificado | math-equations |
| math-models | Modelamiento biológico | Planificado | math-ode, math-regression |
| int-concentrations | Concentraciones en modelos de laboratorio | Planificado | chem-dilution, phys-measure |
| int-enzyme | Enzimas y pH | Planificado | chem-ph, bio-enzymes, math-quadratic |
| int-growth | Crecimiento poblacional | Planificado | math-exp, bio-evidence |
| int-python | Programación científica conceptual | Planificado | math-linear |
| int-expression | Datos simulados de expresión génica | Planificado | bio-expression, math-stat, int-python |
| int-energy | Termodinámica y metabolismo | Planificado | chem-metabolism, phys-thermo |
| int-transport | Modelos de transporte | Planificado | phys-osmosis, math-derivative |
| int-bioinformatics | Bioinformática e IA: fundamentos | Planificado | int-expression, math-regression, math-matrix |
| int-design | Diseño experimental y ética | Planificado | bio-evidence, math-inference |

## Revisión académica pendiente

Todos los contenidos están marcados `requires-human-review`. La lectura de fuentes y la validación de soluciones no equivalen a revisión por profesores. Prioridades: exactitud/ambigüedad de distractores, claridad de transporte/ósmosis, clasificación de virus, condiciones de conservación, redondeo/unidades y calibración de dificultad y tiempo. El diagnóstico contiene una pregunta de aproximación/límite como sondeo, sin asignar competencia de cálculo.
