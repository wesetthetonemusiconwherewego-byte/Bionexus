# Revisión técnica del incremento BioLab/proyecto

Fecha local: 2026-10-22. Base: 18eb63a. Revisión de contenido/código por el asistente y pruebas automáticas; **no revisión académica humana ni validación experimental/educativa**. El catálogo conserva requires-human-review.

| Elemento | Clasificación y comprobación | Límites |
|---|---|---|
| El pH puede afectar función e ionización enzimática | Hecho general: Biology 2e §6.5, ver FUENTES | No determina por sí solo una curva o mecanismo para una enzima concreta |
| A=100 exp[−½((pH−óptimo)/σ)²] | Modelo didáctico original; ambos óptimos dan 100, simetría y extremos finitos; σ positivo | Constantes/simetría elegidas, sin ajuste a datos reales, sin irreversibilidad ni velocidad absoluta |
| N, pH 6→7 | 80,073740…→100%; +19,926259… puntos porcentuales, mostrado 19,93 | Diferencia de porcentajes relativos; no aumento de 19,93% relativo al valor inicial ni significación estadística |
| Comparación guardada | Dos pH distintos del mismo modelo; primera condición y primera posterior distinta; duplicado no es réplica | Cambiar modelo cambia óptimo/anchura; no aísla solo pH. Histórico se conserva sin recalcular |
| Suspensión ideal | N=C₁V₁=1.000 células/mL × 1 mL=1.000 células; Vf=1+4=5 mL; C₂=200 células/mL | Medio agregado sin células, mezcla uniforme, volúmenes aditivos, sin pérdida/crecimiento. No es soluto molecular ni molaridad |
| Conversión | 5 mL=0,005 L; 200 células/mL=200.000 células/L; N esperado=C×V | Unidades explícitas; números binarios de precisión finita y tolerancias declaradas |
| Recuento simulado | V=0,05/0,1/0,2 mL → N esperado=10/20/40; (18+20+22)/3=20 | Serie inventada, sin instrumento, incertidumbre validada ni garantía de cuenta exacta en muestras reales |
| Conclusión | Compatibilidad interna entre modelo y ejemplo simulado | No demuestra viabilidad celular, causalidad experimental, método clínico ni validez universal |

La clasificación de predicción considera iguales diferencias absolutas ≤10⁻⁹ puntos porcentuales (tolerancia numérica, no estadística); las lecturas de la interacción se redondean a dos decimales. La tabla de un registro reabierto muestra el número guardado, sin ese redondeo.

Los seis ejercicios nuevos usan bases implementadas y opciones incorrectas plausibles: confundir concentración con número, volumen o viabilidad; interpretar valor esperado como resultado exacto; confundir concordancia con validación real. Dos pistas graduadas y explicaciones propias por reto. Los 24 bloques anteriores y sus soluciones se comparan literalmente con 18eb63a, además de pasar los validadores de IDs, soluciones, unidades, ciclos, referencias y grafo. Esto no sustituye revisar cada bloque con docentes.

Evidencia: tests/lab-notebook.test.ts, tests/curriculum-integrity.test.ts y tests/e2e/phase4.spec.ts. La fixture previa contiene intencionalmente una lectura histórica 12,345 distinta del motor actual: prueba conservación, nunca se ofrece como respuesta nueva correcta. El nuevo guardado sí rechaza cifras incoherentes.

Pendiente: revisión por docentes de las cuatro ciencias, legibilidad/tiempos con estudiantes, accesibilidad Android y evaluación de transferencia/retención. XP y seis respuestas correctas no certifican dominio ni preparación universitaria. Las predicciones del laboratorio no otorgan puntos ni acreditan habilidades automáticamente. La ayuda consultada y abandonada antes de confirmar una respuesta de proyecto sigue siendo transitoria; “sin pistas registradas” no prueba independencia fuera de esa ronda.
