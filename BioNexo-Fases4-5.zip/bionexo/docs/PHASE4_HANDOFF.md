# Preparación de entrada a Fase 4

**Registro histórico de preparación.** La autorización posterior ADR-013 incluye implementación F4 e integración F5; consultar PROGRESS para estado actual del entorno/build. Esta guía de aceptación sigue vigente y no marca pruebas nativas automáticamente.

Base: `f23fc84`, 2026-10-22. Preparación solicitada, sin ejecutar P4-01/02/03. **P3-03 sigue TESTING y Fase 4 PENDING.** Faltan pruebas nativas; no se cambia la puerta de aceptación para aparentar avance.

## Lo que ya quedó listo

- `npm run android:preflight`: comprueba Java/JDK, SDK, platform-tools/adb, plataformas con android.jar y build-tools con apksigner. Lee JAVA_HOME/ANDROID_HOME o ANDROID_SDK_ROOT. Devuelve JSON y exit 1 cuando falta una herramienta. No descarga nada, no acepta licencias, no accede a cuentas ni dispositivos. TOOLS_PRESENT significa presencia, no compatibilidad completa de Gradle/JDK/API ni un APK compilado.
- `npm run phase4:readiness -- ruta/acceptance.json`: valida completitud del registro manual, huella de fuentes, fecha, build/APK/certificado, dispositivo/TalkBack, once comprobaciones y mediciones. Verifica archivos/hashes dentro de la carpeta del registro; bloquea rutas externas y symlinks que escapan de ella. Sin resultados devuelve BLOCKED/exit 1. Un registro completo da REVIEW_REQUIRED/exit 0: **todavía exige revisión humana**, no modifica estados del plan ni autoriza publicar.
- Plantilla [android-acceptance.template.json](evidence/android-acceptance.template.json), con todos los resultados PENDING y sin datos inventados.
- Prebuild Android reproducido en copia aislada mediante plantilla incluida en Expo, sin descargar SDK ni ejecutar Gradle. Detectó dependencia ausente para apariencia automática; se instaló `expo-system-ui ~58.0.6` compatible. Segundo prebuild sin ese aviso y strings.xml contiene `automatic`.
- Paquete `org.bionexo.learning`, versión 0.1.0, versionCode 1 y EAS preview APK conservados. La nueva dependencia exige reconstruir el binario nativo; un APK anterior no contiene ese cambio.

La huella cubre app/, src/, assets/ y configuración de compilación/dependencias declarada en `applicationFile`. Funciona en checkout Git o ZIP extraído; normaliza CRLF→LF de textos de código/configuración y conserva bytes binarios. Excluye documentación, pruebas, herramientas y perfiles externos. Sigue el modelo Expo CNG: no representa modificaciones manuales ajenas en android/ ni autentica que un APK se construyera con esas fuentes. SHA-256 del APK y revisión del build son controles complementarios; verificar una plantilla cumplimentada no demuestra por sí solo que alguien usó TalkBack.

## Ruta local Windows → Android

Usa un **PC para compilar y el teléfono para probar**. No hace falta contratar una compilación remota. La primera instalación de herramientas y Gradle descarga recursos; aquí no se generó un APK. EAS no fue invocado ni requiere credenciales para esta ruta.

1. Recupera el código/historial del paquete: `git clone bionexo-history.bundle bionexo-android-test`. Usa una copia nueva para generar android/; el prebuild actual regenera esa carpeta. No ejecutes regeneración sobre cambios nativos manuales sin preservarlos antes.
2. Instala/configura Android Studio, su SDK y un JDK completo compatible con el proyecto. Herramientas: platform-tools, SDK platform, build-tools/apksigner y las versiones de NDK/SDK que solicite el proyecto generado. La copia inspeccionada usa wrapper Gradle 9.4.1; los defaults instalados de RN indican compileSdk 37, targetSdk 36, build-tools 37.0.0, NDK 27.1.12297006 y AGP 9.2.1. Son valores leídos de archivos, **no una resolución Gradle comprobada**; revisa la configuración generada antes de instalar versiones por suposición.
3. Configura JAVA_HOME hacia el JDK y ANDROID_HOME hacia el SDK, con binarios accesibles. En PowerShell usa npm.cmd/npx.cmd si la política bloquea npm.ps1; no cambies la política global.

```powershell
cd bionexo-android-test
npm.cmd ci
npm.cmd run check
npm.cmd run android:preflight
npx.cmd expo prebuild --platform android --no-install
cd android
.\gradlew.bat assembleRelease
```

En Linux/macOS, usa npm/npx y `./gradlew assembleRelease`. No hace falta Gradle global: se usa el wrapper generado. APK esperado **solo después de build exitoso**: `android/app/build/outputs/apk/release/app-release.apk`. Si falta SDK/JDK, detente en ese error; no marques build ejecutado ni cambies dependencias a versiones incompatibles para ocultarlo.

4. Comprueba el APK con apksigner y registra su SHA-256/certificado. El template inspeccionado usa firma de depuración también para release local: no es política de firma pública. Conserva firma/package compatibles para actualizar; no desinstales la app para forzar una actualización porque podrías borrar progreso. Exporta tu progreso antes. No agregues keystores/contraseñas al repositorio.

```powershell
Get-FileHash .\app\build\outputs\apk\release\app-release.apk -Algorithm SHA256
# Ejecuta apksigner de la versión build-tools instalada:
# apksigner.bat verify --print-certs RUTA_DEL_APK
```

5. Instala/actualiza explícitamente en el teléfono o un emulador de pruebas. Si la firma no coincide, conserva/exporta datos y resuelve la firma: no desinstales automáticamente. Para medir con perfiles sintéticos utiliza un entorno de prueba separado y sin progreso personal; no reemplaces el cuaderno del estudiante por los datos de medición.
6. Ejecuta la matriz [UX_AUDIT.md](UX_AUDIT.md): TalkBack celular/laboratorio, fontScale real 100/150/200%, legibilidad de pestañas, ambos temas, movimiento reducido, orientación, SQLite/reanudación, arranque en modo avión y respaldo/restauración. Mide tres muestras de arranque frío, caliente y Practicar para 100/1.000/10.000 intentos. Registra limitaciones, método y valores reales; si un caso no pudo ejecutarse, queda PENDING/BLOCKED, nunca PASS.

## Registrar evidencia sin incluir datos personales

Copia la plantilla a una carpeta local de pruebas fuera del repositorio, por ejemplo `android-qa/acceptance.json`. Coloca allí subcarpetas artifacts/ y evidence/. La plantilla ya deja una ruta relativa para artifacts/bionexo.apk; añade notas/capturas/informes de prueba sin nombres, perfiles reales o identificadores de cuenta. No distribuyas el archivo de progreso de una persona como evidencia.

- applicationFingerprint: copia el valor actual del preflight ejecutado sobre las fuentes usadas para el APK. commit: hash completo de ese build (`git rev-parse HEAD` desde el checkout); registra además cualquier diferencia local y reconstruye desde un commit limpio para la aceptación final.
- verifiedAt: fecha/hora real con zona, por ejemplo formato ISO con Z o -03:00. device: tipo physical/emulator, modelo, Android/API, TalkBack y condiciones reales verificadas.
- build: APK identificado, versión/certificado comprobados. `artifact.path` es relativo a la carpeta del JSON y `sha256` es el hash de los bytes actuales del APK.
- checks: cada ID existente exactamente una vez, estado PASS solo tras ejecutar el caso; notes con resultado concreto y evidence con `{ "path": "evidence/archivo.txt", "sha256": "…" }`. Puede referenciarse un informe compartido que documente varios casos. Cada archivo debe existir y coincidir con su hash. El máximo del APK es 250 MB y el de cada evidencia 20 MB; los archivos no se suben automáticamente.
- performance: valores reales en milisegundos, tres o más muestras positivas por operación/volumen y descripción del método. No pegues los tiempos Node/navegador como si fueran Android.

```powershell
cd RUTA_DEL_CHECKOUT
npm.cmd run phase4:readiness -- C:\RUTA\android-qa\acceptance.json
```

El verificador nunca convierte PENDING en PASS ni edita tu teléfono. Un REVIEW_REQUIRED permite **revisar** el registro y el build; después, una sesión debe documentar resultados y actualizar P3-03/Fase 3 solo si cumple todos los criterios. R-04 mantiene bloqueado el lanzamiento público independientemente de este resultado.

## P4-01 preparada, aún no iniciada

Al cerrar la puerta de Fase 3, el primer incremento seguirá siendo el laboratorio enzimático actual:

| Aspecto | Preparación para la implementación |
|---|---|
| Objetivo | Distinguir pregunta, hipótesis, variable independiente pH, respuesta actividad relativa y controles/supuestos del modelo. |
| Motor | Reutilizar enzymeActivity/enzymeCurve y sus parámetros; no agregar temperatura/sustrato como controles sin un modelo y fuentes revisados. |
| Interacción | Formular predicción, comparar al menos dos condiciones bajo el mismo modelo e interpretar lo calculado; mantener las lecturas de P3-02. |
| Datos | P4-01 debe preferir enseñanza derivada sin cambiar formatos. Si necesita persistir campos, preparar ADR/migración y fixture previa antes de editar. |
| Compatibilidad | Conservar IDs, intentos, XP, sesiones guardadas y checkpoints; no convertir las sesiones antiguas de una condición en comparaciones válidas ni borrarlas. |
| Calidad | Modelo simplificado y datos simulados explícitos; fuentes actuales y revisión humana pendiente. Pruebas de cálculos/unidades/controles/extremos, recorrido completo y regresiones. |
| Fuera de esta preparación | No implementar aquí P4-02, proyectos, backend, organismos ni edición genética. No cerrar R-12 sin corregir y verificar sus criterios. |

Fuentes técnicas consultadas el 2026-10-22: [Expo, desarrollo nativo local](https://docs.expo.dev/guides/local-app-development/), [Expo SystemUI](https://docs.expo.dev/versions/latest/sdk/system-ui/), [Android SDK Manager](https://developer.android.com/studio/intro/update#sdk-manager). La matriz local instalada y los archivos generados son la evidencia del proyecto concreto. Fuente conceptual a revisar para P4-01: [OpenStax Biology 2e §6.5](https://openstax.org/books/biology-2e/pages/6-5-enzymes); no atribuirle la gaussiana ni una validación experimental.
