# Auditoría UX y rendimiento · Fase 3

Fecha: 2026-10-22. Base `6d5e92d`. P3-01/02 implementados y comprobados localmente; P3-03 **TESTING**, pendiente aceptación nativa. Ningún resultado siguiente acredita Android/TalkBack ni eficacia educativa.

## Método y resultados

- Chromium 153.0.8010.0 sin interfaz, viewport móvil 412×915, escritorio 1366×900 y caso estrecho 320×915. Emulación Pixel 7 en Playwright es navegador, no un teléfono.
- Texto estrecho: CSS multiplica por dos font-size **y line-height** de hojas de texto/inputs. Se esperan dos frames tras el cambio para estabilizar el layout RN Web. No equivale a `fontScale` del sistema Android ni amplía el texto SVG. Ejes, rangos y lecturas externas al SVG sí escalan. Sin desbordamientos horizontales inesperados al estabilizarse; inspección visual de diagrama/gráfico/lecturas. En la barra de cinco destinos las palabras se envuelven mucho a 320 px/200%: legibilidad y estrategia de navegación con escala nativa extrema requieren evaluación de dispositivo.
- Foco: botón +0,5 pH enfocado por teclado tenía `outline: none`. Ahora indicador continuo de 3 px, color cálido; Enter modifica pH coherentemente. Foco también en pestañas y regiones. Estado web de pestaña explícito; radios/diagramas comparten respuesta y selección. No equivale a foco de accesibilidad nativo.
- El primer recorrido de texto detectó botones de modelos/badge fuera de ancho y colisión de marca en cabecera. Máximo de ancho, reducción flexible, envoltura de fila pH y marca solo con espacio suficiente corrigen esos casos. La auditoría anterior que midió el slider antes de terminar el relayout dio un falso desbordamiento transitorio: se añadió espera de dos frames y se repitió el caso, sin ocultar elementos ni eliminar la aserción.
- Contraste calculado con luminancia relativa de tokens sRGB opacos reales. Texto activo: mínimo 6,79:1 oscuro y 4,52:1 claro sobre fondos incluidos; botón principal 9,41:1 / 5,27:1. El borde de formulario pasó de 1,76:1 / 1,38:1 a 9,17:1 / 6,33:1 contra fondo principal. Se comprueban también fondo superficie/elevado, texto secundario y foco. No cubre todos los estados o píxeles de la app ni controles deshabilitados.
- Regiones A/B/C: 70×56 unidades en la revisión móvil. Descripción completa, elección alternativa por radio, selección por marca/borde y feedback posterior vigente. No se entregan nombres/funciones antes de comprobar. Figura original sin escala/otros orgánulos, no reproducción de una célula completa.
- Movimiento reducido: sistema simulado por prefers-reduced-motion y preferencia persistida; cambios en vivo y recarga comprobados. Configuración muestra estado efectivo; Stack usa `none` cuando corresponde. No se midieron animaciones del sistema nativo.

Datos crudos: [contraste](evidence/phase3-contrast-2026-10-22.json), [inspección inicial](evidence/phase3-visual-before-2026-10-22.json), [auditoría final](evidence/phase3-visual-final-2026-10-22.json). Capturas solo internas, no incluidas como entregable.

## Rendimiento medido, sin cambiar progreso

Carga sintética con 100, 1.000 y 10.000 intentos distribuidos entre los 146 ejercicios de lecciones, 25% con ayuda. Son respuestas correctas, no una representación de todos los patrones de errores/uso; no datos de estudiantes. El caso grande ocupa aproximadamente 1,86 MB con referencias incluidas. Node mide siete muestras calientes tras una ejecución de calentamiento; tablas no representan fotogramas ni memoria de un Android.

| Operación, 10.000 intentos | Mediana anterior | Mediana posterior |
|---|---:|---:|
| Seleccionar repasos | 16,302 ms | 0,423 ms |
| Seleccionar y explicar repasos | 24,951 ms | 11,519 ms |
| Serializar/validar documento | 56,760 ms | 53,207 ms |
| Leer/validar respaldo | 29,935 ms | 31,078 ms |

Solo se optimizó el selector: índice local de última aparición por ejercicio, conservando diagnósticos, empates y orden. Oráculo del código anterior, 30 conjuntos con límites/fechas y fixtures, prueba igualdad e inmutabilidad. No se modificaron reglas de dominio, fechas, firmas ni escritura del perfil. Cambios pequeños de serialización/lectura son variación de medición: esos caminos no se optimizaron.

El navegador mide tres contextos nuevos por volumen, carga HTTP local y tiempo hasta encabezado visible de Inicio/Practicar. Incluye lectura, validación, carga JS, renderizado y automatización; hay calentamiento de host/recursos y posible competencia con E2E. Los tiempos no son monotónicos por volumen, no prueban aceleración de arranque ni establecen un presupuesto móvil. Muestras completas en la auditoría final. R-07 sigue abierto: snapshots completos/copias grandes pueden costar tiempo/memoria; no se justificó normalizar SQLite ni purgar progreso en este incremento.

## Repetir localmente

Instala con `npm ci`; usa Chromium instalado mediante `npx playwright install chromium` o define `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` hacia un ejecutable disponible. Genera en un directorio **nuevo** para evitar chunks antiguos.

```bash
npm run check
npm run export:web -- --source-maps --output-dir dist-security-ux-web
BIONEXO_WEB_ROOT=dist-security-ux-web npm run test:e2e
node --import tsx scripts/measure-ux.ts
BIONEXO_UX_PROFILE_DIR=/tmp/bionexo-ux node --import tsx scripts/measure-ux.ts
BIONEXO_WEB_ROOT=dist-security-ux-web BIONEXO_UX_PROFILE_DIR=/tmp/bionexo-ux node scripts/measure-ui.cjs
npm run export:android -- --source-maps --output-dir dist-security-ux-android
npm run --silent security:bundles -- dist-security-ux-android dist-security-ux-web
```

`measure-ui.cjs` inicia/cierra un servidor HTTP local con puerto disponible. Escribe JSON a stdout, sale con error ante errores de página, desbordamiento final o foco ausente; no modifica perfiles reales. Solo genera capturas si se define `BIONEXO_UX_SCREENSHOT_DIR`, úsalo fuera del repositorio. PowerShell permite asignar estas variables mediante `$env:NOMBRE="valor"` antes del comando. Las rutas temporales son ejemplos locales. No requiere cuenta, API ni servidor externo. El script de medidas Node reconstruye datos sintéticos, no toma un respaldo del usuario.

## Aceptación Android pendiente · P3-03

Sin SDK/adb/emulador/Gradle ni dispositivo: bundle Hermes comprobado, APK no generado ni probado. En un entorno nativo disponible:

1. Registrar modelo, Android/API, memoria, tamaño/resolución, versión/commit y canal de compilación. Exportar primero progreso; no alterar firma/package ni reemplazar datos con ejemplos.
2. TalkBack: Inicio → lección celular → A/B/C → alternativa por radio → comprobar → pausar/reanudar. Verificar orden, nombres/estados, solución anunciada una vez, foco al navegar y controles deshabilitados. Comprobar también lectura/gráfico, modelos y controles pH.
3. Escalas de texto 100/150/200% y tamaño de pantalla, orientación vertical/horizontal: controles no colisionan; lectura completa, teclado/campos/pestañas utilizables; ajustar la barra de navegación si su envoltura reduce legibilidad. Guardar capturas de prueba sin datos personales.
4. Reducir animaciones desde sistema y app; verificar transiciones. Modos claro/oscuro con contraste y foco del dispositivo.
5. Medir arranque frío/caliente y Practicar/Inicio con perfiles sintéticos separados de 100/1.000/10.000 intentos, registrar metodología/muestras/memoria. Verificar almacenamiento nativo, guardar/cerrar/reabrir y arranque offline; no generalizar tiempos de navegador.
6. Corregir solo hallazgos reproducidos, repetir regresiones y registrar evidencia antes de marcar DONE. No iniciar Fase 4 automáticamente. R-04 sigue bloqueando lanzamiento público; comprobar dependencias antes de cualquier canal de distribución.
