# Arquitectura

React Native/Expo SDK 58, TypeScript estricto con `noUncheckedIndexedAccess`, Expo Router. Rutas: `/`, `/lesson/[id]`, `/diagnostic`, `/review`, `/practice-family/[id]`, `/transfer`, `/project` y `/lab-session/[id]`; la navegación principal se refleja en `?tab=` para conservar la sección al recargar la vista web. En pantallas amplias aparece una barra lateral; en móvil cinco destinos principales y accesos a biblioteca/configuración en la cabecera.

## Flujo de datos

1. JSON incluido en el bundle → catálogo tipado → validador en arranque.
2. La UI recibe el ejercicio y recoge una respuesta estructurada.
3. El dominio calcula corrección, evidencia, XP y próxima revisión.
4. `ProgressRepository.update` serializa mutaciones y confirma la escritura antes de actualizar la UI.
5. En Android/iOS `SQLiteRepository` abre `bionexo.db` en almacenamiento privado de la app. No hay fallback silencioso a memoria. En web se usa un adaptador explícito de `localStorage` para facilitar pruebas y previsualización; no se afirma que la vista web sea una PWA instalable/offline completa.

## Persistencia y migración

`PRAGMA user_version` versiona el esquema, no el catálogo. Migración 1: tabla `user_state` con un documento JSON de perfil único; migración 2: tabla `repository_metadata`; migración 3: tabla `profile_recovery` con fecha, motivo y texto original. Cada migración y cada actualización usa `BEGIN IMMEDIATE`/`COMMIT`, con `ROLLBACK` al fallar. Una cola por repositorio impide que las escrituras concurrentes pierdan cambios. Las sentencias con datos usan parámetros.

Un documento por perfil es una decisión para el MVP: agrupa atómicamente intentos, dominio, XP, revisiones y ajustes. Las interfaces separan almacenamiento y dominio para migrar más adelante a tablas normalizadas e índices sin reescribir la interfaz. Versiones de BD futuras se rechazan; datos corruptos producen un aviso y nunca se borran automáticamente. Cerrar y reabrir una SQLite en disco se verifica en pruebas con `node:sqlite`; falta probar el driver nativo en Android.

Los intentos tienen ID por sesión, ejercicio y reintento. Un evento repetido no se vuelve a registrar; la primera respuesta correcta de un ejercicio otorga 10 XP una sola vez. Terminar los seis ejercicios de una lección otorga 20 XP una sola vez. Las respuestas incorrectas no bloquean completar, pero sí influyen en evidencia y recomendaciones. P1-01 añade checkpoints por lección mediante `sessions.ts`: cursor, borrador, unidades, pistas, contador e ID del intento confirmado; también el paso de apoyo y su borrador. Salir pausa; reabrir restaura esos datos sin reenviar respuestas. Diagnóstico/repaso conservan el flujo transitorio anterior.

## Respaldo

Documento JSON `format: bionexo-progress`, envoltorio `version: 3`, perfil interno `version: 1`, máximo 10.000.000 bytes UTF-8. Sus referencias versionadas describen identidades y formas de respuesta; no dependen de las soluciones vigentes. Se validan forma, referencias internas, unidades, rangos, fechas y XP coherente con premios. Se conserva la corrección registrada: el respaldo no tiene firma ni acredita autenticidad o validez académica. Solo los intentos nuevos usan el evaluador actual. Importar requiere selección explícita y confirmación de reemplazo. No hay fusión entre perfiles ni cifrado específico de la exportación. Es una copia local; no se transmite a servidores de BioNexo. Desinstalar la aplicación puede eliminar SQLite: el respaldo externo es la forma de recuperarlo.

## Extensión

- Agregar cursos: contrato de `Lesson`/`Exercise`, catálogo y grafo.
- Agregar laboratorios: modelos puros junto a `laboratory.ts`, UI y pruebas de cálculos.
- Sincronización futura: implementar un repositorio que sincronice eventos manteniendo IDs estables y política de conflictos. No existe hoy.
- Tutor IA futuro: proveedor opcional de explicaciones, desactivado por defecto, sin dependencia para calificar respuestas. No existe hoy.

## Accesibilidad y recursos

Controles con etiquetas y estados, texto escalable, objetivos de al menos 48 unidades, alternativas textuales para gráficas, botones de ajuste además del slider y preferencia del sistema para movimiento reducido. No hay fuentes, imágenes o scripts remotos en el flujo de aprendizaje. Los gráficos e iconos SVG son originales. Auditoría con TalkBack/VoiceOver y escalado extremo pendiente.

## Evolución controlada a 2.0

El proceso está en [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md) y las decisiones en [DECISIONS.md](DECISIONS.md). P0-03 implementa ADR-006:

- Los perfiles 0.1.0 se validan con `src/content/history/v0.1.0-contracts.json`, congelado desde `41566ea`; nunca se regenera con autoría futura. Documentos nuevos incluyen referencias propias y conservan IDs retirados. Cambiar una forma de respuesta requiere un ID nuevo o migración explícita.
- Migración SQLite 1/2→3, copia original y conversión válida se confirman juntas o revierten. Una base existente sin fila no se trata como instalación nueva. Solo una base vacía sin tablas y versión cero crea perfil.
- Web conserva `bionexo-state-v1`; copia primero a `bionexo-recovery-v1`, después reemplaza. Reintentos de migración deduplican el mismo original. Cuota/fallo de copia impiden reemplazo; no se purgan copias automáticamente.
- Corrupción permanece intacta. El repositorio se conserva en el proveedor antes de cargar perfil para habilitar `RecoveryPanel`: exportar rescate, elegir/validar respaldo, revisar resumen, cancelar/confirmar o buscar una copia local válida. También se puede rescatar con catálogo inválido; restaurar/estudiar exige catálogo válido.
- `exportRescue()` entrega un contenedor `bionexo-recovery` con payload sin validar y copias. No se importa silenciosamente como progreso; «Buscar copia local anterior» valida candidatos antes de ofrecer confirmación. Colecciones de copias ilegibles se señalan sin impedir rescatar el perfil accesible.
- Formatos/BD futuros se conservan y no admiten reemplazo por esta versión. SQLite permanece en esquema 3; el envoltorio 3 no permite downgrade automático al código anterior. Exportar antes de actualizar/revertir; usar una versión compatible. Las copias originales son una vía de recuperación manual, no una conversión inversa.

No se reconstruye un archivo SQLite que el driver no pueda abrir. Si fallan cuotas/escrituras, puede exportarse el original accesible y reintentar al resolver el problema. La aplicación no borra datos para liberar espacio. El historial completo y las copias crecen; medir/normalizar corresponde a otra tarea.

## Reanudación de lecciones · P1-01

`UserState.version=1` incorpora `lessonSessions?` por ID de lección. Cada `LessonSession.version=1` tiene ID de sesión, IDs/orden, índice, fechas, firma de contenido y `ExerciseCheckpoint`. No se añaden tablas ni se incrementa SQLite porque la representación SQL no cambia; la migración es del payload 2→3, con copia original dentro de la transacción existente. Web escribe copia antes de convertir, deduplica reintentos y preserva el original si falla por cuota. Perfiles raíz 0.1.0 y documentos 2 conservan exactamente sus valores, sin sesiones inventadas.

La validación de checkpoints usa las referencias históricas del documento: forma de borrador, referencias al intento/ejercicio, ayuda, cursor y respuestas previas; no recalifica historial. Un checkpoint futuro impide reemplazo con versión antigua. Las sesiones se incluyen en exportación/restauración normal y rescate. Restaurar un respaldo antiguo reemplaza el perfil con confirmación y conserva lo reemplazado en rescate; no fusiona sesiones.

`submitLessonAnswer` registra intento y referencia de feedback juntos. IDs por sesión/ejercicio/contador hacen idempotente un envío repetido; respuestas distintas con el mismo ID se rechazan. Avance y finalización se guardan antes de mostrar éxito; última respuesta, premio y eliminación del checkpoint no pueden quedar a medias. Descartar elimina solo un checkpoint con el ID de sesión esperado, sin tocar historial ni otras sesiones. Las escrituras tardías a otro cursor/ID se rechazan.

`ExerciseCard` conserva un borrador local para responder al tacto y serializa sus guardados. Antes de comprobar, avanzar o salir, espera el guardado pendiente; la confirmación usa el intento que devuelve el repositorio. Incluye el hijo de apoyo en esa cola y restaura su feedback desde el ID guardado. Errores de escritura permiten reintentar sin IDs nuevos ni recompensas repetidas; un guardado exitoso elimina el aviso anterior del proveedor.

Una firma no criptográfica de lección y apoyo detecta cambios de contenido al retomar. Una sesión incompatible se conserva y no se ejecuta automáticamente; el usuario puede volver o descartar su punto de reanudación. No es autenticación de un respaldo. Cerrar sin commit solo conserva la última escritura confirmada; no se garantiza recuperar un carácter aún pendiente ni reconstruir SQLite físicamente ilegible. Persistir snapshots por interacción requiere medir rendimiento con historiales grandes en P3-03. No se afirma prueba de driver/gestos/TalkBack Android.

## Piloto progresivo · P1-02

`Lesson.stages?` añade instrucción/ejemplo/objetivo y referencias a ejercicios consecutivos; `lesson-stages.ts` deriva el tramo del cursor existente, sin cambiar contratos persistentes. El generador importa `factoring_pilot.py`; catálogo validado exige cobertura exacta en orden. IDs/soluciones anteriores permanecen; dos retos nuevos se agregan al final. Los checkpoints previos del piloto requieren descarte explícito por firma incompatible (ADR-009); historial y XP se preservan.

P1-03 agrega `hintExample?` y `Explanation.distractors?` al contenido, sin persistirlos en el perfil. `feedback.ts` selecciona comentarios redactados según la respuesta confirmada, sin recalificar ni diagnosticar. El UI muestra el ejemplo al alcanzar la última pista; `hintCount` y `attemptNo` existentes preservan la evidencia de ayuda. Retornar del puente mantiene la respuesta original. Se conserva esquema/formatos, historia y guardas de firma.

## Práctica parametrizada · P2-01

`practiceFamilies` define la autoría offline; `variants.ts` genera un banco acotado inmutable por familia/versión/semilla y elige rondas reproducibles según intentos. `/practice-family/[id]` usa StudySession en modo revisión, sin persistencia de cursor nueva. `allExercises` y referencias del documento incluyen variantes; grade/recordAttempt buscan la instancia instalada por ID. Una familia comparte un único `rewardId` existente entre sus variantes; el contador XP histórico sigue siendo 10×premios + 20×lecciones. No se cambia SQL/formatos y los checkpoints de Fase 1 siguen compatibles. ReviewQueue admite variantes además de retos de lecciones, sin cambiar intervalos ni pesos.

P2-03 agrega `errorRules` y `transferActivities` al catálogo. Son contenido incluido, sin campos persistentes nuevos. El registro global de ejercicios incluye los retos de transferencia en referencias de respaldo. `misconceptions.ts` deriva coincidencias y muestra inicial/última por IDs; nunca recalifica historial. Componentes reutilizables muestran ayuda/bases y evidencia en práctica/progreso; `/transfer` usa el modo revisión transitorio. No cambia la forma de `remediation` ni contenido de lecciones; firmas/checkpoints anteriores siguen compatibles.

`guidance.ts` (P2-04) produce razones tipadas no persistentes sobre la selección existente. La procedencia de un repaso se atribuye únicamente si el replay de resultados registrados reproduce el calendario guardado; discrepancias usan fallback explícito. Home/Practice muestran razones y `/review` captura selección/explicaciones al iniciar; `StudySession` recibe esa guía opcional sin modificar las sesiones persistidas de lección. Mostrar razones no escribe estado ni reprograma fechas.

## Interacciones y medidas · Fase 3

`CellDiagram` es un componente controlado: recibe la respuesta vigente y entrega IDs a/b/c al mismo `setAnswer` de los radios. Regiones con controles de 70×56, selección por marca/borde y descripción textual completa; nombres de orgánulos no se revelan antes de comprobar. No cambia contenido, firmas ni forma de respuesta, por lo que los checkpoints siguen compatibles.

`Plot` usa proyección pura `plot-geometry.ts`; rechaza datos vacíos/no finitos con texto y conserva etiquetas fraccionarias. Ejes/rangos tienen una lectura textual escalable además de las marcas SVG. El laboratorio usa el mismo motor gaussiano anterior; compara lecturas a un mismo pH y expresa diferencias en puntos porcentuales. Curvas continua/discontinua y nombres permiten distinguir sin color.

`graph-context.ts` valida parámetros de navegación `ph`, `model`, `compare`. `Laboratory` deriva los controles de esos parámetros y `router.setParams` los conserva al cambiar pestaña/recargar. Es contexto de navegación, no un nuevo campo de progreso: una apertura con URL nueva sin parámetros inicia valores predeterminados. No se exportan en el respaldo. Hipótesis, observación y condiciones sin guardar siguen siendo transitorias; el aviso pide guardar antes de salir y el cuaderno existente sigue persistiendo explícitamente. No hay notas privadas en la URL.

`reviewQueue` construye un índice local de últimos intentos por ejercicio en una sola pasada. Se mantiene exactamente la última posición del array, no se ordena el historial por fecha ni se excluye un diagnóstico antes incluido. El selector congelado `tests/helpers/review-queue-phase2.ts` verifica igualdad de selección/orden con fixtures y casos de empates/fechas desordenadas/límites. Ningún dato ni calendario se escribe al consultar.

La paleta se aísla en `palettes.ts` sin cambiar colores; bordes activos usan muted y controles de botón/pestañas/regiones muestran foco. La cabecera conserva el icono a anchura menor que 360 o escala nativa ≥1,5 para evitar colisión de marca y accesos. Texto en opciones/badges se ajusta al ancho y la fila pH permite envolver. Movimiento efectivo respeta preferencia local o del sistema y se muestra en Configuración. El soporte nativo no está auditado aún: ver [UX_AUDIT.md](UX_AUDIT.md).

Sin dependencias, SQL ni versiones persistentes nuevas: no hay migración de representación, sustitución de perfiles ni recalificación. ADR-011 y fixture previa de Fase 2 documentan compatibilidad. Medidas reproducibles en `scripts/measure-ux.ts` y `scripts/measure-ui.cjs`; no justifican aún normalizar SQLite ni eliminar historial.

## Preparación de aceptación nativa

ADR-012 añade herramientas de desarrollo separadas de la app: `scripts/readiness/native.ts` calcula huella canónica de entradas de aplicación (texto LF, binarios intactos) y valida un registro manual con evidencias locales; funciona con Git o ZIP extraído. `android-preflight.ts` diagnostica herramientas sin acceder al teléfono. `check-phase4-readiness.ts` bloquea resultados pendientes/obsoletos y devuelve REVIEW_REQUIRED ante un registro completo, sin editar el plan ni certificar una prueba humana. La guía es PHASE4_HANDOFF. No se añade estado al estudiante ni migración.

El prebuild aislado reveló ausencia de expo-system-ui para userInterfaceStyle automático. Se incorpora únicamente ~58.0.6 mediante expo install; el plugin oficial incluido aplica la cadena nativa automática. No cambia app.json, identificador de paquete ni firma previstos ni algoritmos, pero exige reconstruir el binario para incluir ese módulo. Prebuild no prueba Gradle, firma, apariencia o driver Android.

## Extensión BioLab y proyecto · Fases 4/5

Laboratory ahora vive en `src/ui/laboratory.tsx`; `screens.tsx` lo reexporta para conservar navegación. `lab-notebook.ts` mantiene puras predicción/comparación/validación de altas nuevas; la lectura histórica de progress-document permanece independiente. Guía y proyecto se generan desde `phase4_content.py`; el proyecto reusa TransferActivity/StudySession/Attempt y no inventa campos de persistencia. El informe de laboratorio muestra valores guardados sin recalcular y limita renderizado, preservando tabla/respaldo completos. `curriculum-integrity.ts` coteja el grafo incluido y validateCatalog devuelve errores de estructuras inválidas; no se permite importar catálogos externos. Detalles, límites y evidencia en ARCHITECTURE, ACADEMIC_REVIEW y PROGRESS.
