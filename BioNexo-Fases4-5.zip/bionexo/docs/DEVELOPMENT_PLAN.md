# Plan de desarrollo evolutivo · BioNexo 2.0

Fecha: 2026-10-22. Base: `0a5451d` (MVP 0.1.0). Responsable de cada tarea: la sesión/agente que la tome; no hay trabajo paralelo implícitamente autorizado.

## Alcance autorizado de esta ejecución

Autorización actual: «dale ahora con lo que falta y la fase 5», desde `18eb63a`. Incluye P4-01/02/03 y la integración/compilación local de Fase 5. ADR-013 permite continuar el desarrollo funcional mientras se reúne evidencia nativa; **no cierra P3-03 ni autoriza publicación con R-04 abierto**. No se fabrican resultados Android, revisión humana o APK. Los registros previos de preparación son históricos.

## Requisitos y procedencia

| Referencia | Fuente | Uso |
|---|---|---|
| REQ-01 | Especificación original visible y repo 0.1.0 | Android, offline-first, contenido/diagnóstico/repaso/laboratorio, exactitud y progreso persistente. |
| REQ-02 | Informe funcional detallado anterior de BioNexo 2.0 | **No disponible como documento ni texto completo.** Una búsqueda de contexto recuperó solo un resumen de propuestas del asistente. No se inventan detalles ni decisiones del usuario. Registrar el texto íntegro cuando esté disponible antes de tratar sus detalles como aceptación. |
| REQ-03 | Sistema maestro de fases de esta sesión | Fases 0–5, temas funcionales enumerados, tareas/estados, protocolo, migraciones y límites. |
| REQ-04 | AGENTS y documentación previa del repositorio | Se conservan y reconcilian reglas útiles; no se eliminan restricciones offline/académicas. |

El resumen recuperado menciona mapa vivo, motor avanzado, BioLab, BioTutor y BioProjects. Es contexto de propuesta, no un requerimiento detallado confirmado. **BioTutor no se incluye como tarea nueva.** Las tareas siguientes derivan de los temas expresos de REQ-03 y las capacidades ya pedidas; no fijan decisiones de producto ausentes.

## Protocolo y estados

Estados válidos: `PENDING`, `IN_PROGRESS`, `BLOCKED`, `TESTING`, `DONE`. Las dependencias no satisfechas mantienen una tarea PENDING; BLOCKED se reserva para un impedimento concreto al ejecutarla. Un criterio pendiente impide DONE.

Para cada tarea: inspección → reproducción/caso inicial → cambio mínimo → regresiones unitarias/integración pertinentes → verificaciones → corrección de fallos → actualización de evidencia/decisiones → commit delimitado. No hay refactorizaciones globales ni eliminación de pruebas para ocultar fallos.

Antes de persistencia/contenido/algoritmo: identificar datos e IDs afectados, decidir migración compatible y recuperación, usar fixture anterior, comprobar XP/dominio/historial conservados y documentar versiones. No equivale a ejecutar migraciones innecesarias cuando la representación no cambia.

## Puertas entre fases

- La Fase 0 queda DONE en su alcance de auditoría/estabilización local tras P0-04 por acotación (ADR-007). R-04 y el lanzamiento público siguen bloqueados; no se declara BioNexo 2.0 terminado ni vulnerabilidades reparadas.
- Antes de modificar contenido/dominio persistido, cerrar P0-03. Las alertas P0-04 deben resolverse o quedar con una decisión explícita de alcance y revisión; no se ocultan para avanzar ni se autoriza lanzamiento con ellas abiertas.
- Pasar a una fase funcional requiere revisión del incremento y una nueva instrucción que delimite la tarea; terminar un subpaso interno no autoriza todas las fases.
- Autenticación privada, coste externo, infraestructura destructiva o riesgo irreversible detienen la acción dependiente. Se completa primero todo lo comprobable y se documenta el bloqueo concreto.

El estado efectivo y comandos ejecutados están en [PROGRESS.md](PROGRESS.md). Riesgos: [RISKS.md](RISKS.md). Arquitectura: [ARCHITECTURE.md](ARCHITECTURE.md). Decisiones: [DECISIONS.md](DECISIONS.md). Entrega: [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md).

## FASE 0 — AUDITORÍA Y ESTABILIZACIÓN

Estado de fase: **DONE en alcance de auditoría/estabilización local**. P0-04 cierra por acotación, con R-04 abierto y lanzamiento público bloqueado. La Fase 1 terminó después, dentro del alcance local de ADR-007.

### P0-01 · Auditar el MVP y establecer el proceso

- **Estado:** `DONE`.
- **Objetivo funcional:** Distinguir implementación observada, resultados comprobados y declaraciones; dejar tareas trazables y reglas persistentes.
- **Dependencias:** Ninguna.
- **Archivos/módulos:** AGENTS.md, README.md, docs/*, configuración y módulos existentes (lectura).
- **Riesgos:** Confundir el MVP con una versión 2.0 terminada o atribuir al usuario propuestas no confirmadas.
- **Aceptación:** Inspección de Git, dependencias, documentación, contenido, dominio, almacenamiento, UI y pruebas; cinco documentos de proceso enlazados; riesgos y faltantes registrados.
- **Pruebas requeridas:** npm run check; exportación web; Playwright; compatibilidad Expo; configuración pública; auditoría de dependencias.
- **Evidencia de finalización:** Base 0a5451d limpia; 24 pruebas originales y 12 recorridos web repetidos. Documentación y enlaces verificados; resultados finales en PROGRESS y evidence/baseline-2026-10-22.json.

### P0-02 · Proteger la lectura del progreso existente y congelar compatibilidad

- **Estado:** `DONE`.
- **Objetivo funcional:** Evitar que una clave web presente pero vacía se sobrescriba; comprobar un perfil histórico completo y fallos transaccionales.
- **Dependencias:** P0-01 (inspección inicial).
- **Archivos/módulos:** src/storage/open.web.ts; tests/persistence-compatibility.test.ts; tests/fixtures/.
- **Riesgos:** Reinicializar progreso corrupto o regenerar la fixture con el motor que se quiere comprobar.
- **Aceptación:** Crear perfil solo con clave ausente; corrupción conservada sin escritura; fixture 0.1.0 conserva intentos/XP/dominio/repasos/ajustes/diagnóstico/laboratorio; migración 1→2 y rollback comprobados.
- **Pruebas requeridas:** Ocho regresiones de compatibilidad y npm run check; repetir Playwright contra exportación web actualizada.
- **Evidencia de finalización:** Commit 23c1a04: fallo reproducido, 8/8 regresiones nuevas, 32/32 suite completa y 12/12 E2E actualizados; sin migración ni cambios de SQLite/IDs.

### P0-03 · Desacoplar la lectura histórica y habilitar recuperación segura

- **Estado:** `DONE`.
- **Objetivo funcional:** Preservar un perfil cuando el catálogo cambie y permitir recuperación desde un error de apertura sin borrado automático.
- **Dependencias:** P0-02.
- **Archivos/módulos:** src/domain/validation.ts y modelos; src/storage/*; src/ui/provider.tsx; flujo de error en app/index.tsx; fixtures.
- **Riesgos:** Pérdida de historial o XP por recalificar respuestas antiguas; migración incompleta; sobrescribir bytes antes de poder rescatarlos.
- **Aceptación:** Documentar representación/migración antes de editar; conservar fixture anterior completa; cambiar una respuesta o retirar un ID de catálogo no hace desaparecer el perfil; datos inválidos siguen rechazados; rescate explícito disponible desde fallo de apertura; distinguir BD existente sin perfil de instalación nueva.
- **Pruebas requeridas:** Fixtures 0.1.0; catálogo modificado; datos corruptos; versión futura; interrupción/rollback; reejecución de migración; restauración y E2E del flujo de recuperación.
- **Evidencia de finalización:** Implementación según ADR-006: envoltorio 2, perfil 1, SQLite 3, registro histórico congelado, copias originales y UI de rescate/confirmación. 57/57 pruebas, 20/20 E2E, TypeScript/catálogo y ambas exportaciones aprobados; fixture intacta, rollback/cuota/versiones futuras comprobados. Evidencia en PROGRESS y evidence/p0-03-2026-10-22.json.

### P0-04 · Resolver o acotar las alertas de dependencias conservando Expo

- **Estado:** `DONE` (acotación verificada; no remediación).
- **Objetivo funcional:** Investigar las 19 entradas high del informe, su exposición real y opciones compatibles sin downgrade forzado.
- **Dependencias:** P0-01; coordinar con P0-03 si cambia tooling que afecta persistencia.
- **Archivos/módulos:** versiones de package.json/package-lock.json solo si existe solución compatible; scripts de seguridad y CI; tests de guardas; docs/evidence; docs/DECISIONS.md.
- **Riesgos:** Romper RN/Expo o creer que audit fix implica una solución segura; confundir propagación con fallos independientes.
- **Aceptación:** Rastrear dos avisos raíz hasta tooling/runtime; documentar alcance; evaluar versiones mantenidas y soluciones compatibles; aplicar y probar solo una corrección acotada si existe; dejar hallazgos sin resolver visibles para revisión y bloquear lanzamiento público mientras no haya cierre justificado.
- **Pruebas requeridas:** npm audit --json; npm ls; expo install --check; Expo Doctor; check; ambas exportaciones; Playwright cuando cambie lockfile.
- **Evidencia de finalización:** Auditoría viva confirma 19 high de dos raíces sin parche estable indicado; árbol completo sin problemas. Rutas y opciones revisadas en DEPENDENCY_SECURITY y ADR-007. Sin cambios de versiones/lockfile. Guarda de mapas con 9 pruebas nuevas; 66/66 suite, 20/20 E2E, Doctor 20/20, matriz Expo offline y ambas exportaciones aprobados. Cero rutas de ambas raíces en mapas Android/web; esto no repara la auditoría ni autoriza lanzamiento. Job CI de auditoría añadido sin excepciones; ejecución remota no realizada.

### P0-05 · Verificar preparación Android local sin lanzar builds remotos

- **Estado:** `DONE`.
- **Objetivo funcional:** Confirmar que preview solicita APK y que configuración/bundle permiten preparar la siguiente compilación.
- **Dependencias:** P0-01.
- **Archivos/módulos:** eas.json, app.json, .github/workflows/ci.yml y README (inspección); RELEASE_CHECKLIST.md.
- **Riesgos:** Llamar APK a un bundle o consumir cuota/autenticación innecesariamente.
- **Aceptación:** preview.android.buildType=apk y distribution=internal; Expo config válida; dependencias compatibles; exportación Android local; ausencia de secretos detectados por revisión acotada; prerrequisitos de build/device documentados.
- **Pruebas requeridas:** expo install --check; Expo Doctor; expo config --type public; export:android; inspección de archivos y patrones sensibles sin imprimir sus valores.
- **Evidencia de finalización:** Perfil/configuración local verificados, Expo Doctor 20/20, dependencias compatibles y bundle Hermes exportado. No hay Android SDK/adb/emulador ni build remoto solicitado.

## FASE 1 — APRENDIZAJE PROFUNDO

Estado de fase: **DONE**. Cierre verificado 2026-10-22; alcance de piloto definido en ADR-009.

### P1-01 · Reanudar una sesión de aprendizaje interrumpida

- **Estado:** `DONE`.
- **Objetivo funcional:** Conservar punto de sesión y estado necesario para volver al mismo reto sin premios duplicados.
- **Dependencias:** Cierre P0-03 y revisión de P0-04 (ADR-007 permite desarrollo local con controles; no lanzamiento público).
- **Archivos/módulos:** src/ui/session.tsx, exercise.tsx; rutas de sesión; modelos/almacenamiento mediante migración.
- **Riesgos:** Reintentos duplicados, feedback perdido y cambios incompatibles del perfil.
- **Aceptación:** Una lección iniciada se recupera tras cerrar/reabrir; no reenvía un intento ya confirmado; XP/repaso se mantienen; cancelar o finalizar limpia solo esa sesión; los perfiles 0.1.0 siguen utilizables.
- **Pruebas requeridas:** Fixtures anteriores; interrupción antes/después de guardar; doble toque; SQLite reopen y E2E de reanudación.
- **Evidencia de finalización:** Sesiones por lección, borrador/unidades/pistas/apoyo, ID estable y confirmación/avance/fin atómicos verificados. Envoltorio 2→3 con original conservado, SQLite 3 sin tabla nueva. Fixture anterior intacta; 83/83 pruebas, 32/32 E2E, ambas exportaciones, guardas y Doctor 20/20 aprobados; inspección visual móvil sin desbordamiento. Ver PROGRESS/evidence/p1-01-2026-10-22.json. Android real/APK no probados. Evidencia histórica de P1-01; P1-02/P1-03 completados después.

### P1-02 · Profundizar una lección existente con estructura multinivel

- **Estado:** `DONE`.
- **Objetivo funcional:** Convertir un piloto del catálogo solicitado en una secuencia progresiva con ejemplos desarrollados y transferencia, sin rehacer todo el catálogo.
- **Dependencias:** P1-01; especificar los detalles ausentes de REQ-02 al delimitar el piloto.
- **Archivos/módulos:** Modelos Lesson, autoría, catálogo, renderizador de lección y documentación académica.
- **Riesgos:** Etiquetar dificultad sin contenido real o invalidar IDs y datos previos.
- **Aceptación:** Objetivos y progresión explícitos; cada tramo enseña y evalúa; ejemplos en pasos; contenido y fuentes revisables; las 24 lecciones previas permanecen accesibles o migradas.
- **Pruebas requeridas:** Validación de contenido; fixtures; casos correctos/incorrectos; E2E del piloto; revisión humana pendiente señalada.
- **Evidencia de finalización:** Piloto de factorización con cuatro tramos, ejemplos y ocho retos, incluidos dos nuevos de transferencia (ADR-009). Las 24 lecciones y seis IDs/soluciones anteriores se mantienen; fixture v3 conserva perfil y gate explícito. `check` 88/88, exportación web y E2E piloto 4/4 móvil/escritorio PASS. Revisión humana pendiente indicada; integración general de fase pendiente.

### P1-03 · Mejorar pistas y retroalimentación de ese piloto

- **Estado:** `DONE`.
- **Objetivo funcional:** Hacer que la ayuda responda al paso y al error sin presentar la solución inmediatamente como recuerdo independiente.
- **Dependencias:** P1-02.
- **Archivos/módulos:** Autoría de explicaciones/pistas; src/ui/exercise.tsx; registro de ayuda si cambia el contrato.
- **Riesgos:** Sobreestimar dominio después de mostrar la respuesta o añadir feedback científicamente ambiguo.
- **Aceptación:** Pistas graduadas, explicación de distractores pertinentes y ejemplo alternativo; toda ayuda influye en la evidencia como se documente; retorno al ejercicio original conserva su estado.
- **Pruebas requeridas:** Ayuda escalonada; errores repetidos; reanudación; no duplicación de premios; revisión de exactitud del piloto.
- **Evidencia de finalización:** Tres pistas y ejemplo alternativo en cada uno de los ocho retos; feedback por distractor y retorno con respuesta conservada. Ayuda persistida no aporta días independientes ni duplica XP. `check` 93/93, E2E 40/40 móvil/escritorio, ambas exportaciones, guardas y Doctor 20/20 PASS. Revisión humana pendiente; ver PROGRESS y evidence/phase1-2026-10-22.json.

## FASE 2 — MOTOR DE EJERCICIOS Y ADAPTACIÓN

Estado de fase: **DONE**. Verificado 2026-10-22, ADR-010 y evidencia phase2-2026-10-22.json.

### P2-01 · Introducir una familia de ejercicios parametrizados

- **Estado:** `DONE`.
- **Objetivo funcional:** Variar datos de una habilidad ya existente sin repetir artificialmente el catálogo.
- **Dependencias:** P0-03, P1-02.
- **Archivos/módulos:** src/domain/models.ts; generador/validación de ejercicios; autoría; almacenamiento de identidad/semilla si procede.
- **Riesgos:** Soluciones inválidas, variantes no reproducibles o XP infinito por cambiar parámetros.
- **Aceptación:** Generación reproducible por parámetros; dominios y soluciones válidos; identidad de ejercicio/variante explícita; historial anterior y política de premios conservados; sin motor remoto.
- **Pruebas requeridas:** Propiedades con semillas fijas; límites; unidades; identidad y fixtures; recorrido UI de esa familia.
- **Evidencia de finalización:** Familia v1 de trinomios con 14 pares/semillas inmutables y rondas de 3, IDs reproducibles, referencias históricas y premio compartido. `check` 108/108; E2E numérico/familia 4/4 móvil/escritorio, exportación web PASS. Expansión independiente de todas las opciones, límites, duplicación, selección, SQLite/reapertura/restauración y perfil anterior conservado. Revisión humana pendiente; ADR-010.

### P2-02 · Endurecer validación matemática y numérica

- **Estado:** `DONE`.
- **Objetivo funcional:** Evitar aceptar entradas fuera de dominio y mejorar equivalencias dentro de un alcance explícito.
- **Dependencias:** P0-03, para no invalidar respuestas históricas con un evaluador nuevo.
- **Archivos/módulos:** src/domain/answers.ts; contrato numérico/unidades; tests de respuestas y compatibilidad.
- **Riesgos:** Modificar corrección histórica o ejecutar expresiones arbitrarias.
- **Aceptación:** Rechazar operandos no finitos antes de dividir; reproducir 1/1e309 sin aceptarlo como cero; conservar coma, fracciones y notación científica válida; documentar tolerancias/unidades; nunca eval.
- **Pruebas requeridas:** Corpus de entradas válidas/hostiles; overflow/underflow; unidades; límites; historial con evaluador anterior.
- **Evidencia de finalización:** Reproducción previa falla y corrección vigente rechaza overflow/underflow de operandos, cociente y unidades; margen de tolerancia relativo sin piso 1. `check` 100/100 (93 previas + 7 nuevas). Fixture del motor d2a3258 conserva exactamente resultado antiguo, XP y checkpoints compatibles. ADR-010 y AMPLIAR documentan límites; integración de Fase 2 pendiente.

### P2-03 · Identificar errores conceptuales y medir transferencia

- **Estado:** `DONE`.
- **Objetivo funcional:** Relacionar errores de ejercicios del piloto con bases concretas y probar aplicación en un caso distinto.
- **Dependencias:** P1-03, P2-01.
- **Archivos/módulos:** Contenido, explicaciones, dominio/adaptación y ejercicio/caso de transferencia.
- **Riesgos:** Confundir un error de cálculo aislado con diagnóstico de habilidad o afirmar medición validada.
- **Aceptación:** Reglas explicables y trazables al contenido; ejercicio de transferencia diferente del ejemplo; apoyo pertinente y escalonado; no afirmar validación psicométrica.
- **Pruebas requeridas:** Distractores y reglas; independencia XP/dominio; regresiones de adaptación; revisión académica de interpretaciones.
- **Evidencia de finalización:** Diez reglas versionadas con selectores explícitos, bases/ejemplos y límites; dos retos nuevos sobre una diferencia de señales hipotéticas. Primera respuesta y última se separan sin sustituir muestra ni XP. `check` 115/115 y E2E focal 8/8 PASS móvil/escritorio, exportación web PASS. Bases/retorno, ayuda y fórmulas/unidades comprobados; revisión humana pendiente. Se corrigió estado ARIA web observado por E2E.

### P2-04 · Explicar repasos y recomendaciones

- **Estado:** `DONE`.
- **Objetivo funcional:** Mostrar por qué se recomienda una base o revisión usando datos reales del planificador.
- **Dependencias:** P0-03; P2-03 si utiliza clasificación de errores.
- **Archivos/módulos:** src/domain/learning.ts; Practice/Home/Progress; modelos de razones si hace falta.
- **Riesgos:** Mostrar motivos que no coincidan con el orden calculado o cambiar el calendario inadvertidamente.
- **Aceptación:** Misma entrada produce misma selección y razón; incluir evidencia/due/prerrequisito pertinente; permitir práctica libre; no describir algoritmo como óptimo.
- **Pruebas requeridas:** Fixtures temporales; medianoche/zona local; errores/aciertos/ayuda; estabilidad del orden y E2E de explicación.
- **Evidencia de finalización:** Guías tipadas de selección/fechas con fuente solo si el replay coincide, fallback explícito y último intento separado del que programó. Home/Practice/Review muestran razones; lectura no escribe estado/calendario. `check` 125/125, E2E 52/52, medianoche/cambio de zona, ambas exportaciones, guardas y Doctor 20/20 PASS. Revisión humana/Android pendientes; ver PROGRESS y evidencia de Fase 2.

## FASE 3 — EXPERIENCIA VISUAL Y UX

Estado de fase: **TESTING**. P3-01/02 DONE; P3-03 requiere validación Android real.

### P3-01 · Mejorar una interacción científica y su diagrama accesible

- **Estado:** `DONE`.
- **Objetivo funcional:** Evolucionar un diagrama ya utilizado conservando una alternativa completa con lector de pantalla.
- **Dependencias:** P1-02; contrato de ejercicio de P2 cuando aplique.
- **Archivos/módulos:** src/ui/exercise.tsx, components.tsx; datos del diagrama y fuentes.
- **Riesgos:** Añadir decoración sin valor didáctico o hacer depender la respuesta de un gesto inaccesible.
- **Aceptación:** Interacción sirve al objetivo del concepto; etiquetas claras; alternativa textual y controles táctiles; feedback coherente con la solución.
- **Pruebas requeridas:** Lógica de selección; E2E; inspección visual; TalkBack en Android antes de dar acceso nativo por verificado.
- **Evidencia de finalización:** Regiones táctiles, alternativa textual y radios sincronizados sin revelar solución; borrador/confirmación y XP conservados tras recarga. Lógica/E2E/visual PASS; 136 pruebas y 62 E2E de integración. No se afirma TalkBack nativo verificado. Ver ADR-011, UX_AUDIT y PROGRESS.

### P3-02 · Hacer manipulable un gráfico y mejorar su navegación

- **Estado:** `DONE`.
- **Objetivo funcional:** Conectar los controles existentes de modelos con una lectura e interpretación más clara.
- **Dependencias:** P2-02; coordinar con P4-01 para no duplicar motor científico.
- **Archivos/módulos:** components/Plot; pantalla relacionada; rutas y UI.
- **Riesgos:** Divergencia entre datos, curva y alternativa accesible; regresión al volver de una lección.
- **Aceptación:** Cambio de control actualiza modelo/lectura coherentemente; ejes/unidades presentes; navegación conserva contexto y admite volver; sin depender de color solamente.
- **Pruebas requeridas:** Modelo numérico; actualización reactiva; navegación/recarga; inspección móvil y E2E.
- **Evidencia de finalización:** Lecturas comparadas a igual pH, óptimo accesible, ejes/rangos escalables, marcas fraccionarias y curvas diferenciadas; controles conservados en navegación/recarga, URLs inválidas/límites probados. Misma función científica. 136 pruebas/62 E2E y exportaciones; notas no guardadas siguen transitorias y se indica. Ver PROGRESS.

### P3-03 · Auditar accesibilidad y rendimiento móvil con evidencia

- **Estado:** `TESTING`.
- **Objetivo funcional:** Detectar y corregir un conjunto acotado de barreras o costes medidos en pantallas reales.
- **Dependencias:** P3-01/P3-02 para integración; puede auditarse una pantalla antes.
- **Archivos/módulos:** UI/pantallas/rutas afectadas; pruebas; evidencia de medición.
- **Riesgos:** Optimizar sin medir, alterar todo screens.tsx o llamar accesible a una pantalla solo por tener labels.
- **Aceptación:** Registrar dispositivo, tamaño de texto, contraste, foco y movimiento reducido; medir inicio/listas con historial representativo; corregir el cuello de botella/barrera observados sin ampliar alcance.
- **Pruebas requeridas:** Pruebas visuales/E2E; herramientas de medición disponibles; TalkBack y texto grande en Android con resultados registrados.
- **Evidencia de finalización:** Auditoría reproducible de foco/contraste/320 px/texto 200%/movimiento y tiempos con 100–10.000 intentos; índice local reduce selección manteniendo oráculo anterior. Regresiones, bundle Hermes y web verificados. Pendiente dispositivo identificado, TalkBack, fontScale y rendimiento nativo: no marcar DONE ni avanzar a Fase 4. Ver UX_AUDIT y evidencia phase3.

## PREP-04 · Preparar cierre nativo y entrada a Fase 4

- **Estado:** `DONE` como preparación local. Al cierre PREP-04, P3-03 TESTING/Fase 4 PENDING; registro histórico, superado por autorización ADR-013 e implementación F4.
- **Objetivo funcional:** Proveer diagnóstico Android y registro verificable de aceptación, corregir impedimentos locales reproducidos y dejar P4-01 ejecutable cuando cierre la puerta.
- **Dependencias:** P3-01/02 DONE; P3-03 se conserva TESTING, no se redefine su aceptación.
- **Módulos:** scripts/readiness, android-preflight, check-phase4-readiness; package/lockfile; docs/evidence y PHASE4_HANDOFF.
- **Riesgos:** Confundir prebuild con APK/TalkBack; aceptar plantilla no ejecutada; invalidar progreso/firma o introducir cambios de motor fuera de alcance.
- **Aceptación:** Diagnóstico falla honestamente si faltan herramientas; plantilla PENDING nunca acepta; evidencia ligada a fuentes/APK/archivos con hash y exige revisión humana. Prebuild aislado reproducido; aviso de SystemUI corregido; scripts/catálogo/persistencia sin regresiones; instrucción de entrada y límites documentados. No requiere aprobar pruebas Android que no se ejecutaron.
- **Pruebas requeridas:** Validación de registro, rutas/huellas/archivos y CLI; compatibilidad/TypeScript, exportaciones y E2E tras la dependencia; generación nativa local; auditoría.
- **Evidencia:** Preflight/registro/huellas con 12 regresiones nuevas; 148/148 pruebas, 62/62 E2E, prebuild aislado corregido, exportaciones/guardas y Doctor 20/20 PASS. Diagnóstico/plantilla bloquean por falta de Android real. Ejecución en PROGRESS y evidence/phase4-prep-2026-10-22.json. DONE de esta preparación no significa DONE de Fase 3 ni autorización de Fase 4.

## FASE 4 — BIOLAB Y PROYECTOS

Estado de fase: **DONE en el alcance funcional autorizado**. Verificación 163 pruebas y 68 E2E; revisión humana/nativa pendientes declaradas, sin validar eficacia.

### P4-01 · Profundizar el experimento enzimático existente

- **Estado:** `DONE`.
- **Objetivo funcional:** Hacer explícitas pregunta, hipótesis, variable independiente, respuesta y condiciones de control del modelo.
- **Dependencias:** P2-02; P3-02 para controles; revisión de supuestos del modelo.
- **Archivos/módulos:** src/domain/laboratory.ts; Laboratory; contenido/fuentes.
- **Riesgos:** Presentar la gaussiana o sus datos como experimentos reales; agregar variables sin un modelo documentado.
- **Aceptación:** Supuestos y límites visibles; cada variable respaldada por cálculo/documentación; comparación de condiciones y predicción comprobables; no manipulación de organismos.
- **Pruebas requeridas:** Unidades; máximo y extremos; constantes/controles; UI; revisión académica de hechos frente a supuestos.
- **Evidencia de finalización:** Guía offline, variables/controles, predicción con cálculo real del motor y ejemplo en pasos; pruebas de máximos/extremos/simetría/comparación y E2E móvil/escritorio PASS. Hechos/supuestos y revisión humana señalados en ACADEMIC_REVIEW.

### P4-02 · Fortalecer datos y cuaderno del laboratorio

- **Estado:** `DONE`.
- **Objetivo funcional:** Mantener hipótesis, condiciones y observaciones consistentes al comparar y reabrir sesiones.
- **Dependencias:** P4-01; P0-03 para cualquier cambio de formato.
- **Archivos/módulos:** LaboratorySession; almacenamiento/migración; pantallas de cuaderno y visualización.
- **Riesgos:** Perder sesiones antiguas o permitir un criterio distinto del texto presentado al estudiante.
- **Aceptación:** Conservar sesiones 0.1.0; documentar criterio mínimo de comparación; datos y gráficos muestran las mismas condiciones; distinguir registro simulado y observación escrita; reapertura consistente.
- **Pruebas requeridas:** Fixture con laboratorio; migración/reopen si aplica; validación de condiciones; E2E de cuaderno.
- **Evidencia de finalización:** Mínimo nuevo de dos pH distintos del mismo modelo, deduplicación y guardado idempotente; lectura antigua 12.345 preservada, SQLite reopen/restore y E2E PASS. Reapertura con valores originales, tabla paginada y gráfico por modelo limitado con aviso; carga 100/1.000/10.000 sin reescritura.

### P4-03 · Construir un proyecto interdisciplinario acotado

- **Estado:** `DONE`.
- **Objetivo funcional:** Conectar un caso ya pedido de concentraciones, crecimiento o análisis de datos con conocimientos de varias rutas.
- **Dependencias:** P4-02; prerrequisitos reales disponibles; delimitar caso desde requisitos existentes/REQ-02.
- **Archivos/módulos:** Contenido/ruta integrada; motor de ejercicios/laboratorio; UI del proyecto.
- **Riesgos:** Inflar catálogo con pantallas vacías o necesitar contenido planificado para poder terminar el proyecto.
- **Aceptación:** Un recorrido completo con objetivo, bases, datos simulados, análisis y conclusión con limitaciones; fuentes verificables; funciona offline con contenido incluido.
- **Pruebas requeridas:** Integridad de prerrequisitos; cálculos; datos; recorrido completo; revisión académica pendiente identificada.
- **Evidencia de finalización:** Proyecto de seis retos reales de dilución/recuento simulado con bases implementadas, modelo, unidades, análisis y conclusión; recorrido completo/reanudación de confirmados/offline/XP una sola vez PASS. Las 24 lecciones y la primera transferencia idénticas a 18eb63a; resto integrado sigue planificado.

## FASE 5 — INTEGRACIÓN Y LANZAMIENTO

Estado de fase: **TESTING**. P5-01 DONE local; P5-02 BLOCKED y P5-03 TESTING por aceptación nativa pendiente. R-04 mantiene bloqueo público.

### P5-01 · Cerrar regresiones y revisión del catálogo del incremento

- **Estado:** `DONE`.
- **Objetivo funcional:** Verificar juntos los módulos modificados y separar controles automáticos de revisión académica real.
- **Dependencias:** Tareas del incremento autorizado terminadas; P0-04 resuelto o decisión de riesgo revisada.
- **Archivos/módulos:** tests; autoría/catálogo; docs/evidence y checklist.
- **Riesgos:** Dar DONE global por un solo test o usar contenido sin revisión como si estuviera validado.
- **Aceptación:** Suite pertinente completa; currículo y grafo coherentes; fixtures anteriores intactas; ningún fallo abierto ocultado; contenidos con fuentes/estado de revisión.
- **Pruebas requeridas:** check; ambas exportaciones; Playwright; revisión científica documentada; casos límite y datos representativos.
- **Evidencia de finalización:** 163/163 pruebas, 68/68 E2E, ambas exportaciones/guardas, Doctor 20/20, instalación limpia y validación del grafo PASS. Revisión técnica académica documentada, humana pendiente. Fixtures/contenido previo exactos; reproduce/fija retorno web offline; ver evidence/phase45-2026-10-22.json.

### P5-02 · Validar Android, offline y rendimiento en dispositivo

- **Estado:** `BLOCKED`.
- **Objetivo funcional:** Comprobar driver/gestos/exportación nativos, reapertura y estudio en modo avión sobre el APK generado.
- **Dependencias:** P5-01; entorno SDK/emulador/dispositivo disponible.
- **Archivos/módulos:** Build nativo/configuración solo si hay necesidad; matriz manual y evidencia de dispositivo.
- **Riesgos:** Confundir emulación de viewport con Android; cambios de firma/package que impidan actualizar preservando datos.
- **Aceptación:** Dispositivo y versión registrados; cierre/reapertura conserva datos; importación/exportación, texto grande/TalkBack, modo avión y orientación probados; medidas de rendimiento del incremento.
- **Pruebas requeridas:** APK instalado; escenario manual del checklist; conservar perfil antes/después; evaluación de seguridad de dependencias cerrada.
- **Evidencia de finalización:** JDK/SDK/adb/build-tools presentes y preflight PASS; sin dispositivo/emulador/KVM para ejecutar matriz nativa. Faltan TalkBack, escalas/orientación reales, SQLite nativo, modo avión y tiempos; R-04 también pendiente. Un APK compilado no cerrará esta tarea.

### P5-03 · Preparar APK y documentación de entrega

- **Estado:** `TESTING`.
- **Objetivo funcional:** Entregar un artefacto instalable identificado con alcance, instrucciones y evidencia de build finalizado.
- **Dependencias:** P5-01; entorno de compilación listo; completar P5-02 antes de declarar entrega validada.
- **Archivos/módulos:** eas.json/app.json; build outputs; README; RELEASE_CHECKLIST; PROGRESS.
- **Riesgos:** Gasto/cuota externa, secretos de firma, distribución de binario sin comprobar o sin ruta de actualización.
- **Aceptación:** APK existe con hash/origen y build exitoso; no contiene credenciales; instrucciones para Android y pendientes reales; firma/versionado adecuados al canal elegido; costes/autenticación informados si se considera EAS.
- **Pruebas requeridas:** Verificación artefacto y firma; instalación/actualización; pruebas de dispositivo; checklist revisado.
- **Evidencia de finalización:** APK final ARM64 generado con BUILD SUCCESSFUL/exit 0, firma v2, ZIP/alineación 16 KB, versión/package/ABI y contenido incluidos verificados. Permiso overlay heredado eliminado y recompilado offline con certificado conservado. Artefacto/hash en PROGRESS/evidence; no instalado ni probado en Android, por lo que P5-03 sigue TESTING.

## Siguiente incremento recomendado

**Completar P5-02 con el APK identificado y la matriz de aceptación Android**, después de revisar el resultado de P5-03 en PROGRESS. No repetir Fases 1/2/4 ni el cierre local P5-01. P3-03 también requiere TalkBack/escala/orientación reales; usar PHASE4_HANDOFF y plantilla manual, sin copiar resultados web. Resolver R-04 antes de cualquier lanzamiento público.

> Continúa BioNexo desde el último commit de entrega según AGENTS.md y PROGRESS.md. La Fase 4 y P5-01 están DONE en alcance local verificado; Fase 5 sigue TESTING. Revisa el APK real, huella/firma y pendientes de P5-02/P3-03, protege progreso y firma antes de instalar/actualizar. Ejecuta la matriz Android con evidencia real, incluyendo inicio en modo avión, SQLite/reanudación, respaldos, TalkBack, escalas/orientación y rendimiento; si no hay dispositivo no inventes resultados. Mantén R-04 visible y no publiques con 19 high abiertas. No dispares EAS ni costes ni cambies claves para eludir fallos. No vuelvas a implementar el proyecto/laboratorio ya comprobados.
