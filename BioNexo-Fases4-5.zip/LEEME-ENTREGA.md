# BioNexo · entrega de Fases 4/5

Commit de entrega: 6bc0d8772eea4b51632000a68cd013a462345906

Fase 4 y P5-01 terminadas en alcance local comprobado: BioLab guiado/predicciones, cuaderno reabrible y proyecto interdisciplinario de seis retos. 163 pruebas de lógica/integración y 68 recorridos web aprobados. Conserva las 24 lecciones, progreso y formatos previos. La app mantiene versión 0.1.0.

El APK se entrega por separado: BioNexo-Android-ARM64-Prueba.apk. Es para pruebas internas, Android ARM64 (minSdk 24), firmado con la clave de prueba pública de la plantilla. Build, firma v2, alineación 16 KB y hash verificados. No se ha instalado ni probado en un dispositivo/emulador. No es una publicación aprobada.

Antes de actualizar una instalación existente, exporta tu progreso desde Configuración y conserva el respaldo. Comprueba package/firma compatibles; si Android rechaza la actualización, conserva la app y el respaldo. No desinstales para eludir un conflicto de firma.

En PC: entra a bionexo y ejecuta npm ci, npm run check y npm start. Node >=22.13; Python 3 solo para regenerar contenido. README.md contiene guía Windows/Android, APK gratuito por Gradle, arquitectura y fuentes.

Para recuperar Git, desde esta carpeta: git clone bionexo-history.bundle bionexo-con-historial. El bundle incluye todos los commits y no publica nada en un servidor.

Siguiente: completar P5-02/P3-03 en Android real, con modo avión desde arranque, SQLite/reanudación, respaldos, TalkBack, escalas/orientación y rendimiento. P5-03 sigue TESTING por aceptación instalada pendiente. Revisión académica humana pendiente y 19 alertas high abiertas bloquean publicación pública (R-04). No se usó EAS, cuenta externa, servicio pagado ni credenciales.

Estado y evidencia: bionexo/docs/PROGRESS.md y bionexo/docs/evidence. Código MIT; materiales originales CC BY-NC-SA 4.0. BioNexo no es producto oficial de ninguna universidad.
