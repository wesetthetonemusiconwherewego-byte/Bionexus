# Pedagogía implementada y límites

La revisión de Dunlosky et al. (2013, DOI: 10.1177/1529100612453266) califica práctica de recuperación y práctica distribuida con alta utilidad, y autoexplicación e intercalado con utilidad moderada. Esta evidencia orienta el diseño; no prueba la eficacia de BioNexo ni de sus parámetros concretos.

Cada lección combina objetivo, activación, explicación, ejemplo resuelto, seis retos, aplicación y resumen. Las duraciones son estimadas y requieren medir tiempos con usuarios. Hay ejercicios de transferencia, no solo definiciones. La comparación de hipótesis y observaciones se realiza en el cuaderno del laboratorio; las respuestas abiertas del cuaderno no reciben una calificación automática de calidad científica.

## Planificador determinista v1

Por concepto: historial, paso, intervalo, fecha y lapsos. Primera respuesta correcta sin pista: 1 día. Respuestas correctas en días posteriores avanzan por `[1,3,7,14,30,60]` días. Error: paso cero y repaso en 10 minutos; acierto con ayuda: retrocede un paso y propone 12 horas. Cada error puede adelantar la revisión; los aciertos de un mismo día no escalan varias veces. Esto evita completar toda la escala en una lección. Los instantes se guardan en ISO UTC, los días de evidencia y racha siguen el calendario local del dispositivo. Cambiar la hora del sistema puede alterar recomendaciones; no hay servidor de tiempo.

La cola usa round-robin entre conceptos pendientes, priorizando preguntas falladas y las menos recientes. El intercalado inicial se aplica a repasos, después de enseñar la habilidad dentro de su lección. Hay práctica libre antes de la fecha y revisión manual de errores. Los repasos no vencidos no desaparecen del historial. No hay notificaciones automáticas.

## Evidencia de dominio

Puntaje inicial 0; acierto sin ayuda +0,18, con ayuda +0,08 (máximo 1); error multiplica por 0,65. Etiqueta de dominio: puntaje al menos 0,75 y respuestas correctas sin ayuda en al menos dos días. Es una heurística visible, no una estimación validada de retención ni una acreditación. Preguntas repetidas pueden inflar puntaje: evaluar con ítems nuevos y calibrar parámetros son trabajos pendientes. XP es independiente: 10 por ejercicio respondido correctamente por primera vez, 20 por primera finalización de lección.

Las bases recomendadas se consideran suficientes al tener dominio o haber completado su lección con puntaje de al menos 0,6. Siempre se puede abrir la explicación y elegir practicar igualmente. No hay vidas ni pérdida de XP por error. El diagnóstico tiene seis ítems matemáticos y dos de cada otra ciencia; no asigna dominio ni XP. Sus errores priorizan recomendaciones y sus resultados no certifican capacidad universitaria.

## Apoyo tras errores

Tras al menos dos errores de un concepto se muestra una vía de explicación desde el ejemplo, sus bases relacionadas y un ejercicio sencillo de un prerrequisito (o de la misma habilidad si no hay uno). Al resolverlo puede volverse a intentar el problema original, con ayuda marcada para no confundirlo con recuerdo independiente. La adaptación es por reglas explícitas, sin IA ni inferencia psicológica. La progresión de dificultad usa contenido disponible; no genera problemas nuevos.

## Validación futura

Revisión por profesores de ciencias; pruebas con estudiantes; medir comprensión diferida y transferencia; corregir distractores ambiguos; comparar planificadores con un diseño evaluable. No se afirma que el algoritmo sea óptimo o científicamente validado.
