# Arquitectura

React Native/Expo SDK 58, TypeScript estricto con `noUncheckedIndexedAccess`, Expo Router. Rutas: `/`, `/lesson/[id]`, `/diagnostic`, `/review`; la navegación principal se refleja en `?tab=` para conservar la sección al recargar la vista web. En pantallas amplias aparece una barra lateral; en móvil cinco destinos principales y accesos a biblioteca/configuración en la cabecera.

## Flujo de datos

1. JSON incluido en el bundle → catálogo tipado → validador en arranque.
2. La UI recibe el ejercicio y recoge una respuesta estructurada.
3. El dominio calcula corrección, evidencia, XP y próxima revisión.
4. `ProgressRepository.update` serializa mutaciones y confirma la escritura antes de actualizar la UI.
5. En Android/iOS `SQLiteRepository` abre `bionexo.db` en almacenamiento privado de la app. No hay fallback silencioso a memoria. En web se usa un adaptador explícito de `localStorage` para facilitar pruebas y previsualización; no se afirma que la vista web sea una PWA instalable/offline completa.

## Persistencia y migración

`PRAGMA user_version` versiona el esquema, no el catálogo. Migración 1: tabla `user_state` con un documento JSON de perfil único; migración 2: tabla `repository_metadata`. Cada migración y cada actualización usa `BEGIN IMMEDIATE`/`COMMIT`, con `ROLLBACK` al fallar. Una cola por repositorio impide que las escrituras concurrentes pierdan cambios. Las sentencias con datos usan parámetros.

Un documento por perfil es una decisión para el MVP: agrupa atómicamente intentos, dominio, XP, revisiones y ajustes. Las interfaces separan almacenamiento y dominio para migrar más adelante a tablas normalizadas e índices sin reescribir la interfaz. Versiones de BD futuras se rechazan; datos corruptos producen un aviso y nunca se borran automáticamente. Cerrar y reabrir una SQLite en disco se verifica en pruebas con `node:sqlite`; falta probar el driver nativo en Android.

Los intentos tienen ID por sesión, ejercicio y reintento. Un evento repetido no se vuelve a registrar; la primera respuesta correcta de un ejercicio otorga 10 XP una sola vez. Terminar los seis ejercicios de una lección otorga 20 XP una sola vez. Las respuestas incorrectas no bloquean completar, pero sí influyen en evidencia y recomendaciones. Salir durante una sesión conserva los intentos: abrirla otra vez empieza la secuencia desde el principio y no vuelve a otorgar XP ya ganado. Reanudar exactamente la posición es una mejora pendiente.

## Respaldo

Formato JSON de perfil `version: 1`, máximo 10 MB. Se comprueban versión, referencias de catálogo, unidades de progreso, respuestas/corrección, XP coherente con premios, fechas y rangos. Importar requiere selección explícita y confirmación de reemplazo. No hay fusión entre perfiles ni cifrado específico de la exportación. Es una copia local; no se transmite a servidores de BioNexo. Desinstalar la aplicación puede eliminar SQLite: el respaldo externo es la forma de recuperarlo.

## Extensión

- Agregar cursos: contrato de `Lesson`/`Exercise`, catálogo y grafo.
- Agregar laboratorios: modelos puros junto a `laboratory.ts`, UI y pruebas de cálculos.
- Sincronización futura: implementar un repositorio que sincronice eventos manteniendo IDs estables y política de conflictos. No existe hoy.
- Tutor IA futuro: proveedor opcional de explicaciones, desactivado por defecto, sin dependencia para calificar respuestas. No existe hoy.

## Accesibilidad y recursos

Controles con etiquetas y estados, texto escalable, objetivos de al menos 48 unidades, alternativas textuales para gráficas, botones de ajuste además del slider y preferencia del sistema para movimiento reducido. No hay fuentes, imágenes o scripts remotos en el flujo de aprendizaje. Los gráficos e iconos SVG son originales. Auditoría con TalkBack/VoiceOver y escalado extremo pendiente.
