# Fuentes verificadas el 22 de octubre de 2026

| Fuente | Uso real en BioNexo |
|---|---|
| [UNAB, malla de Ingeniería en Biotecnología](https://www.unab.cl/carreras/mallas/ing_biotecnologia.pdf) | Referencia de áreas: ciencias básicas, bioquímica, genética, biología molecular, bioestadística y bioinformática/ciencia de datos. Las dependencias detalladas del catálogo son decisiones didácticas de BioNexo, no prerrequisitos oficiales inferidos del PDF. |
| [MIT, Biological Engineering requirements](https://be.mit.edu/undergraduate-program/major-degree-requirements/) | Referencia de integración de biología, química, física, cálculo, programación y trabajo de diseño. No se presenta la ruta de la app como una reproducción del plan MIT. |
| [OpenStax, catálogo](https://openstax.org/higher-education) | Lecturas complementarias de acceso gratuito; no se incluyen libros descargados ni bancos de preguntas. |
| [Dunlosky et al., 2013](https://doi.org/10.1177/1529100612453266) | Justificación general de recuperación y práctica distribuida. El DOI no respondió al primer acceso; se corroboraron título, autores y conclusiones en [PubMed](https://pubmed.ncbi.nlm.nih.gov/26173288/) y la [página de APS](https://www.psychologicalscience.org/publications/journals/pspi/learning-techniques.html). |

## Lecturas por bloque

- Biología: [Biology 2e](https://openstax.org/books/biology-2e/pages/1-introduction), capítulos 1 (vida e investigación), 2 (química de la vida), 3 (macromoléculas), 4 (células), 5 (membranas).
- Laboratorio: [Biology 2e, 6.5 Enzymes](https://openstax.org/books/biology-2e/pages/6-5-enzymes). La función gaussiana no se atribuye a ese libro ni a un experimento: es una elección didáctica de BioNexo.
- Química: [Chemistry 2e](https://openstax.org/books/chemistry-2e/pages/1-introduction), capítulos 1–3 y 7.
- Física: [College Physics 2e](https://openstax.org/books/college-physics-2e/pages/1-introduction-to-science-and-the-realm-of-physics-physical-quantities-and-units), capítulos 1–7.
- Matemáticas: [Precalculus 2e](https://openstax.org/books/precalculus-2e/pages/1-introduction-to-functions), apéndice A y capítulos 1–3.

## Reutilización y atribución

Se verificó la [información actual de licencias de OpenStax](https://help.openstax.org/s/article/Licensing-information-of-OpenStax-textbooks) y prefacios: las ediciones consultadas se ofrecen actualmente bajo **CC BY-NC-SA 4.0**. No debe asumirse CC BY a partir de copias antiguas. Si se incorporan adaptaciones en el futuro: identificar obra/edición, autores, enlace, licencia y cambios, cumplir atribución visible por página y las condiciones no comerciales/compartir igual. Marcas, portadas y logotipos tienen condiciones distintas.

Los textos, problemas, soluciones, figuras e iconos incluidos en esta entrega son de nueva redacción para BioNexo y no reproducen pasajes ni ilustraciones de esas fuentes. El código tiene licencia MIT; los materiales educativos originales se distribuyen bajo CC BY-NC-SA 4.0. Las referencias no implican aval universitario. No se atribuye a fuentes ninguna validación de los resultados educativos de esta aplicación.

## Compatibilidad técnica

- [Matriz oficial Expo](https://docs.expo.dev/versions/latest/): SDK 58 / React Native 0.88 / React 19.3, mínimo Node 22.13.
- [expo-sqlite](https://docs.expo.dev/versions/latest/sdk/sqlite/): base local persistente.
- Las versiones concretas instaladas se fijan en `package-lock.json` y se verifican contra `expo/bundledNativeModules.json` mediante `expo install --check`.
