# Añadir cursos, conceptos y ejercicios

1. Edita `scripts/build_content.py`, fuente de autoría, o cambia el contrato y el generador juntos. No edites solo el JSON y luego lo sobrescribas sin querer.
2. Asigna ID estable y único a cada entidad. Una corrección de redacción conserva ID; un cambio de habilidad o significado exige ID nuevo y una estrategia de migración de progreso.
3. Cada concepto debe declarar materia, título en ambos idiomas, explicación, ejemplo, fuente, origen y prerrequisitos existentes. `planned` no crea una lección ejecutable. Para pasar a `implemented`, escribe la lección completa y revisa exactitud, distractores y fuentes.
4. Cada lección lleva objetivo medible, activación, explicación, ejemplo en pasos, aplicación, resumen y al menos seis ejercicios. Usa errores plausibles como distractores; varía contextos y demanda cognitiva. La revisión humana queda registrada como pendiente hasta que exista un revisor real.
5. Ejercicios: `choice`, `multi`, `text`, `numeric`, `match`, `order`, `chart`, `diagram`, `prediction`, `case`. Las variantes de gráfico y diagrama tienen datos/estructura propios; no dependen de recursos remotos. Actualmente el diagrama soportado es una célula esquemática. Añade una variante tipada y su renderizador para estructuras nuevas.
6. En numéricos, `correct` y `tolerance` se expresan en `unit`; `acceptedUnits` mapea unidad → factor hacia esa unidad de referencia. Ejemplo: unidad L, factores `{L:1,mL:0.001}`. Decimales con coma, fracciones y exponentes están admitidos; expresiones algebraicas arbitrarias no se evalúan. Especifica siempre los supuestos de una fórmula.
7. Ejecuta `npm run content:build`, `npm run check`, las exportaciones y las pruebas de interfaz pertinentes. Revisa el grafo para no crear ciclos. El validador comprueba referencias, soluciones validables, datos y coherencia de unidades/rangos; no demuestra toda la corrección científica.

## Nuevos laboratorios

Separa el cálculo puro y sus parámetros del renderizador. Declara dominio, unidades, supuestos, limitaciones, y si los datos son simulados. Añade pruebas de casos conocidos, límites y simetrías cuando correspondan. El cuaderno conserva hipótesis, puntos y observaciones. Nunca etiquetes valores del modelo como mediciones reales.

## Futuros idiomas, cuentas o IA

El contenido está separado de la UI, pero la internacionalización completa de textos de interfaz es un trabajo pendiente. El glosario inglés es gradual, no un curso bilingüe completo. No añadas una dependencia de red a la calificación ni al progreso local. Proveedores externos deben ser opcionales y tener pruebas de fallo/sin conexión.
