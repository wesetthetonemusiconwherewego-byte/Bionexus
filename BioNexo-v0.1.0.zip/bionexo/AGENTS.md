# BioNexo contributor instructions

This is an Expo/React Native mobile application, primarily Android. Keep learning, grading, scheduling, science models and persistence independent of UI. Native storage must use expo-sqlite; open.web.ts is a deliberate preview adapter.

- Use npm ci and the committed lockfile. Install native dependencies through npx expo install and run its compatibility check.
- Academic authoring source is scripts/build_content.py. Regenerate JSON with npm run content:build. Preserve stable IDs and do not count planned concepts as playable content.
- Keep original Spanish explanations, meaningful distractors, units, assumptions, sources and worked examples. Human academic review is pending; never describe automatic validation as scientific review.
- Use strict TypeScript. Never eval numeric input or add mandatory paid APIs, accounts, network services, or remote resources to the learning flow.
- Changes to progress must preserve idempotent XP and transactional persistence. Do not silently reset corrupt user data.
- For relevant changes run npm run check and export the affected platform. Use Playwright for interactive changes. Browser results are not proof of Android behavior.
- Update docs/ESTADO.md with actual evidence and outstanding work. Never claim an APK/device test when only a JavaScript bundle was exported.
