import type {
  Attempt,
  DiagnosticResult,
  Exercise,
  Lesson,
  MasteryRecord,
  ReviewSchedule,
  UserState,
} from "./models";
import { grade } from "./answers";
import { catalog, conceptById, exerciseById } from "../content";
const DAY = 86_400_000;
export const INTERVALS = [1, 3, 7, 14, 30, 60] as const;
/** Device-local calendar day. ISO UTC is used for due instants, not streak boundaries. */
export function dayKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function initialState(now = new Date()): UserState {
  return {
    version: 1,
    createdAt: now.toISOString(),
    onboarded: false,
    settings: {
      name: "Explorador",
      theme: "dark",
      reduceMotion: false,
      dailyGoal: 6,
    },
    attempts: [],
    mastery: {},
    reviews: {},
    completedLessonIds: [],
    rewardedExerciseIds: [],
    xp: 0,
    studyDays: {},
    labs: [],
    diagnostic: null,
  };
}
export function schedule(
  previous: ReviewSchedule | undefined,
  conceptId: string,
  correct: boolean,
  hinted: boolean,
  now: Date,
): ReviewSchedule {
  const step = !correct
    ? 0
    : hinted
      ? Math.max(0, (previous?.step ?? 0) - 1)
      : previous
        ? Math.min(previous.step + 1, INTERVALS.length - 1)
        : 0;
  const intervalDays = !correct
    ? 10 / (24 * 60)
    : hinted
      ? 0.5
      : (INTERVALS[step] ?? 1);
  return {
    conceptId,
    step,
    intervalDays,
    dueAt: new Date(now.getTime() + intervalDays * DAY).toISOString(),
    lapses: (previous?.lapses ?? 0) + (correct ? 0 : 1),
  };
}
export function recordAttempt(state: UserState, attempt: Attempt): UserState {
  if (state.attempts.some((a) => a.id === attempt.id)) return state;
  const exercise = exerciseById[attempt.exerciseId];
  if (!exercise) throw new Error("El ejercicio no existe en este catálogo.");
  // The engine computes truth instead of trusting a UI flag or an imported event.
  const validAttempt = {
    ...attempt,
    correct: grade(exercise, attempt.answer),
    conceptIds: exercise.conceptIds,
  };
  const next: UserState = {
    ...state,
    attempts: [...state.attempts, validAttempt],
    mastery: { ...state.mastery },
    reviews: { ...state.reviews },
    rewardedExerciseIds: [...state.rewardedExerciseIds],
    studyDays: { ...state.studyDays },
  };
  if (attempt.mode === "diagnostic") return next;
  const now = new Date(attempt.at),
    day = dayKey(now);
  next.studyDays[day] = (state.studyDays[day] ?? 0) + 1;
  if (validAttempt.correct && !next.rewardedExerciseIds.includes(exercise.id)) {
    next.xp += 10;
    next.rewardedExerciseIds.push(exercise.id);
  }
  for (const conceptId of exercise.conceptIds) {
    const previous: MasteryRecord = state.mastery[conceptId] ?? {
      conceptId,
      score: 0,
      correct: 0,
      wrong: 0,
      streak: 0,
      evidenceDays: [],
    };
    const evidenceDays =
      validAttempt.correct && !attempt.hinted
        ? [...new Set([...previous.evidenceDays, day])]
        : previous.evidenceDays;
    next.mastery[conceptId] = {
      ...previous,
      evidenceDays,
      score: validAttempt.correct
        ? Math.min(1, previous.score + (attempt.hinted ? 0.08 : 0.18))
        : previous.score * 0.65,
      correct: previous.correct + Number(validAttempt.correct),
      wrong: previous.wrong + Number(!validAttempt.correct),
      streak: validAttempt.correct ? previous.streak + 1 : 0,
    };
    // Multiple questions of one concept in a session must not jump through all spacing steps.
    // Failed attempts always shorten the next interval. Correct attempts advance at most once per calendar day.
    const last = [...state.attempts]
      .reverse()
      .find((a) => a.mode !== "diagnostic" && a.conceptIds.includes(conceptId));
    const sameDay = last && dayKey(new Date(last.at)) === day;
    if (!validAttempt.correct || !sameDay || !state.reviews[conceptId]) {
      next.reviews[conceptId] = schedule(
        state.reviews[conceptId],
        conceptId,
        validAttempt.correct,
        attempt.hinted,
        now,
      );
    }
  }
  return next;
}
export function completeLesson(
  state: UserState,
  lesson: Lesson,
  sessionId: string,
): UserState {
  if (state.completedLessonIds.includes(lesson.id)) return state;
  const allAnswered = lesson.exercises.every((e) =>
    state.attempts.some(
      (a) =>
        a.id.startsWith(`${sessionId}:`) &&
        a.exerciseId === e.id &&
        a.mode === "lesson",
    ),
  );
  if (!allAnswered)
    throw new Error("Completa los ejercicios antes de terminar la lección.");
  return {
    ...state,
    completedLessonIds: [...state.completedLessonIds, lesson.id],
    xp: state.xp + 20,
  };
}
export function isMastered(record: MasteryRecord | undefined): boolean {
  return !!record && record.score >= 0.75 && record.evidenceDays.length >= 2;
}
export function prerequisiteMet(state: UserState, id: string): boolean {
  return (
    isMastered(state.mastery[id]) ||
    catalog.lessons.some(
      (l) =>
        l.conceptIds.includes(id) &&
        state.completedLessonIds.includes(l.id) &&
        (state.mastery[id]?.score ?? 0) >= 0.6,
    )
  );
}
export function missingPrerequisites(
  state: UserState,
  lesson: Lesson,
): string[] {
  return lesson.prerequisites.filter((id) => !prerequisiteMet(state, id));
}
export function recommendations(state: UserState): Lesson[] {
  const available = catalog.lessons.filter(
    (l) =>
      !state.completedLessonIds.includes(l.id) &&
      missingPrerequisites(state, l).length === 0,
  );
  const weak = state.diagnostic?.weakConceptIds ?? [
    "math-factor",
    "math-equations",
  ];
  return available.sort(
    (a, b) =>
      Number(b.conceptIds.some((c) => weak.includes(c))) -
        Number(a.conceptIds.some((c) => weak.includes(c))) ||
      Number(b.subjectId === "math") - Number(a.subjectId === "math"),
  );
}
export function reviewQueue(
  state: UserState,
  now = new Date(),
  limit = 8,
): Exercise[] {
  const due = Object.values(state.reviews)
    .filter((r) => new Date(r.dueAt) <= now)
    .sort((a, b) => a.dueAt.localeCompare(b.dueAt));
  const pools = due.map((r) => {
    const candidates = catalog.lessons
      .flatMap((l) => l.exercises)
      .filter((e) => e.conceptIds.includes(r.conceptId));
    return candidates.sort((a, b) => {
      const lastA = [...state.attempts]
        .reverse()
        .find((x) => x.exerciseId === a.id);
      const lastB = [...state.attempts]
        .reverse()
        .find((x) => x.exerciseId === b.id);
      return (
        Number(lastA?.correct ?? true) - Number(lastB?.correct ?? true) ||
        (lastA?.at ?? "").localeCompare(lastB?.at ?? "")
      );
    });
  });
  const output: Exercise[] = [];
  // Round-robin interleaves concepts instead of exhausting one skill first.
  for (
    let round = 0;
    output.length < limit && pools.some((p) => p[round]);
    round++
  )
    for (const pool of pools) {
      const item = pool[round];
      if (
        item &&
        output.length < limit &&
        !output.some((e) => e.id === item.id)
      )
        output.push(item);
    }
  return output;
}
export function diagnosticResult(
  attempts: Attempt[],
  completedAt: string,
): DiagnosticResult {
  const results: DiagnosticResult["results"] = {};
  const weakConceptIds: string[] = [];
  for (const e of catalog.diagnostic) {
    const a = [...attempts]
      .reverse()
      .find((x) => x.exerciseId === e.id && x.mode === "diagnostic");
    if (!a) throw new Error("El diagnóstico aún tiene preguntas pendientes.");
    const result = results[e.subjectId] ?? { correct: 0, total: 0 };
    result.total++;
    result.correct += Number(a.correct);
    results[e.subjectId] = result;
    if (!a.correct) weakConceptIds.push(...e.conceptIds);
  }
  return { completedAt, results, weakConceptIds: [...new Set(weakConceptIds)] };
}
export function remediation(
  state: UserState,
  exercise: Exercise,
): {
  needed: boolean;
  conceptId: string;
  prerequisiteIds: string[];
  explanation: string;
  example: string;
  easier: Exercise | undefined;
} {
  const cid = exercise.conceptIds[0] ?? "",
    concept = conceptById[cid];
  const errors = state.attempts.filter(
    (a) => a.mode !== "diagnostic" && !a.correct && a.conceptIds.includes(cid),
  ).length;
  const prerequisiteIds = concept?.prerequisites ?? [];
  const easier =
    catalog.lessons
      .flatMap((l) => l.exercises)
      .find(
        (e) =>
          e.id !== exercise.id &&
          e.conceptIds.some((id) => prerequisiteIds.includes(id)) &&
          (e.type === "numeric" || e.type === "choice"),
      ) ??
    catalog.lessons
      .flatMap((l) => l.exercises)
      .find((e) => e.id !== exercise.id && e.conceptIds.includes(cid));
  return {
    needed: errors >= 2,
    conceptId: cid,
    prerequisiteIds,
    explanation: `Otra forma de pensarlo: ${concept?.example ?? exercise.explanation.correct}`,
    example: concept?.explanation ?? "",
    easier,
  };
}
export function streak(state: UserState, now = new Date()): number {
  let d = new Date(now);
  if (!state.studyDays[dayKey(d)]) d.setDate(d.getDate() - 1);
  let count = 0;
  while (state.studyDays[dayKey(d)]) {
    count++;
    d.setDate(d.getDate() - 1);
  }
  return count;
}
export function achievements(state: UserState) {
  const subjectTitles: Record<string, string> = {
    biology: "Explorador celular",
    chemistry: "Maestro de los enlaces",
    physics: "Explorador de fuerzas",
    math: "Analista de funciones",
  };
  return [
    ...Object.entries(subjectTitles).map(([id, title]) => ({
      id,
      title,
      description:
        "Demuestra dominio en al menos dos días y en dos conceptos del área.",
      earned:
        catalog.concepts.filter(
          (c) => c.subjectId === id && isMastered(state.mastery[c.id]),
        ).length >= 2,
    })),
    {
      id: "interdisciplinary",
      title: "Científico interdisciplinario",
      description:
        "Completa al menos una lección de cada ciencia y registra una sesión de laboratorio.",
      earned:
        catalog.subjects
          .slice(0, 4)
          .every((s) =>
            catalog.lessons.some(
              (l) =>
                l.subjectId === s.id && state.completedLessonIds.includes(l.id),
            ),
          ) && state.labs.length > 0,
    },
  ];
}
export function weeklyChallenge(state: UserState, now = new Date()) {
  const date = new Date(now);
  const weekday = (date.getDay() + 6) % 7;
  date.setDate(date.getDate() - weekday);
  const monday = dayKey(date);
  const studied = Object.keys(state.studyDays).filter(
    (d) => d >= monday && d <= dayKey(now),
  ).length;
  return { studied, goal: 3, complete: studied >= 3 };
}
