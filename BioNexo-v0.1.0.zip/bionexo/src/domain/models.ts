export type SubjectId =
  "biology" | "chemistry" | "physics" | "math" | "integrated";
export interface Subject {
  id: SubjectId;
  title: string;
  color: string;
  icon: string;
  subtitle: string;
}
export interface Course {
  id: string;
  subjectId: SubjectId;
  title: string;
  unitIds: string[];
}
export interface Prerequisite {
  conceptId: string;
  requires: string[];
}
export interface Concept {
  id: string;
  subjectId: SubjectId;
  title: string;
  english: string;
  prerequisites: string[];
  status: "implemented" | "planned";
  origin: "foundation" | "unab-aligned" | "mit-aligned" | "complementary";
  explanation: string;
  example: string;
  sourceIds: string[];
}
export interface Unit {
  id: string;
  subjectId: SubjectId;
  title: string;
  lessonIds: string[];
  prerequisites: string[];
}
export interface Explanation {
  correct: string;
  misconception: string;
}
interface ExerciseBase {
  id: string;
  subjectId: SubjectId;
  level: number;
  conceptIds: string[];
  prerequisites: string[];
  prompt: string;
  explanation: Explanation;
  hints: string[];
  sourceIds: string[];
}
export interface Option {
  id: string;
  text: string;
}
export type Exercise = ExerciseBase &
  (
    | {
        type: "choice" | "prediction" | "case";
        options: Option[];
        correct: string;
      }
    | {
        type: "chart";
        options: Option[];
        correct: string;
        chart: { x: number; y: number }[];
        xLabel: string;
        yLabel: string;
      }
    | { type: "diagram"; options: Option[]; correct: string; diagram: "cell" }
    | { type: "multi"; options: Option[]; correct: string[] }
    | { type: "text"; correct: string[] }
    | {
        type: "numeric";
        correct: number;
        tolerance: number;
        unit: string;
        acceptedUnits: Record<string, number>;
      }
    | { type: "order"; items: Option[]; correct: string[] }
    | {
        type: "match";
        left: Option[];
        right: Option[];
        correct: Record<string, string>;
      }
  );
export type Answer =
  string | string[] | Record<string, string> | { value: string; unit: string };
export interface Lesson {
  id: string;
  unitId: string;
  subjectId: SubjectId;
  title: string;
  minutes: number;
  objective: string;
  activation: string;
  conceptIds: string[];
  prerequisites: string[];
  explanation: string;
  example: string[];
  application: string;
  summary: string;
  exercises: Exercise[];
  sourceIds: string[];
  reviewStatus: "requires-human-review";
}
export interface Attempt {
  id: string;
  exerciseId: string;
  conceptIds: string[];
  answer: Answer;
  correct: boolean;
  at: string;
  mode: "lesson" | "review" | "diagnostic";
  hinted: boolean;
}
export interface MasteryRecord {
  conceptId: string;
  score: number;
  correct: number;
  wrong: number;
  streak: number;
  evidenceDays: string[];
}
export interface ReviewSchedule {
  conceptId: string;
  dueAt: string;
  intervalDays: number;
  step: number;
  lapses: number;
}
export interface Achievement {
  id: string;
  title: string;
  description: string;
  earned: boolean;
}
export interface LaboratorySession {
  id: string;
  at: string;
  hypothesis: string;
  observation: string;
  points: { ph: number; activity: number; enzyme: string }[];
}
export interface UserSettings {
  theme: "dark" | "light" | "system";
  reduceMotion: boolean;
  dailyGoal: number;
  name: string;
}
export interface DiagnosticResult {
  completedAt: string;
  results: Record<string, { correct: number; total: number }>;
  weakConceptIds: string[];
}
export interface UserState {
  version: 1;
  createdAt: string;
  onboarded: boolean;
  settings: UserSettings;
  attempts: Attempt[];
  mastery: Record<string, MasteryRecord>;
  reviews: Record<string, ReviewSchedule>;
  completedLessonIds: string[];
  rewardedExerciseIds: string[];
  xp: number;
  studyDays: Record<string, number>;
  labs: LaboratorySession[];
  diagnostic: DiagnosticResult | null;
}
export interface Source {
  id: string;
  title: string;
  url: string;
  note: string;
}
