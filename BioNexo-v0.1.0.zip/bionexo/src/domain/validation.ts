import type { Exercise, UserState } from "./models";
import { correctAnswer, grade } from "./answers";
import { catalog, exerciseById } from "../content";
export function validateCatalog(data: typeof catalog = catalog): string[] {
  const errors: string[] = [];
  const entities = [
    ...data.subjects,
    ...data.courses,
    ...data.units,
    ...data.concepts,
    ...data.lessons,
    ...data.lessons.flatMap((l) => l.exercises),
    ...data.diagnostic,
    ...data.sources,
  ];
  const ids = new Set<string>();
  for (const entity of entities) {
    if (!entity.id || ids.has(entity.id))
      errors.push(`ID ausente o duplicado: ${entity.id}`);
    ids.add(entity.id);
  }
  const concepts = new Map(data.concepts.map((c) => [c.id, c]));
  const sources = new Set(data.sources.map((s) => s.id));
  const visited = new Set<string>(),
    active = new Set<string>();
  function visit(id: string) {
    if (active.has(id)) {
      errors.push(`Ciclo: ${id}`);
      return;
    }
    if (visited.has(id)) return;
    active.add(id);
    const c = concepts.get(id);
    if (!c) errors.push(`Concepto inexistente: ${id}`);
    else c.prerequisites.forEach(visit);
    active.delete(id);
    visited.add(id);
  }
  data.concepts.forEach((c) => visit(c.id));
  const checkRefs = (item: {
    id: string;
    sourceIds: string[];
    prerequisites?: string[];
    conceptIds?: string[];
  }) => {
    for (const id of [
      ...(item.prerequisites ?? []),
      ...(item.conceptIds ?? []),
    ])
      if (!concepts.has(id))
        errors.push(`${item.id}: prerrequisito/concepto inexistente ${id}`);
    if (
      !item.sourceIds?.length ||
      item.sourceIds.some((id) => !sources.has(id))
    )
      errors.push(`${item.id}: fuente inválida`);
  };
  for (const c of data.concepts) {
    checkRefs(c);
    if (!c.title || !c.explanation || !c.english)
      errors.push(`${c.id}: datos obligatorios`);
  }
  const exercises = [
    ...data.lessons.flatMap((l) => l.exercises),
    ...data.diagnostic,
  ];
  for (const lesson of data.lessons) {
    checkRefs(lesson);
    if (
      !lesson.objective ||
      !lesson.explanation ||
      !lesson.activation ||
      !lesson.example.length ||
      !lesson.application ||
      !lesson.summary ||
      lesson.exercises.length < 6
    )
      errors.push(`${lesson.id}: lección incompleta`);
    if (
      !data.units.some(
        (u) => u.id === lesson.unitId && u.lessonIds.includes(lesson.id),
      )
    )
      errors.push(`${lesson.id}: unidad inválida`);
  }
  for (const unit of data.units) {
    if (
      unit.lessonIds.length < 2 ||
      unit.lessonIds.some(
        (id) => !data.lessons.some((l) => l.id === id && l.unitId === unit.id),
      )
    )
      errors.push(`${unit.id}: referencias de lección inválidas`);
    for (const id of unit.prerequisites)
      if (!concepts.has(id))
        errors.push(`${unit.id}: prerrequisito inexistente`);
  }
  for (const course of data.courses)
    if (
      course.unitIds.some(
        (id) =>
          !data.units.some(
            (u) => u.id === id && u.subjectId === course.subjectId,
          ),
      )
    )
      errors.push(`${course.id}: unidad inexistente`);
  for (const exercise of exercises) {
    checkRefs(exercise);
    if (
      !exercise.prompt ||
      !exercise.explanation?.correct ||
      !exercise.explanation?.misconception ||
      !exercise.hints?.length ||
      !exercise.conceptIds.length ||
      !data.subjects.some((s) => s.id === exercise.subjectId)
    )
      errors.push(`${exercise.id}: datos obligatorios`);
    if ("options" in exercise) {
      const options = exercise.options.map((o) => o.id);
      if (
        new Set(options).size !== options.length ||
        options.length < 2 ||
        exercise.options.some((o) => !o.text)
      )
        errors.push(`${exercise.id}: opciones inválidas`);
      const answers = Array.isArray(exercise.correct)
        ? exercise.correct
        : [exercise.correct];
      if (!answers.length || answers.some((a) => !options.includes(a)))
        errors.push(`${exercise.id}: solución fuera de opciones`);
    }
    if (
      exercise.type === "numeric" &&
      (!Number.isFinite(exercise.correct) ||
        !Number.isFinite(exercise.tolerance) ||
        exercise.tolerance < 0 ||
        exercise.acceptedUnits[exercise.unit] !== 1 ||
        Object.values(exercise.acceptedUnits).some(
          (f) => !Number.isFinite(f) || f <= 0,
        ))
    )
      errors.push(`${exercise.id}: fórmula/unidad inválida`);
    if (
      exercise.type === "chart" &&
      (exercise.chart.length < 2 ||
        exercise.chart.some(
          (p) => !Number.isFinite(p.x) || !Number.isFinite(p.y),
        ) ||
        !exercise.xLabel ||
        !exercise.yLabel)
    )
      errors.push(`${exercise.id}: gráfico inválido`);
    if (exercise.type === "text" && !exercise.correct.length)
      errors.push(`${exercise.id}: sin solución`);
    if (
      exercise.type === "order" &&
      (new Set(exercise.correct).size !== exercise.items.length ||
        exercise.correct.length !== exercise.items.length ||
        exercise.items.some((i) => !exercise.correct.includes(i.id)))
    )
      errors.push(`${exercise.id}: orden inválido`);
    if (
      exercise.type === "match" &&
      (Object.keys(exercise.correct).length !== exercise.left.length ||
        new Set(Object.values(exercise.correct)).size !==
          exercise.right.length ||
        exercise.left.some(
          (l) => !exercise.right.some((r) => r.id === exercise.correct[l.id]),
        ))
    )
      errors.push(`${exercise.id}: parejas inválidas`);
    try {
      if (!grade(exercise, correctAnswer(exercise)))
        errors.push(`${exercise.id}: solución no validable`);
    } catch {
      errors.push(`${exercise.id}: solución inválida`);
    }
  }
  return errors;
}
function object(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function finite(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}
function strings(value: unknown): value is string[] {
  return (
    Array.isArray(value) &&
    value.every((x) => typeof x === "string") &&
    new Set(value).size === value.length
  );
}
function date(value: unknown): value is string {
  return typeof value === "string" && Number.isFinite(Date.parse(value));
}
/** Strict known-version backup, bounded size, no dynamic code or SQL from imports. */
export function parseBackup(input: string): UserState {
  if (input.length > 10_000_000) throw new Error("El respaldo supera 10 MB.");
  const raw: unknown = JSON.parse(input);
  if (!object(raw) || raw.version !== 1)
    throw new Error("Versión de respaldo no compatible.");
  const fail = () => {
    throw new Error(
      "El respaldo tiene datos inválidos o pertenece a otro catálogo.",
    );
  };
  if (
    !date(raw.createdAt) ||
    typeof raw.onboarded !== "boolean" ||
    !object(raw.settings)
  )
    return fail();
  const s = raw.settings;
  if (
    typeof s.name !== "string" ||
    s.name.length > 60 ||
    !["dark", "light", "system"].includes(String(s.theme)) ||
    typeof s.reduceMotion !== "boolean" ||
    !Number.isInteger(s.dailyGoal) ||
    !finite(s.dailyGoal) ||
    s.dailyGoal < 1 ||
    s.dailyGoal > 50
  )
    return fail();
  if (
    !strings(raw.completedLessonIds) ||
    raw.completedLessonIds.some(
      (id) => !catalog.lessons.some((l) => l.id === id),
    ) ||
    !strings(raw.rewardedExerciseIds) ||
    raw.rewardedExerciseIds.some(
      (id) => !exerciseById[id] || id.startsWith("diagnostic-"),
    )
  )
    return fail();
  if (
    !finite(raw.xp) ||
    raw.xp !==
      raw.rewardedExerciseIds.length * 10 + raw.completedLessonIds.length * 20
  )
    return fail();
  if (
    !Array.isArray(raw.attempts) ||
    !Array.isArray(raw.labs) ||
    !object(raw.mastery) ||
    !object(raw.reviews) ||
    !object(raw.studyDays)
  )
    return fail();
  const seen = new Set<string>();
  for (const a of raw.attempts) {
    if (
      !object(a) ||
      typeof a.id !== "string" ||
      seen.has(a.id) ||
      typeof a.exerciseId !== "string" ||
      !exerciseById[a.exerciseId] ||
      !date(a.at) ||
      typeof a.correct !== "boolean" ||
      typeof a.hinted !== "boolean" ||
      !["lesson", "review", "diagnostic"].includes(String(a.mode)) ||
      !strings(a.conceptIds)
    )
      return fail();
    const e = exerciseById[a.exerciseId]!;
    if (
      a.conceptIds.join("|") !== e.conceptIds.join("|") ||
      grade(e, a.answer) !== a.correct
    )
      return fail();
    seen.add(a.id);
  }
  for (const [cid, m] of Object.entries(raw.mastery))
    if (
      !object(m) ||
      m.conceptId !== cid ||
      !catalog.concepts.some((c) => c.id === cid) ||
      !finite(m.score) ||
      m.score < 0 ||
      m.score > 1 ||
      ![m.correct, m.wrong, m.streak].every(
        (x) => finite(x) && Number.isInteger(x) && x >= 0,
      ) ||
      !strings(m.evidenceDays) ||
      m.evidenceDays.some((x) => !/^\d{4}-\d{2}-\d{2}$/.test(x))
    )
      return fail();
  for (const [cid, r] of Object.entries(raw.reviews))
    if (
      !object(r) ||
      r.conceptId !== cid ||
      !catalog.concepts.some((c) => c.id === cid) ||
      !date(r.dueAt) ||
      !finite(r.intervalDays) ||
      r.intervalDays <= 0 ||
      !Number.isInteger(r.step) ||
      !finite(r.step) ||
      r.step < 0 ||
      r.step > 5 ||
      !Number.isInteger(r.lapses) ||
      !finite(r.lapses) ||
      r.lapses < 0
    )
      return fail();
  for (const [day, count] of Object.entries(raw.studyDays))
    if (
      !/^\d{4}-\d{2}-\d{2}$/.test(day) ||
      !finite(count) ||
      !Number.isInteger(count) ||
      count < 1
    )
      return fail();
  const labIds = new Set<string>();
  for (const l of raw.labs) {
    if (
      !object(l) ||
      typeof l.id !== "string" ||
      labIds.has(l.id) ||
      !date(l.at) ||
      typeof l.hypothesis !== "string" ||
      typeof l.observation !== "string" ||
      !Array.isArray(l.points) ||
      !l.points.length ||
      l.points.some(
        (p) =>
          !object(p) ||
          !finite(p.ph) ||
          p.ph < 0 ||
          p.ph > 14 ||
          !finite(p.activity) ||
          p.activity < 0 ||
          p.activity > 100 ||
          !["neutral", "acid"].includes(String(p.enzyme)),
      )
    )
      return fail();
    labIds.add(l.id);
  }
  if (raw.diagnostic !== null) {
    const d = raw.diagnostic;
    if (
      !object(d) ||
      !date(d.completedAt) ||
      !strings(d.weakConceptIds) ||
      d.weakConceptIds.some(
        (id) => !catalog.concepts.some((c) => c.id === id),
      ) ||
      !object(d.results)
    )
      return fail();
    for (const [subject, r] of Object.entries(d.results))
      if (
        !catalog.subjects.some((s) => s.id === subject) ||
        !object(r) ||
        !finite(r.correct) ||
        !finite(r.total) ||
        r.correct < 0 ||
        r.correct > r.total ||
        !Number.isInteger(r.correct) ||
        !Number.isInteger(r.total) ||
        r.total < 1
      )
        return fail();
  }
  return raw as unknown as UserState;
}
