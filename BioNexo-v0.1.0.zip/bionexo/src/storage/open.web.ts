import type { UserState } from "../domain/models";
import { initialState } from "../domain/learning";
import { parseBackup } from "../domain/validation";
import type { ProgressRepository } from "./repository";
/** Web preview adapter. Native Android/iOS always use SQLite. Never silently fallback on native. */
export async function openRepository(): Promise<ProgressRepository> {
  const key = "bionexo-state-v1";
  let tail: Promise<unknown> = Promise.resolve();
  if (!localStorage.getItem(key))
    localStorage.setItem(key, JSON.stringify(initialState()));
  const read = () => parseBackup(localStorage.getItem(key) ?? "");
  const update = (change: (s: UserState) => UserState) => {
    const op = tail.then(() => {
      const next = change(read());
      const json = JSON.stringify(next);
      parseBackup(json);
      localStorage.setItem(key, json);
      return next;
    });
    tail = op.catch(() => undefined);
    return op;
  };
  return {
    load: async () => {
      await tail;
      return read();
    },
    update,
    restore: (json) => {
      const next = parseBackup(json);
      return update(() => next);
    },
    export: async () => {
      await tail;
      return JSON.stringify(read(), null, 2);
    },
  };
}
