import type { UserState } from "../domain/models";
import { initialState } from "../domain/learning";
import { parseBackup } from "../domain/validation";
export interface SqlPort {
  execAsync(sql: string): Promise<unknown>;
  runAsync(
    sql: string,
    ...params: (string | number | null)[]
  ): Promise<unknown>;
  getFirstAsync<T>(
    sql: string,
    ...params: (string | number | null)[]
  ): Promise<T | null>;
}
export interface ProgressRepository {
  load(): Promise<UserState>;
  update(change: (state: UserState) => UserState): Promise<UserState>;
  restore(json: string): Promise<UserState>;
  export(): Promise<string>;
}
export const MIGRATIONS = [
  "CREATE TABLE IF NOT EXISTS user_state (id INTEGER PRIMARY KEY CHECK (id = 1), payload TEXT NOT NULL);",
  "CREATE TABLE IF NOT EXISTS repository_metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL); INSERT OR IGNORE INTO repository_metadata(key,value) VALUES ('format','bionexo-v1');",
];
export class SQLiteRepository implements ProgressRepository {
  private tail: Promise<unknown> = Promise.resolve();
  private ready: Promise<void>;
  constructor(private db: SqlPort) {
    this.ready = this.migrate();
  }
  private async migrate() {
    await this.db.execAsync("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;");
    const row = await this.db.getFirstAsync<{ user_version: number }>(
      "PRAGMA user_version;",
    );
    const version = row?.user_version ?? 0;
    if (version > MIGRATIONS.length)
      throw new Error(
        "La base de datos pertenece a una versión más reciente de BioNexo.",
      );
    for (let i = version; i < MIGRATIONS.length; i++) {
      await this.db.execAsync("BEGIN IMMEDIATE;");
      try {
        await this.db.execAsync(MIGRATIONS[i]!);
        await this.db.execAsync(`PRAGMA user_version=${i + 1}; COMMIT;`);
      } catch (e) {
        await this.db.execAsync("ROLLBACK;");
        throw e;
      }
    }
    await this.db.runAsync(
      "INSERT OR IGNORE INTO user_state(id,payload) VALUES (1,?);",
      JSON.stringify(initialState()),
    );
  }
  async load() {
    await this.ready;
    await this.tail;
    return this.read();
  }
  private async read() {
    const row = await this.db.getFirstAsync<{ payload: string }>(
      "SELECT payload FROM user_state WHERE id=1;",
    );
    if (!row) throw new Error("No se encontró el perfil local.");
    return parseBackup(row.payload);
  }
  update(change: (state: UserState) => UserState): Promise<UserState> {
    const operation = this.tail.then(async () => {
      await this.ready;
      await this.db.execAsync("BEGIN IMMEDIATE;");
      try {
        const state = change(await this.read());
        parseBackup(JSON.stringify(state));
        await this.db.runAsync(
          "UPDATE user_state SET payload=? WHERE id=1;",
          JSON.stringify(state),
        );
        await this.db.execAsync("COMMIT;");
        return state;
      } catch (e) {
        await this.db.execAsync("ROLLBACK;");
        throw e;
      }
    });
    this.tail = operation.catch(() => undefined);
    return operation;
  }
  restore(json: string) {
    const validated = parseBackup(json);
    return this.update(() => validated);
  }
  async export() {
    return JSON.stringify(await this.load(), null, 2);
  }
}
