import React, { useMemo, useRef, useState } from "react";
import { AccessibilityInfo, Pressable, View } from "react-native";
import { router } from "expo-router";
import Svg, { Ellipse, Circle, Line, Text as SvgText } from "react-native-svg";
import type { Answer, Exercise } from "../domain/models";
import { grade, solution } from "../domain/answers";
import { remediation } from "../domain/learning";
import { conceptById } from "../content";
import { useApp } from "./provider";
import { Button, Card, Chip, Field, Heading, Label, Plot } from "./components";
export function shuffle<T>(items: readonly T[], seed: string): T[] {
  let n = [...seed].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    n = (Math.imul(n, 1664525) + 1013904223) >>> 0;
    const j = n % (i + 1);
    [result[i], result[j]] = [result[j]!, result[i]!];
  }
  return result;
}
export function ExerciseCard({
  exercise,
  onSubmit,
  onContinue,
  canRemediate = true,
}: {
  exercise: Exercise;
  onSubmit: (
    e: Exercise,
    answer: Answer,
    hinted: boolean,
    attemptNo: string,
  ) => Promise<void>;
  onContinue: () => void;
  canRemediate?: boolean;
}) {
  const { theme, state } = useApp();
  const [answer, setAnswer] = useState<Answer>(
    exercise.type === "numeric"
      ? { value: "", unit: exercise.unit }
      : exercise.type === "match"
        ? {}
        : exercise.type === "multi" || exercise.type === "order"
          ? []
          : "",
  );
  const [feedback, setFeedback] = useState<boolean | null>(null),
    [busy, setBusy] = useState(false),
    [hintCount, setHintCount] = useState(0),
    [attemptNo, setAttemptNo] = useState(0),
    [bridge, setBridge] = useState(false),
    [bridgeDone, setBridgeDone] = useState(false),
    [error, setError] = useState("");
  const lock = useRef(false);
  const options = useMemo(
    () =>
      shuffle(
        "options" in exercise
          ? exercise.options
          : exercise.type === "order"
            ? exercise.items
            : [],
        exercise.id,
      ),
    [exercise],
  );
  const right = useMemo(
    () =>
      shuffle(
        exercise.type === "match" ? exercise.right : [],
        exercise.id + "right",
      ),
    [exercise],
  );
  const remedy = state ? remediation(state, exercise) : null;
  const isArray = Array.isArray(answer);
  const map =
    typeof answer === "object" && !isArray
      ? (answer as Record<string, string>)
      : {};
  const ready =
    typeof answer === "string"
      ? answer.trim().length > 0
      : isArray
        ? answer.length > 0
        : exercise.type === "numeric"
          ? !!map.value?.trim()
          : exercise.type === "match"
            ? Object.keys(map).length === exercise.left.length
            : false;
  const choose = (id: string) => {
    if (feedback !== null) return;
    if (exercise.type === "multi") {
      const values = isArray ? answer : [];
      setAnswer(
        values.includes(id) ? values.filter((x) => x !== id) : [...values, id],
      );
    } else if (exercise.type === "order") {
      const values = isArray ? answer : [];
      if (!values.includes(id)) setAnswer([...values, id]);
    } else setAnswer(id);
  };
  async function submit() {
    if (lock.current || !ready) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      await onSubmit(
        exercise,
        answer,
        hintCount > 0 || attemptNo > 0,
        String(attemptNo),
      );
      const result = grade(exercise, answer);
      setFeedback(result);
      AccessibilityInfo.announceForAccessibility(
        result
          ? "Respuesta correcta. Lee la explicación."
          : "Revisa la respuesta y su explicación.",
      );
    } catch {
      setError("No se guardó la respuesta. Inténtalo de nuevo.");
    } finally {
      setBusy(false);
      lock.current = false;
    }
  }
  return (
    <View style={{ gap: 16 }}>
      <Chip>
        {
          (
            {
              choice: "ELEGIR",
              multi: "SELECCIÓN MÚLTIPLE",
              text: "COMPLETAR",
              numeric: "CALCULAR",
              match: "CONECTAR",
              order: "ORDENAR",
              chart: "INTERPRETAR",
              diagram: "IDENTIFICAR",
              prediction: "PREDECIR",
              case: "ANALIZAR",
            } as const
          )[exercise.type]
        }
      </Chip>
      <Heading small>{exercise.prompt}</Heading>
      {exercise.type === "chart" && (
        <Card>
          <Plot
            points={exercise.chart}
            xLabel={exercise.xLabel}
            yLabel={exercise.yLabel}
          />
          <Label muted style={{ fontSize: 13 }}>
            Datos accesibles ·{" "}
            {exercise.chart.map((p) => `(${p.x}; ${p.y})`).join(" · ")}
          </Label>
        </Card>
      )}
      {exercise.type === "diagram" && (
        <Svg
          width="100%"
          height={190}
          viewBox="0 0 320 190"
          accessibilityLabel="Esquema: A, región circular central; B, espacio interior circundante; C, límite externo."
        >
          <Ellipse
            cx="140"
            cy="90"
            rx="100"
            ry="65"
            fill={theme.raised}
            stroke={theme.accent}
            strokeWidth="2"
          />
          <Circle
            cx="130"
            cy="85"
            r="25"
            fill={theme.surface}
            stroke={theme.bg === "#09151C" ? "#C3A0FF" : "#8051B0"}
            strokeWidth="2"
          />
          <Line x1="150" y1="75" x2="230" y2="25" stroke={theme.muted} />
          <Line x1="182" y1="113" x2="252" y2="129" stroke={theme.muted} />
          <Line x1="221" y1="51" x2="277" y2="60" stroke={theme.muted} />
          <SvgText x="230" y="20" fill={theme.text} fontSize="13">
            A
          </SvgText>
          <SvgText x="230" y="150" fill={theme.text} fontSize="13">
            B
          </SvgText>
          <SvgText x="235" y="80" fill={theme.text} fontSize="13">
            C
          </SvgText>
        </Svg>
      )}
      {exercise.type === "numeric" ? (
        <>
          <Field
            testID="numeric-answer"
            editable={feedback === null && !busy}
            label="Respuesta numérica"
            value={map.value ?? ""}
            onChangeText={(value) =>
              setAnswer({ value, unit: map.unit ?? exercise.unit })
            }
            placeholder="Ej.: 0,5 · 1/2 · 5e-1"
          />
          <Label muted style={{ fontSize: 13 }}>
            Unidad de referencia: {exercise.unit || "sin unidad"}. Tolerancia: ±
            {exercise.tolerance}. Selecciona la unidad que usas.
          </Label>
          <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
            {Object.keys(exercise.acceptedUnits).map((unit) => (
              <Button
                key={unit}
                secondary={map.unit !== unit}
                disabled={feedback !== null}
                onPress={() => setAnswer({ value: map.value ?? "", unit })}
              >
                {unit || "Sin unidad"}
              </Button>
            ))}
          </View>
        </>
      ) : exercise.type === "text" ? (
        <Field
          label="Completa con el término"
          editable={feedback === null && !busy}
          value={typeof answer === "string" ? answer : ""}
          onChangeText={(value) => {
            if (feedback === null) setAnswer(value);
          }}
        />
      ) : exercise.type === "match" ? (
        <View style={{ gap: 14 }}>
          {exercise.left.map((left) => (
            <Card key={left.id}>
              <Label style={{ fontWeight: "700" }}>{left.text}</Label>
              <View style={{ gap: 8 }}>
                {right.map((r) => (
                  <Button
                    key={r.id}
                    secondary={map[left.id] !== r.id}
                    disabled={feedback !== null}
                    onPress={() => setAnswer({ ...map, [left.id]: r.id })}
                    label={`${left.text}: ${r.text}`}
                  >
                    {r.text}
                  </Button>
                ))}
              </View>
            </Card>
          ))}
        </View>
      ) : (
        <View style={{ gap: 10 }}>
          {options.map((option) => {
            const selected = isArray
              ? answer.includes(option.id)
              : answer === option.id;
            return (
              <Pressable
                accessibilityRole={
                  exercise.type === "multi"
                    ? "checkbox"
                    : exercise.type === "order"
                      ? "button"
                      : "radio"
                }
                accessibilityState={{
                  checked: selected,
                  disabled: feedback !== null,
                }}
                disabled={feedback !== null}
                key={option.id}
                onPress={() => choose(option.id)}
                style={({ pressed }) => ({
                  borderWidth: 1.5,
                  borderColor: selected ? theme.accent : theme.border,
                  backgroundColor: selected ? theme.raised : theme.surface,
                  padding: 17,
                  borderRadius: 16,
                  minHeight: 56,
                  opacity: pressed ? 0.8 : 1,
                  flexDirection: "row",
                  gap: 14,
                  alignItems: "center",
                })}
              >
                <View
                  style={{
                    borderRadius: exercise.type === "multi" ? 5 : 15,
                    borderWidth: 1,
                    borderColor: selected ? theme.accent : theme.muted,
                    width: 26,
                    height: 26,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Label style={{ fontSize: 12, color: theme.accent }}>
                    {exercise.type === "order" && isArray && selected
                      ? answer.indexOf(option.id) + 1
                      : selected
                        ? "✓"
                        : ""}
                  </Label>
                </View>
                <Label style={{ flex: 1 }}>{option.text}</Label>
              </Pressable>
            );
          })}
          {exercise.type === "order" && (
            <>
              <Label muted>
                Tu secuencia:{" "}
                {isArray && answer.length
                  ? answer
                      .map(
                        (id) => exercise.items.find((i) => i.id === id)?.text,
                      )
                      .join(" → ")
                  : "Toca los pasos en el orden que propones."}
              </Label>
              <Button
                secondary
                disabled={feedback !== null}
                onPress={() => setAnswer([])}
              >
                Vaciar secuencia
              </Button>
            </>
          )}
        </View>
      )}
      {feedback === null && (
        <>
          <Button
            secondary
            disabled={hintCount >= exercise.hints.length}
            onPress={() => setHintCount((n) => n + 1)}
          >
            Ver pista {Math.min(hintCount + 1, exercise.hints.length)} de{" "}
            {exercise.hints.length}
          </Button>
          {exercise.hints.slice(0, hintCount).map((hint, i) => (
            <Label key={i} muted style={{ fontSize: 14 }}>
              {hint}
            </Label>
          ))}
          <Button
            testID="check-answer"
            disabled={!ready}
            busy={busy}
            onPress={() => void submit()}
          >
            Comprobar respuesta
          </Button>
        </>
      )}
      {!!error && <Label style={{ color: theme.danger }}>{error}</Label>}
      {feedback !== null && (
        <Card style={{ borderColor: feedback ? theme.accent : theme.warm }}>
          <Heading small>
            {feedback ? "Bien razonado" : "Una oportunidad para conectar"}
          </Heading>
          {!feedback && (
            <Label style={{ fontWeight: "700" }}>
              Solución: {solution(exercise)}
            </Label>
          )}
          <Label>{exercise.explanation.correct}</Label>
          {!feedback && (
            <Label muted>{exercise.explanation.misconception}</Label>
          )}
          {canRemediate && !feedback && remedy?.needed && (
            <>
              <Label style={{ fontWeight: "700" }}>
                Construyamos el puente
              </Label>
              <Label>{remedy.explanation}</Label>
              <Label muted>{remedy.example}</Label>
              {remedy.prerequisiteIds.map((id) => (
                <Label key={id} muted>
                  Base relacionada: {conceptById[id]?.title}
                </Label>
              ))}
              {remedy.easier && !bridge && !bridgeDone && (
                <Button secondary onPress={() => setBridge(true)}>
                  Resolver un paso más sencillo
                </Button>
              )}
              {bridge && remedy.easier && (
                <ExerciseCard
                  key={remedy.easier.id}
                  exercise={remedy.easier}
                  onSubmit={(e, a, h, n) =>
                    onSubmit(e, a, h, `bridge-${attemptNo}-${n}`)
                  }
                  canRemediate={false}
                  onContinue={() => {
                    setBridge(false);
                    setBridgeDone(true);
                  }}
                />
              )}
              {bridgeDone && (
                <Button
                  secondary
                  onPress={() => {
                    setFeedback(null);
                    setAttemptNo((n) => n + 1);
                    setAnswer(
                      exercise.type === "numeric"
                        ? { value: "", unit: exercise.unit }
                        : exercise.type === "match"
                          ? {}
                          : exercise.type === "multi" ||
                              exercise.type === "order"
                            ? []
                            : "",
                    );
                  }}
                >
                  Volver al problema original
                </Button>
              )}
            </>
          )}
          {!bridge && (
            <Button testID="continue-question" onPress={onContinue}>
              Continuar
            </Button>
          )}
        </Card>
      )}
    </View>
  );
}
