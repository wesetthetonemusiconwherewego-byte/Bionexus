import React, { useRef, useState } from "react";
import { Linking, Switch, View, useWindowDimensions } from "react-native";
import Slider from "@react-native-community/slider";
import { router } from "expo-router";
import { catalog, conceptById } from "../content";
import {
  achievements,
  dayKey,
  isMastered,
  missingPrerequisites,
  recommendations,
  reviewQueue,
  streak,
  weeklyChallenge,
} from "../domain/learning";
import { ENZYMES, enzymeActivity, enzymeCurve } from "../domain/laboratory";
import type { LaboratorySession, SubjectId } from "../domain/models";
import { parseBackup } from "../domain/validation";
import { exportProgress, importProgress } from "../storage/transfer";
import { useApp } from "./provider";
import {
  Button,
  Card,
  Chip,
  Eyebrow,
  Field,
  Heading,
  Icon,
  Label,
  Meter,
  Plot,
  ScienceArt,
} from "./components";
const sectionRow = {
  flexDirection: "row" as const,
  alignItems: "center" as const,
  justifyContent: "space-between" as const,
  gap: 12,
};
export function Home() {
  const { state, theme } = useApp();
  const { width } = useWindowDimensions();
  if (!state) return null;
  const suggested = recommendations(state)[0] ?? catalog.lessons[0]!;
  const today = state.studyDays[dayKey(new Date())] ?? 0;
  const due = Object.values(state.reviews).filter(
    (r) => new Date(r.dueAt) <= new Date(),
  ).length;
  return (
    <View style={{ gap: 22 }}>
      <View style={sectionRow}>
        <View>
          <Eyebrow>TU PRÓXIMO DESCUBRIMIENTO</Eyebrow>
          <Heading>Hola, {state.settings.name}.</Heading>
          <Label muted>Cada idea abre una nueva conexión.</Label>
        </View>
      </View>
      <Card style={{ padding: 24, borderColor: theme.accent }}>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 12,
          }}
        >
          <View style={{ flex: 1, minWidth: 180, gap: 12 }}>
            <Chip>EXPEDICIÓN · FUNDAMENTOS</Chip>
            <Heading>La ciencia empieza{"\n"}con una pregunta.</Heading>
            <Label muted>
              Un pequeño paso hoy. Más herramientas para investigar mañana.
            </Label>
            <Button onPress={() => router.push(`/lesson/${suggested.id}`)}>
              Continuar explorando →
            </Button>
          </View>
          {width >= 600 && <ScienceArt compact />}
        </View>
      </Card>
      <View style={{ flexDirection: "row", gap: 12, flexWrap: "wrap" }}>
        {[
          [String(state.xp), "XP acumulado"],
          [`${streak(state)} días`, "Racha de estudio"],
          [String(due), "Conceptos por repasar"],
        ].map(([n, label]) => (
          <Card key={label} style={{ flex: 1, minWidth: 100, padding: 16 }}>
            <Label style={{ fontSize: 25, lineHeight: 32, fontWeight: "700" }}>
              {n}
            </Label>
            <Label muted style={{ fontSize: 12, lineHeight: 18 }}>
              {label}
            </Label>
          </Card>
        ))}
      </View>
      <Card>
        <View style={sectionRow}>
          <Heading small>Tu objetivo de hoy</Heading>
          <Chip>
            {Math.min(today, state.settings.dailyGoal)} /{" "}
            {state.settings.dailyGoal}
          </Chip>
        </View>
        <Meter
          value={today / state.settings.dailyGoal}
          label="Objetivo diario"
        />
        <Label muted style={{ fontSize: 14 }}>
          {today >= state.settings.dailyGoal
            ? "Objetivo logrado. Puedes seguir por curiosidad."
            : "Responde ejercicios, investiga tus errores y construye el hábito."}
        </Label>
      </Card>
      <View style={sectionRow}>
        <Heading small>Tu siguiente conexión</Heading>
        <Icon name="route" />
      </View>
      <Card>
        <Eyebrow>
          {catalog.subjects
            .find((s) => s.id === suggested.subjectId)
            ?.title.toUpperCase()}
        </Eyebrow>
        <Heading small>{suggested.title}</Heading>
        <Label muted>{suggested.objective}</Label>
        <View style={sectionRow}>
          <Chip>{suggested.minutes} MIN · 6 RETOS</Chip>
          <Button
            secondary
            onPress={() => router.push(`/lesson/${suggested.id}`)}
          >
            Abrir lección
          </Button>
        </View>
      </Card>
      {!state.diagnostic && (
        <Card>
          <Heading small>Encuentra tu punto de partida</Heading>
          <Label muted>
            Un diagnóstico breve puede orientar la ruta. Es opcional y no mide
            preparación universitaria.
          </Label>
          <Button secondary onPress={() => router.push("/diagnostic")}>
            Hacer diagnóstico
          </Button>
        </Card>
      )}
      <Card>
        <Eyebrow>APRENDER ≠ ACUMULAR PUNTOS</Eyebrow>
        <Label muted>
          El XP reconoce la práctica. El dominio requiere respuestas correctas
          sin ayuda y evidencia en distintos días.
        </Label>
      </Card>
    </View>
  );
}
export function Learn() {
  const { state, theme } = useApp();
  const [selected, setSelected] = useState<SubjectId>("math");
  if (!state) return null;
  const subject = catalog.subjects.find((s) => s.id === selected)!;
  return (
    <View style={{ gap: 22 }}>
      <Eyebrow>EXPLORA LAS CONEXIONES</Eyebrow>
      <Heading>Tu mapa científico</Heading>
      <Label muted>
        Avanza por las bases o abre una explicación por curiosidad.
      </Label>
      <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
        {catalog.subjects.map((s) => (
          <Button
            key={s.id}
            secondary={selected !== s.id}
            onPress={() => setSelected(s.id)}
          >
            {s.title}
          </Button>
        ))}
      </View>
      <Card>
        <View style={sectionRow}>
          <Icon name={subject.icon} size={32} />
          <Chip color={theme.accent}>
            {selected === "integrated" ? "RUTA EN DESARROLLO" : "RUTA ACTIVA"}
          </Chip>
        </View>
        <Heading small>{subject.title}</Heading>
        <Label muted>{subject.subtitle}</Label>
      </Card>
      {catalog.units
        .filter((u) => u.subjectId === selected)
        .map((u, i) => (
          <View key={u.id} style={{ gap: 12 }}>
            <View style={{ ...sectionRow, justifyContent: "flex-start" }}>
              <View
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 18,
                  backgroundColor: theme.raised,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Label>{i + 1}</Label>
              </View>
              <Heading small>{u.title}</Heading>
            </View>
            {catalog.lessons
              .filter((l) => l.unitId === u.id)
              .map((l) => {
                const done = state.completedLessonIds.includes(l.id);
                const missing = missingPrerequisites(state, l);
                return (
                  <Card
                    key={l.id}
                    style={{
                      marginLeft: 17,
                      borderLeftWidth: 3,
                      borderLeftColor: done ? theme.accent : theme.border,
                    }}
                  >
                    <View style={sectionRow}>
                      <Chip>
                        {done
                          ? "COMPLETADA"
                          : missing.length
                            ? "BASES RECOMENDADAS"
                            : "LISTA PARA EXPLORAR"}
                      </Chip>
                      <Label muted style={{ fontSize: 12 }}>
                        {l.minutes} min
                      </Label>
                    </View>
                    <Heading small>{l.title}</Heading>
                    <Label muted style={{ fontSize: 14 }}>
                      {l.objective}
                    </Label>
                    <Button
                      secondary
                      onPress={() => router.push(`/lesson/${l.id}`)}
                    >
                      {done
                        ? "Volver a practicar"
                        : missing.length
                          ? "Explorar explicación"
                          : "Comenzar lección"}
                    </Button>
                  </Card>
                );
              })}
          </View>
        ))}
      {selected === "integrated" && (
        <Card>
          <Heading small>Primer puente: enzimas y pH</Heading>
          <Label muted>
            El laboratorio didáctico está disponible. Las lecciones de esta ruta
            todavía requieren desarrollo; no cuentan como contenido terminado.
          </Label>
          <Button onPress={() => router.replace("/?tab=lab")}>
            Explorar el laboratorio
          </Button>
        </Card>
      )}
      <Heading small>Horizonte de la ruta</Heading>
      {catalog.concepts
        .filter((c) => c.subjectId === selected && c.status === "planned")
        .map((c) => (
          <Card key={c.id}>
            <Chip>PLANIFICADO</Chip>
            <Label style={{ fontWeight: "700" }}>{c.title}</Label>
            <Label muted style={{ fontSize: 13 }}>
              Bases:{" "}
              {c.prerequisites.map((id) => conceptById[id]?.title).join(" · ")}
            </Label>
          </Card>
        ))}
    </View>
  );
}
export function Practice() {
  const { state } = useApp();
  if (!state) return null;
  const queue = reviewQueue(state);
  const errors = [
    ...new Set(
      state.attempts
        .filter((a) => !a.correct && a.mode !== "diagnostic")
        .map((a) => a.exerciseId),
    ),
  ];
  const next = Object.values(state.reviews).sort((a, b) =>
    a.dueAt.localeCompare(b.dueAt),
  )[0];
  return (
    <View style={{ gap: 20 }}>
      <Eyebrow>RECORDAR · CONECTAR · APLICAR</Eyebrow>
      <Heading>Fortalece tus bases</Heading>
      <Label muted>Los errores son información sobre el siguiente paso.</Label>
      <Card>
        <Icon name="practice" size={32} />
        <Heading small>
          {queue.length ? "Tu repaso está listo" : "Todo al día"}
        </Heading>
        <Label muted>
          {queue.length
            ? `${queue.length} ejercicios intercalados de los conceptos pendientes.`
            : next
              ? `Próximo repaso sugerido: ${new Date(next.dueAt).toLocaleString("es-CL")}. Puedes practicar antes.`
              : "Completa una lección para construir tu calendario personal."}
        </Label>
        <Button disabled={!queue.length} onPress={() => router.push("/review")}>
          Comenzar repaso
        </Button>
      </Card>
      <Card>
        <Heading small>Volver a intentarlo</Heading>
        <Label muted>
          {errors.length} ejercicios con errores registrados. Se priorizan
          cuando el concepto vuelve a estar pendiente.
        </Label>
        <Button
          secondary
          onPress={() => router.push("/review?mode=errors")}
          disabled={!errors.length}
        >
          Revisar errores
        </Button>
      </Card>
      <Heading small>Práctica libre</Heading>
      <Label muted>No necesitas esperar una fecha para estudiar.</Label>
      {catalog.subjects.slice(0, 4).map((s) => {
        const lesson =
          catalog.lessons.find(
            (l) =>
              l.subjectId === s.id && !state.completedLessonIds.includes(l.id),
          ) ?? catalog.lessons.find((l) => l.subjectId === s.id)!;
        return (
          <Card key={s.id}>
            <View style={sectionRow}>
              <Icon name={s.icon} />
              <Label style={{ flex: 1, fontWeight: "700" }}>{s.title}</Label>
              <Button
                secondary
                onPress={() => router.push(`/lesson/${lesson.id}`)}
              >
                Practicar
              </Button>
            </View>
          </Card>
        );
      })}
    </View>
  );
}
export function Laboratory() {
  const { state, update, theme } = useApp();
  const [ph, setPh] = useState(7),
    [selected, setSelected] = useState(0),
    [comparison, setComparison] = useState(false),
    [hypothesis, setHypothesis] = useState(""),
    [observation, setObservation] = useState(""),
    [points, setPoints] = useState<LaboratorySession["points"]>([]),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  const lock = useRef(false);
  const enzyme = ENZYMES[selected]!;
  const activity = enzymeActivity(ph, enzyme.optimum, enzyme.width);
  const save = async () => {
    if (lock.current || !points.length) return;
    lock.current = true;
    setBusy(true);
    try {
      const session: LaboratorySession = {
        id: `lab-${Date.now()}-${Math.random().toString(36).slice(2)}`,
        at: new Date().toISOString(),
        hypothesis,
        observation,
        points,
      };
      await update((s) => ({ ...s, labs: [...s.labs, session] }));
      setPoints([]);
      setMessage("Sesión guardada en tu cuaderno local.");
    } catch {
      setMessage("No se guardó la sesión. Tus datos siguen en pantalla.");
    } finally {
      lock.current = false;
      setBusy(false);
    }
  };
  return (
    <View style={{ gap: 20 }}>
      <Eyebrow>LABORATORIO VIRTUAL / 01</Eyebrow>
      <Heading>Una enzima.{"\n"}Muchos entornos.</Heading>
      <Label muted>
        Investiga cómo cambia una actividad simulada al modificar el pH.
      </Label>
      <Chip color={theme.warm}>MODELO DIDÁCTICO · DATOS SIMULADOS</Chip>
      <Card>
        <Heading small>Antes de mover el control</Heading>
        <Field
          label="Tu hipótesis"
          value={hypothesis}
          onChangeText={setHypothesis}
          multiline
          placeholder="Predigo que… porque…"
        />
      </Card>
      <Card>
        <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
          {ENZYMES.map((e, i) => (
            <Button
              key={e.id}
              secondary={i !== selected}
              onPress={() => setSelected(i)}
            >
              {e.title}
            </Button>
          ))}
        </View>
        <Plot
          points={enzymeCurve(enzyme.optimum, enzyme.width)}
          comparison={
            comparison
              ? enzymeCurve(
                  ENZYMES[1 - selected]!.optimum,
                  ENZYMES[1 - selected]!.width,
                )
              : undefined
          }
          xLabel="pH (sin unidad)"
          yLabel="Actividad relativa (%)"
          marker={{ x: ph, y: activity }}
        />
        <View style={sectionRow}>
          <Heading small>pH {ph.toFixed(1)}</Heading>
          <Chip>{activity.toFixed(1)} % de actividad</Chip>
        </View>
        <Slider
          testID="ph-slider"
          accessibilityLabel="pH de la simulación"
          accessibilityValue={{ min: 0, max: 14, now: ph, text: ph.toFixed(1) }}
          minimumValue={0}
          maximumValue={14}
          step={0.1}
          value={ph}
          onValueChange={setPh}
          minimumTrackTintColor={theme.accent}
          maximumTrackTintColor={theme.border}
          thumbTintColor={theme.accent}
          style={{ height: 48 }}
        />
        <View style={{ flexDirection: "row", gap: 10 }}>
          <Button
            secondary
            onPress={() =>
              setPh((x) => Math.max(0, Math.round((x - 0.5) * 10) / 10))
            }
          >
            −0,5 pH
          </Button>
          <Button
            secondary
            onPress={() =>
              setPh((x) => Math.min(14, Math.round((x + 0.5) * 10) / 10))
            }
          >
            +0,5 pH
          </Button>
        </View>
        <View style={sectionRow}>
          <Label style={{ flex: 1 }}>
            Comparar segundo modelo (línea discontinua)
          </Label>
          <Switch
            accessibilityLabel="Comparar segundo modelo"
            value={comparison}
            onValueChange={setComparison}
          />
        </View>
        <Button
          onPress={() => {
            setPoints((p) => [...p, { ph, activity, enzyme: enzyme.id }]);
            setMessage("");
          }}
        >
          Registrar condición actual
        </Button>
        <Label muted style={{ fontSize: 13 }}>
          Lectura accesible: pH {ph.toFixed(1)} → {activity.toFixed(2)} % (
          {enzyme.title}). No es una medición real.
        </Label>
      </Card>
      <Card>
        <Heading small>Cuaderno de observaciones</Heading>
        {points.length ? (
          points.map((p, i) => (
            <Label key={i} style={{ fontSize: 14 }}>
              {i + 1}. Modelo {p.enzyme === "neutral" ? "N" : "A"} · pH{" "}
              {p.ph.toFixed(1)} → {p.activity.toFixed(2)} %
            </Label>
          ))
        ) : (
          <Label muted>
            Registra al menos dos condiciones para compararlas.
          </Label>
        )}
        <Field
          label="¿Qué observaste? ¿Apoya tu hipótesis?"
          value={observation}
          onChangeText={setObservation}
          multiline
        />
        <Button
          busy={busy}
          disabled={!points.length || !hypothesis.trim() || !observation.trim()}
          onPress={() => void save()}
        >
          Guardar sesión
        </Button>
        {!!message && <Label>{message}</Label>}
      </Card>
      <Card>
        <Heading small>Qué representa el modelo</Heading>
        <Label>A(pH) = 100 × exp[−½((pH − pH óptimo)/σ)²]</Label>
        <Label muted>
          σ = {enzyme.width}. La temperatura, cantidad de enzima y concentración
          de sustrato se suponen constantes. La curva es simétrica por elección
          didáctica. El máximo siempre es 100 % relativo; no equivale a una
          velocidad absoluta.
        </Label>
        <Label muted>
          Enzimas reales pueden presentar asimetría, diferentes mecanismos de
          ionización, inactivación irreversible y efectos del entorno. Este
          modelo no los predice y no se ajustó a datos publicados.
        </Label>
      </Card>
      <Heading small>Sesiones guardadas · {state?.labs.length ?? 0}</Heading>
      {state?.labs
        .slice(-5)
        .reverse()
        .map((l) => (
          <Card key={l.id}>
            <Label style={{ fontWeight: "700" }}>
              {new Date(l.at).toLocaleString("es-CL")}
            </Label>
            <Label>Hipótesis: {l.hypothesis}</Label>
            <Label muted>{l.observation}</Label>
            <Label muted style={{ fontSize: 13 }}>
              {l.points
                .map(
                  (p) =>
                    `${p.enzyme} · pH ${p.ph} / ${p.activity.toFixed(1)} %`,
                )
                .join(" · ")}
            </Label>
          </Card>
        ))}
    </View>
  );
}
export function Progress() {
  const { state, theme } = useApp();
  if (!state) return null;
  const mastery = Object.values(state.mastery);
  const challenge = weeklyChallenge(state);
  return (
    <View style={{ gap: 20 }}>
      <Eyebrow>EL CAMINO QUE HAS CONSTRUIDO</Eyebrow>
      <Heading>Tu bitácora científica</Heading>
      <Card>
        <View style={sectionRow}>
          <Heading>Nivel {1 + Math.floor(state.xp / 200)}</Heading>
          <Chip>{state.xp} XP</Chip>
        </View>
        <Meter value={(state.xp % 200) / 200} label="Progreso del nivel" />
        <Label muted>
          {state.completedLessonIds.length} de 24 lecciones completadas ·{" "}
          {mastery.filter(isMastered).length} conceptos con dominio demostrado.
        </Label>
        <Label muted style={{ fontSize: 13 }}>
          El nivel representa XP; no es un nivel académico. Completar una
          lección tampoco garantiza dominio.
        </Label>
      </Card>
      <Card>
        <Heading small>Desafío semanal</Heading>
        <Label>Estudiar en tres días distintos.</Label>
        <Meter
          value={challenge.studied / challenge.goal}
          label="Desafío semanal"
        />
        <Label muted>
          {challenge.studied} / {challenge.goal} días esta semana ·{" "}
          {challenge.complete ? "¡Desafío logrado!" : "A tu propio ritmo."}
        </Label>
      </Card>
      <Heading small>Habilidades por área</Heading>
      {catalog.subjects.slice(0, 4).map((s) => {
        const concepts = catalog.concepts.filter(
          (c) => c.subjectId === s.id && c.status === "implemented",
        );
        const score =
          concepts.reduce((n, c) => n + (state.mastery[c.id]?.score ?? 0), 0) /
          concepts.length;
        return (
          <Card key={s.id}>
            <View style={sectionRow}>
              <Icon name={s.icon} />
              <Label style={{ flex: 1, fontWeight: "700" }}>{s.title}</Label>
              <Label muted>{Math.round(score * 100)} %</Label>
            </View>
            <Meter value={score} label={`Evidencia en ${s.title}`} />
            <Label muted style={{ fontSize: 13 }}>
              {concepts.filter((c) => isMastered(state.mastery[c.id])).length} /{" "}
              {concepts.length} conceptos dominados en varios días.
            </Label>
          </Card>
        );
      })}
      <Heading small>Tu evidencia por concepto</Heading>
      {mastery.length ? (
        mastery.map((m) => (
          <Card key={m.conceptId}>
            <Label style={{ fontWeight: "700" }}>
              {conceptById[m.conceptId]?.title}
            </Label>
            <Chip>
              {isMastered(m) ? "DOMINIO DEMOSTRADO" : "EN DESARROLLO"}
            </Chip>
            <Label muted>
              {m.correct} aciertos · {m.wrong} errores · {m.evidenceDays.length}{" "}
              días con evidencia sin ayuda.
            </Label>
            <Label muted style={{ fontSize: 13 }}>
              Repaso:{" "}
              {state.reviews[m.conceptId]
                ? new Date(state.reviews[m.conceptId]!.dueAt).toLocaleString(
                    "es-CL",
                  )
                : "Sin programación"}
            </Label>
          </Card>
        ))
      ) : (
        <Label muted>
          Tu primera lección comenzará a construir esta evidencia.
        </Label>
      )}
      <Heading small>Insignias científicas</Heading>
      {achievements(state).map((a) => (
        <Card key={a.id} style={{ opacity: a.earned ? 1 : 0.75 }}>
          <View style={sectionRow}>
            <Icon
              name={a.earned ? "check" : "orbit"}
              color={a.earned ? theme.accent : theme.muted}
            />
            <Label style={{ fontWeight: "700", flex: 1 }}>{a.title}</Label>
            <Chip>{a.earned ? "LOGRADA" : "EN CAMINO"}</Chip>
          </View>
          <Label muted style={{ fontSize: 13 }}>
            {a.description}
          </Label>
        </Card>
      ))}
      {state.diagnostic && (
        <Card>
          <Heading small>Orientación del diagnóstico</Heading>
          {Object.entries(state.diagnostic.results).map(([id, r]) => (
            <Label key={id}>
              {catalog.subjects.find((s) => s.id === id)?.title}: {r.correct}/
              {r.total}
            </Label>
          ))}
          <Label muted>
            Muestra breve de habilidades; no estima capacidad universitaria.
          </Label>
        </Card>
      )}
    </View>
  );
}
export function Library() {
  const [query, setQuery] = useState("");
  const { theme } = useApp();
  const concepts = catalog.concepts.filter(
    (c) =>
      c.status === "implemented" &&
      `${c.title} ${c.english}`
        .toLocaleLowerCase()
        .includes(query.toLocaleLowerCase()),
  );
  return (
    <View style={{ gap: 20 }}>
      <Eyebrow>IDEAS A LAS QUE PUEDES VOLVER</Eyebrow>
      <Heading>Biblioteca de conexiones</Heading>
      <Field
        label="Buscar en el glosario"
        value={query}
        onChangeText={setQuery}
        placeholder="Célula, mol, factoring…"
      />
      {concepts.map((c) => (
        <Card key={c.id}>
          <Heading small>{c.title}</Heading>
          <Chip>{c.english}</Chip>
          <Label>{c.explanation}</Label>
          <Label muted>{c.example}</Label>
          <Button
            secondary
            onPress={() => router.push(`/lesson/${c.id}-lesson`)}
          >
            Estudiar con ejercicios
          </Button>
        </Card>
      ))}
      {!concepts.length && (
        <Label muted>
          No hay coincidencias en los conceptos implementados.
        </Label>
      )}
      <Heading small>Fórmulas de referencia</Heading>
      <Card>
        <Label>n = m/M · cantidad de sustancia</Label>
        <Label>v media = Δx/Δt · velocidad</Label>
        <Label>ΣF = ma · masa constante y marco inercial</Label>
        <Label>K = ½mv² · energía cinética clásica</Label>
        <Label>a² − b² = (a − b)(a + b)</Label>
      </Card>
      <Heading small>Fuentes y lecturas</Heading>
      <Label muted>
        BioNexo es un proyecto independiente. Sus textos y ejercicios son
        originales. Los enlaces externos requieren conexión; el contenido
        incluido funciona sin ella.
      </Label>
      {catalog.sources.map((s) => (
        <Card key={s.id}>
          <Label style={{ fontWeight: "700" }}>{s.title}</Label>
          <Label muted style={{ fontSize: 13 }}>
            {s.note}
          </Label>
          <Button
            secondary
            onPress={() => {
              void Linking.openURL(s.url).catch(() => {});
            }}
            label={`Abrir fuente ${s.title}`}
          >
            Abrir referencia ↗
          </Button>
        </Card>
      ))}
      <Label style={{ color: theme.warm, fontSize: 13 }}>
        Contenido pendiente de revisión académica humana. Las pruebas
        automáticas comprueban integridad y cálculos; no sustituyen esa
        revisión.
      </Label>
    </View>
  );
}
export function Settings() {
  const { state, update, restore, repository } = useApp();
  const [name, setName] = useState(state?.settings.name ?? ""),
    [pending, setPending] = useState<string | null>(null),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  if (!state) return null;
  const setTheme = (value: "dark" | "light" | "system") => {
    void update((s) => ({
      ...s,
      settings: { ...s.settings, theme: value },
    })).catch(() => {});
  };
  const doExport = async () => {
    try {
      if (repository) {
        await exportProgress(await repository.export());
        setMessage("Respaldo preparado. Guárdalo donde puedas recuperarlo.");
      }
    } catch (e) {
      setMessage(e instanceof Error ? e.message : "No se pudo exportar.");
    }
  };
  const doImport = async () => {
    try {
      const json = await importProgress();
      if (json) {
        parseBackup(json);
        setPending(json);
        setMessage(
          "Respaldo válido. Confirma abajo para reemplazar el progreso actual.",
        );
      }
    } catch (e) {
      setMessage(
        e instanceof Error ? e.message : "No se pudo abrir el respaldo.",
      );
    }
  };
  return (
    <View style={{ gap: 20 }}>
      <Eyebrow>A TU RITMO</Eyebrow>
      <Heading>Configuración</Heading>
      <Card>
        <Field
          label="Tu nombre de explorador"
          value={name}
          onChangeText={setName}
          maxLength={60}
        />
        <Button
          secondary
          onPress={() => {
            void update((s) => ({
              ...s,
              settings: { ...s.settings, name: name.trim() || "Explorador" },
            }))
              .then(() => setMessage("Nombre guardado."))
              .catch(() => {});
          }}
        >
          Guardar nombre
        </Button>
      </Card>
      <Card>
        <Heading small>Apariencia</Heading>
        <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
          {(["dark", "light", "system"] as const).map((t) => (
            <Button
              key={t}
              secondary={state.settings.theme !== t}
              onPress={() => setTheme(t)}
            >
              {t === "dark" ? "Oscuro" : t === "light" ? "Claro" : "Sistema"}
            </Button>
          ))}
        </View>
        <View style={sectionRow}>
          <Label style={{ flex: 1 }}>Reducir animaciones</Label>
          <Switch
            accessibilityLabel="Reducir animaciones"
            value={state.settings.reduceMotion}
            onValueChange={(value) => {
              void update((s) => ({
                ...s,
                settings: { ...s.settings, reduceMotion: value },
              })).catch(() => {});
            }}
          />
        </View>
        <Label muted style={{ fontSize: 13 }}>
          También se respeta la preferencia de movimiento del sistema. La
          interfaz permite el escalado de texto del dispositivo.
        </Label>
      </Card>
      <Card>
        <Heading small>Objetivo diario</Heading>
        <Label muted>
          Ejercicios respondidos, sin penalizaciones por errores.
        </Label>
        <View style={{ flexDirection: "row", gap: 8, flexWrap: "wrap" }}>
          {[3, 6, 10, 15].map((goal) => (
            <Button
              key={goal}
              secondary={state.settings.dailyGoal !== goal}
              onPress={() => {
                void update((s) => ({
                  ...s,
                  settings: { ...s.settings, dailyGoal: goal },
                })).catch(() => {});
              }}
            >
              {goal} retos
            </Button>
          ))}
        </View>
      </Card>
      <Card>
        <Heading small>Tu progreso te pertenece</Heading>
        <Label muted>
          El perfil se guarda en este dispositivo. Exporta un respaldo antes de
          desinstalar o cambiar de teléfono. Restaurar reemplaza el progreso
          local.
        </Label>
        <Button secondary onPress={() => void doExport()}>
          Exportar progreso
        </Button>
        <Button secondary onPress={() => void doImport()}>
          Importar respaldo
        </Button>
        {!!message && <Label>{message}</Label>}
        {pending && (
          <>
            <Button
              busy={busy}
              onPress={() => {
                setBusy(true);
                void restore(pending)
                  .then(() => {
                    setPending(null);
                    setMessage("Progreso restaurado.");
                  })
                  .catch(() => setMessage("No se restauró el respaldo."))
                  .finally(() => setBusy(false));
              }}
            >
              Confirmar reemplazo del progreso
            </Button>
            <Button secondary onPress={() => setPending(null)}>
              Cancelar restauración
            </Button>
          </>
        )}
      </Card>
      <Card>
        <Heading small>Diagnóstico</Heading>
        <Label muted>
          Repite la orientación cuando quieras. No elimina tus lecciones ni
          cambia tu dominio demostrado.
        </Label>
        <Button secondary onPress={() => router.push("/diagnostic")}>
          Repetir diagnóstico
        </Button>
      </Card>
      <Label muted style={{ fontSize: 13 }}>
        BioNexo 0.1.0 · Sin cuenta, publicidad ni API de pago. Todas las
        actividades de laboratorio son simulaciones educativas.
      </Label>
    </View>
  );
}
