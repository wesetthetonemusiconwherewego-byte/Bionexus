import React, { createContext, useContext, useEffect, useState } from "react";
import { AccessibilityInfo, useColorScheme } from "react-native";
import type { UserState } from "../domain/models";
import type { ProgressRepository } from "../storage/repository";
import { openRepository } from "../storage/open";
import { validateCatalog } from "../domain/validation";
export const palettes = {
  dark: {
    bg: "#09151C",
    surface: "#12232D",
    raised: "#1B303C",
    border: "#2B424F",
    text: "#F0F6F9",
    muted: "#A4BAC6",
    accent: "#66E2C8",
    accentText: "#062D26",
    danger: "#FFB3B3",
    warm: "#FFC28D",
  },
  light: {
    bg: "#F3F7F8",
    surface: "#FFFFFF",
    raised: "#E7EFF2",
    border: "#C8D6DC",
    text: "#112D39",
    muted: "#465E6B",
    accent: "#087A66",
    accentText: "#FFFFFF",
    danger: "#AD2424",
    warm: "#8B4700",
  },
};
interface AppContext {
  state: UserState | null;
  error: string | null;
  theme: typeof palettes.dark;
  reduceMotion: boolean;
  repository: ProgressRepository | null;
  update: (fn: (s: UserState) => UserState) => Promise<UserState>;
  restore: (json: string) => Promise<void>;
  retry: () => void;
  dismissError: () => void;
}
const Context = createContext<AppContext | null>(null);
export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<UserState | null>(null),
    [repository, setRepository] = useState<ProgressRepository | null>(null),
    [error, setError] = useState<string | null>(null),
    [revision, setRevision] = useState(0),
    [systemReduced, setSystemReduced] = useState(false);
  const color = useColorScheme();
  useEffect(() => {
    let mounted = true;
    const issues = validateCatalog();
    if (issues.length) {
      setError(
        "El catálogo tiene inconsistencias: " + issues.slice(0, 3).join("; "),
      );
      return;
    }
    openRepository()
      .then(async (repo) => {
        const loaded = await repo.load();
        if (mounted) {
          setRepository(repo);
          setState(loaded);
          setError(null);
        }
      })
      .catch((e) => {
        if (mounted) setError(String(e instanceof Error ? e.message : e));
      });
    return () => {
      mounted = false;
    };
  }, [revision]);
  useEffect(() => {
    AccessibilityInfo.isReduceMotionEnabled().then(setSystemReduced);
    const sub = AccessibilityInfo.addEventListener(
      "reduceMotionChanged",
      setSystemReduced,
    );
    return () => sub.remove();
  }, []);
  const name =
    state?.settings.theme === "system"
      ? color === "light"
        ? "light"
        : "dark"
      : (state?.settings.theme ?? "dark");
  const theme = palettes[name];
  const update = async (fn: (s: UserState) => UserState) => {
    try {
      if (!repository)
        throw new Error("El perfil local todavía no está disponible.");
      const next = await repository.update(fn);
      setState(next);
      return next;
    } catch (e) {
      setError(
        e instanceof Error
          ? e.message
          : "No se pudo guardar. Vuelve a intentarlo.",
      );
      throw e;
    }
  };
  const restore = async (json: string) => {
    if (!repository) throw new Error("Perfil no disponible.");
    try {
      const next = await repository.restore(json);
      setState(next);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Respaldo inválido.");
      throw e;
    }
  };
  return (
    <Context.Provider
      value={{
        state,
        error,
        theme,
        reduceMotion: systemReduced || !!state?.settings.reduceMotion,
        repository,
        update,
        restore,
        retry: () => setRevision((x) => x + 1),
        dismissError: () => setError(null),
      }}
    >
      {children}
    </Context.Provider>
  );
}
export function useApp() {
  const value = useContext(Context);
  if (!value) throw new Error("AppProvider requerido.");
  return value;
}
