import React, { useRef, useState } from "react";
import { View } from "react-native";
import { router } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import type { Answer, Exercise, Lesson } from "../domain/models";
import {
  completeLesson,
  diagnosticResult,
  recordAttempt,
} from "../domain/learning";
import { grade } from "../domain/answers";
import { conceptById } from "../content";
import { useApp } from "./provider";
import {
  Button,
  Card,
  Eyebrow,
  Heading,
  Label,
  Meter,
  Page,
  ScienceArt,
} from "./components";
import { ExerciseCard } from "./exercise";
export function StudySession({
  exercises,
  title,
  mode,
  lesson,
}: {
  exercises: Exercise[];
  title: string;
  mode: "lesson" | "review" | "diagnostic";
  lesson?: Lesson;
}) {
  const { state, update, theme, error } = useApp();
  const [index, setIndex] = useState(0),
    [done, setDone] = useState(false),
    [finishing, setFinishing] = useState(false),
    [failed, setFailed] = useState(false);
  const session = useRef(
    `${mode}-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  );
  const lock = useRef(false);
  const current = exercises[index];
  const submit = async (
    e: Exercise,
    answer: Answer,
    hinted: boolean,
    attemptNo: string,
  ) => {
    await update((s) =>
      recordAttempt(s, {
        id: `${session.current}:${e.id}:${attemptNo}`,
        exerciseId: e.id,
        conceptIds: e.conceptIds,
        answer,
        correct: grade(e, answer),
        at: new Date().toISOString(),
        mode,
        hinted,
      }),
    );
  };
  const next = async () => {
    if (lock.current) return;
    lock.current = true;
    if (index < exercises.length - 1) {
      setIndex(index + 1);
      queueMicrotask(() => {
        lock.current = false;
      });
      return;
    }
    setFinishing(true);
    setFailed(false);
    try {
      await update((s) =>
        mode === "lesson" && lesson
          ? completeLesson(s, lesson, session.current)
          : mode === "diagnostic"
            ? {
                ...s,
                diagnostic: diagnosticResult(
                  s.attempts.filter((a) =>
                    a.id.startsWith(session.current + ":"),
                  ),
                  new Date().toISOString(),
                ),
              }
            : s,
      );
      setDone(true);
    } catch {
      setFailed(true);
    } finally {
      setFinishing(false);
      lock.current = false;
    }
  };
  const latest = exercises.map((e) =>
    [...(state?.attempts ?? [])]
      .reverse()
      .find(
        (a) => a.exerciseId === e.id && a.id.startsWith(session.current + ":"),
      ),
  );
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }}>
      <Page>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
          <Button secondary onPress={() => router.replace("/")}>
            Salir
          </Button>
          <Label style={{ flex: 1, fontWeight: "700" }}>{title}</Label>
        </View>
        {error && (
          <Label accessibilityRole={undefined} style={{ color: theme.danger }}>
            {error}
          </Label>
        )}
        {done ? (
          <>
            <View style={{ alignItems: "center" }}>
              <ScienceArt compact />
            </View>
            <Eyebrow>UNA CONEXIÓN MÁS</Eyebrow>
            <Heading>
              {mode === "diagnostic"
                ? "Tu punto de partida está listo"
                : "Expedición completada"}
            </Heading>
            <Card>
              <Label>
                {latest.filter((a) => a?.correct).length} / {exercises.length}{" "}
                respuestas finales correctas.
              </Label>
              <Label muted>
                {mode === "diagnostic"
                  ? "Usaremos esta muestra breve para sugerir bases que conviene reforzar. No otorga dominio ni XP."
                  : "Tu progreso y calendario de repasos ya están guardados. Volver en otros días ayuda a consolidar las ideas."}
              </Label>
              {mode !== "diagnostic" && (
                <Label>
                  {state?.xp ?? 0} XP acumulado en tu perfil. Cada ejercicio
                  correcto otorga XP una sola vez.
                </Label>
              )}
            </Card>
            {mode === "lesson" && lesson && (
              <Card>
                <Heading small>Qué conectaste hoy</Heading>
                <Label>{lesson.summary}</Label>
                <Label muted>{lesson.application}</Label>
              </Card>
            )}
            {mode === "diagnostic" && state?.diagnostic && (
              <Card>
                <Heading small>Bases para reforzar</Heading>
                <Label>
                  {state.diagnostic.weakConceptIds.length
                    ? state.diagnostic.weakConceptIds
                        .map((id) => conceptById[id]?.title ?? id)
                        .join(" · ")
                    : "Esta muestra no detectó errores. Puedes explorar la ruta y comprobar tus bases con lecciones completas."}
                </Label>
                <Label muted>
                  El diagnóstico puede repetirse desde Configuración.
                </Label>
              </Card>
            )}
            <Button onPress={() => router.replace("/?tab=progress")}>
              Ver mi progreso
            </Button>
            <Button secondary onPress={() => router.replace("/?tab=learn")}>
              Volver al mapa
            </Button>
          </>
        ) : !current ? (
          <>
            <Heading>No hay ejercicios pendientes</Heading>
            <Label>
              Completa lecciones o vuelve cuando llegue tu próximo repaso.
            </Label>
            <Button onPress={() => router.replace("/?tab=practice")}>
              Volver a práctica
            </Button>
          </>
        ) : (
          <>
            <View style={{ gap: 8 }}>
              <Eyebrow>
                {mode === "diagnostic"
                  ? "ORIENTACIÓN INICIAL"
                  : mode === "review"
                    ? "PRÁCTICA INTERCALADA"
                    : "TU EXPEDICIÓN"}
              </Eyebrow>
              <Meter
                value={index / exercises.length}
                label="Progreso de la sesión"
              />
              <Label muted style={{ fontSize: 12 }}>
                RETO {index + 1} DE {exercises.length}
              </Label>
            </View>
            <ExerciseCard
              key={current.id}
              exercise={current}
              onSubmit={submit}
              onContinue={() => void next()}
              canRemediate={mode !== "diagnostic"}
            />
            {finishing && <Label>Guardando resumen…</Label>}
            {failed && (
              <Button secondary onPress={() => void next()}>
                Reintentar guardar el resumen
              </Button>
            )}
          </>
        )}
      </Page>
    </SafeAreaView>
  );
}
