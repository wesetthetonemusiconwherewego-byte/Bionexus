import React, { useState } from "react";
import { useLocalSearchParams, router } from "expo-router";
import { catalog, exerciseById } from "../src/content";
import { reviewQueue } from "../src/domain/learning";
import type { UserState } from "../src/domain/models";
import { useApp } from "../src/ui/provider";
import { Button, Label, Page } from "../src/ui/components";
import { StudySession } from "../src/ui/session";
export default function Review() {
  const { state } = useApp();
  const { mode } = useLocalSearchParams<{ mode?: string }>();
  if (!state)
    return (
      <Page>
        <Label>Abriendo perfil…</Label>
        <Button onPress={() => router.replace("/")}>Volver</Button>
      </Page>
    );
  return <ReviewContent initial={state} errors={mode === "errors"} />;
}
function ReviewContent({
  initial,
  errors,
}: {
  initial: UserState;
  errors: boolean;
}) {
  const [exercises] = useState(() =>
    errors
      ? [
          ...new Set(
            initial.attempts
              .filter((a) => !a.correct && a.mode !== "diagnostic")
              .reverse()
              .map((a) => a.exerciseId),
          ),
        ]
          .map((id) => exerciseById[id]!)
          .filter(Boolean)
          .slice(0, 8)
      : reviewQueue(initial),
  );
  return (
    <StudySession
      exercises={exercises}
      title={errors ? "Revisión de errores" : "Repaso de conexiones"}
      mode="review"
    />
  );
}
