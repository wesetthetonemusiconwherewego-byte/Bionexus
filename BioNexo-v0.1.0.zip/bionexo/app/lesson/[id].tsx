import React, { useState } from "react";
import { View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { catalog, conceptById, lessonById } from "../../src/content";
import { missingPrerequisites } from "../../src/domain/learning";
import { useApp } from "../../src/ui/provider";
import {
  Button,
  Card,
  Chip,
  Eyebrow,
  Heading,
  Label,
  Page,
} from "../../src/ui/components";
import { StudySession } from "../../src/ui/session";
export default function LessonScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { state, theme } = useApp();
  const [started, setStarted] = useState(false);
  const lesson = lessonById[id ?? ""];
  if (!state)
    return (
      <Page>
        <Label>Abriendo perfil…</Label>
        <Button onPress={() => router.replace("/")}>Volver</Button>
      </Page>
    );
  if (!lesson)
    return (
      <Page>
        <Heading>Lección no encontrada</Heading>
        <Button onPress={() => router.replace("/?tab=learn")}>
          Volver al mapa
        </Button>
      </Page>
    );
  if (started)
    return (
      <StudySession
        exercises={lesson.exercises}
        title={lesson.title}
        mode="lesson"
        lesson={lesson}
      />
    );
  const missing = missingPrerequisites(state, lesson);
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }}>
      <Page>
        <Button secondary onPress={() => router.replace("/?tab=learn")}>
          ← Volver al mapa
        </Button>
        <Eyebrow>
          {catalog.subjects
            .find((s) => s.id === lesson.subjectId)
            ?.title.toUpperCase()}{" "}
          / FUNDAMENTOS
        </Eyebrow>
        <Heading>{lesson.title}</Heading>
        <Chip>{lesson.minutes} MIN · 6 RETOS</Chip>
        <Card>
          <Heading small>Al terminar podrás…</Heading>
          <Label>{lesson.objective}</Label>
        </Card>
        {missing.length > 0 && (
          <Card>
            <Heading small>Un puente antes de avanzar</Heading>
            <Label muted>
              Estas bases aún no tienen suficiente evidencia. Puedes abrir sus
              explicaciones o practicar esta lección igualmente.
            </Label>
            {missing.map((cid) => (
              <View key={cid} style={{ gap: 8 }}>
                <Label>{conceptById[cid]?.title}</Label>
                {lessonById[cid + "-lesson"] && (
                  <Button
                    secondary
                    onPress={() => router.push(`/lesson/${cid}-lesson`)}
                  >
                    Reforzar {conceptById[cid]?.title}
                  </Button>
                )}
              </View>
            ))}
          </Card>
        )}
        <Card>
          <Eyebrow>ANTES DE EMPEZAR</Eyebrow>
          <Label>{lesson.activation}</Label>
        </Card>
        <Heading small>La idea central</Heading>
        <Label>{lesson.explanation}</Label>
        <Card>
          <Heading small>Un ejemplo, paso a paso</Heading>
          {lesson.example.map((step, i) => (
            <View key={i} style={{ flexDirection: "row", gap: 12 }}>
              <Label style={{ color: theme.accent, fontWeight: "700" }}>
                {i + 1}.
              </Label>
              <Label style={{ flex: 1 }}>{step}</Label>
            </View>
          ))}
        </Card>
        <Card>
          <Eyebrow>CONEXIÓN CON BIOTECNOLOGÍA</Eyebrow>
          <Label>{lesson.application}</Label>
        </Card>
        <Label muted style={{ fontSize: 12 }}>
          Referencias:{" "}
          {lesson.sourceIds
            .map((id) => catalog.sources.find((s) => s.id === id)?.title)
            .join(" · ")}
          . Texto original de BioNexo; pendiente de revisión académica humana.
        </Label>
        <Button onPress={() => setStarted(true)}>
          {missing.length ? "Practicar igualmente" : "Comenzar los retos"}
        </Button>
      </Page>
    </SafeAreaView>
  );
}
