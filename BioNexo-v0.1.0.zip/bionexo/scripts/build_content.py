"""Authoring source. Produces deterministic, original Spanish curriculum assets."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
subjects=[
 {'id':'biology','title':'Biología','color':'#4DDEC3','icon':'cell','subtitle':'De la célula a los sistemas vivos'},
 {'id':'chemistry','title':'Química','color':'#C3A0FF','icon':'flask','subtitle':'La materia que hace posible la vida'},
 {'id':'physics','title':'Física','color':'#FFBE85','icon':'orbit','subtitle':'Las reglas detrás de cada proceso'},
 {'id':'math','title':'Matemáticas','color':'#87BEFF','icon':'function','subtitle':'El lenguaje para entender y predecir'},
 {'id':'integrated','title':'Biotecnología integrada','color':'#F2CC76','icon':'dna','subtitle':'Conecta ideas y construye modelos'}]
sources=[
 ('unab','UNAB · Malla Ingeniería en Biotecnología','https://www.unab.cl/carreras/mallas/ing_biotecnologia.pdf','Referencia de áreas universitarias; no define los prerrequisitos de esta app.'),
 ('mit','MIT · Biological Engineering requirements','https://be.mit.edu/undergraduate-program/major-degree-requirements/','Referencia de integración de ciencias e ingeniería; BioNexo es independiente.'),
 ('bio','OpenStax · Biology 2e','https://openstax.org/books/biology-2e/pages/1-introduction','Lectura complementaria, capítulos 1–5. Texto y ejercicios de BioNexo originales; no se incluyen figuras ni extractos del libro.'),
 ('chem','OpenStax · Chemistry 2e','https://openstax.org/books/chemistry-2e/pages/1-introduction','Lectura complementaria, capítulos 1–3 y 7. Licencia actual del libro CC BY-NC-SA 4.0.'),
 ('phys','OpenStax · College Physics 2e','https://openstax.org/books/college-physics-2e/pages/1-introduction-to-science-and-the-realm-of-physics-physical-quantities-and-units','Lectura complementaria, capítulos 1–7. Licencia actual CC BY-NC-SA 4.0.'),
 ('math-ref','OpenStax · Precalculus 2e','https://openstax.org/books/precalculus-2e/pages/1-introduction-to-functions','Lectura complementaria, capítulos 1–3 y apéndice A. Licencia actual CC BY-NC-SA 4.0.'),
 ('learning','Dunlosky et al. (2013) · Improving Students’ Learning','https://doi.org/10.1177/1529100612453266','Recuperación y práctica distribuida: alta utilidad en la revisión. Intercalado: utilidad moderada; no valida el algoritmo de esta app.'),
 ('license','OpenStax · Licensing information','https://help.openstax.org/s/article/Licensing-information-of-OpenStax-textbooks','Consulta 2026-10-22. Verificar la licencia de cada edición antes de reutilizar material.'),
 ('enzyme','OpenStax · Biology 2e, 6.5 Enzymes','https://openstax.org/books/biology-2e/pages/6-5-enzymes','Contexto conceptual del laboratorio. La curva gaussiana de BioNexo es una elección didáctica, no un ajuste experimental.')]
sources=[dict(id=a,title=b,url=c,note=d) for a,b,c,d in sources]
lessons=[]; units=[]; concepts=[]
def choice(prompt, options, correct, explanation, misconception, kind='choice'):
 return dict(type=kind,prompt=prompt,options=[dict(id=chr(97+i),text=x) for i,x in enumerate(options)],correct=chr(97+correct),explanation=dict(correct=explanation,misconception=misconception))
def num(prompt,correct,unit,explanation,tolerance=1e-8,accepted=None):
 return dict(type='numeric',prompt=prompt,correct=correct,tolerance=tolerance,unit=unit,acceptedUnits=accepted or {unit:1},explanation=dict(correct=explanation,misconception='Comprueba la operación y las unidades. El valor se convierte a la unidad pedida antes de comparar.'))
def multi(prompt,options,correct,explanation):
 return dict(type='multi',prompt=prompt,options=[dict(id=chr(97+i),text=x) for i,x in enumerate(options)],correct=[chr(97+i) for i in correct],explanation=dict(correct=explanation,misconception='Distingue las propiedades que se cumplen en todos los casos de las que solo aparecen en algunos.'))
def text(prompt,answers,explanation):
 return dict(type='text',prompt=prompt,correct=answers,explanation=dict(correct=explanation,misconception='Revisa el término científico y su significado; se aceptan mayúsculas y tildes equivalentes.'))
def order(prompt,items,explanation):
 return dict(type='order',prompt=prompt,items=[dict(id=str(i),text=s) for i,s in enumerate(items)],correct=[str(i) for i in range(len(items))],explanation=dict(correct=explanation,misconception='Cada paso debe usar el resultado del anterior. Puedes vaciar la secuencia y volver a ordenar.'))
def match(prompt,pairs,explanation):
 return dict(type='match',prompt=prompt,left=[dict(id='l'+str(i),text=p[0]) for i,p in enumerate(pairs)],right=[dict(id='r'+str(i),text=p[1]) for i,p in enumerate(pairs)],correct={'l'+str(i):'r'+str(i) for i in range(len(pairs))},explanation=dict(correct=explanation,misconception='Relaciona cada concepto con su función o definición, sin guiarte por el orden de presentación.'))
def chart(prompt,options,correct,points,x,y,explanation):
 q=choice(prompt,options,correct,explanation,'Lee ambos ejes y compara valores, no solo la forma del trazo.','chart');q.update(chart=[dict(x=a,y=b) for a,b in points],xLabel=x,yLabel=y);return q

def add(subject,unitid,unittitle,cid,title,english,prereqs,objective,activation,explanation,example,application,qs,summary=None):
 uid=subject+'-'+unitid; lid=cid+'-lesson'; source={'biology':'bio','chemistry':'chem','physics':'phys','math':'math-ref'}[subject]
 if not any(u['id']==uid for u in units): units.append(dict(id=uid,subjectId=subject,title=unittitle,lessonIds=[],prerequisites=prereqs))
 next(u for u in units if u['id']==uid)['lessonIds'].append(lid)
 concepts.append(dict(id=cid,subjectId=subject,title=title,english=english,prerequisites=prereqs,status='implemented',origin='foundation',explanation=explanation,example=' → '.join(example),sourceIds=[source]))
 for i,q in enumerate(qs):
  q.update(id=f'{cid}-q{i+1}',subjectId=subject,level=1,conceptIds=[cid],prerequisites=prereqs,sourceIds=[source],hints=[activation,'Ejemplo relacionado: '+' → '.join(example)])
 lessons.append(dict(id=lid,unitId=uid,subjectId=subject,title=title,minutes=8,objective=objective,activation=activation,conceptIds=[cid],prerequisites=prereqs,explanation=explanation,example=example,application=application,summary=summary or objective,exercises=qs,sourceIds=[source],reviewStatus='requires-human-review'))

add('biology','life','01 · La lógica de la vida','bio-life','¿Qué hace vivo a un sistema?','living systems',[],
 'Distinguir propiedades compartidas por las células vivas de características no universales.',
 'Piensa en una semilla y en un cristal: ambos pueden aumentar de tamaño. ¿Qué más tendrías que investigar?',
 'Los sistemas vivos tienen organización celular y mantienen procesos de intercambio de materia y energía. La homeostasis regula condiciones internas dentro de rangos, no las mantiene perfectamente constantes. Las poblaciones evolucionan a lo largo de generaciones. No todos los individuos pueden reproducirse; un organismo estéril sigue vivo. Crecer, moverse o consumir energía por sí solos no bastan para identificar vida. Los virus dependen de células hospedadoras y su clasificación como vivos es una discusión conceptual: no son células.',
 ['Una llama consume combustible y crece.','No tiene células ni un sistema hereditario celular.','Consumir energía es necesario para la vida celular, pero no es un criterio suficiente.'],
 'Para evaluar un cultivo celular se combinan señales como integridad de membrana y metabolismo; una sola medición puede ser ambigua.',[
 choice('Un cristal crece en una disolución. ¿Eso demuestra que está vivo?',['Sí, todo crecimiento es biológico','No, el crecimiento solo no demuestra vida','Sí, si es grande'],1,'El crecimiento también ocurre por incorporación física de materia en sistemas no vivos.','Crecer no implica organización celular.'),
 multi('Selecciona propiedades generales de los sistemas celulares vivos.',['Organización celular','Metabolismo','Locomoción visible','Regulación interna'],[0,1,3],'Las células intercambian materia y energía y regulan su medio interno. La locomoción no es universal.'),
 choice('Un organismo estéril está sano. ¿Cómo lo clasificas?',['No vivo','Vivo; la esterilidad no elimina sus procesos vitales','Virus'],1,'La reproducción individual no es condición necesaria para que un organismo esté vivo.','Las propiedades de poblaciones no siempre son requisitos de cada individuo.'),
 text('¿Cómo se llama la regulación de condiciones internas?',['homeostasis','homeostasia'],'La homeostasis implica regulación dinámica, no ausencia de cambios.'),
 choice('¿En qué escala se observa evolución biológica?',['Poblaciones a través de generaciones','Cada célula cuando se estira','Cada individuo cuando aprende'],0,'La evolución implica cambios heredables en poblaciones a lo largo de generaciones.','Aprender o crecer no equivale a evolución poblacional.'),
 choice('Una muestra consume oxígeno. ¿Qué conclusión permite ese dato por sí solo?',['Es inequívocamente un ser vivo','Tiene ADN','Es compatible con actividad metabólica; faltan más evidencias'],2,'También existen reacciones no biológicas que consumen oxígeno. Hay que contrastar varias evidencias.','Una señal aislada no demuestra una explicación única.','case')])

add('biology','life','01 · La lógica de la vida','bio-evidence','Preguntar, medir, comparar','scientific evidence',['bio-life'],
 'Identificar variable independiente, respuesta medida y control en un experimento simulado.',
 'Si cambias a la vez luz y temperatura, ¿podrías atribuir el resultado a una sola de ellas?',
 'Una hipótesis propone una explicación contrastable; una predicción describe un resultado esperado si esa explicación y sus supuestos son adecuados. En un experimento controlado se modifica una variable independiente y se mide una respuesta, procurando mantener comparables las demás condiciones. Los controles ayudan a interpretar resultados. Las réplicas independientes permiten estimar variación; medir cinco veces la misma muestra no equivale a cinco muestras independientes. Una asociación entre dos variables no establece por sí sola una causa.',
 ['Hipótesis: cierta enzima responde al pH.','Comparar pH 5 y pH 7 con la misma cantidad de enzima y temperatura.','Medir velocidad inicial en varias muestras independientes por condición.'],
 'La biotecnología necesita distinguir un efecto de tratamiento del ruido y de variables que se cambiaron sin querer.',[
 choice('Se ajusta el pH y se mide actividad. ¿Cuál es la variable independiente?',['Actividad','pH','Número de observaciones'],1,'El pH es la variable manipulada.','La respuesta medida es la variable dependiente.'),
 choice('¿Qué comparación aísla mejor el efecto del pH?',['pH distinto y temperatura distinta','pH distinto con temperatura y cantidad de enzima iguales','pH igual sin medir actividad'],1,'Mantener comparables las demás condiciones ayuda a atribuir diferencias al pH.','Cambiar varias condiciones confunde la interpretación.'),
 multi('¿Qué fortalece una comparación?',['Réplicas independientes','Definir qué se medirá antes','Ocultar todos los resultados desfavorables','Un control pertinente'],[0,1,3],'Las réplicas, criterios previos y controles mejoran la interpretación; descartar resultados por conveniencia la sesga.'),
 match('Relaciona cada término con su papel.', [('Hipótesis','Explicación contrastable'),('Predicción','Resultado esperado bajo supuestos'),('Réplica independiente','Nueva unidad experimental')],'Una hipótesis y una predicción cumplen funciones distintas.'),
 choice('Dos variables aumentan juntas. ¿Qué puedes afirmar?',['Una causa necesariamente a la otra','Hay asociación; falta evaluar causas alternativas','No se pueden estudiar'],1,'La asociación puede deberse a una tercera variable o a causalidad en otra dirección.','Correlación y causalidad no son equivalentes.','case'),
 order('Ordena una investigación sencilla.', ['Formular una pregunta medible','Definir hipótesis y comparación','Registrar datos de las condiciones','Analizar resultados y limitaciones'],'Las decisiones previas permiten interpretar los datos sin adaptar la hipótesis a conveniencia.')])

add('biology','molecules','02 · Materia viva','bio-water','Agua, polaridad y puentes','water polarity',['bio-life'],
 'Relacionar la polaridad del agua con su capacidad de interacción y disolución.',
 'Recuerda que las cargas de signos opuestos se atraen.',
 'En el agua, los electrones de los enlaces O–H se comparten de forma desigual. El oxígeno tiene carga parcial negativa y los hidrógenos carga parcial positiva; la molécula es neutra en conjunto. Entre moléculas de agua se forman puentes de hidrógeno. Estos no son los enlaces covalentes O–H dentro de una molécula. El agua interactúa bien con muchos iones y moléculas polares, pero no disuelve por igual todas las sustancias. Las sustancias apolares tienden a agruparse en agua; esa conducta participa en la organización de membranas.',
 ['NaCl aporta iones al disolverse.','El oxígeno del agua orienta su carga parcial negativa hacia Na+.','La hidratación ayuda a estabilizar los iones separados.'],
 'El entorno acuoso influye en el plegamiento de proteínas y en la preparación de disoluciones.',[
 choice('¿Qué carga neta tiene una molécula de agua?',['Positiva','Negativa','Cero'],2,'Las cargas parciales se distribuyen de manera desigual, pero la carga neta es cero.','Polar no significa iónico.'),
 choice('¿Dónde se forma un puente de hidrógeno entre aguas?',['Entre moléculas diferentes','En el núcleo del oxígeno','Es el enlace covalente O–H'],0,'El puente de hidrógeno es una interacción entre moléculas de agua en este caso.','No confundas enlaces intramoleculares con interacciones intermoleculares.'),
 choice('¿Hacia Na+ se orienta preferentemente qué parte del agua?',['El oxígeno','Los dos hidrógenos','No hay orientación'],0,'El oxígeno tiene carga parcial negativa y atrae al catión.','Las cargas de signo opuesto se atraen.'),
 multi('Selecciona afirmaciones correctas.',['El agua es polar','Disuelve todas las grasas por igual','Puede hidratar iones','Su carga total es cero'],[0,2,3],'La polaridad favorece interacciones con iones y solutos polares; muchos lípidos son poco solubles.'),
 text('Completa: una molécula con distribución desigual de cargas parciales es ___.',['polar'],'La polaridad describe la separación de cargas parciales.'),
 choice('Aceite y agua se separan. ¿Qué interpretación es mejor?',['El aceite tiene células','Las interacciones del agua favorecen la agrupación de sustancias apolares','El agua deja de ser polar'],1,'El efecto hidrofóbico favorece la agrupación de componentes apolares en medio acuoso.','Separarse no significa que los enlaces del agua cambien de naturaleza.','prediction')])

add('biology','molecules','02 · Materia viva','bio-macromolecules','Las piezas moleculares','biomolecules',['bio-water'],
 'Relacionar proteínas, ácidos nucleicos, carbohidratos y lípidos con sus componentes y funciones.',
 'Una función biológica depende de la estructura y de las interacciones de sus moléculas.',
 'Las proteínas son cadenas de aminoácidos que se pliegan en estructuras relacionadas con su función. Muchas enzimas son proteínas, aunque existen ARN catalíticos. Los ácidos nucleicos ADN y ARN contienen nucleótidos y participan en almacenamiento y expresión de información. Los carbohidratos incluyen azúcares simples y polisacáridos; cumplen funciones energéticas y estructurales. Los lípidos son un grupo diverso de moléculas con regiones hidrofóbicas; no todos son polímeros de monómeros repetidos. Los fosfolípidos participan en membranas.',
 ['La secuencia de aminoácidos contribuye al plegamiento.','El plegamiento determina interacciones posibles.','Cambiar la estructura puede alterar actividad, sin garantizar que todo cambio la elimine.'],
 'Diseñar una proteína exige conectar secuencia, estructura y función, no solo memorizar su nombre.',[
 match('Relaciona molécula y componente característico.', [('Proteína','Aminoácidos'),('ADN','Nucleótidos'),('Polisacárido','Monosacáridos')],'Las unidades de construcción ayudan a distinguir las grandes familias.'),
 choice('¿Qué afirmación sobre lípidos es precisa?',['Todos son polímeros idénticos','Son diversos; muchos tienen regiones hidrofóbicas','Todos son enzimas'],1,'Los lípidos agrupan estructuras variadas y no son todos polímeros.','No extiendas el modelo de proteína a todas las biomoléculas.'),
 multi('¿Qué pueden hacer las proteínas?',['Catalizar reacciones','Transportar moléculas','Formar estructuras','Ser siempre la única molécula hereditaria'],[0,1,2],'Las proteínas cumplen múltiples funciones. En la vida celular el ADN es el principal soporte hereditario.'),
 text('¿Cómo se llaman las unidades que forman las proteínas?',['aminoacidos','aminoácidos','aminoacido','aminoácido'],'Los aminoácidos se conectan por enlaces peptídicos.'),
 choice('Se altera el plegamiento de una enzima. ¿Qué puede ocurrir?',['Puede cambiar su actividad','Se convierte necesariamente en ADN','Su función nunca cambia'],0,'La estructura tridimensional afecta la interacción con sustratos.','Una secuencia no funciona de forma independiente de su estructura.','prediction'),
 choice('Se necesita una barrera celular con regiones hidrofóbicas. ¿Qué componente elegir?',['Fosfolípidos','Glucosa aislada','Iones sodio'],0,'Los fosfolípidos tienen cabezas hidrofílicas y colas hidrofóbicas que favorecen bicapas.','Un soluto pequeño no forma por sí solo una bicapa estable.','case')])

add('biology','cells','03 · Arquitectura celular','bio-cells','Un mapa de la célula','cell structure',['bio-macromolecules'],
 'Comparar células procariontes y eucariontes y localizar estructuras fundamentales.',
 'Todas las células comparten una frontera que las separa del entorno.',
 'Las células poseen membrana plasmática, material genético, citoplasma y ribosomas. Las eucariontes tienen un núcleo delimitado por membrana; las procariontes carecen de ese núcleo, pero sí tienen ADN. Los ribosomas sintetizan proteínas. Las mitocondrias participan en la respiración celular en eucariontes; las bacterias no necesitan mitocondrias para producir ATP. Los cloroplastos realizan fotosíntesis en plantas y algas fotosintéticas, pero no están en todas las células vegetales. Un dibujo celular es un modelo, no una imagen a escala.',
 ['Una célula bacteriana tiene ADN y ribosomas.','Su ADN no está encerrado en un núcleo membranoso.','Se clasifica como procarionte, no como célula sin información genética.'],
 'Seleccionar un sistema celular para biotecnología exige conocer qué estructuras y procesos contiene.',[
 choice('¿Qué comparten bacterias y células animales?',['Núcleo membranoso','Ribosomas','Cloroplastos'],1,'Ambas necesitan ribosomas para fabricar proteínas.','La ausencia de núcleo no implica ausencia de ribosomas.'),
 choice('Una bacteria carece de núcleo. ¿Carece de ADN?',['Sí','No; posee ADN fuera de un núcleo membranoso','Solo tiene proteínas'],1,'El ADN procarionte se localiza principalmente en una región nucleoide.','Núcleo y material genético no son sinónimos.'),
 multi('Selecciona estructuras generales de las células.',['Membrana plasmática','Ribosomas','ADN','Cloroplastos en todas'],[0,1,2],'Los cloroplastos no son universales, ni siquiera en todas las células de una planta.'),
 dict(choice('En el esquema eucarionte, identifica la región que contiene la mayor parte del ADN.',['Región A','Región B','Región C'],0,'El núcleo eucarionte contiene la mayor parte del ADN; mitocondrias y cloroplastos también pueden contenerlo.','El esquema representa una célula eucarionte simplificada.','diagram'),diagram='cell'),
 match('Relaciona estructura y función.', [('Ribosoma','Síntesis de proteínas'),('Membrana','Frontera selectiva'),('Mitocondria','Respiración en eucariontes')],'Una estructura puede participar en varias funciones; aquí se destaca una característica.'),
 choice('¿Qué evitarías afirmar sobre una célula de raíz sin cloroplastos?',['Que es necesariamente animal','Que tiene membrana','Que posee ribosomas'],0,'Muchas células de raíz son vegetales sin cloroplastos fotosintéticos.','No todas las células vegetales realizan fotosíntesis.','case')])

add('biology','cells','03 · Arquitectura celular','bio-membranes','Fronteras en movimiento','membrane transport',['bio-cells','bio-water'],
 'Predecir difusión y ósmosis bajo supuestos explícitos y distinguir transporte pasivo de activo.',
 'Piensa en el movimiento neto: las partículas siguen moviéndose incluso cuando no hay cambio neto.',
 'La membrana contiene una bicapa lipídica y proteínas. En difusión simple, el flujo neto de una sustancia ocurre a favor de su gradiente de concentración bajo condiciones sencillas; para iones también importa el potencial eléctrico. En difusión facilitada intervienen proteínas sin acoplamiento directo a una fuente de energía para mover contra el gradiente. El transporte activo utiliza energía directa o indirectamente para mover sustancias contra un gradiente electroquímico. La ósmosis es el movimiento neto de agua a través de una membrana selectiva. Con igual presión y solutos no permeantes, el agua tiende hacia el lado de mayor concentración de esos solutos.',
 ['Separar agua pura y una disolución de sacarosa con membrana que solo deja pasar agua.','Suponer igual presión inicial y sacarosa no permeante.','El flujo neto inicial de agua va hacia la disolución.'],
 'Las predicciones de transporte requieren conocer permeabilidad, presión y naturaleza de los solutos.',[
 choice('Una molécula neutra difunde de mayor a menor concentración. ¿Es pasivo?',['Sí, bajo esas condiciones','No, toda difusión gasta ATP directamente','Solo si se detiene al final'],0,'La difusión a favor del gradiente es transporte pasivo.','Movimiento no implica consumo directo de ATP.'),
 choice('En equilibrio dinámico, las partículas…',['Dejan de moverse','Se mueven sin flujo neto','Se destruyen'],1,'Persisten movimientos en ambas direcciones con flujos compensados.','Equilibrio no significa inmovilidad.'),
 choice('Membrana solo permeable al agua, igual presión: un lado tiene más sacarosa. ¿Hacia dónde va el flujo neto inicial de agua?',['Hacia más sacarosa','Hacia menos sacarosa','No se puede mover agua'],0,'Con soluto no permeante e igual presión inicial, el agua tiende hacia mayor concentración de soluto.','La predicción requiere las condiciones indicadas.','prediction'),
 match('Relaciona proceso y característica.', [('Difusión facilitada','Proteína y movimiento pasivo'),('Transporte activo','Acoplamiento energético'),('Ósmosis','Movimiento neto de agua')],'Una proteína de transporte no implica necesariamente transporte activo.'),
 multi('¿Qué información puede importar al predecir transporte?',['Permeabilidad','Gradiente de concentración','Potencial eléctrico para iones','Solo el color del líquido'],[0,1,2],'La selectividad y las fuerzas impulsoras determinan el transporte.'),
 choice('Una bomba mantiene iones contra su gradiente electroquímico. ¿Qué requiere?',['Una fuente de energía','Que no haya membrana','Equilibrio estático'],0,'Mantener un gradiente contra la tendencia espontánea requiere energía directa o indirecta.','El gradiente es una forma de almacenamiento de energía.','case')])

add('chemistry','matter','01 · Observar la materia','chem-matter','Sustancias y mezclas','matter and mixtures',[],
 'Clasificar sustancias puras y mezclas distinguiendo elementos y compuestos.',
 'Una muestra puede verse uniforme y aun contener varias sustancias.',
 'La materia tiene masa y ocupa espacio. Un elemento contiene átomos con el mismo número de protones. Un compuesto contiene elementos unidos químicamente en proporciones definidas. Una mezcla reúne sustancias en proporciones variables sin convertirse necesariamente en un compuesto nuevo. Las mezclas homogéneas son uniformes a la escala considerada; las heterogéneas presentan regiones distinguibles. El agua salada puede ser homogénea y seguir siendo una mezcla. Una sustancia pura no se define por ser natural, saludable o transparente.',
 ['Agua destilada idealizada: compuesto H₂O.','Agua con sal disuelta: mezcla homogénea.','Cambiar la cantidad de sal cambia la composición de la mezcla.'],
 'Antes de analizar una muestra hay que distinguir pureza química de apariencia uniforme.',[
 choice('Una disolución uniforme de NaCl en agua es…',['Elemento','Mezcla homogénea','Sustancia pura'],1,'Contiene al menos dos sustancias aunque no distingamos sus componentes a simple vista.','Uniforme no significa puro.'),
 match('Relaciona clasificación y ejemplo idealizado.', [('Elemento','Cobre puro'),('Compuesto','Agua pura'),('Mezcla','Aire limpio')],'El aire contiene varios gases y no tiene una única fórmula molecular.'),
 multi('Selecciona afirmaciones correctas sobre mezclas.',['Composición variable','Pueden ser homogéneas','Siempre forman enlaces nuevos entre todos los componentes','Pueden contener compuestos'],[0,1,3],'Las mezclas no exigen una proporción química fija ni un compuesto nuevo.'),
 choice('¿Qué distingue principalmente un elemento de otro?',['Número de protones','Forma del recipiente','Temperatura de la muestra'],0,'El número atómico identifica al elemento.','El estado físico puede cambiar sin cambiar el elemento.'),
 text('¿Cómo se llama una mezcla que presenta fases distinguibles?',['heterogenea','heterogénea','mezcla heterogenea','mezcla heterogénea'],'La heterogeneidad depende de la escala y las fases observables.'),
 choice('Dos botellas tienen agua salada con distinta cantidad de sal. ¿Qué concluyes?',['Son necesariamente dos elementos','La composición variable es compatible con mezclas','El agua dejó de ser H₂O'],1,'La relación entre componentes puede variar sin cambiar su identidad química.','La composición fija corresponde a un compuesto definido.','case')])

add('chemistry','matter','01 · Observar la materia','chem-change','Cambios y conservación','physical and chemical changes',['chem-matter'],
 'Distinguir cambios físicos y químicos y aplicar conservación de masa en un sistema cerrado.',
 'Cambiar de estado no cambia necesariamente la identidad química.',
 'Un cambio físico altera estado, forma o distribución sin que eso implique sustancias nuevas. En un cambio químico se reorganizan átomos y enlaces, produciendo nuevas especies. En una reacción química ordinaria, la masa total se conserva si se contabiliza todo lo que entra y sale. Una balanza puede registrar pérdida si un gas abandona un recipiente abierto: no significa que desaparezcan átomos. Burbujas o cambios de color son indicios, pero no demuestran por sí solos una reacción; hervir agua también produce burbujas.',
 ['Un sólido de 12 g reacciona con 8 g de gas en un sistema cerrado.','La masa total inicial es 20 g.','Si no se pierde material, la masa total final es 20 g.'],
 'Un balance de masa permite detectar pérdidas de material y revisar mediciones en bioprocesos.',[
 choice('Derretir hielo puro es principalmente un cambio…',['Químico','Físico','Nuclear'],1,'La sustancia sigue siendo H₂O; cambia su organización física.','Un cambio de estado no crea por sí solo un compuesto nuevo.'),
 choice('¿Qué caracteriza un cambio químico?',['Cualquier cambio de tamaño','Formación de especies químicas diferentes','Todo movimiento'],1,'La identidad de las especies cambia por reorganización de átomos y enlaces.','Romper un objeto no es necesariamente una reacción.'),
 num('En un recipiente cerrado reaccionan 7 g y 3 g. Sin pérdidas, ¿masa total final? ',10,'g','7 + 3 = 10 g. Se cuenta todo el sistema.',accepted={'g':1,'kg':1000,'mg':0.001}),
 choice('Un recipiente abierto pierde masa al producir gas. ¿Qué explicación revisar primero?',['La materia desapareció','El gas salió del sistema medido','Los átomos no pesan'],1,'La masa del recipiente y su contenido puede bajar cuando parte de la materia sale.','La frontera del sistema determina qué mide la balanza.','case'),
 multi('¿Qué observaciones por sí solas NO demuestran una reacción?',['Burbujas','Cambio de temperatura','Cambio de forma'],[0,1,2],'También hay procesos físicos que generan burbujas, cambian temperatura o forma. Se requiere evidencia de sustancias nuevas.'),
 choice('Agua hierve y produce burbujas. ¿Qué contienen principalmente?',['Vapor de agua','Oxígeno por ruptura obligatoria de H₂O','Sal'],0,'En ebullición el líquido pasa a gas conservando su identidad molecular.','Hervir no es descomponer agua.','prediction')])

add('chemistry','atoms','02 · Identidad atómica','chem-atom','Dentro del átomo','atomic structure',['chem-matter'],
 'Calcular protones, neutrones y electrones en átomos e iones sencillos.',
 'Número atómico Z = protones. Número másico A = protones + neutrones.',
 'El núcleo contiene protones positivos y neutrones sin carga eléctrica neta. Los electrones tienen carga negativa y se describen mediante estados cuánticos, no órbitas planetarias exactas. Z identifica el elemento; A cuenta protones y neutrones de un isótopo particular. En un átomo neutro el número de electrones iguala al de protones. Un catión tiene menos electrones que protones; un anión tiene más. La masa atómica promedio de la tabla no es lo mismo que el número másico de un isótopo.',
 ['Para ²³Na, Z = 11 y A = 23.','Neutrones = 23 − 11 = 12.','Na⁺ tiene 11 protones y 10 electrones.'],
 'Las propiedades y señales analíticas dependen de identidad atómica, isótopos y carga.',[
 num('Un átomo tiene Z = 6. ¿Cuántos protones tiene?',6,'','Z cuenta protones.'),
 num('Un isótopo tiene A = 14 y Z = 6. ¿Cuántos neutrones?',8,'','N = A − Z = 14 − 6 = 8.'),
 num('Mg²⁺ tiene Z = 12. ¿Cuántos electrones tiene?',10,'','La carga +2 indica pérdida de dos electrones: 12 − 2 = 10.'),
 choice('Si cambia el número de protones, cambia…',['El elemento','Solo la carga','Solo el recipiente'],0,'El elemento se define por Z.','Perder un electrón cambia la carga, no el elemento.'),
 match('Relaciona partícula y carga.', [('Protón','Positiva'),('Electrón','Negativa'),('Neutrón','Neta cero')],'La neutralidad del átomo resulta de compensar cargas, no de partículas sin carga solamente.'),
 choice('El cloro gana un electrón. ¿Qué forma?',['Catión','Anión','Un elemento nuevo'],1,'Ganar un electrón genera carga neta negativa sin cambiar Z.','Los electrones no determinan el número atómico.','prediction')])

add('chemistry','atoms','02 · Identidad atómica','chem-periodic','Leer la tabla periódica','periodic table',['chem-atom'],
 'Interpretar grupos y periodos y reconocer tendencias cualitativas con sus límites.',
 'La posición en la tabla se ordena por número atómico creciente.',
 'Las filas son periodos y las columnas grupos. En elementos representativos, un mismo grupo suele asociarse con patrones de electrones de valencia y propiedades semejantes, aunque no idénticas. Los metales tienden a perder electrones en muchas reacciones; los no metales pueden ganarlos o compartirlos. El radio atómico tiende a aumentar al bajar en un grupo y a disminuir de izquierda a derecha en un periodo. Las tendencias son herramientas cualitativas con excepciones: no reemplazan datos específicos.',
 ['Li y Na están en el grupo 1.','Ambos tienen un electrón de valencia en su átomo neutro fundamental.','Presentan semejanzas químicas, sin tener reactividad exactamente igual.'],
 'La posición periódica permite anticipar qué interacciones químicas conviene investigar.',[
 choice('¿Qué representa un grupo?',['Una columna','Una fila','Una mezcla'],0,'Los grupos son columnas de la tabla periódica.','Los periodos son filas.'),
 choice('¿Cómo se ordenan los elementos?',['Por masa de cualquier muestra','Por número atómico','Por orden alfabético'],1,'El número atómico aumenta a lo largo de la tabla.','La masa de una muestra no identifica la posición periódica.'),
 choice('Al bajar en un grupo, el radio atómico generalmente…',['Aumenta','Se vuelve cero','Siempre disminuye'],0,'Se ocupan niveles principales más externos y el radio suele aumentar.','Las tendencias tienen excepciones; no son identidades exactas.'),
 multi('¿Qué puedes inferir de dos elementos del mismo grupo representativo?',['Pueden tener química semejante','Son el mismo elemento','Comparten un patrón de valencia','Tienen siempre la misma masa'],[0,2],'El grupo indica semejanzas, no identidad de masa o de número atómico.'),
 text('¿Cómo se llaman las filas de la tabla?',['periodos','períodos','periodo','período'],'Los periodos son filas; los grupos, columnas.'),
 choice('Un metal del grupo 1 reacciona formando un ion simple. ¿Qué carga es una predicción razonable?',['+1','−3','+8'],0,'Perder su electrón de valencia produce un catión +1 en muchas reacciones.','Se trata de una predicción de química usual, no de una regla para toda condición.','prediction')])

add('chemistry','bonds','03 · Unir y contar','chem-bonds','Enlaces e interacciones','chemical bonding',['chem-periodic','bio-water'],
 'Distinguir enlace covalente, interacción iónica y polaridad sin confundirlas.',
 'Una molécula puede ser neutra y presentar regiones de carga parcial.',
 'En un enlace covalente se comparte densidad electrónica entre átomos. La diferencia de electronegatividad contribuye a que el enlace sea polar. La polaridad total de una molécula depende también de la geometría: CO₂ tiene enlaces polares, pero su geometría lineal simétrica compensa los dipolos. Los sólidos iónicos se estabilizan por atracciones entre cationes y aniones en una red, no por moléculas discretas de NaCl en el cristal. Un puente de hidrógeno es una interacción específica, distinta de un enlace covalente O–H.',
 ['En CO₂, cada enlace C=O tiene un dipolo.','La molécula es lineal.','Los dipolos opuestos se compensan y la molécula no tiene dipolo neto.'],
 'En bioquímica, distinguir enlaces de interacciones ayuda a explicar estructuras y disolución.',[
 choice('Un enlace covalente implica…',['Compartir densidad electrónica','Ausencia total de electrones','Solo contacto entre núcleos'],0,'La distribución de electrones compartida estabiliza el enlace.','Los electrones participan en los enlaces.'),
 choice('CO₂ tiene enlaces polares. Su molécula lineal simétrica es…',['Siempre un ion','Sin dipolo neto por compensación','Una mezcla'],1,'La suma vectorial de dipolos se anula en la geometría lineal ideal.','Enlace polar no garantiza molécula polar.'),
 match('Relaciona ejemplo y descripción.', [('NaCl cristalino','Red de iones'),('O–H dentro del agua','Enlace covalente polar'),('Entre dos aguas','Puede haber puente de hidrógeno')],'Los niveles de organización determinan qué interacción describimos.'),
 multi('¿Qué influye en la polaridad molecular?',['Polaridad de los enlaces','Geometría molecular','Color del recipiente'],[0,1],'La suma de dipolos depende de magnitud y dirección.'),
 choice('Separar moléculas de agua al evaporar rompe principalmente…',['Interacciones entre moléculas','Todos los enlaces O–H','Núcleos de oxígeno'],0,'La evaporación separa moléculas; no requiere descomponerlas.','No confundas interacción entre moléculas con enlace dentro de ellas.','case'),
 text('¿Cómo se llama un ion de carga positiva?',['cation','catión'],'El catión tiene menos electrones que protones.')])

add('chemistry','bonds','03 · Unir y contar','chem-mole','Del mol a la masa','mole and molar mass',['chem-atom','math-equations'],
 'Usar n = m/M y la relación estequiométrica más simple con unidades.',
 'Una masa molar relaciona gramos de sustancia con cantidad de sustancia en moles.',
 'El mol es la unidad SI de cantidad de sustancia. Un mol contiene exactamente 6,02214076 × 10²³ entidades especificadas, como moléculas o iones. La masa molar M expresa masa por mol. Si m está en gramos y M en g/mol, n = m/M da moles. Una fórmula química indica cuántos átomos de cada elemento hay en una entidad; los coeficientes de una ecuación ajustada indican relaciones de cantidades de sustancia. En ejercicios introductorios se usan masas molares redondeadas declaradas.',
 ['Para agua, usar M = 18 g/mol en este ejercicio.','Si m = 36 g, entonces n = 36 g ÷ 18 g/mol.','Resultado: 2 mol; no 2 gramos.'],
 'Contar moles conecta masas medibles con las proporciones de una reacción.',[
 num('Usa M(H₂O) = 18 g/mol. ¿Cuántos moles hay en 9 g de agua?',0.5,'mol','n = 9/18 = 0,5 mol.',accepted={'mol':1,'mmol':0.001}),
 num('Si n = 0,2 mol y M = 50 g/mol, ¿qué masa hay?',10,'g','m = nM = 0,2 × 50 = 10 g.',accepted={'g':1,'mg':0.001,'kg':1000}),
 choice('Un mol de moléculas de agua y un mol de moléculas de CO₂ tienen…',['La misma masa','El mismo número de moléculas','La misma masa molar'],1,'Un mol cuenta el mismo número de entidades, no la misma masa.','La masa depende de la identidad de las entidades.'),
 num('¿Cuántos átomos de hidrógeno hay en una molécula H₂O?',2,'','El subíndice 2 indica dos átomos de hidrógeno por molécula.'),
 choice('En 2 H₂ + O₂ → 2 H₂O, la razón molar H₂:O₂ es…',['1:2','2:1','1:1'],1,'Los coeficientes relacionan 2 mol de H₂ con 1 mol de O₂.','No cambies subíndices para ajustar una reacción.'),
 order('Ordena el cálculo de moles a partir de masa.', ['Identificar sustancia y masa molar','Expresar masa en gramos','Dividir masa por masa molar','Comprobar que la unidad final es mol'],'Las unidades g ÷ (g/mol) se reducen a mol.')])

add('physics','units','01 · Medir el mundo','phys-units','Magnitudes y unidades','physical quantities',[],
 'Convertir unidades de longitud, volumen y tiempo conservando la magnitud.',
 'Convertir unidades cambia el número escrito, no el objeto medido.',
 'Una magnitud física combina un valor y una unidad. El SI usa unidades básicas como metro, kilogramo y segundo; otras se derivan de ellas. Los prefijos representan potencias de diez: kilo es 10³, centi es 10⁻² y mili es 10⁻³. Para volumen, 1 L = 1000 mL = 10⁻³ m³. Convertir requiere multiplicar por factores equivalentes a uno. Las unidades elevadas a potencias deben convertirse elevando también el factor: 1 cm² = 10⁻⁴ m², no 10⁻² m².',
 ['250 mL × (1 L / 1000 mL).','Se cancelan mL.','Resultado: 0,250 L.'],
 'Un error de prefijo puede multiplicar por mil una concentración o una dosis simulada.',[
 num('Convierte 250 mL a L.',0.25,'L','250 ÷ 1000 = 0,25 L.',accepted={'L':1,'mL':0.001}),
 num('Convierte 2 min a segundos.',120,'s','2 × 60 = 120 s.',accepted={'s':1,'min':60}),
 num('Convierte 35 cm a metros.',0.35,'m','35 × 0,01 = 0,35 m.',accepted={'m':1,'cm':0.01,'mm':0.001}),
 choice('El prefijo mili significa…',['10³','10⁻³','10⁻⁶'],1,'Mili equivale a una milésima de la unidad.','Micro es una millonésima; kilo es mil.'),
 choice('1 cm² equivale a…',['0,01 m²','0,0001 m²','100 m²'],1,'(0,01 m)² = 0,0001 m².','Hay que elevar al cuadrado el factor de longitud.'),
 match('Relaciona magnitud y unidad SI.', [('Tiempo','s'),('Longitud','m'),('Masa','kg')],'El SI expresa masa en kilogramo, no en newton.')])

add('physics','units','01 · Medir el mundo','phys-measure','Medir también es estimar','measurement uncertainty',['phys-units','math-fractions'],
 'Calcular una media y reconocer límites de precisión y exactitud en mediciones.',
 'Repetir mediciones ayuda a observar variación, pero no elimina todos los errores.',
 'Una medición tiene resolución y fuentes de incertidumbre. La precisión describe concordancia entre mediciones repetidas; la exactitud se relaciona con cercanía al valor de referencia. Un instrumento mal calibrado puede dar resultados precisos pero sesgados. La media aritmética suma los valores y divide por el número de mediciones. Más decimales escritos no garantizan mejor información. Las réplicas y la calibración aportan información diferente: promediar no corrige automáticamente un sesgo sistemático.',
 ['Mediciones: 9, 10 y 11 mL.','Media = (9 + 10 + 11)/3.','Resultado: 10 mL; todavía hay variación y posibles sesgos.'],
 'Comparar instrumentos y controles ayuda a interpretar si un cambio biológico supera la variación de medida.',[
 num('La masa medida es 4, 5 y 6 g. ¿Cuál es su media?',5,'g','(4 + 5 + 6)/3 = 5 g.',accepted={'g':1,'kg':1000}),
 choice('Una balanza siempre añade 2 g. Promediar muchas lecturas…',['Elimina necesariamente ese sesgo','No corrige por sí solo el sesgo','Hace la masa cero'],1,'La calibración debe detectar el desplazamiento sistemático.','Repetir reduce ciertas variaciones, no todo error.'),
 choice('Lecturas muy cercanas entre sí pero alejadas de la referencia son…',['Precisas y posiblemente sesgadas','Necesariamente exactas','Prueba de que la referencia no existe'],0,'La concordancia entre repeticiones es precisión.','Precisión y exactitud no son equivalentes.'),
 multi('¿Qué conviene registrar junto a un valor medido?',['Unidad','Instrumento y resolución','Condiciones relevantes','Solo su color favorito'],[0,1,2],'El contexto permite evaluar y reproducir mediciones.'),
 num('Dos lecturas son 2,4 y 2,8 mL. ¿Su media?',2.6,'mL','(2,4 + 2,8)/2 = 2,6 mL.',accepted={'mL':1,'L':1000}),
 choice('Escribir 5,000000 g sin respaldo del instrumento…',['Mejora la exactitud','Puede comunicar una precisión injustificada','Calibra la balanza'],1,'Los dígitos deben corresponder a la información disponible.','Decimales extra no crean información.','case')])

add('physics','motion','02 · Describir movimiento','phys-vectors','Dirección y desplazamiento','vectors',['phys-units'],
 'Distinguir escalares y vectores y calcular desplazamientos en una dimensión.',
 'Elige una dirección positiva antes de sumar movimientos.',
 'Un escalar se describe por magnitud y unidad; un vector también requiere dirección. En una dimensión, un signo permite codificar sentidos opuestos. La distancia recorrida suma longitudes del trayecto y nunca es negativa. El desplazamiento es posición final menos posición inicial; puede ser cero aunque se haya recorrido distancia. Masa y temperatura son escalares; fuerza, velocidad y desplazamiento son vectores. Elegir otro origen no cambia un desplazamiento, pero invertir el eje cambia su signo.',
 ['Elegir derecha como positiva.','Avanzar +5 m y retroceder −2 m.','Desplazamiento = +3 m; distancia = 7 m.'],
 'La dirección importa al modelar fuerzas y transporte orientado en sistemas físicos.',[
 num('Posición inicial 2 m, final 8 m. ¿Desplazamiento con ese eje?',6,'m','Δx = 8 − 2 = 6 m.',accepted={'m':1,'cm':0.01}),
 num('Caminas 3 m a la derecha y 3 m a la izquierda. ¿Distancia total?',6,'m','La distancia suma ambas longitudes: 3 + 3 = 6 m.',accepted={'m':1,'cm':0.01}),
 num('En el mismo viaje de ida y vuelta, ¿desplazamiento?',0,'m','Posición final igual a inicial: Δx = 0.',accepted={'m':1,'cm':0.01}),
 multi('Selecciona vectores.',['Fuerza','Masa','Desplazamiento','Velocidad'],[0,2,3],'Estos vectores requieren dirección; masa es escalar.'),
 choice('Con derecha positiva, moverse a la izquierda tiene desplazamiento…',['Negativo','Siempre positivo','Sin unidad'],0,'El signo codifica el sentido con el eje elegido.','Negativo no significa longitud física negativa.'),
 choice('Cambias el origen de posición sin invertir el eje. El desplazamiento…',['Se duplica','No cambia','Se convierte en masa'],1,'Al restar posición final e inicial se cancela el mismo cambio de origen.','Posición y desplazamiento son conceptos distintos.','prediction')])

add('physics','motion','02 · Describir movimiento','phys-speed','Leer el movimiento','velocity',['phys-vectors','math-linear'],
 'Calcular velocidad media y leer la pendiente de una gráfica posición-tiempo.',
 'La pendiente relaciona un cambio vertical con el cambio horizontal correspondiente.',
 'La velocidad media en una dimensión es Δx/Δt, con Δt positivo. Puede ser negativa si el desplazamiento lo es. La rapidez media usa distancia total/tiempo y no es negativa. En un gráfico posición-tiempo, la pendiente indica velocidad: una recta representa velocidad constante y una recta horizontal reposo respecto del eje. La altura del gráfico no indica por sí sola velocidad. La aceleración describe cambios de velocidad, no simplemente estar en movimiento.',
 ['Posición de 2 m a 10 m en 4 s.','Δx = 8 m y Δt = 4 s.','Velocidad media = 2 m/s.'],
 'Las series temporales de posición permiten estimar movimiento de partículas simuladas.',[
 num('Desplazamiento de 12 m en 3 s. ¿Velocidad media?',4,'m/s','v = 12/3 = 4 m/s.',accepted={'m/s':1,'cm/s':0.01}),
 num('Desplazamiento −8 m en 4 s. ¿Velocidad media?',-2,'m/s','v = −8/4 = −2 m/s.',accepted={'m/s':1}),
 chart('¿Qué velocidad representa esta recta posición-tiempo?',['2 m/s','4 m/s','0 m/s'],0,[(0,1),(1,3),(2,5)],'Tiempo (s)','Posición (m)','La pendiente es (5 − 1)/(2 − 0) = 2 m/s.'),
 choice('Una línea horizontal en posición-tiempo indica…',['Posición constante','Velocidad creciente','Distancia infinita'],0,'La posición no cambia con el tiempo; la velocidad es cero.','La altura no es la velocidad.'),
 choice('En una vuelta completa al punto inicial, la velocidad media es…',['Cero','Igual a la rapidez siempre','Negativa necesariamente'],0,'El desplazamiento es cero, aunque la distancia sea mayor que cero.','Rapidez y velocidad media usan numeradores diferentes.'),
 choice('Un objeto con velocidad constante distinta de cero tiene aceleración…',['Cero','Siempre positiva','Igual a su posición'],0,'Si el vector velocidad no cambia, su variación temporal es cero.','Movimiento no implica aceleración.','case')])

add('physics','energy','03 · Fuerza y energía','phys-force','Fuerza neta y cambio','net force',['phys-speed','math-equations'],
 'Aplicar F neta = ma y diferenciar masa, peso y fuerza neta.',
 'Suma las fuerzas con sus signos antes de calcular aceleración.',
 'En el marco clásico e inercial, la segunda ley de Newton relaciona fuerza neta con aceleración: ΣF = ma para masa constante. No dice que toda fuerza individual sea igual a ma ni que se necesite fuerza neta para mantener velocidad constante. Masa se mide en kg; peso es una fuerza gravitatoria, aproximadamente mg cerca de la superficie terrestre. Aquí se usará g = 10 m/s² cuando se indique. Fuerzas equilibradas tienen suma cero, aunque cada una sea distinta de cero.',
 ['Empuje +10 N y rozamiento −4 N sobre 2 kg.','Fuerza neta = 6 N.','a = 6/2 = 3 m/s².'],
 'Balances de fuerzas ayudan a interpretar sedimentación y movimiento, antes de añadir modelos de fluidos.',[
 num('Masa 2 kg y fuerza neta 8 N. ¿Aceleración?',4,'m/s²','a = F/m = 8/2 = 4 m/s².',accepted={'m/s²':1,'m/s^2':1}),
 num('Fuerzas +9 N y −5 N. ¿Fuerza neta?',4,'N','9 − 5 = 4 N.',accepted={'N':1}),
 num('Masa 3 kg y g = 10 m/s². ¿Magnitud del peso?',30,'N','P = mg = 3 × 10 = 30 N.',accepted={'N':1}),
 choice('Si la fuerza neta es cero, un objeto puede…',['Seguir con velocidad constante','Solo permanecer quieto','Acelerar siempre'],0,'Velocidad constante incluye reposo y movimiento uniforme.','Fuerza neta cambia velocidad; no la mantiene necesariamente.'),
 match('Relaciona magnitud y unidad.', [('Masa','kg'),('Fuerza','N'),('Aceleración','m/s²')],'El peso se expresa en N, porque es una fuerza.'),
 choice('Dos fuerzas opuestas de 7 N actúan sobre un objeto. ¿Aceleración en ese eje?',['Cero','7 m/s² sin importar la masa','14 m/s²'],0,'La suma vectorial es cero y por tanto a = 0 para masa no nula.','Sumar magnitudes sin dirección daría un resultado incorrecto.','case')])

add('physics','energy','03 · Fuerza y energía','phys-energy','Trabajo y energía','work and energy',['phys-force'],
 'Calcular trabajo en un caso paralelo y energía cinética y reconocer conservación de energía.',
 'La energía puede transferirse entre sistemas y transformarse entre formas.',
 'El trabajo de una fuerza constante es W = F d cos θ. Para fuerza paralela al desplazamiento y mismo sentido, W = Fd; si es perpendicular, el trabajo es cero. La energía cinética traslacional es K = ½mv². El trabajo neto modifica K bajo el modelo clásico. La energía total se conserva al considerar el sistema y sus intercambios; la energía mecánica puede convertirse en energía interna por rozamiento. La potencia es energía transferida por unidad de tiempo. No es una cantidad de energía.',
 ['Fuerza paralela de 5 N a lo largo de 2 m.','W = 5 × 2 = 10 J.','Transferir 10 J en 2 s implica potencia media de 5 W.'],
 'Balances energéticos conectan mecánica, calor y posteriormente metabolismo.',[
 num('Fuerza de 6 N paralela y en el sentido de un desplazamiento de 3 m. ¿Trabajo?',18,'J','W = Fd = 6 × 3 = 18 J.',accepted={'J':1,'kJ':1000}),
 num('Masa 2 kg a 3 m/s. ¿Energía cinética?',9,'J','K = ½ × 2 × 3² = 9 J.',accepted={'J':1,'kJ':1000}),
 num('Se transfieren 20 J en 4 s. ¿Potencia media?',5,'W','P = E/t = 20/4 = 5 W.',accepted={'W':1,'kW':1000}),
 choice('Si duplicas la rapidez manteniendo la masa, K…',['Se duplica','Se cuadruplica','No cambia'],1,'K es proporcional a v²; (2v)² = 4v².','La dependencia es cuadrática.','prediction'),
 choice('El rozamiento reduce energía mecánica. ¿Desaparece energía total?',['Sí','No, parte pasa a energía interna y otras transferencias','Se convierte en masa negativa'],1,'La contabilidad total incluye energía interna del objeto y entorno.','Conservar energía total no implica conservar energía mecánica.'),
 choice('Una fuerza es perpendicular al desplazamiento. ¿Su trabajo en ese tramo?',['Cero','Fd siempre','Infinito'],0,'cos 90° = 0, por eso su contribución al trabajo es cero.','La dirección de la fuerza respecto del movimiento importa.','case')])

add('math','numbers','01 · Herramientas numéricas','math-fractions','Fracciones que significan algo','fractions',[],
 'Sumar, multiplicar y convertir fracciones conectándolas con proporciones.',
 'El denominador indica el tamaño de las partes; solo sumas directamente partes del mismo tamaño.',
 'Una fracción a/b expresa una división con b distinto de cero. Para sumar fracciones se usa un denominador común; multiplicar numeradores y denominadores sirve para multiplicación, no para suma. Fracciones equivalentes resultan de multiplicar ambos términos por el mismo número no nulo. Un porcentaje es una razón por cien. Para dividir por una fracción no nula, se multiplica por su recíproco. Una respuesta decimal, una fracción y una notación científica pueden representar el mismo valor.',
 ['Para 1/2 + 1/4, escribir 1/2 = 2/4.','Sumar 2/4 + 1/4 = 3/4.','El resultado equivale a 0,75 y a 75 %.'],
 'Proporciones y fracciones permiten interpretar composición de muestras y escalas.',[
 num('Calcula 1/2 + 1/4. Puedes escribir fracción o decimal.',0.75,'','2/4 + 1/4 = 3/4 = 0,75.'),
 num('Calcula (2/3) × (3/4).',0.5,'','6/12 = 1/2. Multiplica numeradores y denominadores.'),
 num('¿Qué porcentaje representa 3 de cada 5? Escribe el número porcentual.',60,'%','3/5 × 100 = 60 %.',accepted={'%':1}),
 num('Calcula (1/2) ÷ (1/4).',2,'','(1/2) × 4 = 2.'),
 choice('¿Cuál es equivalente a 2/3?',['4/6','3/4','2/6'],0,'Multiplicar ambos términos por 2 conserva el valor.','Cambiar solo un término cambia la razón.'),
 choice('Un estudiante dice 1/2 + 1/3 = 2/5. ¿Qué debe cambiar?',['Usar denominador común','Sumar solo denominadores','Nada'],0,'1/2 = 3/6 y 1/3 = 2/6; la suma es 5/6.','Sumar numeradores y denominadores directamente es un error frecuente.','case')])

add('math','numbers','01 · Herramientas numéricas','math-powers','Potencias y escalas','powers and roots',['math-fractions'],
 'Aplicar reglas de exponentes enteros y distinguir raíz principal de soluciones de una ecuación.',
 'Un exponente negativo indica recíproco, no un resultado necesariamente negativo.',
 'Para una base no nula, a⁰ = 1 y a⁻ⁿ = 1/aⁿ. Al multiplicar potencias de la misma base se suman exponentes; al elevar una potencia a otra se multiplican. Los paréntesis importan: (−3)² = 9, mientras −3² = −9 con la convención habitual. La raíz cuadrada principal √9 es 3; la ecuación x² = 9 tiene soluciones 3 y −3. En notación científica, c × 10ⁿ usa 1 ≤ |c| < 10 para números no nulos.',
 ['0,003 = 3 × 0,001.','0,001 = 10⁻³.','Entonces 0,003 = 3 × 10⁻³.'],
 'Las potencias de diez describen escalas celulares, cantidades moleculares y unidades pequeñas.',[
 num('Calcula 2³ × 2².',32,'','2^(3+2) = 2⁵ = 32.'),
 num('Calcula 10⁻².',0.01,'','10⁻² = 1/100 = 0,01.'),
 num('Calcula (−3)².',9,'','Los paréntesis incluyen el signo: (−3)(−3) = 9.'),
 num('Calcula la raíz cuadrada principal √49.',7,'','La raíz principal es no negativa: 7.'),
 multi('Selecciona todas las soluciones reales de x² = 16.',['4','−4','8','−8'],[0,1],'Tanto 4² como (−4)² son 16; no confundas la ecuación con √16.'),
 choice('¿Cuál es la notación científica normalizada de 0,00052?',['5,2 × 10⁻⁴','52 × 10⁴','5,2 × 10⁴'],0,'Mover la coma cuatro posiciones a la derecha exige multiplicar por 10⁻⁴.','Un número pequeño requiere exponente negativo con coeficiente entre 1 y 10.')])

add('math','algebra','02 · Álgebra con sentido','math-equations','Ecuaciones en equilibrio','equations',['math-powers'],
 'Resolver ecuaciones lineales y despejar una variable conservando equivalencia.',
 'Una igualdad conserva sus soluciones si aplicas la misma operación válida a ambos miembros.',
 'Resolver una ecuación es encontrar valores que hacen verdadera una igualdad. Para 3x + 2 = 14 se resta 2 en ambos lados y luego se divide por 3. No se trata de mover símbolos cambiando signos sin razón: cada paso conserva equivalencia. No se puede dividir por cero. Las ecuaciones pueden tener una, ninguna o infinitas soluciones. Para comprobar una propuesta se sustituye en la ecuación original. En fórmulas científicas, despejar permite identificar cómo calcular una magnitud a partir de otras.',
 ['3x + 2 = 14 → 3x = 12.','Dividir ambos lados por 3: x = 4.','Comprobar: 3 × 4 + 2 = 14.'],
 'Despejar n = m/M o v = d/t evita memorizar una fórmula distinta para cada incógnita.',[
 num('Resuelve 3x + 2 = 14. Escribe x.',4,'','Restar 2 da 3x = 12; dividir por 3 da x = 4.'),
 num('Resuelve 2(x − 1) = 10.',6,'','Dividir por 2: x − 1 = 5; sumar 1: x = 6.'),
 num('Resuelve 5 − x = 9.',-4,'','Restar 5: −x = 4; multiplicar por −1: x = −4.'),
 choice('De v = d/t, con t ≠ 0, se obtiene…',['d = vt','d = v/t','d = t/v siempre'],0,'Multiplicar ambos miembros por t da vt = d.','Despejar exige operar sobre ambos lados.'),
 choice('La ecuación x + 1 = x + 2 tiene…',['Una solución x = 1','Ninguna solución','Infinitas soluciones'],1,'Restar x deja 1 = 2, una contradicción.','No toda ecuación tiene una solución.'),
 order('Ordena la resolución de 2x + 4 = 12.', ['Restar 4 en ambos miembros','Obtener 2x = 8','Dividir ambos miembros por 2','Comprobar x = 4 en la ecuación original'],'La sustitución comprueba que las transformaciones fueron válidas.')])

add('math','algebra','02 · Álgebra con sentido','math-factor','Factorizar es reconocer estructura','factoring',['math-equations'],
 'Factorizar factor común, diferencia de cuadrados y trinomios cuadráticos simples.',
 'Factorizar transforma una suma en un producto equivalente; puedes verificar expandiendo.',
 'La distributividad permite escribir 3x + 6 = 3(x + 2). La diferencia de cuadrados cumple a² − b² = (a − b)(a + b). Para un trinomio x² + bx + c se buscan dos números que sumen b y cuyo producto sea c, si existen en el conjunto considerado. Un producto es cero cuando al menos uno de sus factores lo es; eso permite resolver ciertas ecuaciones. No se pueden cancelar términos de una suma como si fueran factores. La igualdad de expresiones debe respetar las restricciones de dominio si se divide.',
 ['x² + 5x + 6: buscar suma 5 y producto 6.','Los números son 2 y 3.','Factorización: (x + 2)(x + 3); al expandir se recupera el trinomio.'],
 'Factorizar prepara la simplificación de expresiones y el análisis de límites con restricciones de dominio.',[
 choice('Factoriza x² − 9.',['(x − 3)(x + 3)','(x − 9)(x + 1)','(x − 3)²'],0,'Es una diferencia de cuadrados: x² − 3².','(x − 3)² incluye −6x, que no está en la expresión original.'),
 choice('Factoriza 3x + 6.',['3(x + 2)','3(x + 6)','x(3 + 6)'],0,'El factor común es 3: 3x + 3×2 = 3(x+2).','Al expandir debes recuperar los dos términos.'),
 choice('Factoriza x² + 5x + 6.',['(x + 2)(x + 3)','(x + 1)(x + 6)','(x − 2)(x − 3)'],0,'2 + 3 = 5 y 2×3 = 6.','Necesitas cumplir simultáneamente suma y producto.'),
 multi('Selecciona las soluciones de x² − 9 = 0.',['3','−3','9','0'],[0,1],'(x − 3)(x + 3) = 0 implica x = 3 o x = −3.'),
 choice('Simplifica (x² − 9)/(x − 3). ¿Qué condición conserva la expresión original?',['x ≠ 3','x = 3 obligatoriamente','Ninguna restricción'],0,'Puedes obtener x + 3 solo para x ≠ 3; la expresión original no existe en x = 3.','Cancelar factores no restaura un valor excluido del dominio.','case'),
 num('Si x = 2, evalúa (x + 2)(x + 3).',20,'','(2+2)(2+3) = 4×5 = 20, igual a 2²+5×2+6.')])

add('math','functions','03 · Funciones para modelar','math-linear','Funciones y cambio lineal','linear functions',['math-equations'],
 'Evaluar funciones afines e interpretar pendiente e intercepto en un modelo.',
 'Una función asigna a cada entrada de su dominio una única salida.',
 'Una función relaciona entradas y salidas con una regla y un dominio. En el modelo afín f(x) = mx + b, m es la variación de salida por unidad de entrada y b = f(0). Si x tiene unidades, m y b también deben ser coherentes. Una pendiente negativa describe disminución, no una función inválida. Un modelo lineal útil en cierto intervalo puede fallar fuera de él. El dominio debe reflejar tanto las restricciones matemáticas como el contexto; una cantidad de células contadas no puede ser una fracción negativa.',
 ['C(t) = 2t + 3, con C en mg/L y t en min.','C(4) = 11 mg/L.','Pendiente: 2 (mg/L)/min; valor inicial: 3 mg/L.'],
 'Una recta de calibración conecta una señal instrumental con una magnitud dentro de un rango validado.',[
 num('Si f(x) = 2x + 3, calcula f(4).',11,'','2×4 + 3 = 11.'),
 num('Una recta pasa por (1,3) y (3,7). ¿Su pendiente?',2,'','m = (7−3)/(3−1) = 4/2 = 2.'),
 choice('En f(x) = −2x + 5, el intercepto f(0) es…',['5','−2','0'],0,'Al poner x = 0, queda 5.','La pendiente y el intercepto tienen funciones diferentes.'),
 chart('¿Qué muestra la gráfica y = 3x + 1?',['Salida inicial 1 y aumento de 3 por unidad','Salida inicial 3 y aumento de 1','Salida constante'],0,[(0,1),(1,4),(2,7)],'Entrada x','Salida y','La recta corta el eje vertical en 1 y aumenta 3 por cada unidad de x.'),
 choice('Una misma entrada tiene dos salidas distintas en una relación. ¿Es función de esa entrada?',['Sí siempre','No con esa asignación','Solo si son positivas'],1,'Una función requiere salida única para cada entrada del dominio.','Se permiten varias entradas con una misma salida, pero no al revés.'),
 choice('Una calibración lineal se comprobó entre 0 y 10 mg/L. Usarla a 1000 mg/L…',['Está automáticamente validado','Es extrapolar y requiere comprobar el modelo','Da siempre cero error'],1,'Fuera del rango estudiado pueden aparecer saturación y otras desviaciones.','Un buen ajuste en un intervalo no prueba validez universal.','case')])

add('math','functions','03 · Funciones para modelar','math-quadratic','Curvas y raíces','quadratic functions',['math-factor','math-linear'],
 'Interpretar raíces, vértice y signo de apertura de una función cuadrática simple.',
 'Las raíces son entradas donde la salida vale cero; el vértice es un punto de la curva.',
 'Una función cuadrática tiene forma ax² + bx + c con a ≠ 0. Su gráfica es una parábola: abre hacia arriba si a > 0 y hacia abajo si a < 0. Las raíces reales son intersecciones con el eje horizontal y pueden ser dos, una repetida o ninguna. La forma (x − h)² + k permite reconocer vértice (h,k) cuando el coeficiente del cuadrado es 1. Una raíz es un valor de x, no la altura del vértice. Para modelar fenómenos, una parábola suele ser una aproximación local y puede producir valores no físicos fuera de cierto dominio.',
 ['f(x) = (x − 2)² − 1.','El cuadrado es mínimo cuando x = 2: f(2) = −1.','Vértice (2,−1); raíces x = 1 y x = 3.'],
 'Interpretar máximos y mínimos prepara el estudio de derivadas y de modelos de respuesta biológica.',[
 num('Evalúa f(x) = x² − 4 en x = 3.',5,'','3² − 4 = 9 − 4 = 5.'),
 multi('Selecciona las raíces de f(x) = x² − 4.',['−2','2','4','0'],[0,1],'(x−2)(x+2)=0 produce las raíces −2 y 2.'),
 choice('¿Hacia dónde abre y = −x² + 3?',['Arriba','Abajo','Es una recta'],1,'El coeficiente de x² es negativo.','El término constante no decide la apertura.'),
 choice('El vértice de y = (x − 2)² + 1 es…',['(2,1)','(−2,1)','(1,2)'],0,'El cuadrado es mínimo en x = 2 y la salida allí es 1.','El signo dentro del paréntesis debe interpretarse como x − h.'),
 chart('En los puntos mostrados de y = x², ¿dónde está el mínimo?',['x = 0','x = −2','x = 2'],0,[(-2,4),(-1,1),(0,0),(1,1),(2,4)],'x','y','y alcanza 0 en x = 0 y el cuadrado no puede ser negativo.'),
 choice('¿Tiene y = x² + 1 alguna raíz real?',['Sí, x = 1','No, x² + 1 es al menos 1','Sí, x = 0'],1,'Para x real, x² ≥ 0; por tanto x² + 1 ≥ 1 y no es cero.','No toda parábola corta el eje horizontal.','case')])

# Full roadmap: these are concepts with explicit dependencies, not empty playable lessons.
planned={
 'biology':[
 ('bio-homeostasis','Homeostasis','homeostasis',['bio-membranes']),('bio-cycle','Ciclo celular y mitosis','cell cycle',['bio-cells']),('bio-meiosis','Meiosis','meiosis',['bio-cycle']),('bio-signaling','Señalización celular','cell signaling',['bio-membranes']),('bio-enzymes','Enzimas','enzymes',['bio-macromolecules','chem-bonds']),('bio-atp','Metabolismo y ATP','metabolism',['bio-enzymes']),('bio-photosynthesis','Fotosíntesis','photosynthesis',['bio-atp']),('bio-respiration','Respiración celular','cellular respiration',['bio-atp']),('bio-dna','ADN y ARN','DNA and RNA',['bio-macromolecules']),('bio-replication','Replicación','replication',['bio-dna']),('bio-expression','Transcripción y traducción','gene expression',['bio-dna']),('bio-mutation','Mutaciones','mutations',['bio-replication','bio-expression']),('bio-regulation','Regulación génica','gene regulation',['bio-expression']),('bio-genetics','Genética mendeliana y molecular','genetics',['bio-meiosis','bio-dna','math-probability']),('bio-micro','Microbiología','microbiology',['bio-cells','bio-atp']),('bio-immunology','Inmunología','immunology',['bio-signaling','bio-expression']),('bio-protein','Biología de proteínas','protein biology',['bio-expression','chem-enzyme']),('bio-physiology','Fisiología','physiology',['bio-homeostasis','bio-signaling']),('bio-plant','Biotecnología vegetal','plant biotechnology',['bio-photosynthesis','bio-genetics']),('bio-synthetic','Biología sintética conceptual','synthetic biology',['bio-regulation','bio-evidence'])],
 'chemistry':[
 ('chem-reactions','Reacciones y estequiometría','stoichiometry',['chem-mole','chem-change']),('chem-solutions','Disoluciones y concentración','solutions',['chem-mole','math-fractions']),('chem-dilution','Diluciones','dilution',['chem-solutions','math-equations']),('chem-gases','Gases','gases',['chem-mole','phys-temperature']),('chem-equilibrium','Equilibrio químico','chemical equilibrium',['chem-reactions']),('chem-ph','Ácidos, bases y pH','acids and bases',['chem-equilibrium','math-log']),('chem-buffer','Sistemas amortiguadores','buffers',['chem-ph']),('chem-thermo','Termodinámica química','thermodynamics',['phys-thermo','chem-reactions']),('chem-kinetics','Cinética química','chemical kinetics',['chem-reactions','math-linear']),('chem-redox','Oxidación y reducción','redox',['chem-atom','chem-reactions']),('chem-organic','Química orgánica','organic chemistry',['chem-bonds']),('chem-proteins','Aminoácidos y proteínas','amino acids',['chem-organic','bio-macromolecules']),('chem-lipids','Carbohidratos y lípidos','carbohydrates and lipids',['chem-organic']),('chem-enzyme','Cinética enzimática','enzyme kinetics',['bio-enzymes','chem-kinetics','math-functions-rational']),('chem-metabolism','Metabolismo y bioenergética','bioenergetics',['chem-thermo','chem-redox','bio-atp']),('chem-analytical','Técnicas analíticas conceptuales','analytical chemistry',['chem-solutions','phys-optics'])],
 'physics':[
 ('phys-fluids','Fluidos y presión','fluids',['phys-force']),('phys-temperature','Temperatura y calor','temperature and heat',['phys-energy']),('phys-thermo','Termodinámica','thermodynamics',['phys-temperature']),('phys-electric','Electricidad','electricity',['phys-force','math-equations']),('phys-waves','Ondas','waves',['phys-speed','math-trig']),('phys-optics','Óptica e instrumentos','optics',['phys-waves']),('phys-diffusion','Difusión','diffusion',['phys-measure','math-linear']),('phys-osmosis','Ósmosis y transporte','osmosis',['phys-diffusion','bio-membranes','chem-solutions']),('phys-surface','Fenómenos de superficie','surface phenomena',['bio-water','phys-fluids']),('phys-heat','Transferencia de calor','heat transfer',['phys-thermo']),('phys-instruments','Fundamentos de instrumentos','instrumentation',['phys-optics','phys-electric','phys-measure'])],
 'math':[
 ('math-polynomial','Polinomios','polynomials',['math-factor','math-quadratic']),('math-functions-rational','Funciones racionales','rational functions',['math-polynomial']),('math-exp','Funciones exponenciales','exponential functions',['math-powers','math-linear']),('math-log','Logaritmos','logarithms',['math-exp']),('math-trig','Trigonometría esencial','trigonometry',['math-equations']),('math-limits','Límites','limits',['math-functions-rational','math-factor']),('math-continuity','Continuidad','continuity',['math-limits']),('math-derivative','Derivadas','derivatives',['math-continuity']),('math-app-derivative','Aplicaciones de derivadas','derivative applications',['math-derivative']),('math-integral','Integrales','integrals',['math-derivative']),('math-ode','Ecuaciones diferenciales sencillas','differential equations',['math-integral','math-exp']),('math-probability','Probabilidad','probability',['math-fractions']),('math-stat','Estadística descriptiva','descriptive statistics',['math-fractions']),('math-inference','Inferencia estadística','statistical inference',['math-probability','math-stat']),('math-regression','Regresión','regression',['math-stat','math-linear']),('math-matrix','Matrices','matrices',['math-equations']),('math-models','Modelamiento biológico','biological modeling',['math-ode','math-regression'])],
 'integrated':[
 ('int-concentrations','Concentraciones en modelos de laboratorio','concentration models',['chem-dilution','phys-measure']),('int-enzyme','Enzimas y pH','enzyme and pH',['chem-ph','bio-enzymes','math-quadratic']),('int-growth','Crecimiento poblacional','population growth',['math-exp','bio-evidence']),('int-python','Programación científica conceptual','scientific programming',['math-linear']),('int-expression','Datos simulados de expresión génica','gene expression data',['bio-expression','math-stat','int-python']),('int-energy','Termodinámica y metabolismo','metabolic energy',['chem-metabolism','phys-thermo']),('int-transport','Modelos de transporte','transport models',['phys-osmosis','math-derivative']),('int-bioinformatics','Bioinformática e IA: fundamentos','bioinformatics and AI',['int-expression','math-regression','math-matrix']),('int-design','Diseño experimental y ética','experimental design and ethics',['bio-evidence','math-inference'])]}
for subject,items in planned.items():
 for cid,title,en,pre in items:
  # No fabricated teaching text: the roadmap is explicitly marked planned.
  concepts.append(dict(id=cid,subjectId=subject,title=title,english=en,prerequisites=pre,status='planned',origin='complementary' if cid in ['bio-synthetic','int-bioinformatics','math-matrix'] else 'mit-aligned' if cid in ['int-python','math-ode'] else 'foundation' if cid in ['math-polynomial','math-functions-rational','math-exp','math-log','math-trig'] else 'unab-aligned',explanation='Contenido planificado. Requiere desarrollo de explicaciones y revisión académica antes de convertirse en lección.',example='Consulta los prerrequisitos y las fuentes en la biblioteca.',sourceIds=['unab','mit']))

# Independent diagnostic questions; no copied lesson IDs, no inference of university readiness.
diagnostic=[
 ('math-fractions',num('Calcula 2/3 + 1/6.',5/6,'','4/6 + 1/6 = 5/6.',tolerance=0.0001)),
 ('math-equations',num('Resuelve 4x − 3 = 13.',4,'','4x = 16, luego x = 4.')),
 ('math-factor',choice('Factoriza x² − 16.',['(x − 4)(x + 4)','(x − 4)²','(x − 16)(x + 1)'],0,'x² − 4² es diferencia de cuadrados.','Expande para comprobar cada propuesta.')),
 ('math-factor',choice('Factoriza x² + 7x + 12.',['(x + 3)(x + 4)','(x + 2)(x + 6)','(x − 3)(x − 4)'],0,'3 + 4 = 7 y 3×4 = 12.','Deben cumplirse suma y producto.')),
 ('math-linear',num('Si f(x) = 3x − 1, calcula f(2).',5,'','3×2 − 1 = 5.')),
 ('math-quadratic',choice('Para estudiar qué valor se aproxima f(x) cerca de x = 2, ¿basta siempre con calcular f(2)?',['Sí, sin condiciones','No: importan valores cercanos y el dominio','No se pueden estudiar aproximaciones'],1,'Un límite describe comportamiento cercano y no exige que el valor puntual exista. Este es un sondeo introductorio.','Valor en un punto y comportamiento cercano no son idénticos.')),
 ('bio-cells',choice('¿Qué estructura está presente tanto en bacterias como en células animales?',['Núcleo','Ribosoma','Cloroplasto'],1,'Los ribosomas son compartidos por células procariontes y eucariontes.','Una bacteria no tiene núcleo membranoso.')),
 ('bio-membranes',choice('En equilibrio de difusión, ¿qué ocurre con las partículas?',['Dejan de moverse','Se mueven sin flujo neto','Desaparecen'],1,'El equilibrio es dinámico.','Flujo neto cero no implica inmovilidad.')),
 ('chem-atom',num('Átomo neutro con 8 protones: ¿cuántos electrones?',8,'','La neutralidad requiere igual número de protones y electrones.')),
 ('chem-matter',choice('Agua con azúcar completamente disuelta es…',['Mezcla homogénea','Elemento','Átomo'],0,'Contiene más de una sustancia con distribución uniforme.','Uniforme no equivale a sustancia pura.')),
 ('phys-units',num('Convierte 500 mg a g.',0.5,'g','500/1000 = 0,5 g.',accepted={'g':1,'mg':0.001})),
 ('phys-speed',num('Desplazamiento 15 m en 5 s: ¿velocidad media?',3,'m/s','15/5 = 3 m/s.',accepted={'m/s':1}))]
dqs=[]
for i,(cid,q) in enumerate(diagnostic):
 c=next(c for c in concepts if c['id']==cid); q.update(id=f'diagnostic-{i+1}',subjectId=c['subjectId'],level=1,conceptIds=[cid],prerequisites=[],sourceIds=c['sourceIds'],hints=['Responde sin ayuda para orientar la recomendación.']);dqs.append(q)
courses=[dict(id=s['id']+'-foundations',subjectId=s['id'],title=s['title']+' · Fundamentos',unitIds=[u['id'] for u in units if u['subjectId']==s['id']]) for s in subjects[:4]]
for name,data in [('catalog',dict(subjects=subjects,courses=courses,units=units,concepts=concepts,lessons=lessons,sources=sources,diagnostic=dqs)),('prerequisites',[dict(conceptId=c['id'],requires=c['prerequisites']) for c in concepts])]:
 (ROOT/'src/content'/f'{name}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(f'{len(lessons)} lessons, {sum(len(l["exercises"]) for l in lessons)} exercises, {len(concepts)} concepts, {len(dqs)} diagnostic items')
