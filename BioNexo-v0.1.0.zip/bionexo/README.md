# BioNexo · ciencia que se conecta

Aplicación móvil educativa **offline-first**, en español, orientada a construir bases para estudiar biotecnología. Android es el objetivo principal; el código también permite iOS. Esta entrega implementa un MVP: **24 lecciones, 144 ejercicios, 12 preguntas diagnósticas y un laboratorio de actividad enzimática/pH**. No es un producto oficial de UNAB, MIT ni OpenStax.

## Empezar en Windows, Linux o macOS

Requisitos: Node.js 22.13 o superior (recomendado Node 24 LTS), npm y Python 3 solo si se regenera contenido. Instalar dependencias requiere conexión. Estudiar en una aplicación nativa instalada no la requiere.

```bash
npm ci
npm start
```

En PowerShell, si se bloquea `npm.ps1`, usa `npm.cmd ci` y `npm.cmd start` sin cambiar la política global del equipo.

Con Expo Go **compatible con SDK 58**, escanea el QR desde Android. El teléfono debe poder alcanzar el servidor de desarrollo (normalmente ambos equipos en la misma Wi-Fi). Si Expo Go no admite este SDK, utiliza una compilación de desarrollo o un APK local. El servidor de desarrollo necesita estar encendido: Expo Go no es la entrega offline definitiva.

```bash
npm run android       # abre un emulador/dispositivo conectado; requiere SDK Android/adb
npm run web           # vista adaptable en navegador
npm run check         # TypeScript + integridad académica + pruebas de dominio/SQLite
npm run export:android # valida el empaquetado JS y recursos Android; NO genera un APK
npm run export:web
npx playwright install chromium
npm run test:e2e      # pruebas de interfaz web en tamaños móvil y escritorio
```

En Codex Cloud se pueden instalar dependencias, editar, ejecutar pruebas y exportar bundles. Abrir un teléfono/emulador, firmar y distribuir una aplicación son pasos distintos. La vista web usa almacenamiento local del navegador; **Android e iOS usan expo-sqlite**.

## Generar APK sin contratar un servicio

Instala Android Studio, el SDK Android correspondiente a la versión de React Native del proyecto, JDK compatible (consulta requisitos actuales), y configura `ANDROID_HOME` y `adb`. El primer prebuild/Gradle necesita descargar herramientas y dependencias. No se incluyen SDK ni binarios en el ZIP.

```bash
npm ci
npx expo prebuild --platform android
npx expo run:android --variant release
```

En Windows también puedes compilar directamente tras el prebuild:

```powershell
cd android
.\gradlew.bat assembleRelease
```

En Linux/macOS: `cd android` y `./gradlew assembleRelease`. APK esperado: `android/app/build/outputs/apk/release/app-release.apk`. La configuración generada suele usar firma de desarrollo para pruebas locales; **no es una política de firma para publicar en Google Play**. Comprueba la firma generada y conserva una clave propia si decides distribuir versiones permanentes.

Alternativa EAS: `npx eas-cli build --platform android --profile preview`. Requiere cuenta Expo/autenticación, acceso de red y cuota disponible; los límites pueden cambiar. No es necesaria para desarrollar ni para usar Gradle local. `eas.json` ya define un APK de distribución interna; no incluye identificadores de cuenta ni secretos.

Para comprobar el APK en tu teléfono: instalar, completar una lección, cerrar completamente, volver a abrir, activar modo avión, estudiar otra lección y guardar una sesión del laboratorio. Estas comprobaciones nativas **quedan pendientes de dispositivo real/emulador** en esta entrega.

## Qué funciona

- Onboarding sin cuentas; diagnóstico opcional y repetible.
- Cuatro rutas con tres unidades y dos lecciones por unidad, seis ejercicios por lección.
- Diez formatos: selección, selección múltiple, completar, emparejar, ordenar, numérico con unidades, gráfico, diagrama, predicción y caso.
- Respuestas con pistas, explicaciones y apoyo tras errores repetidos.
- Repasos por concepto, intercalado, práctica libre y revisión de errores.
- Perfil local persistente, XP sin recompensas duplicadas, racha, objetivos, desafío semanal e insignias.
- Laboratorio enzimático: pH, dos modelos, curvas, hipótesis, observaciones, comparación y cuaderno persistente.
- Modos claro/oscuro/sistema, objetivos táctiles, etiquetas accesibles y movimiento reducido.
- Exportación/importación JSON validada con confirmación antes de reemplazar progreso.

Todos los conceptos avanzados del mapa están identificados como **planificados**. No son ejercicios vacíos ni forman parte del conteo de 24 lecciones. Los porcentajes de dominio son heurísticos, no medidas psicométricas validadas. El contenido requiere revisión académica humana antes de utilizarse con fines formales.

## Estructura

| Carpeta | Responsabilidad |
|---|---|
| `app/` | Rutas Expo Router y pantallas de sesión |
| `src/content/` | Catálogo JSON offline y grafo de prerrequisitos |
| `src/domain/` | Modelos, evaluación, repaso, progreso, validación y ciencia del laboratorio |
| `src/storage/` | SQLite, migraciones, serialización transaccional y transferencias |
| `src/ui/` | Componentes, tema, estado y pantallas |
| `scripts/` | Autoría de contenido, validación y servidor local de pruebas |
| `tests/` | Pruebas unitarias, de SQLite real y navegación web |
| `docs/` | Arquitectura, currículo, fuentes, estado y ampliación |

Documentación: [arquitectura](docs/ARQUITECTURA.md), [currículo](docs/CURRICULO.md), [pedagogía](docs/PEDAGOGIA.md), [fuentes](docs/FUENTES.md), [ampliación](docs/AMPLIAR.md), [estado y verificación](docs/ESTADO.md).

## Desarrollo reproducible

Dependencias fijadas en `package-lock.json`; usa `npm ci`. El SDK se verificó contra su matriz oficial y `expo/bundledNativeModules.json`: Expo 58, React Native 0.88 y React 19.3. `npx expo install --check` comprueba la compatibilidad instalada. No se fijan versiones beta/canary. `.github/workflows/ci.yml` ejecuta controles y exportaciones en cada push/PR. La aplicación no usa fuentes remotas, secretos, backend obligatorio ni claves API.

El código es MIT; los contenidos originales de `src/content` y `scripts/build_content.py` se ofrecen bajo CC BY-NC-SA 4.0 (ver `CONTENT_LICENSE.md`). Las referencias externas conservan sus condiciones. No se redistribuyen libros, logotipos ni ilustraciones de terceros.
