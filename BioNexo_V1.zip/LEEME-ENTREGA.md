# BioNexo · Física y Matemáticas incorporadas

Entrega 2026-10-23. Commit 573d5b567c59af21c3fda686aff540358a1f5679.

Esta entrega contiene código fuente y el historial Git completo; NO es un APK.

MAT-PHY-01 añade 17 lecciones matemáticas y 11 físicas, 168 ejercicios originales. La app suma 88 lecciones/530 ejercicios. Biología (26/156) y Química (22/132) conservadas; Matemáticas 23/140 y Física 17/102. Quedan nueve conceptos integrados planificados y revisión docente pendiente. Introducciones no equivalen a cursos universitarios completos.

Comprobado: TypeScript estricto, catálogo/grafo y 266/266 pruebas; 88/88 E2E Chromium móvil/escritorio. 77 soluciones numéricas y tres gráficos contrastados. 60 lecciones/firmas y grafo previos exactos, perfil/XP/repasos y SQLite Node preservados al cerrar/reabrir/exportar/restaurar. Autoría determinista. Exportaciones web y Android/Hermes aprobadas; Hermes no genera APK ni prueba Android.

Auditoría actual: 4 high/0 critical, exit 1, por node-forge y dependientes. El aviso de braces fue retirado oficialmente el 2026-10-23; no se cambiaron dependencias. SEC-01/R-04 y publicación siguen bloqueados. No se ejecutaron APK nuevo, Android/TalkBack/EAS ni revisión docente.

## Retomar desde el historial

```bash
git clone bionexo-history.bundle bionexo-git
cd bionexo-git
npm ci
npm run check
npm start
```

O usa la carpeta bionexo/ con las fuentes ya extraídas. README.md incluye instrucciones Android/APK/Expo. Lee AGENTS.md, docs/PROGRESS.md, docs/FISICA_MATEMATICAS.md y docs/DEVELOPMENT_PLAN.md antes de editar. Fixtures previas congeladas: no regenerar para ocultar incompatibilidades. Formatos SQL/documento/perfil/checkpoint 3/3/1/1 intactos; sin migración requerida para esta ampliación.

El APK histórico entregado por separado NO contiene las expansiones de las cuatro rutas. Hace falta compilar otro artefacto identificado y comprobar actualización/SQLite/offline/accesibilidad en Android conservando datos. No reutilizar su política/hash como evidencia de un build nuevo.

Próximo incremento académico recomendado: primera unidad de Biotecnología integrada con las bases ahora disponibles, conservando las 88 lecciones. No repetir las cuatro rutas ni declarar cerrados seguridad o criterios nativos.

SHA256SUMS.txt permite verificar fuentes e historial. No se incluyen node_modules, herramientas descargadas, secretos ni credenciales.
