import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, mkdtempSync, rmSync } from "node:fs";
import { createHash } from "node:crypto";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { DatabaseSync } from "node:sqlite";
import { catalog, exerciseById, lessonById } from "../src/content";
import { grade, correctAnswer } from "../src/domain/answers";
import {
  initialState,
  recordAttempt,
  completeLesson,
  missingPrerequisites,
  remediation,
  reviewQueue,
} from "../src/domain/learning";
import {
  lessonSignature,
  sessionMatchesLesson,
  beginLessonSession,
  saveLessonCheckpoint,
  submitLessonAnswer,
} from "../src/domain/sessions";
import {
  createDocument,
  serializeDocument,
  parseBackup,
} from "../src/domain/progress-document";
import { SQLiteRepository, type SqlPort } from "../src/storage/repository";

const rawCatalog = readFileSync(
  "tests/fixtures/chemistry-baseline/catalog-1fe7c48.json",
  "utf8",
);
const baseline = JSON.parse(rawCatalog) as typeof catalog;
const signatures = JSON.parse(
  readFileSync("tests/fixtures/chemistry-baseline/signatures.json", "utf8"),
) as Record<string, string>;
const newLessons = catalog.lessons.filter(
  (l) =>
    l.subjectId === "chemistry" && !baseline.lessons.some((o) => o.id === l.id),
);
const profileRaw = readFileSync(
  "tests/fixtures/chemistry-baseline/progress-v3.json",
  "utf8",
);

test("Química: los 16 temas pendientes tienen dos tramos completos y 96 retos distintos", () => {
  const pending = baseline.concepts.filter(
    (c) => c.subjectId === "chemistry" && c.status === "planned",
  );
  assert.equal(pending.length, 16);
  assert.equal(newLessons.length, 16);
  assert.equal(newLessons.flatMap((l) => l.exercises).length, 96);
  for (const c of pending) {
    const current = catalog.concepts.find((x) => x.id === c.id)!;
    assert.equal(current.status, "implemented");
    const l = lessonById[c.id + "-lesson"]!;
    assert.equal(l.subjectId, "chemistry");
    assert.equal(l.exercises.length, 6);
    assert.equal(l.stages!.length, 2);
    assert.ok(l.explanation.length > 600);
    assert.ok(
      l.activation.length > 20 &&
        l.application.length > 40 &&
        l.summary !== l.objective,
    );
    assert.ok(l.stages!.every((s) => s.example.steps.length >= 3));
    assert.notDeepEqual(
      l.stages![0]!.example.steps,
      l.stages![1]!.example.steps,
    );
    assert.deepEqual(
      l.stages!.flatMap((s) => s.exerciseIds),
      l.exercises.map((e) => e.id),
    );
    assert.equal(l.reviewStatus, "requires-human-review");
    assert.ok(l.exercises.some((e) => e.type === "case"));
    assert.ok(
      l.exercises.every(
        (e) =>
          e.sourceIds.length &&
          e.hints.length >= 2 &&
          e.explanation.correct.length > 20,
      ),
    );
  }
  const prompts = newLessons.flatMap((l) => l.exercises.map((e) => e.prompt));
  assert.equal(new Set(prompts).size, 96);
});

test("Química: las 44 lecciones previas y TODAS sus firmas siguen exactas, incluida Biología", () => {
  assert.equal(
    createHash("sha256").update(rawCatalog).digest("hex"),
    "55f5672d03165c8eddf9344910115d9793c72710e01eeb974c4289b273cddba7",
  );
  assert.equal(baseline.lessons.length, 44);
  for (const l of baseline.lessons) {
    assert.deepEqual(lessonById[l.id], l, l.id);
    assert.equal(lessonSignature(lessonById[l.id]!), signatures[l.id], l.id);
  }
  for (const c of baseline.concepts.filter(
    (c) =>
      c.status === "implemented" ||
      ["biology", "integrated"].includes(c.subjectId),
  ))
    assert.deepEqual(
      catalog.concepts.find((x) => x.id === c.id),
      c,
      c.id,
    );
  for (const key of [
    "diagnostic",
    "practiceFamilies",
    "errorRules",
    "transferActivities",
    "subjects",
  ] as const)
    assert.deepEqual(catalog[key], baseline[key]);
  assert.deepEqual(
    catalog.concepts.map((c) => [c.id, c.prerequisites]),
    baseline.concepts.map((c) => [c.id, c.prerequisites]),
  );
  for (const source of baseline.sources)
    assert.deepEqual(
      catalog.sources.find((s) => s.id === source.id),
      source,
    );
  for (const u of baseline.units)
    assert.deepEqual(
      catalog.units.find((x) => x.id === u.id),
      u,
    );
});

test("Química: cursos, fuentes y bases cruzadas permanecen explícitos", () => {
  assert.equal(
    catalog.lessons.filter((l) => l.subjectId === "chemistry").length,
    22,
  );
  assert.equal(
    catalog.lessons
      .filter((l) => l.subjectId === "chemistry")
      .flatMap((l) => l.exercises).length,
    132,
  );
  assert.equal(
    catalog.units.filter((u) => u.subjectId === "chemistry").length,
    10,
  );
  assert.equal(
    catalog.courses.filter((c) => c.subjectId === "chemistry").length,
    4,
  );
  assert.equal(
    catalog.concepts.filter((c) => c.status === "planned").length,
    9,
  );
  const crossSubjectBases = [
    "phys-temperature",
    "phys-thermo",
    "math-log",
    "math-functions-rational",
    "phys-optics",
  ];
  for (const id of crossSubjectBases) {
    assert.equal(
      catalog.concepts.find((c) => c.id === id)!.status,
      "implemented",
    );
    assert.ok(lessonById[id + "-lesson"]);
  }
  assert.ok(
    missingPrerequisites(
      initialState(),
      lessonById["chem-enzyme-lesson"]!,
    ).includes("math-functions-rational"),
  );
  assert.ok(
    lessonById["bio-protein-lesson"]!.prerequisites.includes("chem-enzyme"),
  );
  for (const l of newLessons) {
    assert.ok(catalog.courses.some((c) => c.unitIds.includes(l.unitId)));
    for (const id of l.sourceIds) {
      const s = catalog.sources.find((s) => s.id === id)!;
      assert.ok(s);
      assert.match(s.url, /^https:\/\/(openstax.org|goldbook.iupac.org)\//);
      assert.match(s.note, /2026-10-23/);
    }
  }
});

for (const l of newLessons)
  test(`Química · respuestas, distractores, repetición y XP: ${l.id}`, () => {
    let state = initialState();
    for (let round = 0; round < 2; round++)
      for (const e of l.exercises) {
        assert.equal(grade(e, correctAnswer(e)), true, e.id);
        assert.equal(grade(e, { value: "NaN", unit: "unknown" }), false);
        if ("options" in e && typeof e.correct === "string")
          for (const o of e.options.filter((o) => o.id !== e.correct))
            assert.equal(grade(e, o.id), false);
        if (e.type === "multi") {
          assert.equal(grade(e, []), false);
          assert.equal(
            grade(
              e,
              e.options.map((o) => o.id),
            ),
            false,
          );
        }
        if (e.type === "numeric") {
          assert.equal(
            grade(e, { value: String(e.correct), unit: "g" }),
            false,
          );
          assert.equal(
            grade(e, { value: String(e.correct + 1), unit: e.unit }),
            false,
          );
        }
        state = recordAttempt(state, {
          id: `${round}:${e.id}`,
          exerciseId: e.id,
          conceptIds: e.conceptIds,
          answer: correctAnswer(e),
          correct: true,
          hinted: false,
          at: "2026-10-23T13:00:00Z",
          mode: "lesson",
        });
      }
    state = completeLesson(state, l, "0");
    state = completeLesson(state, l, "1");
    assert.equal(state.xp, 80);
    assert.equal(state.attempts.length, 12);
    assert.deepEqual(state.completedLessonIds, [l.id]);
    assert.ok(state.reviews[l.conceptIds[0]!]);
    assert.deepEqual(
      parseBackup(serializeDocument(createDocument(state))),
      state,
    );
  });

test("Química: cálculos independientes verifican resultados numéricos publicados y errores plausibles", () => {
  const cases: [string, number, number][] = [
    ["chem-reactions-v1-q3", (1.2 * 2) / 2, 2.4],
    ["chem-reactions-v1-q4", Math.min(5 / 2, 2) * 2, 5],
    ["chem-reactions-v1-q5", (100 * 7.5) / 10, 0.75],
    ["chem-solutions-v1-q2", 0.15 / (500 / 1000), 0.0003],
    ["chem-solutions-v1-q3", (0.08 * 250) / 1000, 20],
    ["chem-solutions-v1-q4", 5 / 50 / 0.4, 12.5],
    ["chem-dilution-v1-q2", (0.6 * 10) / 150, 0.0375],
    ["chem-dilution-v1-q3", (0.15 * 180) / 0.9, 1080],
    ["chem-dilution-v1-q4", 3 * 5, 3 + 5],
    ["chem-dilution-v1-q5", (0.2 * 0.02 + 0.4 * 0.02) / 0.04, 0.6],
    ["chem-gases-v1-q1", 25 + 273.15, 25],
    ["chem-gases-v1-q3", (0.2 * 8.314 * 300) / 5, 8.314],
    ["chem-gases-v1-q4", (90 * 4) / 6, 135],
    ["chem-equilibrium-v1-q2", 0.6 / 0.2, 1 / 3],
    ["chem-equilibrium-v1-q5", 0.9 / 0.3, 1],
    ["chem-ph-v1-q2", -Math.log10(1e-3), -3],
    ["chem-ph-v1-q3", 14 - 9, 9],
    ["chem-ph-v1-q4", 1e-3 / 1e-5, 2],
    ["chem-buffer-v1-q2", 6.2 + Math.log10(1), 0],
    ["chem-buffer-v1-q3", 5 + Math.log10(10), 15],
    ["chem-buffer-v1-q4", 8 - 3, 11],
    ["chem-thermo-v1-q2", 20 - (300 * 100) / 1000, 20 - 300 * 100],
    ["chem-thermo-v1-q3", -12 - 400 * (-20 / 1000), -20],
    ["chem-thermo-v1-q5", -18 + 7, -25],
    ["chem-kinetics-v1-q1", (0.16 - 0.1) / 20, 0.16 / 20],
    ["chem-kinetics-v1-q3", 0.02 * 0.3, 0.02 / 0.3],
    ["chem-redox-v1-q3", 3, -3],
    ["chem-redox-v1-q4", 6, 5],
    ["chem-organic-v1-q4", 2 + 2, 3],
    ["chem-proteins-v1-q3", 9 - 1, 9],
    ["chem-lipids-v1-q3", 7 - 1, 7],
    ["chem-enzyme-v1-q1", (20 * 4) / (4 + 4), 20],
    ["chem-enzyme-v1-q4", (18 * 0) / (2 + 0), 18],
    ["chem-metabolism-v1-q3", 16 - 28, 12],
    ["chem-metabolism-v1-q5", 9 - 6, 15],
    ["chem-analytical-v1-q2", (0.22 - 0.02) / 0.5, 0.22 / 0.5],
    ["chem-analytical-v1-q5", 2 * 0.3, 0.15],
  ];
  const numeric = newLessons
    .flatMap((l) => l.exercises)
    .filter((e) => e.type === "numeric");
  assert.deepEqual(
    cases.map((c) => c[0]).sort(),
    numeric.map((e) => e.id).sort(),
  );
  for (const [id, expected, wrong] of cases) {
    const e = exerciseById[id]!;
    assert.equal(e.type, "numeric");
    if (e.type !== "numeric") throw Error(id);
    assert.ok(Math.abs(e.correct - expected) < 1e-10, id);
    assert.equal(grade(e, { value: String(expected), unit: e.unit }), true, id);
    assert.equal(grade(e, { value: String(wrong), unit: e.unit }), false, id);
  }
});

test("Química: equivalencias, coma, exponentes y tolerancias conservan dimensión y escala", () => {
  for (const [id, value, unit] of [
    ["chem-solutions-v1-q2", "300", "mmol/L"],
    ["chem-solutions-v1-q2", "0,30", "M"],
    ["chem-dilution-v1-q3", "3e-2", "L"],
    ["chem-gases-v1-q3", "99768", "Pa"],
    ["chem-thermo-v1-q2", "-10000", "J/mol"],
    ["chem-kinetics-v1-q1", "3", "mmol/(L·s)"],
    ["chem-enzyme-v1-q1", "0.010", "mmol/min"],
    ["chem-analytical-v1-q2", "4e-4", "mol/L"],
  ])
    assert.equal(
      grade(exerciseById[id!]!, { value: value!, unit: unit! }),
      true,
      id!,
    );
  assert.equal(
    grade(exerciseById["chem-gases-v1-q3"]!, { value: "99.77", unit: "kPa" }),
    true,
  );
  assert.equal(
    grade(exerciseById["chem-gases-v1-q3"]!, { value: "99.8", unit: "kPa" }),
    false,
  );
  assert.equal(
    grade(exerciseById["chem-gases-v1-q1"]!, { value: "25", unit: "°C" }),
    false,
  );
});

test("Química: puntos de gráficos satisfacen ecuaciones y límites declarados", () => {
  const gas = exerciseById["chem-gases-v1-q5"]!,
    kin = exerciseById["chem-kinetics-v1-q4"]!,
    enzyme = exerciseById["chem-enzyme-v1-q5"]!,
    analytical = exerciseById["chem-analytical-v1-q3"]!;
  for (const e of [gas, kin, enzyme, analytical]) assert.equal(e.type, "chart");
  if (
    gas.type !== "chart" ||
    kin.type !== "chart" ||
    enzyme.type !== "chart" ||
    analytical.type !== "chart"
  )
    throw Error("missing charts");
  for (const p of gas.chart) assert.equal(p.y / p.x, 0.25);
  const slopes = kin.chart
    .slice(1)
    .map((p, i) => (p.y - kin.chart[i]!.y) / (p.x - kin.chart[i]!.x));
  assert.ok(slopes.every((s, i) => s > 0 && (!i || s < slopes[i - 1]!)));
  for (const p of enzyme.chart) {
    assert.ok(Math.abs(p.y - (12 * p.x) / (2 + p.x)) < 1e-10);
    assert.ok(p.y >= 0 && p.y < 12);
  }
  for (const p of analytical.chart)
    assert.ok(Math.abs(p.y - (0.02 + 0.5 * p.x)) < 1e-10);
});

test("Química: errores repetidos activan apoyo de bases, historial y repaso cercano", () => {
  let state = initialState();
  const l = lessonById["chem-reactions-lesson"]!,
    e = l.exercises[0]!;
  for (let i = 0; i < 2; i++)
    state = recordAttempt(state, {
      id: `wrong:${i}`,
      exerciseId: e.id,
      conceptIds: e.conceptIds,
      answer: "b",
      correct: false,
      hinted: false,
      at: "2026-10-23T13:00:00Z",
      mode: "lesson",
    });
  const help = remediation(state, e);
  assert.equal(help.needed, true);
  assert.ok(help.prerequisiteIds.includes("chem-mole"));
  assert.ok(help.easier);
  assert.ok(
    help.easier!.conceptIds.some((c) => help.prerequisiteIds.includes(c)),
  );
  assert.ok(
    reviewQueue(state, new Date("2026-10-24T13:00:00Z")).some((q) =>
      q.conceptIds.includes("chem-reactions"),
    ),
  );
  assert.equal(state.xp, 0);
  assert.equal(state.attempts.length, 2);
});

test("Química: perfil con sesión/feedback biológico anterior se conserva sin recalificar", () => {
  assert.equal(
    createHash("sha256").update(profileRaw).digest("hex"),
    "91688255681d73b7fe9e06d43eeefb17438402ef92ae3e190943794e08ae286f",
  );
  const old = parseBackup(profileRaw);
  assert.deepEqual(old, JSON.parse(profileRaw).state);
  assert.ok(old.attempts.some((a) => a.exerciseId === "bio-dna-v1-q1"));
  assert.ok(old.lessonSessions!["bio-dna-lesson"]!.card.submittedAttemptId);
  for (const session of Object.values(old.lessonSessions ?? {}))
    assert.equal(
      sessionMatchesLesson(session, lessonById[session.lessonId]!),
      true,
    );
  const next = beginLessonSession(
    old,
    lessonById["chem-dilution-lesson"]!,
    "chem-new",
    "2026-10-23T13:00:00Z",
  );
  assert.equal(next.xp, old.xp);
  assert.deepEqual(next.attempts, old.attempts);
  assert.deepEqual(next.labs, old.labs);
  for (const [id, session] of Object.entries(old.lessonSessions ?? {}))
    assert.deepEqual(next.lessonSessions![id], session);
  assert.deepEqual(parseBackup(serializeDocument(createDocument(next))), next);
});

test("SQLite: respuesta química, checkpoint y Biología previa sobreviven reapertura y restauración", async (t) => {
  const dir = mkdtempSync(join(tmpdir(), "bionexo-chemistry-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const path = join(dir, "profile.db");
  function open() {
    const db = new DatabaseSync(path);
    const port: SqlPort = {
      execAsync: async (s) => {
        db.exec(s);
      },
      runAsync: async (s, ...args) => {
        db.prepare(s).run(...args);
      },
      getFirstAsync: async <T>(
        s: string,
        ...args: (string | number | null)[]
      ) => (db.prepare(s).get(...args) as T) ?? null,
    };
    return { db, repo: new SQLiteRepository(port) };
  }
  let connection = open();
  const old = await connection.repo.restore(profileRaw);
  const l = lessonById["chem-solutions-lesson"]!,
    e = l.exercises[0]!,
    at = "2026-10-23T13:00:00Z";
  await connection.repo.update((s) =>
    beginLessonSession(s, l, "chem-sqlite", at),
  );
  await connection.repo.update((s) =>
    saveLessonCheckpoint(
      s,
      l,
      "chem-sqlite",
      0,
      { ...s.lessonSessions![l.id]!.card, answer: correctAnswer(e) },
      at,
    ),
  );
  const saved = await connection.repo.update((s) =>
    submitLessonAnswer(
      s,
      l,
      "chem-sqlite",
      0,
      e,
      correctAnswer(e),
      false,
      "0",
      at,
    ),
  );
  assert.equal(saved.xp, old.xp + 10);
  assert.deepEqual(saved.attempts.slice(0, -1), old.attempts);
  assert.deepEqual(
    saved.lessonSessions!["bio-dna-lesson"],
    old.lessonSessions!["bio-dna-lesson"],
  );
  assert.deepEqual(saved.labs, old.labs);
  const exported = await connection.repo.export();
  connection.db.close();
  connection = open();
  assert.deepEqual(await connection.repo.load(), saved);
  assert.deepEqual(await connection.repo.restore(exported), saved);
  connection.db.close();
});

test("Química: las posiciones correctas están distribuidas y los feedbacks siguen sus opciones", () => {
  const counts: Record<string, number> = {};
  for (const e of newLessons.flatMap((l) => l.exercises))
    if ("options" in e && typeof e.correct === "string") {
      counts[e.correct] = (counts[e.correct] ?? 0) + 1;
      assert.equal(e.explanation.distractors?.[e.correct], undefined);
      for (const option of e.options.filter((o) => o.id !== e.correct))
        assert.ok(
          e.explanation.distractors?.[option.id]?.includes(option.text),
        );
    }
  const total = Object.values(counts).reduce((a, b) => a + b, 0);
  assert.equal(Object.keys(counts).length, 3);
  assert.ok(
    Object.values(counts).every((n) => n / total < 0.55),
    JSON.stringify(counts),
  );
});
