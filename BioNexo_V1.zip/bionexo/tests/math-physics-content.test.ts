import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, mkdtempSync, rmSync } from "node:fs";
import { createHash } from "node:crypto";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { catalog, lessonById, exerciseById } from "../src/content";
import { correctAnswer, grade } from "../src/domain/answers";
import {
  initialState,
  recordAttempt,
  completeLesson,
  missingPrerequisites,
  remediation,
  reviewQueue,
} from "../src/domain/learning";
import {
  lessonSignature,
  sessionMatchesLesson,
  beginLessonSession,
  saveLessonCheckpoint,
  submitLessonAnswer,
} from "../src/domain/sessions";
import {
  parseBackup,
  createDocument,
  serializeDocument,
} from "../src/domain/progress-document";
import { SQLiteRepository, type SqlPort } from "../src/storage/repository";

const root = "tests/fixtures/math-physics-baseline/";
const catalogRaw = readFileSync(root + "catalog-1cb18a8.json", "utf8");
const baseline = JSON.parse(catalogRaw) as typeof catalog;
const signaturesRaw = readFileSync(root + "signatures.json", "utf8");
const signatures = JSON.parse(signaturesRaw) as Record<string, string>;
const profileRaw = readFileSync(root + "progress-v3.json", "utf8");
const newLessons = catalog.lessons.filter(
  (l) => !baseline.lessons.some((o) => o.id === l.id),
);
const at = "2026-10-23T15:00:00Z";

test("Física/Matemáticas: 28 temas antes planificados tienen 168 retos originales y dos tramos completos", () => {
  const pending = baseline.concepts.filter(
    (c) => ["math", "physics"].includes(c.subjectId) && c.status === "planned",
  );
  assert.equal(pending.length, 28);
  assert.equal(newLessons.length, 28);
  assert.equal(newLessons.flatMap((l) => l.exercises).length, 168);
  assert.equal(newLessons.filter((l) => l.subjectId === "math").length, 17);
  assert.equal(newLessons.filter((l) => l.subjectId === "physics").length, 11);
  for (const c of pending) {
    const l = lessonById[c.id + "-lesson"]!;
    assert.ok(l, c.id);
    assert.equal(
      catalog.concepts.find((x) => x.id === c.id)!.status,
      "implemented",
    );
    assert.equal(l.subjectId, c.subjectId);
    assert.equal(l.exercises.length, 6);
    assert.equal(l.stages!.length, 2);
    assert.ok(l.explanation.length > 600, l.id);
    assert.ok(
      l.example.length >= 3 &&
        l.activation.length > 20 &&
        l.application.length > 40,
    );
    assert.notEqual(l.summary, l.objective);
    assert.ok(l.stages!.every((s) => s.example.steps.length >= 3));
    assert.notDeepEqual(
      l.stages![0]!.example.steps,
      l.stages![1]!.example.steps,
    );
    assert.deepEqual(
      l.stages!.flatMap((s) => s.exerciseIds),
      l.exercises.map((e) => e.id),
    );
    assert.equal(l.reviewStatus, "requires-human-review");
    assert.ok(l.exercises.some((e) => e.type === "case"));
    assert.ok(
      l.exercises.every(
        (e) =>
          e.hints.length === 3 &&
          e.sourceIds.length &&
          e.explanation.correct.length > 20,
      ),
      l.id,
    );
  }
  const prompts = newLessons.flatMap((l) => l.exercises.map((e) => e.prompt));
  assert.equal(new Set(prompts).size, 168);
});

test("Física/Matemáticas: las 60 lecciones/firmas anteriores, fuentes, cursos y grafo siguen exactos", () => {
  assert.equal(
    createHash("sha256").update(catalogRaw).digest("hex"),
    "f745e5578c0b57b1f0c149606cc719a97c7203bd55f5c847bd80aa6aa5ff29b1",
  );
  assert.equal(
    createHash("sha256").update(signaturesRaw).digest("hex"),
    "446270a0cfde0f85feebcacc1ad5805dc7f75709c0f5fa0134a482725e7ef8e0",
  );
  assert.equal(baseline.lessons.length, 60);
  for (const l of baseline.lessons) {
    assert.deepEqual(lessonById[l.id], l, l.id);
    assert.equal(lessonSignature(lessonById[l.id]!), signatures[l.id], l.id);
  }
  for (const c of baseline.concepts.filter(
    (c) =>
      c.status === "implemented" || !["math", "physics"].includes(c.subjectId),
  ))
    assert.deepEqual(
      catalog.concepts.find((x) => x.id === c.id),
      c,
      c.id,
    );
  for (const key of [
    "diagnostic",
    "practiceFamilies",
    "transferActivities",
    "errorRules",
    "subjects",
  ] as const)
    assert.deepEqual(catalog[key], baseline[key]);
  assert.deepEqual(
    catalog.concepts.map((c) => [c.id, c.prerequisites]),
    baseline.concepts.map((c) => [c.id, c.prerequisites]),
  );
  for (const key of ["sources", "units", "courses"] as const)
    for (const old of baseline[key])
      assert.deepEqual(
        catalog[key].find((x) => x.id === old.id),
        old,
        old.id,
      );
});

test("Física/Matemáticas: cursos y prerrequisitos son reales sin presentar integración como terminada", () => {
  const expected = {
    math: { lessons: 23, exercises: 140, units: 11, courses: 4 },
    physics: { lessons: 17, exercises: 102, units: 8, courses: 3 },
  };
  for (const [subject, counts] of Object.entries(expected)) {
    const ls = catalog.lessons.filter((l) => l.subjectId === subject);
    assert.equal(ls.length, counts.lessons);
    assert.equal(ls.flatMap((l) => l.exercises).length, counts.exercises);
    assert.equal(
      catalog.units.filter((u) => u.subjectId === subject).length,
      counts.units,
    );
    assert.equal(
      catalog.courses.filter((c) => c.subjectId === subject).length,
      counts.courses,
    );
  }
  const planned = catalog.concepts.filter((c) => c.status === "planned");
  assert.equal(planned.length, 9);
  assert.ok(planned.every((c) => c.subjectId === "integrated"));
  for (const l of catalog.lessons)
    for (const cid of l.prerequisites) {
      assert.equal(
        catalog.concepts.find((c) => c.id === cid)!.status,
        "implemented",
        l.id + " -> " + cid,
      );
      assert.ok(lessonById[cid + "-lesson"]);
    }
  assert.ok(
    missingPrerequisites(
      initialState(),
      lessonById["math-limits-lesson"]!,
    ).includes("math-factor"),
  );
  for (const l of newLessons) {
    assert.ok(catalog.courses.some((c) => c.unitIds.includes(l.unitId)));
    for (const ref of l.sourceIds) {
      const s = catalog.sources.find((s) => s.id === ref)!;
      assert.ok(s);
      assert.match(s.url, /^https:\/\/openstax.org\/books\//);
      assert.match(s.note, /2026-10-23/);
    }
  }
});

for (const l of newLessons)
  test(`Física/Matemáticas · soluciones y XP único: ${l.id}`, () => {
    let state = initialState();
    for (let round = 0; round < 2; round++)
      for (const e of l.exercises) {
        assert.equal(grade(e, correctAnswer(e)), true, e.id);
        assert.equal(grade(e, { value: "NaN", unit: "invalid" }), false);
        if ("options" in e && typeof e.correct === "string")
          for (const option of e.options.filter((o) => o.id !== e.correct))
            assert.equal(grade(e, option.id), false);
        if (e.type === "multi") {
          assert.equal(grade(e, []), false);
          assert.equal(
            grade(
              e,
              e.options.map((o) => o.id),
            ),
            false,
          );
        }
        if (e.type === "numeric") {
          assert.equal(
            grade(e, { value: String(e.correct), unit: "invalid" }),
            false,
          );
          assert.equal(
            grade(e, { value: String(e.correct + 1), unit: e.unit }),
            false,
          );
        }
        state = recordAttempt(state, {
          id: `${round}:${e.id}`,
          exerciseId: e.id,
          conceptIds: e.conceptIds,
          answer: correctAnswer(e),
          correct: true,
          hinted: false,
          at,
          mode: "lesson",
        });
      }
    state = completeLesson(state, l, "0");
    state = completeLesson(state, l, "1");
    assert.equal(state.xp, 80);
    assert.equal(state.attempts.length, 12);
    assert.deepEqual(state.completedLessonIds, [l.id]);
    assert.ok(state.reviews[l.conceptIds[0]!]);
    assert.deepEqual(
      parseBackup(serializeDocument(createDocument(state))),
      state,
    );
  });

test("Física/Matemáticas: todas las soluciones numéricas se contrastan con cálculos independientes", () => {
  const cases: [string, number, number][] = [
    ["math-polynomial-v1-q2", 2, 3],
    ["math-polynomial-v1-q3", 2 * (-2) ** 2 - 3 * -2 + 1, -1],
    ["math-functions-rational-v1-q2", (6 ** 2 - 16) / (6 - 4), 8],
    ["math-functions-rational-v1-q4", 3 / (1 + 3), 3],
    ["math-trig-v1-q1", 3 / 5, 5 / 3],
    ["math-trig-v1-q2", 4 / 5, 5 / 4],
    ["math-trig-v1-q4", 90 / 180, 90],
    ["math-exp-v1-q1", 50 * 2 ** 3, 50 * 2 * 3],
    ["math-exp-v1-q2", 120 * 0.5 ** 2, 120 * 0.5 * 2],
    ["math-exp-v1-q5", 0.2 * 5, 0.2 / 5],
    ["math-log-v1-q1", Math.log2(32), 32 / 2],
    ["math-log-v1-q2", Math.log10(0.001), 3],
    ["math-log-v1-q5", Math.log2(16), 8],
    ["math-limits-v1-q2", 3 + 3, 0],
    ["math-limits-v1-q4", -2 - 2, 0],
    ["math-continuity-v1-q2", 4 + 4, 0],
    ["math-continuity-v1-q4", 2 ** 2 + 1, 2],
    ["math-derivative-v1-q1", 2 * 3, 3 ** 2],
    ["math-derivative-v1-q3", 3 * 2 ** 2 - 2, 2 ** 3 - 2 * 2 + 7],
    ["math-derivative-v1-q4", 4 * 3, 2 * 3 ** 2],
    ["math-app-derivative-v1-q1", 3, 16],
    ["math-app-derivative-v1-q2", 16, 3],
    ["math-app-derivative-v1-q4", 2, 5],
    ["math-integral-v1-q1", 2 ** 3 - 0 ** 3, 12],
    ["math-integral-v1-q2", 4 * 3, 4 / 3],
    ["math-integral-v1-q4", 2 ** 2 / 2 - (-2) ** 2 / 2, 4],
    ["math-integral-v1-q5", 5 - 2, -2],
    ["math-ode-v1-q2", 0.3 * 40, 40],
    ["math-ode-v1-q4", 2 + 3 * 4, 3 * 4],
    ["math-ode-v1-q5", 80 + 0.5 * 0.1 * 80, 80 * Math.exp(0.05)],
    ["math-probability-v1-q1", 2 / 6, 4 / 6],
    ["math-probability-v1-q2", 1 - 0.2, 0.2],
    ["math-probability-v1-q4", 0.5 * 0.4, 0.5 + 0.4],
    ["math-probability-v1-q5", 40 * 0.25, 0.25],
    ["math-stat-v1-q1", (3 + 5 + 7 + 9) / 4, 24],
    ["math-stat-v1-q2", (4 + 6) / 2, 6],
    ["math-stat-v1-q3", 12 - 2, 12],
    ["math-inference-v1-q3", 10 - 4, 7],
    ["math-regression-v1-q1", 1 + 2 * 4, 7],
    ["math-regression-v1-q2", 11 - 9, 9 - 11],
    ["math-matrix-v1-q2", 2 * 4 + 1 * 5, 2 * 4],
    ["math-matrix-v1-q3", 0 * 4 + 3 * 5, 3 * 4],
    ["math-models-v1-q1", 0.4 * 25 * (1 - 25 / 100), 0.4 * 25],
    ["math-models-v1-q2", 0.4 * 100 * (1 - 100 / 100), 40],
    ["math-models-v1-q4", 0.2 * 50 * (1 - 50 / 100), 10],
    ["phys-fluids-v1-q1", 20 / 0.005, 20 * 0.005],
    ["phys-fluids-v1-q2", 25 / 100 ** 2, 25 / 100],
    ["phys-fluids-v1-q4", 1000 * 10 * 0.3, (1000 * 10) / 0.3],
    ["phys-fluids-v1-q5", 100 + 3, 3],
    ["phys-temperature-v1-q2", 20 + 273.15, 20],
    ["phys-temperature-v1-q3", 27 - 15, 27 - 15 + 273.15],
    ["phys-temperature-v1-q4", 0.5 * 800 * 4, 800 * 4],
    ["phys-thermo-v1-q1", 700 - 250, 700 + 250],
    ["phys-thermo-v1-q3", 0 - -120, -120],
    ["phys-thermo-v1-q4", 90, 0],
    ["phys-electric-v1-q1", 2 / 4, 2 * 4],
    ["phys-electric-v1-q2", 10 / 200, 200 / 10],
    ["phys-electric-v1-q4", 8 * 0.25, 8 / 0.25],
    ["phys-waves-v1-q1", 1 / 0.25, 0.25],
    ["phys-waves-v1-q2", 8 * 0.5, 8 / 0.5],
    ["phys-waves-v1-q4", 12 / 6, 12 * 6],
    ["phys-optics-v1-q2", 1 / (1 / 12 - 1 / 24), 12],
    ["phys-optics-v1-q3", -24 / 24, 1],
    ["phys-optics-v1-q4", 1 / (1 / 10 - 1 / 5), 10],
    ["phys-diffusion-v1-q2", -0.2 * 3, 0.6],
    ["phys-diffusion-v1-q4", -2e-9 * 1000, 2e-6],
    ["phys-diffusion-v1-q5", 2 ** 2, 2],
    ["phys-osmosis-v1-q2", 0.01 * 1000, 0.01 / 1000],
    ["phys-osmosis-v1-q3", 1 * 0.1 * 8.314 * 300, 0.24942],
    ["phys-osmosis-v1-q5", 2 / 1, 1],
    ["phys-surface-v1-q2", 2 * 0.02 * 0.05, 0.02 * 0.05],
    ["phys-surface-v1-q4", (2 * 0.03) / 0.001, (4 * 0.03) / 0.001],
    ["phys-surface-v1-q5", 1 / (1 / 2), 0.5],
    ["phys-heat-v1-q2", (1 * 0.01 * 20) / 0.02, 1 * 0.01 * 20 * 0.02],
    ["phys-heat-v1-q3", 10 * 60, 10],
    ["phys-instruments-v1-q1", 40 * 10, 40 + 10],
    ["phys-instruments-v1-q4", 12.4 - 12.0, 12.0 - 12.4],
  ];
  const all = newLessons
    .flatMap((l) => l.exercises)
    .filter((e) => e.type === "numeric");
  assert.equal(cases.length, 77);
  assert.deepEqual(cases.map((c) => c[0]).sort(), all.map((e) => e.id).sort());
  for (const [id, expected, wrong] of cases) {
    const e = exerciseById[id]!;
    if (e.type !== "numeric") throw Error(id);
    assert.ok(Math.abs(e.correct - expected) < 1e-10, id);
    assert.equal(grade(e, { value: String(expected), unit: e.unit }), true, id);
    assert.equal(grade(e, { value: String(wrong), unit: e.unit }), false, id);
  }
});

test("Física/Matemáticas: equivalencias numéricas y conversiones mantienen dimensión, signo y precisión", () => {
  const cases: [string, string, string][] = [
    ["math-functions-rational-v1-q4", "3/4", ""],
    ["math-trig-v1-q4", "1/2", ""],
    ["math-probability-v1-q1", "0,33333", ""],
    ["math-derivative-v1-q4", "0.012", "g/h"],
    ["math-integral-v1-q5", "3e-3", "g"],
    ["phys-fluids-v1-q1", "4", "kPa"],
    ["phys-fluids-v1-q2", "25", "cm²"],
    ["phys-temperature-v1-q3", "12", "°C"],
    ["phys-temperature-v1-q4", "1.6", "kJ"],
    ["phys-electric-v1-q2", "50", "mA"],
    ["phys-electric-v1-q4", "2000", "mW"],
    ["phys-optics-v1-q4", "-0.1", "m"],
    ["phys-diffusion-v1-q4", "-0.002", "mmol/(m²·s)"],
    ["phys-osmosis-v1-q2", "0.010", "mol/L"],
    ["phys-osmosis-v1-q3", "0.24942", "kPa"],
    ["phys-surface-v1-q2", "2", "mN"],
    ["phys-heat-v1-q3", "0,6", "kJ"],
  ];
  for (const [id, value, unit] of cases)
    assert.equal(grade(exerciseById[id]!, { value, unit }), true, id);
  assert.equal(
    grade(exerciseById["phys-diffusion-v1-q4"]!, {
      value: "0",
      unit: "mol/(m²·s)",
    }),
    false,
  );
  assert.equal(
    grade(exerciseById["phys-diffusion-v1-q4"]!, {
      value: "-0.00000201",
      unit: "mol/(m²·s)",
    }),
    false,
  );
  assert.equal(
    grade(exerciseById["phys-temperature-v1-q2"]!, { value: "20", unit: "°C" }),
    false,
  );
  assert.equal(
    grade(exerciseById["phys-osmosis-v1-q3"]!, {
      value: "249.42",
      unit: "mol/L",
    }),
    false,
  );
});

test("Física/Matemáticas: dominios y contraejemplos no confunden simplificación, causalidad o convenciones", () => {
  const checks: [string, RegExp][] = [
    ["math-functions-rational-v1-q3", /original sigue sin estar definida/],
    ["math-limits-v1-q3", /No existe/],
    ["math-continuity-v1-q3", /No: sigue sin existir/],
    ["math-continuity-v1-q5", /Continua, aunque no derivable/],
    ["math-app-derivative-v1-q3", /candidato/],
    ["math-integral-v1-q3", /neta con signo/],
    ["math-probability-v1-q3", /excluyentes y no independientes/],
    ["math-inference-v1-q1", /tan o más extremos/],
    ["math-inference-v1-q4", /No se rechaza H₀; no se demuestra igualdad/],
    ["math-regression-v1-q6", /Extrapolación/],
    ["math-models-v1-q6", /falta validación/],
    ["phys-fluids-v1-q3", /mitad/],
    ["phys-thermo-v1-q2", /negativo/],
    ["phys-electric-v1-q3", /J\/C/],
    ["phys-optics-v1-q1", /f positivo/],
    ["phys-diffusion-v1-q3", /seguir moviéndose/],
    ["phys-osmosis-v1-q6", /No: solutos efectivos/],
    ["phys-surface-v1-q3", /4γ\/r/],
    ["phys-heat-v1-q1", /Radiación/],
    ["phys-instruments-v1-q2", /coexistir con sesgo/],
  ];
  for (const [id, pattern] of checks) {
    const e = exerciseById[id]!;
    if (!("options" in e) || typeof e.correct !== "string") throw Error(id);
    assert.match(e.options.find((o) => o.id === e.correct)!.text, pattern, id);
  }
  // Direct algebraic checks outside the quiz evaluator: factored identities and a removable exclusion.
  for (const x of [-5, -2, 0, 1, 4, 9])
    assert.equal((x - 4) * (x + 3), x * x - x - 12);
  assert.equal(3 ** 2 - 9, 0);
  assert.equal(3 - 3, 0); // original quotient undefined, even though nearby limit is 6.
});

test("Física/Matemáticas: curvas nuevas respetan datos, ecuación, signo y muestreo", () => {
  const exp = exerciseById["math-exp-v1-q4"]!,
    reg = exerciseById["math-regression-v1-q4"]!,
    wave = exerciseById["phys-waves-v1-q5"]!;
  const charts = newLessons
    .flatMap((l) => l.exercises)
    .filter((e) => e.type === "chart");
  assert.equal(charts.length, 3);
  if (exp.type !== "chart" || reg.type !== "chart" || wave.type !== "chart")
    throw Error("missing graph");
  for (const p of exp.chart) assert.equal(p.y, 20 * 2 ** p.x);
  for (const p of reg.chart)
    assert.equal(p.y - (1 + 2 * p.x), p.x === 2 ? -1 : 0);
  for (const p of wave.chart)
    assert.ok(Math.abs(p.y - Math.sin(2 * Math.PI * p.x)) < 1e-10);
  assert.equal(1.25 - 0.25, 1);
  assert.ok(wave.chart.some((p) => p.y < 0));
});

test("Física/Matemáticas: errores repetidos activan bases y repasos sin bloquear exploración", () => {
  for (const id of ["math-limits-lesson", "phys-osmosis-lesson"]) {
    let state = initialState();
    const l = lessonById[id]!,
      e = l.exercises[0]!;
    for (let i = 0; i < 2; i++)
      state = recordAttempt(state, {
        id: `wrong:${i}`,
        exerciseId: e.id,
        conceptIds: e.conceptIds,
        answer: "invalid",
        correct: false,
        hinted: false,
        at,
        mode: "lesson",
      });
    const help = remediation(state, e);
    assert.equal(help.needed, true);
    assert.ok(help.easier);
    assert.ok(
      help.easier!.conceptIds.some((cid) => help.prerequisiteIds.includes(cid)),
    );
    assert.ok(
      reviewQueue(state, new Date("2026-10-24T15:00:00Z")).some((q) =>
        q.conceptIds.includes(l.conceptIds[0]!),
      ),
    );
    assert.equal(state.xp, 0);
    const next = beginLessonSession(state, l, "explore", at);
    assert.ok(next.lessonSessions![l.id]);
  }
});

test("Física/Matemáticas: perfil con feedback biológico y químico mantiene intentos, XP y sesiones exactos", () => {
  assert.equal(
    createHash("sha256").update(profileRaw).digest("hex"),
    "2fe8dfdb2e50cc4529c84919d65b6bc4039c3f8d88d200b74732ba5ebeb6e0c7",
  );
  const old = parseBackup(profileRaw);
  assert.deepEqual(old, JSON.parse(profileRaw).state);
  for (const id of ["bio-dna-lesson", "chem-dilution-lesson"]) {
    const session = old.lessonSessions![id]!;
    assert.ok(session.card.submittedAttemptId);
    assert.equal(sessionMatchesLesson(session, lessonById[id]!), true);
  }
  let state = beginLessonSession(
    old,
    lessonById["math-limits-lesson"]!,
    "math-new",
    at,
  );
  state = beginLessonSession(
    state,
    lessonById["phys-osmosis-lesson"]!,
    "physics-new",
    at,
  );
  assert.equal(state.xp, old.xp);
  assert.deepEqual(state.attempts, old.attempts);
  assert.deepEqual(state.mastery, old.mastery);
  assert.deepEqual(state.reviews, old.reviews);
  assert.deepEqual(state.labs, old.labs);
  for (const [id, session] of Object.entries(old.lessonSessions ?? {}))
    assert.deepEqual(state.lessonSessions![id], session);
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(state))),
    state,
  );
});

test("SQLite: respuestas de ambas rutas y perfil biología/química sobreviven cierre y restauración", async (t) => {
  const dir = mkdtempSync(join(tmpdir(), "bionexo-math-physics-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const file = join(dir, "profile.db");
  function open() {
    const db = new DatabaseSync(file);
    const port: SqlPort = {
      execAsync: async (s) => {
        db.exec(s);
      },
      runAsync: async (s, ...args) => {
        db.prepare(s).run(...args);
      },
      getFirstAsync: async <T>(
        s: string,
        ...args: (string | number | null)[]
      ) => (db.prepare(s).get(...args) as T) ?? null,
    };
    return { db, repo: new SQLiteRepository(port) };
  }
  let connection = open();
  const old = await connection.repo.restore(profileRaw);
  for (const id of ["math-limits-lesson", "phys-osmosis-lesson"]) {
    const l = lessonById[id]!,
      e = l.exercises[0]!,
      sid = "sqlite-" + id;
    await connection.repo.update((s) => beginLessonSession(s, l, sid, at));
    await connection.repo.update((s) =>
      saveLessonCheckpoint(
        s,
        l,
        sid,
        0,
        { ...s.lessonSessions![l.id]!.card, answer: correctAnswer(e) },
        at,
      ),
    );
    await connection.repo.update((s) =>
      submitLessonAnswer(s, l, sid, 0, e, correctAnswer(e), false, "0", at),
    );
  }
  const saved = await connection.repo.load(),
    backup = await connection.repo.export();
  assert.equal(saved.xp, old.xp + 20);
  assert.deepEqual(saved.attempts.slice(0, -2), old.attempts);
  assert.deepEqual(saved.labs, old.labs);
  for (const [id, session] of Object.entries(old.lessonSessions ?? {}))
    assert.deepEqual(saved.lessonSessions![id], session);
  connection.db.close();
  connection = open();
  assert.deepEqual(await connection.repo.load(), saved);
  assert.deepEqual(await connection.repo.restore(backup), saved);
  connection.db.close();
});

test("Física/Matemáticas: la distribución de respuestas no favorece siempre primera opción", () => {
  for (const subject of ["math", "physics"]) {
    const counts: Record<string, number> = {};
    for (const e of newLessons
      .filter((l) => l.subjectId === subject)
      .flatMap((l) => l.exercises))
      if ("options" in e && typeof e.correct === "string") {
        counts[e.correct] = (counts[e.correct] ?? 0) + 1;
        assert.equal(e.explanation.distractors?.[e.correct], undefined);
        for (const option of e.options.filter((o) => o.id !== e.correct))
          assert.ok(
            e.explanation.distractors?.[option.id]?.includes(option.text),
          );
      }
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    assert.equal(Object.keys(counts).length, 3);
    assert.ok(
      Object.values(counts).every((n) => n / total < 0.55),
      JSON.stringify(counts),
    );
  }
});
