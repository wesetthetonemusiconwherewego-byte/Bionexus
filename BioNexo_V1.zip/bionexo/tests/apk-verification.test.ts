import test from "node:test";
import assert from "node:assert/strict";
import {
  mkdtempSync,
  writeFileSync,
  mkdirSync,
  rmSync,
  readFileSync,
  symlinkSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";
import {
  parseApkPolicy,
  verifyApk,
  type ToolRunner,
  type ToolResult,
} from "../scripts/readiness/apk";
import {
  applicationFingerprint,
  sha256File,
} from "../scripts/readiness/native";

// These tool outputs only exercise the inspector; they are NOT Android evidence.
function fixture(t: { after: (fn: () => void) => void }) {
  const root = mkdtempSync(join(tmpdir(), "bionexo-apk-"));
  t.after(() => rmSync(root, { recursive: true, force: true }));
  mkdirSync(join(root, "src"));
  writeFileSync(join(root, "src", "input.ts"), "synthetic source");
  const apk = join(root, "artifact with spaces.apk");
  writeFileSync(apk, "SYNTHETIC UNIT TEST, NOT AN APK");
  const policy = parseApkPolicy({
    ...JSON.parse(readFileSync("docs/release/preview-arm64-v1.json", "utf8")),
    sha256: sha256File(apk),
    bytes: readFileSync(apk).length,
    applicationFingerprint: applicationFingerprint(root),
  });
  const outputs: Record<string, ToolResult> = {
    signature: {
      status: 0,
      stderr: "",
      stdout: `Verifies\nVerified using v2 scheme (APK Signature Scheme v2): true\nNumber of signers: 1\nV2 Signer: certificate SHA-256 digest: ${policy.certificateSha256}\n`,
    },
    manifest: {
      status: 0,
      stderr: "",
      stdout: `package: name='${policy.package}' versionCode='1' versionName='0.1.0'\nminSdkVersion:'24'\ntargetSdkVersion:'36'\napplication: label='BioNexo' icon='res/icon'\n${policy.permissions.map((p) => `uses-permission: name='${p}'`).join("\n")}\nnative-code: 'arm64-v8a'\n`,
    },
    alignment: { status: 0, stderr: "", stdout: "" },
    entries: {
      status: 0,
      stderr: "",
      stdout: policy.requiredEntries.join("\n") + "\nclasses.dex\n",
    },
  };
  const calls: { command: string; args: string[] }[] = [];
  const runner: ToolRunner = (command, args) => {
    calls.push({ command, args });
    const key =
      args[0] === "-jar"
        ? "signature"
        : args[0] === "dump"
          ? "manifest"
          : args[0] === "-c"
            ? "alignment"
            : "entries";
    return outputs[key]!;
  };
  const verify = () =>
    verifyApk(apk, join(root, "tools with spaces"), policy, root, runner);
  return { root, apk, policy, outputs, calls, runner, verify };
}

test("APK: política identifica el artefacto previo y rechaza contratos incompletos", () => {
  const p = JSON.parse(
    readFileSync("docs/release/preview-arm64-v1.json", "utf8"),
  );
  assert.equal(
    parseApkPolicy(p).sourceCommit,
    "83eb426664228368e5816df2bb207329682e4df5",
  );
  for (const value of [
    null,
    [],
    {},
    { ...p, version: 2 },
    { ...p, sha256: "bad" },
    { ...p, bytes: 0 },
    { ...p, bytes: 250_000_001 },
    { ...p, certificateSha256: "" },
    { ...p, sourceCommit: "short" },
    { ...p, requiredEntries: ["AndroidManifest.xml"] },
    { ...p, abis: [] },
    { ...p, permissions: ["x", "x"] },
    { ...p, minSdk: 40, targetSdk: 36 },
  ])
    assert.throws(() => parseApkPolicy(value));
});

test("APK: inspección sintética completa exige comprobaciones sin certificar dispositivo", (t) => {
  const f = fixture(t),
    before = readFileSync(f.apk),
    policy = structuredClone(f.policy);
  const result = f.verify();
  assert.equal(result.status, "ARTIFACT_VERIFIED");
  assert.deepEqual(result.issues, []);
  assert.ok(Object.values(result.checks).every(Boolean));
  assert.equal(result.nativeAcceptance, "PENDING");
  assert.match(result.publicRelease, /BLOCKED/);
  assert.equal(f.calls.length, 4);
  assert.deepEqual(readFileSync(f.apk), before);
  assert.deepEqual(f.policy, policy);
  assert.ok(f.calls.every((c) => c.args.includes(f.apk)));
});

test("APK: acepta sdkVersion y formato Signer #1 sin confundir SHA de clave pública", (t) => {
  const f = fixture(t);
  f.outputs.manifest!.stdout = f.outputs.manifest!.stdout.replace(
    "minSdkVersion",
    "sdkVersion",
  );
  f.outputs.signature!.stdout =
    f.outputs.signature!.stdout.replace("V2 Signer:", "Signer #1:") +
    "Signer #1 public key SHA-256 digest: " +
    "0".repeat(64) +
    "\n";
  assert.equal(f.verify().status, "ARTIFACT_VERIFIED");
});

test("APK: hash/tamaño/fuentes incompatibles bloquean antes de ejecutar herramientas", (t) => {
  for (const change of ["hash", "size", "source"] as const) {
    const f = fixture(t);
    if (change === "hash")
      writeFileSync(f.apk, Buffer.alloc(f.policy.bytes, 0));
    if (change === "size") writeFileSync(f.apk, "changed length");
    if (change === "source")
      writeFileSync(join(f.root, "src", "input.ts"), "edited");
    assert.equal(f.verify().status, "BLOCKED", change);
    assert.equal(f.calls.length, 0);
  }
});

test("APK: firma no verificada, otra clave o varios firmantes no pasan", (t) => {
  for (const change of [
    "false",
    "certificate",
    "multi",
    "empty",
    "public-key-only",
  ]) {
    const f = fixture(t);
    if (change === "false")
      f.outputs.signature!.stdout = f.outputs.signature!.stdout.replace(
        ": true",
        ": false",
      );
    if (change === "certificate")
      f.outputs.signature!.stdout = f.outputs.signature!.stdout.replace(
        f.policy.certificateSha256,
        "0".repeat(64),
      );
    if (change === "multi")
      f.outputs.signature!.stdout = f.outputs.signature!.stdout.replace(
        "signers: 1",
        "signers: 2",
      );
    if (change === "empty") f.outputs.signature!.stdout = "";
    if (change === "public-key-only")
      f.outputs.signature!.stdout = f.outputs.signature!.stdout.replace(
        "certificate SHA-256",
        "public key SHA-256",
      );
    assert.equal(f.verify().status, "BLOCKED", change);
  }
});

test("APK: versión/package/SDK/ABI/debuggable distintos bloquean la actualización propuesta", (t) => {
  for (const [from, to] of [
    ["org.bionexo.learning", "org.other.app"],
    ["versionCode='1'", "versionCode='2'"],
    ["versionName='0.1.0'", "versionName='0.1.1'"],
    ["Version:'24'", "Version:'26'"],
    ["Version:'36'", "Version:'37'"],
    ["arm64-v8a", "x86_64"],
    ["application: ", "application-debuggable\napplication: "],
  ] as const) {
    const f = fixture(t);
    f.outputs.manifest!.stdout = f.outputs.manifest!.stdout.replace(from!, to!);
    assert.equal(f.verify().status, "BLOCKED", to);
  }
});

test("APK: permisos añadidos, prohibidos o ausentes se detectan incluso con política alterada", (t) => {
  for (const permission of [
    "SYSTEM_ALERT_WINDOW",
    "RECORD_AUDIO",
    "READ_EXTERNAL_STORAGE",
    "WRITE_EXTERNAL_STORAGE",
    "CAMERA",
  ]) {
    const f = fixture(t),
      p = `android.permission.${permission}`;
    f.outputs.manifest!.stdout += `uses-permission: name='${p}'\n`;
    assert.equal(f.verify().checks.permissions, false);
    if (permission !== "CAMERA") {
      f.policy.permissions.push(p);
      assert.equal(f.verify().checks.permissions, false);
    }
  }
  const f = fixture(t);
  f.outputs.manifest!.stdout = f.outputs.manifest!.stdout.replace(
    /^uses-permission:.*\n/gm,
    "",
  );
  assert.equal(f.verify().checks.permissions, false);
});

test("APK: cada herramienta fallida o sin respuesta impide dar verde", (t) => {
  for (const key of ["signature", "manifest", "alignment", "entries"])
    for (const status of [1, null]) {
      const f = fixture(t);
      f.outputs[key]!.status = status;
      assert.equal(f.verify().status, "BLOCKED", `${key}/${status}`);
    }
  const f = fixture(t);
  const result = verifyApk(f.apk, "missing", f.policy, f.root, () => {
    throw Error("missing executable");
  });
  assert.equal(result.status, "BLOCKED");
});

test("APK: bundle ausente y nombres sensibles incluidos nunca se omiten", (t) => {
  const f = fixture(t);
  f.outputs.entries!.stdout = "AndroidManifest.xml\n";
  assert.equal(f.verify().checks.embeddedResources, false);
  for (const entry of [
    "assets/.env",
    "assets/.env.local",
    "assets/release.keystore",
    "assets/key.jks",
    "assets/secret.pem",
    "assets/key.p12",
    "assets/key.pfx",
    "assets/private.key",
  ]) {
    f.outputs.entries!.stdout =
      f.policy.requiredEntries.join("\n") + "\n" + entry;
    assert.equal(f.verify().checks.sensitiveFilenames, false, entry);
  }
});

test("APK: archivo ausente/directorio/enlace se rechaza sin ejecutar herramientas", (t) => {
  const f = fixture(t);
  const link = join(f.root, "link.apk");
  symlinkSync(f.apk, link);
  for (const path of [join(f.root, "missing.apk"), f.root, link])
    assert.equal(
      verifyApk(path, "tools", f.policy, f.root, f.runner).status,
      "BLOCKED",
    );
  assert.equal(f.calls.length, 0);
});

test("APK: detecta sustitución durante la inspección", (t) => {
  const f = fixture(t);
  const runner: ToolRunner = (command, args) => {
    const result = f.runner(command, args);
    if (args[0] === "list") writeFileSync(f.apk, "changed after initial hash");
    return result;
  };
  assert.equal(
    verifyApk(f.apk, "tools", f.policy, f.root, runner).checks
      .unchangedArtifact,
    false,
  );
});

test("APK CLI: argumentos faltantes y política inválida devuelven bloqueo JSON/exit 1", (t) => {
  const f = fixture(t),
    policy = join(f.root, "policy.json");
  writeFileSync(policy, "{}");
  for (const args of [[], [f.apk, "missing tools", policy]]) {
    const run = spawnSync(
      process.execPath,
      ["--import", "tsx", resolve("scripts/verify-apk.ts"), ...args],
      { encoding: "utf8", timeout: 30_000 },
    );
    assert.equal(run.status, 1);
    assert.equal(JSON.parse(run.stdout).status, "BLOCKED");
  }
});
