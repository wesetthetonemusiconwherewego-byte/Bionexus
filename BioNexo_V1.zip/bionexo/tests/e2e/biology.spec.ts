import { test, expect, type Page } from "@playwright/test";
import { catalog, lessonById } from "../../src/content";
import type { Exercise } from "../../src/domain/models";
const key = "bionexo-state-v1";
const biology = catalog.lessons.filter(
  (l) => l.subjectId === "biology" && l.stages,
);
async function enter(page: Page) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: /Hola,/ })).toBeVisible();
}
async function answer(page: Page, e: Exercise) {
  if (e.type === "numeric")
    await page
      .getByRole("textbox", { name: "Respuesta numérica", exact: true })
      .fill(String(e.correct));
  else if (e.type === "multi")
    for (const id of e.correct)
      await page
        .getByRole("checkbox", {
          name: e.options.find((o) => o.id === id)!.text,
          exact: true,
        })
        .click();
  else if ("options" in e)
    await page
      .getByRole("radio", {
        name: e.options.find((o) => o.id === e.correct)!.text,
        exact: true,
      })
      .click();
  else throw Error("Unexpected exercise type in DNA lesson");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
}
test("Biología: las veinte lecciones nuevas tienen lector real y se incorporan a Biblioteca", async ({
  page,
}) => {
  await enter(page);
  await page.getByRole("tab", { name: "Aprender", exact: true }).click();
  await page.getByRole("button", { name: "Biología", exact: true }).click();
  await expect(
    page
      .getByText("Biología · Genética y biología molecular", { exact: true })
      .first(),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", {
      name: "Biología sintética conceptual",
      exact: true,
    }),
  ).toBeVisible();
  expect(biology).toHaveLength(20);
  await expect(
    page.getByRole("heading", { name: "Horizonte de la ruta", exact: true }),
  ).toHaveCount(0);
  for (const l of biology) {
    await page.goto(`/lesson/${l.id}`);
    await expect(
      page.getByRole("heading", { name: l.title, exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", {
        name: "Tu recorrido en esta lección",
        exact: true,
      }),
    ).toBeVisible();
    await expect(page.getByText(l.summary, { exact: true })).toHaveCount(0); // Summary belongs after practice.
    await expect(
      page.getByText(l.objective, { exact: true }).first(),
    ).toBeVisible();
  }
  await page.goto("/?tab=library");
  await page
    .getByRole("textbox", { name: "Buscar en el glosario", exact: true })
    .fill("ADN y ARN");
  await expect(
    page.getByRole("heading", { name: "ADN y ARN", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Estudiar con ejercicios", exact: true }),
  ).toBeVisible();
});
test("Biología: ADN completa dos tramos, reanuda feedback sin duplicar y conserva progreso offline", async ({
  page,
  context,
}) => {
  await enter(page);
  const l = lessonById["bio-dna-lesson"]!;
  await page.goto(`/lesson/${l.id}`);
  await page
    .getByRole("button", { name: "Practicar igualmente", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Comprender y distinguir", exact: true }),
  ).toBeVisible();
  await answer(page, l.exercises[0]!);
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
  for (const e of l.exercises.slice(1)) {
    if (e === l.exercises[3])
      await expect(
        page.getByRole("heading", {
          name: "Aplicar e interpretar evidencia",
          exact: true,
        }),
      ).toBeVisible();
    await answer(page, e);
    await page.getByRole("button", { name: "Continuar", exact: true }).click();
  }
  await expect(
    page.getByRole("heading", { name: "Expedición completada", exact: true }),
  ).toBeVisible();
  await expect(page.getByText(l.summary, { exact: true })).toBeVisible();
  await page
    .getByRole("button", { name: "Ver mi progreso", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Tu bitácora científica", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText(`1 de ${catalog.lessons.length} lecciones completadas`),
  ).toBeVisible();
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Tu bitácora científica", exact: true }),
  ).toBeVisible();
  await context.setOffline(true);
  await page
    .getByRole("button", { name: "Abrir biblioteca", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "ADN y ARN", exact: true }),
  ).toBeVisible();
  const s = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    key,
  );
  expect(s.xp).toBe(80);
  expect(s.attempts).toHaveLength(6);
  expect(s.completedLessonIds).toContain(l.id);
  expect(s.lessonSessions[l.id]).toBeUndefined();
  expect(s.reviews["bio-dna"]).toBeTruthy();
});
test("Biología avanzada: muestra curso conceptual y acceso al prerrequisito químico implementado", async ({
  page,
}) => {
  await enter(page);
  await page.goto("/lesson/bio-protein-lesson");
  await expect(
    page.getByText(/Áreas avanzadas: introducción conceptual/),
  ).toBeVisible();
  await expect(
    page.getByText("Cinética enzimática", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText(/Esta base de otra ruta sigue planificada/),
  ).toHaveCount(0);
  await expect(
    page.getByRole("button", {
      name: "Reforzar Cinética enzimática",
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Practicar igualmente", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: lessonById["bio-protein-lesson"]!.exercises[0]!.prompt,
      exact: true,
    }),
  ).toBeVisible();
});
