import { test, expect, type Page } from "@playwright/test";
import { catalog, lessonById } from "../../src/content";
import type { Exercise } from "../../src/domain/models";
const key = "bionexo-state-v1";
const math = catalog.lessons.filter(
  (l) => l.subjectId === "math" && l.stages && l.id !== "math-factor-lesson",
);
const physics = catalog.lessons.filter(
  (l) => l.subjectId === "physics" && l.stages,
);
async function enter(page: Page) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
    .click();
  await expect(page.getByRole("heading", { name: /Hola,/ })).toBeVisible();
}
async function answer(page: Page, e: Exercise, converted = false) {
  if (e.type === "numeric") {
    if (converted) {
      await page.getByRole("button", { name: "mol/L", exact: true }).click();
      await page
        .getByRole("textbox", { name: "Respuesta numérica", exact: true })
        .fill("0,010");
    } else
      await page
        .getByRole("textbox", { name: "Respuesta numérica", exact: true })
        .fill(String(e.correct));
  } else if (e.type === "multi") {
    for (const id of e.correct)
      await page
        .getByRole("checkbox", {
          name: e.options.find((o) => o.id === id)!.text,
          exact: true,
        })
        .click();
  } else if ("options" in e)
    await page
      .getByRole("radio", {
        name: e.options.find((o) => o.id === e.correct)!.text,
        exact: true,
      })
      .click();
  else throw Error("Unexpected format");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
}

test("Matemáticas: 17 lectores reales, mapa de cálculo y acceso desde Biblioteca", async ({
  page,
}) => {
  await enter(page);
  await page.getByRole("tab", { name: "Aprender", exact: true }).click();
  await page.getByRole("button", { name: "Matemáticas", exact: true }).click();
  await expect(
    page
      .getByText("Matemáticas · Cálculo: introducción", { exact: true })
      .first(),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Horizonte de la ruta", exact: true }),
  ).toHaveCount(0);
  await page
    .getByRole("heading", { name: "Límites", exact: true })
    .locator("..")
    .getByRole("button", { name: "Explorar explicación", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Límites", exact: true }),
  ).toBeVisible();
  expect(math).toHaveLength(17);
  for (const l of math) {
    await page.goto(`/lesson/${l.id}`);
    await expect(
      page.getByRole("heading", { name: l.title, exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", {
        name: "Tu recorrido en esta lección",
        exact: true,
      }),
    ).toBeVisible();
    await expect(
      page.getByText(l.objective, { exact: true }).first(),
    ).toBeVisible();
    await expect(page.getByText(l.summary, { exact: true })).toHaveCount(0);
  }
  await page.goto("/?tab=library");
  await page
    .getByRole("textbox", { name: "Buscar en el glosario", exact: true })
    .fill("Integrales");
  await page
    .getByRole("button", { name: "Estudiar con ejercicios", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Integrales", exact: true }),
  ).toBeVisible();
});

test("Física: 11 lectores, curso biofísico y base trigonométrica enlazada desde ondas", async ({
  page,
}) => {
  await enter(page);
  await page.getByRole("tab", { name: "Aprender", exact: true }).click();
  await page.getByRole("button", { name: "Física", exact: true }).click();
  await expect(
    page.getByText("Física · Biofísica: introducción", { exact: true }).first(),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", { name: "Horizonte de la ruta", exact: true }),
  ).toHaveCount(0);
  expect(physics).toHaveLength(11);
  for (const l of physics) {
    await page.goto(`/lesson/${l.id}`);
    await expect(
      page.getByRole("heading", { name: l.title, exact: true }),
    ).toBeVisible();
    await expect(
      page.getByRole("heading", {
        name: "Tu recorrido en esta lección",
        exact: true,
      }),
    ).toBeVisible();
    await expect(
      page.getByText(l.objective, { exact: true }).first(),
    ).toBeVisible();
    await expect(
      page.getByText(/Esta base de otra ruta sigue planificada/),
    ).toHaveCount(0);
  }
  await page.goto("/lesson/phys-waves-lesson");
  await page
    .getByRole("button", {
      name: "Reforzar Trigonometría esencial",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("heading", { name: "Trigonometría esencial", exact: true }),
  ).toBeVisible();
  await page.goto("/lesson/chem-ph-lesson");
  await page
    .getByRole("button", { name: "Reforzar Logaritmos", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Logaritmos", exact: true }),
  ).toBeVisible();
});

for (const id of ["math-limits-lesson", "phys-osmosis-lesson"])
  test(`${id}: dos tramos, feedback reanudable, unidades y progreso offline`, async ({
    page,
    context,
  }) => {
    await enter(page);
    const l = lessonById[id]!;
    await page.goto(`/lesson/${id}`);
    await page
      .getByRole("button", { name: "Practicar igualmente", exact: true })
      .click();
    await expect(
      page.getByRole("heading", {
        name: "Comprender y representar",
        exact: true,
      }),
    ).toBeVisible();
    for (let index = 0; index < l.exercises.length; index++) {
      const e = l.exercises[index]!;
      if (index === 3)
        await expect(
          page.getByRole("heading", {
            name: "Aplicar y comprobar condiciones",
            exact: true,
          }),
        ).toBeVisible();
      await answer(page, e, e.id === "phys-osmosis-v1-q2");
      if (index === 1) {
        await page.reload();
        await expect(
          page.getByRole("heading", { name: "Bien razonado", exact: true }),
        ).toBeVisible();
        const saved = await page.evaluate(
          (k) => JSON.parse(localStorage.getItem(k)!).state,
          key,
        );
        expect(saved.attempts).toHaveLength(2);
        expect(saved.xp).toBe(20);
        if (id === "phys-osmosis-lesson")
          expect(saved.attempts[1].answer).toEqual({
            value: "0,010",
            unit: "mol/L",
          });
      }
      await page
        .getByRole("button", { name: "Continuar", exact: true })
        .click();
    }
    await expect(
      page.getByRole("heading", { name: "Expedición completada", exact: true }),
    ).toBeVisible();
    await expect(page.getByText(l.summary, { exact: true })).toBeVisible();
    await page
      .getByRole("button", { name: "Ver mi progreso", exact: true })
      .click();
    await expect(
      page.getByRole("heading", {
        name: "Tu bitácora científica",
        exact: true,
      }),
    ).toBeVisible();
    await expect(
      page.getByText(`1 de ${catalog.lessons.length} lecciones completadas`),
    ).toBeVisible();
    await page.reload();
    await expect(
      page.getByRole("heading", {
        name: "Tu bitácora científica",
        exact: true,
      }),
    ).toBeVisible();
    await context.setOffline(true);
    await page
      .getByRole("button", { name: "Abrir biblioteca", exact: true })
      .click();
    await page
      .getByRole("textbox", { name: "Buscar en el glosario", exact: true })
      .fill(l.title);
    await expect(
      page.getByRole("heading", { name: l.title, exact: true }),
    ).toBeVisible();
    const s = await page.evaluate(
      (k) => JSON.parse(localStorage.getItem(k)!).state,
      key,
    );
    expect(s.xp).toBe(80);
    expect(s.attempts).toHaveLength(6);
    expect(s.completedLessonIds).toContain(l.id);
    expect(s.lessonSessions[l.id]).toBeUndefined();
    expect(s.reviews[l.conceptIds[0]!]).toBeTruthy();
  });
