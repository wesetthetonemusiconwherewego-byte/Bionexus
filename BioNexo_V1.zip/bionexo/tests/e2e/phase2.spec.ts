import { test, expect, type Page } from "@playwright/test";
import {
  catalog,
  lessonById,
  practiceExercises,
  exerciseById,
} from "../../src/content";
import type { Exercise } from "../../src/domain/models";
import { initialState, recordAttempt } from "../../src/domain/learning";
import {
  createDocument,
  serializeDocument,
} from "../../src/domain/progress-document";

export const profileKey = "bionexo-state-v1";
async function enter(page: Page) {
  await page.goto("/");
  await page
    .getByRole("button", { name: "Explorar sin diagnóstico", exact: true })
    .click();
}
async function correct(page: Page, exercise: Exercise) {
  if (exercise.type === "numeric")
    await page
      .getByRole("textbox", { name: "Respuesta numérica", exact: true })
      .fill(String(exercise.correct));
  else if (exercise.type === "multi") {
    for (const id of exercise.correct)
      await page
        .getByRole("checkbox", {
          name: exercise.options.find((o) => o.id === id)!.text,
          exact: true,
        })
        .click();
  } else if ("options" in exercise && typeof exercise.correct === "string")
    await page
      .getByRole("radio", {
        name: exercise.options.find((o) => o.id === exercise.correct)!.text,
        exact: true,
      })
      .click();
  else throw new Error("Formato no cubierto por helper");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "Bien razonado", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
}
test("número fuera de rango: no acreditar cero ni borrar el feedback al recargar", async ({
  page,
}) => {
  await enter(page);
  const lesson = lessonById["phys-vectors-lesson"]!;
  await page.goto("/lesson/" + lesson.id);
  await page
    .getByRole("button", {
      name: /^(Comenzar los retos|Practicar igualmente)$/,
    })
    .click();
  await correct(page, lesson.exercises[0]!);
  await correct(page, lesson.exercises[1]!);
  await page
    .getByRole("textbox", { name: "Respuesta numérica", exact: true })
    .fill("1/1e309");
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Una oportunidad para conectar",
      exact: true,
    }),
  ).toBeVisible();
  await page.reload();
  await expect(
    page.getByRole("heading", {
      name: "Una oportunidad para conectar",
      exact: true,
    }),
  ).toBeVisible();
  const state = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    profileKey,
  );
  expect(state.attempts.at(-1).correct).toBe(false);
  expect(state.attempts.at(-1).answer.value).toBe("1/1e309");
  expect(state.xp).toBe(20);
});

test("regla explícita: volver de una base conserva respuesta; repetición ofrece apoyo y retorno ayudado", async ({
  page,
}) => {
  await enter(page);
  await page.goto("/lesson/math-factor-lesson");
  await page
    .getByRole("button", { name: "Practicar igualmente", exact: true })
    .click();
  const exercise = exerciseById["math-factor-q1"]!;
  if (!("options" in exercise)) throw new Error("Formato inesperado");
  const wrong = exercise.options.find((o) => o.id === "c")!.text;
  await page.getByRole("radio", { name: wrong, exact: true }).click();
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Una idea para revisar: Distinguir cuadrados y conjugados",
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", {
      name: "Revisar base: Potencias y escalas",
      exact: true,
    })
    .click();
  await expect(
    page.getByRole("heading", { name: "Potencias y escalas", exact: true }),
  ).toBeVisible();
  await page.goto("/lesson/math-factor-lesson");
  await expect(
    page.getByRole("radio", { name: wrong, exact: true }),
  ).toBeChecked();
  await page.getByRole("button", { name: "Salir", exact: true }).click();
  await page.goto("/review?mode=errors");
  await page.getByRole("radio", { name: wrong, exact: true }).click();
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByText(
      "Esta regla coincide con 2 intentos incorrectos de tu historial. Puedes reconstruir la base antes de volver.",
      { exact: true },
    ),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Resolver un paso más sencillo", exact: true })
    .click();
  await correct(page, exerciseById["math-equations-q1"]!);
  await page
    .getByRole("button", { name: "Volver al problema original", exact: true })
    .click();
  await expect(
    page.getByRole("radio", { name: wrong, exact: true }),
  ).toBeChecked();
  await correct(page, exercise);
  const state = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    profileKey,
  );
  expect(state.attempts.at(-1).hinted).toBe(true);
  expect(state.lessonSessions["math-factor-lesson"].card.answer).toBe("c");
});

test("transferencia: datos simulados, ayuda y muestra inicial conservada tras practicar de nuevo", async ({
  page,
  context,
}) => {
  await enter(page);
  const activity = catalog.transferActivities![0]!;
  await page.goto("/transfer");
  await expect(
    page.getByRole("heading", {
      name: "Modelo supuesto · sin datos experimentales",
      exact: true,
    }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Comenzar transferencia", exact: true })
    .click();
  await context.setOffline(true);
  await page.getByRole("checkbox", { name: "t = 2 min", exact: true }).click();
  await page
    .getByRole("button", { name: "Comprobar respuesta", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: "Una idea para revisar: Buscar todas las raíces",
      exact: true,
    }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
  await page
    .getByRole("button", { name: "Ver pista 1 de 3", exact: true })
    .click();
  await correct(page, activity.exercises[1]!);
  await context.setOffline(false);
  await page
    .getByRole("button", { name: "Ver mi progreso", exact: true })
    .click();
  await expect(
    page
      .getByText("Muestra inicial: 0/2 retos resueltos sin pistas.", {
        exact: true,
      })
      .filter({ visible: true }),
  ).toBeVisible();
  await page.reload();
  await page
    .getByRole("button", { name: "Practicar transferencia", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Comenzar transferencia", exact: true })
    .click();
  for (const exercise of activity.exercises) await correct(page, exercise);
  await page
    .getByRole("button", { name: "Ver mi progreso", exact: true })
    .click();
  await expect(
    page
      .getByText("Muestra inicial: 0/2 retos resueltos sin pistas.", {
        exact: true,
      })
      .filter({ visible: true }),
  ).toBeVisible();
  await expect(
    page
      .getByText(
        /2\/2 respondidos · 1 con ayuda.*2\/2 respuestas más recientes correctas/,
      )
      .filter({ visible: true }),
  ).toBeVisible();
  const state = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    profileKey,
  );
  expect(state.attempts).toHaveLength(4);
  expect(state.xp).toBe(20);
});

test("familia: dos rondas con nuevos datos, historial persistente y un único premio compartido", async ({
  page,
}) => {
  await enter(page);
  for (let round = 0; round < 2; round++) {
    await page.goto("/?tab=practice");
    await page
      .getByRole("button", { name: "Practicar con nuevos datos", exact: true })
      .click();
    await page
      .getByRole("button", { name: "Comenzar variantes", exact: true })
      .click();
    for (const exercise of practiceExercises.slice(round * 3, round * 3 + 3)) {
      await expect(
        page.getByRole("heading", { name: exercise.prompt, exact: true }),
      ).toBeVisible();
      await correct(page, exercise);
    }
    await expect(
      page.getByRole("heading", { name: "Expedición completada", exact: true }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Ver mi progreso", exact: true })
      .click();
    await expect(
      page.getByRole("heading", {
        name: "Tu bitácora científica",
        exact: true,
      }),
    ).toBeVisible();
    await page.reload();
  }
  const state = await page.evaluate(
    (k) => JSON.parse(localStorage.getItem(k)!).state,
    profileKey,
  );
  expect(state.xp).toBe(10);
  expect(state.rewardedExerciseIds).toEqual([practiceExercises[0]!.id]);
  expect(state.attempts).toHaveLength(6);
  expect(
    state.attempts.map((a: { exerciseId: string }) => a.exerciseId),
  ).toEqual(practiceExercises.slice(0, 6).map((e) => e.id));
  expect(state.mastery["math-factor"].evidenceDays).toHaveLength(1);
  expect(catalog.lessons).toHaveLength(88);
});

test("razones: Home explica la base y el repaso muestra la fecha y el error reales sin modificar estado", async ({
  page,
}) => {
  let state = initialState();
  state.onboarded = true;
  state = recordAttempt(state, {
    id: "due-e2e",
    exerciseId: "math-fractions-q1",
    conceptIds: [],
    answer: { value: "99", unit: "" },
    correct: false,
    hinted: false,
    mode: "review",
    at: new Date(Date.now() - 20 * 60_000).toISOString(),
  });
  const raw = serializeDocument(createDocument(state));
  await page.goto("/");
  await page.evaluate(({ key, raw }) => localStorage.setItem(key, raw), {
    key: profileKey,
    raw,
  });
  await page.reload();
  await expect(
    page
      .getByText("Por qué esta lección", { exact: true })
      .filter({ visible: true }),
  ).toBeVisible();
  await page.getByRole("tab", { name: "Practicar", exact: true }).click();
  await expect(
    page
      .getByText(
        "Fracciones que significan algo: Un error registrado acortó este repaso.",
        { exact: true },
      )
      .filter({ visible: true }),
  ).toHaveCount(3);
  await expect(
    page
      .getByText(/Intervalo guardado: 10 minutos\./)
      .filter({ visible: true }),
  ).toHaveCount(3);
  expect(await page.evaluate((k) => localStorage.getItem(k), profileKey)).toBe(
    raw,
  );
  await page
    .getByRole("button", { name: "Comenzar repaso", exact: true })
    .click();
  await expect(page).toHaveURL(/\/review$/);
  await expect(
    page.getByRole("heading", {
      name: exerciseById["math-fractions-q1"]!.prompt,
      exact: true,
    }),
  ).toBeVisible();
  await expect(
    page.getByRole("heading", {
      name: "Por qué aparece este repaso",
      exact: true,
    }),
  ).toBeVisible();
  expect(await page.evaluate((k) => localStorage.getItem(k), profileKey)).toBe(
    raw,
  );
});

test("razones: calendario sin procedencia usa explicación prudente y mantiene práctica libre", async ({
  page,
}) => {
  const state = initialState();
  state.onboarded = true;
  state.reviews["math-factor"] = {
    conceptId: "math-factor",
    dueAt: new Date(Date.now() - 60_000).toISOString(),
    intervalDays: 7,
    step: 2,
    lapses: 0,
  };
  const raw = serializeDocument(createDocument(state));
  await page.goto("/");
  await page.evaluate(({ key, raw }) => localStorage.setItem(key, raw), {
    key: profileKey,
    raw,
  });
  await page.goto("/?tab=practice");
  await expect(
    page
      .getByText(
        /La fecha proviene de tu calendario guardado; el historial disponible no permite atribuirla/,
      )
      .filter({ visible: true }),
  ).toHaveCount(3);
  expect(await page.evaluate((k) => localStorage.getItem(k), profileKey)).toBe(
    raw,
  );
  await page
    .getByRole("button", { name: "Practicar con nuevos datos", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Comenzar variantes", exact: true })
    .click();
  await expect(
    page.getByRole("heading", {
      name: practiceExercises[0]!.prompt,
      exact: true,
    }),
  ).toBeVisible();
});
