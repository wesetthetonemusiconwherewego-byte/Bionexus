import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, mkdtempSync, rmSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { createHash } from "node:crypto";
import { catalog, exerciseById, lessonById } from "../src/content";
import { grade, correctAnswer } from "../src/domain/answers";
import {
  initialState,
  recordAttempt,
  completeLesson,
  missingPrerequisites,
} from "../src/domain/learning";
import {
  beginLessonSession,
  sessionMatchesLesson,
  submitLessonAnswer,
  saveLessonCheckpoint,
} from "../src/domain/sessions";
import { SQLiteRepository, type SqlPort } from "../src/storage/repository";
import {
  createDocument,
  parseBackup,
  serializeDocument,
} from "../src/domain/progress-document";

const baselineRaw = readFileSync(
  "tests/fixtures/biology-baseline/catalog-3734d2f.json",
  "utf8",
);
const baseline = JSON.parse(baselineRaw) as typeof catalog;
const newLessons = catalog.lessons.filter(
  (l) =>
    l.subjectId === "biology" &&
    !baseline.lessons.some((old) => old.id === l.id),
);

test("Biología: los 20 conceptos antes planificados ahora tienen enseñanza y 120 retos originales", () => {
  const pending = baseline.concepts.filter(
    (c) => c.subjectId === "biology" && c.status === "planned",
  );
  assert.equal(pending.length, 20);
  assert.equal(newLessons.length, 20);
  assert.equal(newLessons.flatMap((l) => l.exercises).length, 120);
  for (const c of pending) {
    const current = catalog.concepts.find((x) => x.id === c.id)!;
    assert.equal(current.status, "implemented");
    assert.ok(current.explanation.length > 400);
    const lesson = lessonById[c.id + "-lesson"]!;
    assert.equal(lesson.subjectId, "biology");
    assert.equal(lesson.exercises.length, 6);
    assert.equal(lesson.stages!.length, 2);
    assert.notEqual(lesson.summary, lesson.objective);
    assert.equal(lesson.reviewStatus, "requires-human-review");
    assert.ok(lesson.example.length >= 3);
    assert.deepEqual(
      lesson.stages!.flatMap((s) => s.exerciseIds),
      lesson.exercises.map((e) => e.id),
    );
    assert.ok(lesson.exercises.some((e) => e.type === "case"));
    assert.ok(
      lesson.exercises.every((e) => e.hints.length >= 2 && e.sourceIds.length),
    );
  }
  const signatures = newLessons
    .flatMap((l) => l.exercises)
    .map((e) =>
      JSON.stringify([e.prompt, "options" in e ? e.options : e.correct]),
    );
  assert.equal(new Set(signatures).size, 120);
});

test("Biología: no se altera ningún bloque anterior, dato implementado de otras materias o arista del grafo", () => {
  for (const old of baseline.lessons) assert.deepEqual(lessonById[old.id], old);
  for (const old of baseline.concepts.filter(
    (c) => c.status === "implemented" || c.subjectId === "integrated",
  ))
    assert.deepEqual(
      catalog.concepts.find((c) => c.id === old.id),
      old,
    );
  for (const key of [
    "diagnostic",
    "practiceFamilies",
    "transferActivities",
    "errorRules",
  ] as const)
    assert.deepEqual(catalog[key], baseline[key]);
  assert.deepEqual(
    catalog.concepts.map((c) => [c.id, c.prerequisites]),
    baseline.concepts.map((c) => [c.id, c.prerequisites]),
  );
});

test("Biología: cursos/niveles reales y bases aún planificadas no se presentan como terminadas", () => {
  assert.equal(
    catalog.courses.filter((c) => c.subjectId === "biology").length,
    4,
  );
  assert.equal(
    catalog.concepts.filter((c) => c.status === "planned").length,
    9,
  );
  const protein = lessonById["bio-protein-lesson"]!;
  assert.ok(
    missingPrerequisites(initialState(), protein).includes("chem-enzyme"),
  );
  assert.equal(
    catalog.concepts.find((c) => c.id === "chem-enzyme")!.status,
    "implemented",
  );
  for (const l of newLessons) {
    assert.ok(catalog.courses.some((c) => c.unitIds.includes(l.unitId)));
    const e = l.exercises[0]!;
    assert.equal(
      e.level,
      l.id === "bio-homeostasis-lesson"
        ? 1
        : l.id.match(
              /bio-(cycle|meiosis|signaling|enzymes|atp|photosynthesis|respiration)-/,
            )
          ? 2
          : l.id.match(
                /bio-(dna|replication|expression|mutation|regulation|genetics)-/,
              )
            ? 3
            : 4,
    );
  }
});

for (const lesson of newLessons)
  test(`Biología · soluciones y XP único: ${lesson.id}`, () => {
    let state = initialState();
    for (let round = 0; round < 2; round++)
      for (const e of lesson.exercises) {
        assert.equal(grade(e, correctAnswer(e)), true);
        assert.equal(grade(e, { value: "NaN", unit: "invalid" }), false);
        if ("options" in e && typeof e.correct === "string")
          for (const wrong of e.options.filter((o) => o.id !== e.correct))
            assert.equal(grade(e, wrong.id), false);
        state = recordAttempt(state, {
          id: `${round}:${e.id}`,
          exerciseId: e.id,
          conceptIds: e.conceptIds,
          answer: correctAnswer(e),
          correct: true,
          hinted: false,
          at: "2026-10-23T12:00:00Z",
          mode: "lesson",
        });
      }
    state = completeLesson(state, lesson, "0");
    state = completeLesson(state, lesson, "1");
    assert.equal(state.xp, 80);
    assert.equal(state.attempts.length, 12);
    assert.deepEqual(
      parseBackup(serializeDocument(createDocument(state))),
      state,
    );
  });

test("Biología: conteos y casos científicos discriminan confusiones de cromosomas, ADN, herencia y secuencias", () => {
  for (const [id, right, wrong, unit] of [
    ["bio-cycle-v1-q3", "6", "12", ""],
    ["bio-cycle-v1-q4", "12", "6", ""],
    ["bio-meiosis-v1-q3", "5", "10", ""],
    ["bio-atp-v1-q4", "-15", "15", "kJ/mol"],
    ["bio-respiration-v1-q4", "6", "36", ""],
    ["bio-dna-v1-q5", "20", "10", ""],
    ["bio-genetics-v1-q4", "1/4", "3/4", ""],
    ["bio-genetics-v1-q5", "1/2", "1/4", ""],
    ["bio-synthetic-v1-q4", "1", "3", ""],
  ] as const) {
    assert.equal(grade(exerciseById[id]!, { value: right, unit }), true, id);
    assert.equal(grade(exerciseById[id]!, { value: wrong, unit }), false, id);
  }
  const complement = exerciseById["bio-dna-v1-q4"]!;
  assert.equal(grade(complement, "b"), true);
  assert.equal(grade(complement, "a"), false);
});

test("Biología: el perfil y checkpoint anteriores se mantienen exactos y compatibles al ampliar catálogo", () => {
  const raw = readFileSync(
    "tests/fixtures/progress-pre-phase45-v3.json",
    "utf8",
  );
  assert.equal(
    createHash("sha256").update(raw).digest("hex"),
    "cb2ce6187f255f63d761f5371d9701b55186e7c3f66b308f9d483a68f828c8dc",
  );
  const old = parseBackup(raw);
  assert.deepEqual(old, JSON.parse(raw).state);
  for (const session of Object.values(old.lessonSessions ?? {}))
    assert.equal(
      sessionMatchesLesson(session, lessonById[session.lessonId]!),
      true,
    );
  const updated = beginLessonSession(
    old,
    lessonById["bio-dna-lesson"]!,
    "biology-new",
    "2026-10-23T12:00:00Z",
  );
  assert.deepEqual(updated.attempts, old.attempts);
  assert.equal(updated.xp, old.xp);
  assert.deepEqual(updated.labs, old.labs);
  for (const [id, session] of Object.entries(old.lessonSessions ?? {}))
    assert.deepEqual(updated.lessonSessions![id], session);
  assert.deepEqual(
    parseBackup(serializeDocument(createDocument(updated))),
    updated,
  );
});

test("SQLite: respuesta biológica nueva, checkpoint y perfil anterior sobreviven reapertura/restauración", async (t) => {
  const dir = mkdtempSync(join(tmpdir(), "bionexo-biology-"));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const path = join(dir, "profile.db");
  const open = () => {
    const db = new DatabaseSync(path);
    const port: SqlPort = {
      execAsync: async (sql) => {
        db.exec(sql);
      },
      runAsync: async (sql, ...args) => {
        db.prepare(sql).run(...args);
      },
      getFirstAsync: async <T>(
        sql: string,
        ...args: (string | number | null)[]
      ) => (db.prepare(sql).get(...args) as T) ?? null,
    };
    return { db, repo: new SQLiteRepository(port) };
  };
  let connection = open();
  const raw = readFileSync(
    "tests/fixtures/progress-pre-phase45-v3.json",
    "utf8",
  );
  const old = await connection.repo.restore(raw);
  const lesson = lessonById["bio-dna-lesson"]!,
    e = lesson.exercises[0]!;
  await connection.repo.update((s) =>
    beginLessonSession(s, lesson, "dna-session", "2026-10-23T12:00:00Z"),
  );
  await connection.repo.update((s) =>
    saveLessonCheckpoint(
      s,
      lesson,
      "dna-session",
      0,
      { ...s.lessonSessions![lesson.id]!.card, answer: correctAnswer(e) },
      "2026-10-23T12:00:00Z",
    ),
  );
  const saved = await connection.repo.update((s) =>
    submitLessonAnswer(
      s,
      lesson,
      "dna-session",
      0,
      e,
      correctAnswer(e),
      false,
      "0",
      "2026-10-23T12:00:01Z",
    ),
  );
  const backup = await connection.repo.export();
  assert.equal(saved.xp, old.xp + 10);
  assert.deepEqual(saved.attempts.slice(0, -1), old.attempts);
  assert.deepEqual(saved.labs, old.labs);
  connection.db.close();
  connection = open();
  assert.deepEqual(await connection.repo.load(), saved);
  assert.deepEqual(await connection.repo.restore(backup), saved);
  assert.deepEqual(
    (await connection.repo.load()).lessonSessions,
    saved.lessonSessions,
  );
  connection.db.close();
});
