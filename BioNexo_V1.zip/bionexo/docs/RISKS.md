# Registro de riesgos · auditoría 2026-10-22

Severidad indica prioridad local, no un puntaje CVSS de BioNexo. «Observado» es código/configuración; «reproducido» tiene un caso ejecutado. La ausencia de evidencia de explotación no cierra una alerta.

| ID | Prioridad / estado | Hallazgo y evidencia | Tratamiento / tarea |
|---|---|---|---|
| R-01 | Alta · corregido en P0-03 | Lectura histórica desacoplada del catálogo mediante referencias congeladas/propias. Pruebas cambian solución y retiran IDs sin perder perfil; nuevos intentos siguen usando evaluación vigente. | ADR-006; conservar registro histórico e IDs. Un respaldo sin firma no acredita autenticidad científica. |
| R-02 | Alta · corregido en P0-03 con límites | Recuperación accesible sin perfil válido; exporta originales y restaura solo con confirmación. SQLite existente sin fila no crea perfil. Corrupción, rollback, cuotas y versiones futuras tienen regresiones. | No reconstruye SQLite físicamente ilegible; no sobrescribe versiones futuras. Driver nativo sigue pendiente. |
| R-03 | Alta · corregido para clave vacía web | `!localStorage.getItem(key)` sobrescribía `""` con perfil inicial. Reproducción falló antes del cambio; ahora solo null permite crear y se verifica que no se escribe el valor corrupto. | P0-02 y ADR-002. Sin migración; mantener regresión. No prueba todos los caminos de recuperación. |
| R-04 | Alta · abierto, acotado en P0-04 | Auditoría MAT-PHY-01: 4 high/0 critical propagadas desde node-forge, sin parche indicado en su aviso. GitHub retiró braces el 2026-10-23; package/lockfile intactos, no atribuir el descenso a una reparación local. npm ls sin problemas; mapas Android/web no incluyen rutas de esas raíces. Hay uso de certificados en CLI; no se demuestra explotación ni se acredita ausencia de riesgo nativo. | ADR-007 y DEPENDENCY_SECURITY.md: continuar desarrollo local con guardas; lanzamiento público bloqueado. CI de auditoría falla sin excepciones; inspección de mapas detecta futura inclusión. Versiones/lockfile intactos. Revisar antes de publicar o cambiar dependencias. |
| R-05 | Alta · no comprobado | No hay Android SDK/adb/emulador aquí; el bundle Hermes no acredita build Gradle, firma, instalación, SQLite nativo o modo avión desde arranque. | P0-05 cubre preparación local, P5-02/P5-03 dispositivo/APK. No pedir credenciales ni cuota durante esta auditoría. |
| R-06 | Media · corregido en P2-02, histórico conservado | El evaluador vigente rechaza 1/1e309 y overflow/underflow de operandos, cociente y unidades; tolerancia relativa sin piso que oculte escalas pequeñas. Regresiones fallan antes/pasan después; fixture anterior conserva resultado/XP/checkpoints sin recalificar. | ADR-010. Number sigue teniendo precisión limitada; no se promete álgebra simbólica. Mantener corpus y no regenerar fixtures. |
| R-07 | Media · parcialmente tratado | P0-03 armoniza 10.000.000 bytes UTF-8. Perfil completo y referencias siguen serializados/revalidados; las copias originales crecen sin purga. Cuota o tamaño impiden guardar antes de reemplazar el original. | Medir historial en P3-03; normalizar solo con medición/migración. Exportar copias; no borrar para liberar cuota automáticamente. |
| R-08 | Media · corregido para lecciones en P1-01, límites abiertos | Cursor, borrador/unidades, ayuda, feedback y apoyo se guardan por lección; ID estable y confirmación atómica evitan duplicados. Diagnóstico/repaso siguen transitorios. | ADR-008: último commit confirmado ante cierre abrupto; no se recuperan escrituras pendientes. Historial grande y driver Android siguen pendientes de medición/prueba. |
| R-09 | Media · observado, abierto | BioLab y proyecto adicional de seis retos también requieren revisión humana. Los 24 contenidos figuran `requires-human-review`; 73 conceptos son planificados. Fase 1 profundiza solo factorización; Fase 2 añade 14 variantes, diez reglas y dos retos de transferencia con pruebas automáticas, sin revisión humana. Duraciones, dominio y recomendaciones son heurísticas sin evaluación con estudiantes. | P1/P2/P5: revisión y pruebas de transferencia; mantener etiqueta de revisión; no atribuir validación a las fuentes generales. |
| R-10 | Media · observado, abierto | `catalog.json` se convierte mediante aserción de tipos y el validador presupone ciertas estructuras. El incremento P5 valida el grafo incluido y devuelve errores de estructura desde validateCatalog. Permanece la aserción tipada de importación: no es un esquema universal para contenido externo ni garantiza recuperación de todo módulo malformado antes de arrancar. | Integridad de contenido en P5-01; no tratar tipos compilados como validación universal de archivos externos. No se acepta contenido externo actualmente. |
| R-11 | Baja/media · observado, abierto | El reloj local afecta fechas; reinsistir en una pregunta puede inflar evidencia, aunque dominio exige varios días. No hay validación psicométrica. | P2-03/P2-04, pruebas temporales y transparencia; no cambiar algoritmo en esta auditoría. |
| R-12 | Corregido en alcance P4 | Nuevos registros exigen dos pH distintos de un mismo modelo y notas; duplicados no crean réplicas. Registros antiguos conservados. Guía/predicción y proyecto interdisciplinario de seis retos implementados. | Pruebas de dominio/SQLite, recorrido web y carga de cuaderno; no implica revisión humana ni validación experimental. |
| R-13 | Media · información faltante | Informe funcional 2.0 completo no está disponible; contexto recuperado solo resume propuestas del asistente. No consta autorización adicional para BioTutor u otros detalles ausentes. | REQ-02/ADR-005: no inventar requisitos, incorporar el documento íntegro cuando exista. Fase 0 puede terminar su incremento sin él. |

## Almacenamiento y privacidad observados

SQLite está en la ubicación privada de la app elegida por `expo-sqlite`; no se añade cifrado propio. Respaldos JSON contienen nombre e historial y no están cifrados por la app. No se encontraron archivos de claves/credenciales versionados ni coincidencias en la revisión acotada de patrones privados; esto no equivale a una auditoría de secretos exhaustiva o del binario. No se inspeccionaron ni solicitaron credenciales privadas.

## Dependencias

Informe reproducible: [dependency-audit-2026-10-22.json](evidence/dependency-audit-2026-10-22.json). Avisos: [braces](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm) y [node-forge](https://github.com/advisories/GHSA-86w9-cpqp-85rv). Al consultarlos no indicaban versión corregida. P0-04 volvió a consultar avisos y versiones el 22 de octubre de 2026: siguen sin parche estable indicado. Evidencia nueva en [DEPENDENCY_SECURITY.md](DEPENDENCY_SECURITY.md). Repetir antes de publicar o modificar dependencias. No se interpreta `Expo Doctor 20/20` como ausencia de vulnerabilidades.

## Comprobación al cierre de Fase 1

Auditoría actual en [phase1-audit-2026-10-22.json](evidence/phase1-audit-2026-10-22.json): exit 1, 19 high/0 critical. Guardas de mapas actuales PASS (Android 1/1321 fuentes, web 9/848); no prueba de APK. No cambian dependencias. Un checkpoint de contenido modificado sigue intacto y requiere descarte explícito; la fixture v3 prueba conservación de otra sesión e historial. No se revocan lecciones completadas ni XP. R-06 queda para P2-02; R-05, R-09, R-11 y R-13 siguen abiertos. Fase 1 DONE no cierra estos límites de lanzamiento, revisión o medición.

## Controles de Fase 2

R-06 corregido para nuevos intentos; los resultados antiguos no se recalifican. Familia v1 con banco acotado, IDs/semillas congelados y premio compartido; SQL 3/documento 3/perfil 1/checkpoint 1 intactos. Una fixture del motor d2a3258 verifica lectura/exportación exacta y reanudación actual. Reglas explicables y muestras de transferencia pequeñas no equivalen a diagnósticos ni dominio validado. Mostrar razones no escribe el calendario; cuando no hay procedencia reconstruible (incluido cambio de zona), usa el vencimiento guardado sin inventar causa. El coste de recorrer historiales y acumular copias sigue pendiente en P3-03.

Auditoría actual en [phase2-audit-2026-10-22.json](evidence/phase2-audit-2026-10-22.json): 19 high/0 critical, exit 1. No se cambiaron dependencias; R-04 y bloqueo público permanecen. Los bundles se inspeccionan en salidas nuevas para no contar archivos sobrantes de exportaciones anteriores. No APK ni dispositivo Android; revisión académica/TalkBack pendientes.

La ayuda consultada y abandonada antes de responder en rondas transitorias no deja evento persistente (observado en el flujo de revisión); las lecciones sí conservan pistas. La marca sin ayuda de esos intentos no demuestra independencia fuera de la ronda. Mantener esta limitación explícita al interpretar transferencia/dominio y evaluar su evolución; no inventar un intento para guardar una consulta.

## Controles de Fase 3

P3-01/02 comprobados; P3-03 TESTING por falta de Android/TalkBack. R-05 sigue abierto: exportación Hermes no es APK. R-07 tiene medidas de 100/1.000/10.000 intentos (caso grande ~1,86 MB): selección 16,302→0,423 ms de mediana en Node, con oráculo de orden anterior; serialización/validación completa permanece ~53 ms y copias sin purga. No se interpreta como rendimiento nativo ni se cambia almacenamiento sin migración justificada. Datos crudos y límites en UX_AUDIT.

La navegación conserva solo controles del gráfico en parámetros validados, sin notas privadas. Una apertura nueva sin parámetros usa valores predeterminados; hipótesis/observaciones/condiciones no guardadas siguen transitorias y se avisa. El cuaderno guardado y respaldos mantienen su formato. R-12 queda para Fase 4; no se simula un diseño experimental profundo aquí.

Foco invisible y desbordamiento de controles corregidos en navegador; contraste activo automatizado y movimiento reducido comprobados. Barra de cinco destinos a 320 px/200% envuelve mucho las etiquetas: evaluar legibilidad con escala nativa y TalkBack antes de cerrar P3-03, junto con foco/gestos/orientación. No se declara accesibilidad universal.

Auditoría actual exit 1, 19 high/0 critical: R-04 sigue bloqueando publicación. Mapas nuevos sin raíces afectadas no equivalen a auditoría de binario. Sin dependencias/lockfile nuevos ni credenciales. Revisión académica humana continúa pendiente para la figura simplificada y demás contenido; no hay cambios de soluciones ni recalificación histórica.

## Preparación de paso a Fase 4 · PREP-04

R-05 permanece abierto: se generó el proyecto Android en copia aislada, sin Gradle/SDK/APK/dispositivo. Se corrigió el aviso nativo de apariencia automática con expo-system-ui 58.0.6, compatible con la matriz instalada; no se afirma prueba visual nativa y debe reconstruirse el binario. Firma/package/datos requieren continuidad, sin desinstalar para eludir diferencias de certificado.

Preflight/registro bloquean sin evidencia, pero el comprobador valida completitud/integridad, no autenticidad de una observación humana, certificado ni procedencia criptográfica del build. No usar tests sintéticos del validador como aceptación nativa. Datos personales y firmas privadas quedan fuera de la carpeta de evidencia/entrega. P3-03 sigue TESTING/Fase 4 PENDING; R-04 mantiene 19 high/0 critical tras la nueva dependencia y bloquea lanzamiento público.

## Integración de Fases 4/5

El SDK/JDK y herramientas nativas ya están disponibles en esta sesión; esto sustituye la limitación anterior de herramientas, no la aceptación de dispositivo. P3-03/P5-02 siguen pendientes hasta TalkBack, escala real, SQLite nativo, actualización compatible y arranque en modo avión. La plantilla manual continúa bloqueando. APK ARM64 compilado/firma v2/alineación/hash verificados en PROGRESS; no se ha instalado/ejecutado. Solo clave pública de prueba, sin firma de producción ni validación Android. Overlay heredado eliminado en el artefacto final.

Concurrencia de Gradle y Playwright alcanzó el límite de 8 GB del entorno de desarrollo y produjo timeout de una prueba anterior. Se interrumpió esa pasada y la compilación para repetir secuencialmente con --max-workers=2, --no-parallel y Kotlin in-process. No se elevó el timeout para ocultarlo; no es una medición de memoria/rendimiento de la app Android. No se borraron pruebas. Las limitaciones de historial completo/copia serializada (R-07), revisión humana (R-09) y seguridad (R-04, 19 high/0 critical) siguen abiertas.

La precarga de la pantalla de destino corrige el retorno web desde proyecto después de recargar y desconectar. La web no es una PWA: arrancar o abrir una ruta no precargada desde cero sigue requiriendo red. El objetivo offline-first corresponde a los recursos incluidos en la aplicación nativa, cuya ejecución real está pendiente. Borradores sin confirmar de cuaderno/proyecto no persisten; la UI lo declara.

## Continuación Fase 5 · 2026-10-23

El entorno se recuperó desde el archivo entregado y su historial; las herramientas de la sesión anterior no persisten aquí. Se instalaron solo Build Tools oficiales para inspeccionar el APK existente, cuyo hash/firma se mantienen. No hay JDK completo/SDK de compilación/adb ni dispositivo/emulador/KVM. El nuevo inspector detecta desviaciones conocidas del artefacto, sin certificar procedencia ni instalación/actualización y sin reparar R-04. Auditoría viva: 19 high/0 critical; versiones raíz y avisos consultados de nuevo sin parche indicado. R-05/R-09 y los criterios nativos siguen abiertos. El plan no define Fase 6: el usuario eligió enviar sus requisitos, todavía ausentes; no se atribuyen funciones nuevas a esa fase.

## SEC-01 · intento de remediación · 2026-10-23

R-04 sigue **abierto/BLOCKED** tras consultar registro, padres y avisos oficiales, y simular audit fix en copia aislada. Últimas publicadas siguen afectadas; propuesta forge #1152 no incorporada a release. Auditoría y simulación mantienen 19 high/0 critical. No se aplican downgrades incompatibles ni se elimina severidad por ausencia en mapas. package/lockfile y aplicación exactos; check 227/227. Ver DEPENDENCY_SECURITY/PROGRESS/evidence/security-resolution-2026-10-23.json para resultados/límites actuales; no interpretar esta investigación como reparación.

## MAT-PHY-01 · contenido de Física/Matemáticas · 2026-10-23

28 introducciones/168 retos nuevos, revisión docente pendiente (R-09), sin equivalencia de asignaturas universitarias ni calibración de tiempos/dificultad. Se verifican 77 soluciones numéricas y tres gráficos, condiciones de dominio/unidades y errores conceptuales; esto no reemplaza revisión humana. Los nueve conceptos integrados siguen planificados; no se anuncia completo ese recorrido. Diagnóstico y fundamentos originales conservados: sus límites ya registrados no se corrigen silenciosamente.

Las 60 lecciones/firmas y grafo anteriores permanecen exactos; fixtures con ADN/diluciones y reapertura/restauración SQLite de Node comprueban compatibilidad sin migración. No valida el driver Android. La huella nueva requiere reconstruir APK y comprobar actualización preservando datos. Exportación Hermes/E2E Chromium no cierran R-05/P3-03/P5-02/P5-03. Auditoría nueva 4 high/0 critical por node-forge; braces retirado oficialmente, sin cambios de dependencias. R-04 sigue abierto y bloquea publicación.
