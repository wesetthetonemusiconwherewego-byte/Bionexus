# Revisión técnica del incremento BioLab/proyecto

Fecha local: 2026-10-22. Base: 18eb63a. Revisión de contenido/código por el asistente y pruebas automáticas; **no revisión académica humana ni validación experimental/educativa**. El catálogo conserva requires-human-review.

| Elemento | Clasificación y comprobación | Límites |
|---|---|---|
| El pH puede afectar función e ionización enzimática | Hecho general: Biology 2e §6.5, ver FUENTES | No determina por sí solo una curva o mecanismo para una enzima concreta |
| A=100 exp[−½((pH−óptimo)/σ)²] | Modelo didáctico original; ambos óptimos dan 100, simetría y extremos finitos; σ positivo | Constantes/simetría elegidas, sin ajuste a datos reales, sin irreversibilidad ni velocidad absoluta |
| N, pH 6→7 | 80,073740…→100%; +19,926259… puntos porcentuales, mostrado 19,93 | Diferencia de porcentajes relativos; no aumento de 19,93% relativo al valor inicial ni significación estadística |
| Comparación guardada | Dos pH distintos del mismo modelo; primera condición y primera posterior distinta; duplicado no es réplica | Cambiar modelo cambia óptimo/anchura; no aísla solo pH. Histórico se conserva sin recalcular |
| Suspensión ideal | N=C₁V₁=1.000 células/mL × 1 mL=1.000 células; Vf=1+4=5 mL; C₂=200 células/mL | Medio agregado sin células, mezcla uniforme, volúmenes aditivos, sin pérdida/crecimiento. No es soluto molecular ni molaridad |
| Conversión | 5 mL=0,005 L; 200 células/mL=200.000 células/L; N esperado=C×V | Unidades explícitas; números binarios de precisión finita y tolerancias declaradas |
| Recuento simulado | V=0,05/0,1/0,2 mL → N esperado=10/20/40; (18+20+22)/3=20 | Serie inventada, sin instrumento, incertidumbre validada ni garantía de cuenta exacta en muestras reales |
| Conclusión | Compatibilidad interna entre modelo y ejemplo simulado | No demuestra viabilidad celular, causalidad experimental, método clínico ni validez universal |

La clasificación de predicción considera iguales diferencias absolutas ≤10⁻⁹ puntos porcentuales (tolerancia numérica, no estadística); las lecturas de la interacción se redondean a dos decimales. La tabla de un registro reabierto muestra el número guardado, sin ese redondeo.

Los seis ejercicios nuevos usan bases implementadas y opciones incorrectas plausibles: confundir concentración con número, volumen o viabilidad; interpretar valor esperado como resultado exacto; confundir concordancia con validación real. Dos pistas graduadas y explicaciones propias por reto. Los 24 bloques anteriores y sus soluciones se comparan literalmente con 18eb63a, además de pasar los validadores de IDs, soluciones, unidades, ciclos, referencias y grafo. Esto no sustituye revisar cada bloque con docentes.

Evidencia: tests/lab-notebook.test.ts, tests/curriculum-integrity.test.ts y tests/e2e/phase4.spec.ts. La fixture previa contiene intencionalmente una lectura histórica 12,345 distinta del motor actual: prueba conservación, nunca se ofrece como respuesta nueva correcta. El nuevo guardado sí rechaza cifras incoherentes.

Pendiente: revisión por docentes de las cuatro ciencias, legibilidad/tiempos con estudiantes, accesibilidad Android y evaluación de transferencia/retención. XP y seis respuestas correctas no certifican dominio ni preparación universitaria. Las predicciones del laboratorio no otorgan puntos ni acreditan habilidades automáticamente. La ayuda consultada y abandonada antes de confirmar una respuesta de proyecto sigue siendo transitoria; “sin pistas registradas” no prueba independencia fuera de esa ronda.

## Biología · revisión técnica BIO-01

20 lecciones/120 ejercicios nuevos, todos con revisión humana pendiente. Se verifican conteos de ADN/cromosomas/cromátidas por fase, orientación complementaria ADN/ARN, probabilidades monogénicas bajo supuestos, signos/unidades de balances energéticos ficticios y regla AND. Las pruebas discriminan respuestas erróneas plausibles, preservan los 24 bloques anteriores y ejercitan seis respuestas por lección con XP idempotente. La matriz de hechos/modelos/supuestos y las referencias por lección están en [BIOLOGIA.md](BIOLOGIA.md). No es revisión docente ni validación de datos experimentales.

Las áreas avanzadas son introducciones conceptuales de 10 minutos estimados; no sustituyen asignaturas de microbiología/inmunología/biología sintética. No se añaden procedimientos experimentales, secuencias funcionales ni interpretación clínica individual. El diagnóstico de límites asociado a cuadráticas y los resúmenes originales repetidos identificados en la revisión anterior siguen fuera de este incremento: no se cambia historial/contenido ajeno para corregirlos silenciosamente. Las seis lecciones iniciales de Biología también quedan para una profundización posterior compatible con checkpoints.

## CHEM-01 · revisión técnica, no docente · 2026-10-23

Las 16 lecciones y 96 ejercicios nuevos tienen revisión humana pendiente. La matriz de ecuaciones/condiciones está en [QUIMICA.md](QUIMICA.md). Pruebas comparan las 37 soluciones numéricas con relaciones independientes, unidades equivalentes (mol/mmol, L/mL, kPa/Pa, J/kJ, velocidades), redondeo explícito de gas y cuatro curvas calculadas. Se rechaza temperatura Celsius como si fuera kelvin; no se convierte automáticamente una escala afín con factores multiplicativos. Enzyme [S]=0 es límite matemático y no estado de sustrato en exceso. Equilibrio 1:1/actividades, neutralidad a 25 °C, capacidad finita y rangos de calibración quedan explícitos. No se recalifica el material anterior ni se corrige otro tema sin alcance.

Revisión humana requerida especialmente para cobertura/profundidad, protonación/actividad en disoluciones reales, criterios de validez cinética y analítica, distractores y dificultad/tiempos. El diagnóstico corto anterior no certifica preparación universitaria y conserva su limitación conocida. No hay resultados experimentales reales, recomendaciones clínicas/nutricionales ni procedimientos de preparación de sustancias.

## MAT-PHY-01 · revisión técnica, no docente · 2026-10-23

28 lecciones/168 retos originales con revisión humana pendiente. Matriz de relaciones/supuestos y fuentes por tema en [FISICA_MATEMATICAS.md](FISICA_MATEMATICAS.md). La suite contrasta **77 respuestas numéricas** por cálculos independientes y tres curvas; conserva exclusiones de racionales, laterales/continuidad, extremos del dominio, acumulación con signo y condiciones iniciales. Respuestas numéricas usan formatos existentes, sin eval/solucionador simbólico nuevo.

Criterios científicos: signo de trabajo por sistema en ΔU=Q−W, gradiente de Fick, imagen virtual/aumento negativo, área cm²↔m² y mol/L↔mol/m³, temperatura absoluta vs diferencia y tolerancia pequeña que no acepte cero para −2×10⁻⁶. Película dos caras/gota una interfaz/burbuja no intercambian factores de Laplace; placa estacionaria no describe todo balance térmico. P-valor no P(H₀), no rechazo no equivalencia ni causalidad; IC frecuentista se interpreta por procedimiento. Precisión no exactitud; conteo esperado no garantizado; ajustarse a datos simulados por la misma regla no valida un modelo real.

Los gráficos de exponencial/onda unen solo muestras y no prueban comportamiento entre puntos. El gráfico de regresión muestra datos y la recta de comparación está dada en el enunciado; no se presenta el segmento que une datos como ajuste. No se dibujan huecos/límites como valores existentes. Todos los parámetros biológicos y registros de ejemplos son simulados/ficticios. No hay protocolos con organismos/electricidad ni recomendaciones clínicas. Tiempos, dificultad, cobertura avanzada e interpretación por principiantes requieren docentes/estudiantes; no se afirma evaluación humana ni eficacia.
