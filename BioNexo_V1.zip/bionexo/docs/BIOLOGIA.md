# Biología · expansión del catálogo

Este documento conserva el alcance/evidencia de BIO-01. CHEM-01 añadió después 16 lecciones químicas: total actual 60/362 y 37 temas pendientes, sin modificar las 26 lecciones biológicas. Cinética enzimática ya tiene lección; probabilidad sigue planificada. Ver [QUIMICA.md](QUIMICA.md).

MAT-PHY-01 añade luego Física/Matemáticas: total actual 88/530; probabilidad ya dispone de lección, conservando las 26 lecciones y firmas biológicas. Ver [FISICA_MATEMATICAS.md](FISICA_MATEMATICAS.md).

Fecha: 2026-10-23. Base `3734d2f`; autorización «Dale implementando los contenidos de biología primero». BIO-01/ADR-015. Son introducciones conceptuales con práctica, no formación universitaria completa ni contenido revisado por profesores.

## Contenido disponible

Biología pasa de 6 a **26 lecciones y 156 ejercicios**, distribuidas en 12 unidades y 4 cursos. Los 20 conceptos antes planificados ahora tienen enseñanza, referencias y ejercicios reales. La aplicación completa tiene 44 lecciones/266 ejercicios, 44 conceptos con lección y 53 aún planificados en otras rutas; diagnóstico/variantes/proyectos se cuentan aparte.

Las seis lecciones biológicas y las otras 18 lecciones anteriores conservan exactamente sus textos, ejercicios, soluciones y firmas. No se vuelven a otorgar recompensas por abrir esta expansión. Homeostasis se añade a la unidad celular inicial; después se recorren biología celular, genética/molecular y áreas avanzadas introductorias.

| Lección nueva | Unidad | Tramos / retos |
|---|---|---:|
| Homeostasis | 03 · Arquitectura celular | 2 / 6 |
| Ciclo celular y mitosis | 04 · División y herencia celular | 2 / 6 |
| Meiosis | 04 · División y herencia celular | 2 / 6 |
| Señalización celular | 05 · Comunicación y catálisis | 2 / 6 |
| Enzimas | 05 · Comunicación y catálisis | 2 / 6 |
| Metabolismo y ATP | 06 · Energía y metabolismo | 2 / 6 |
| Fotosíntesis | 06 · Energía y metabolismo | 2 / 6 |
| Respiración celular | 06 · Energía y metabolismo | 2 / 6 |
| ADN y ARN | 07 · Información y copia | 2 / 6 |
| Replicación | 07 · Información y copia | 2 / 6 |
| Transcripción y traducción | 08 · De secuencia a función | 2 / 6 |
| Mutaciones | 08 · De secuencia a función | 2 / 6 |
| Regulación génica | 09 · Regulación y herencia | 2 / 6 |
| Genética mendeliana y molecular | 09 · Regulación y herencia | 2 / 6 |
| Microbiología | 10 · Diversidad y defensa | 2 / 6 |
| Inmunología | 10 · Diversidad y defensa | 2 / 6 |
| Biología de proteínas | 11 · Proteínas y sistemas | 2 / 6 |
| Fisiología | 11 · Proteínas y sistemas | 2 / 6 |
| Biotecnología vegetal | 12 · Aplicaciones conceptuales | 2 / 6 |
| Biología sintética conceptual | 12 · Aplicaciones conceptuales | 2 / 6 |

Cada lección estima 10 minutos, tiene objetivo medible, activación, explicación original, ejemplo en pasos, dos tramos (comprender; aplicar/interpretar), seis retos con al menos dos pistas, explicación de soluciones/errores y resumen propio distinto del objetivo. Hay selección, múltiple, ordenamiento, numéricos, gráficos y casos; se reusa el motor accesible/reanudable. Los gráficos/conteos/secuencias breves son ficticios explícitos.

## Bases y exploración

Se conservan IDs y todas las aristas de prerrequisitos del grafo de 97 conceptos. Genética conserva `math-probability` y biología de proteínas conserva `chem-enzyme`, todavía planificados en otras rutas. La pantalla lo indica y permite explorar; estas introducciones desarrollan su ejemplo elemental y no se presentan como sustituto de esos cursos. La ruta de Biología no promete que toda persona cumpla automáticamente las bases de otras ciencias.

Biblioteca incluye los 26 conceptos biológicos y su vocabulario inglés. Aprender diferencia los cursos y no muestra un horizonte vacío para Biología. Mi progreso calcula el denominador desde el catálogo (44), conservando el numerador real del estudiante. La cabecera de lección ya no llama Fundamentos a todos los niveles.

## Hechos, supuestos y límites académicos

| Tema | Distinción que debe mantenerse |
|---|---|
| Homeostasis | Regulación dinámica; una curva compatible no demuestra mecanismo ni diagnóstico. Termostato es analogía. |
| Ciclo/meiosis | ADN C, juegos n y número de cromosomas no son intercambiables; conteos fijan fase y condición. |
| Catálisis/ATP | Menor barrera no cambia equilibrio; romper un enlace aislado requiere energía, importa la reacción completa. Sumar ΔG no demuestra acoplamiento. |
| Fotosíntesis | O₂ procede del agua; Calvin depende de recursos, no sigue indefinidamente a tasa constante en oscuridad. |
| Respiración | Glucólisis citosólica; fermentación no equivale a toda respiración anaerobia; no hay rendimiento universal de ATP. |
| ADN/ARN | Complementariedad antiparalela, orientación explícita, ARN no siempre traducido; fragmentos ficticios, no genes funcionales. |
| Expresión/mutación | ARN no equivale a proteína activa; cambio de secuencia no determina beneficio/daño ni heredabilidad germinal. |
| Herencia | Un locus/dominancia completa y eventos equiprobables; probabilidad no impone conteos exactos ni describe todo rasgo. |
| Microbiología/inmunología | Diversidad microbiana no equivale a patogenicidad; marcador/anticuerpo no implica viabilidad, diagnóstico o protección universal. |
| Proteínas/fisiología | Cantidad no implica función; desnaturalizar no exige romper toda cadena; un indicador no evalúa todo el organismo. |
| Vegetal/sintética | Selección, clonación y regulación son distintos. AND es un modelo matemático ficticio; simulación no valida sistema biológico ni liberación. |

Todo el contenido conserva `requires-human-review`. Faltan revisión docente, calibración de tiempo/dificultad, evaluación de comprensión diferida/transferencia y pruebas Android. No hay cultivos, protocolos de transformación, secuencias funcionales ni intervención en organismos.

## Referencias verificadas

Consulta 2026-10-23. OpenStax Biology 2e, secciones concretas; licencia consultada CC BY-NC-SA 4.0. Textos, ejemplos, datos y preguntas originales de BioNexo, sin copiar pasajes, figuras ni ejercicios del libro. Ver CONTENT_LICENSE y FUENTES. La referencia no valida los datos simulados, la eficacia educativa o equivalencia universitaria.

| Lección | Fuente conceptual |
|---|---|
| Homeostasis | [OpenStax · Biology 2e · Homeostasis](https://openstax.org/books/biology-2e/pages/33-3-homeostasis) |
| Ciclo celular y mitosis | [OpenStax · Biology 2e · Ciclo celular y mitosis](https://openstax.org/books/biology-2e/pages/10-2-the-cell-cycle) |
| Meiosis | [OpenStax · Biology 2e · Meiosis](https://openstax.org/books/biology-2e/pages/11-1-the-process-of-meiosis) |
| Señalización celular | [OpenStax · Biology 2e · Señalización celular](https://openstax.org/books/biology-2e/pages/9-1-signaling-molecules-and-cellular-receptors) |
| Enzimas | [OpenStax · Biology 2e · Enzimas](https://openstax.org/books/biology-2e/pages/6-5-enzymes) |
| Metabolismo y ATP | [OpenStax · Biology 2e · Metabolismo y ATP](https://openstax.org/books/biology-2e/pages/6-4-atp-adenosine-triphosphate) |
| Fotosíntesis | [OpenStax · Biology 2e · Fotosíntesis](https://openstax.org/books/biology-2e/pages/8-1-overview-of-photosynthesis) |
| Respiración celular | [OpenStax · Biology 2e · Respiración celular](https://openstax.org/books/biology-2e/pages/7-4-oxidative-phosphorylation) · [OpenStax · Biology 2e · Glucólisis](https://openstax.org/books/biology-2e/pages/7-2-glycolysis) |
| ADN y ARN | [OpenStax · Biology 2e · ADN y ARN](https://openstax.org/books/biology-2e/pages/14-2-dna-structure-and-sequencing) |
| Replicación | [OpenStax · Biology 2e · Replicación](https://openstax.org/books/biology-2e/pages/14-3-basics-of-dna-replication) |
| Transcripción y traducción | [OpenStax · Biology 2e · Transcripción y traducción](https://openstax.org/books/biology-2e/pages/15-5-ribosomes-and-protein-synthesis) · [OpenStax · Biology 2e · Transcripción eucarionte](https://openstax.org/books/biology-2e/pages/15-3-eukaryotic-transcription) |
| Mutaciones | [OpenStax · Biology 2e · Mutaciones](https://openstax.org/books/biology-2e/pages/14-6-dna-repair) |
| Regulación génica | [OpenStax · Biology 2e · Regulación génica](https://openstax.org/books/biology-2e/pages/16-1-regulation-of-gene-expression) |
| Genética mendeliana y molecular | [OpenStax · Biology 2e · Genética mendeliana y molecular](https://openstax.org/books/biology-2e/pages/12-2-characteristics-and-traits) |
| Microbiología | [OpenStax · Biology 2e · Microbiología](https://openstax.org/books/biology-2e/pages/22-2-structure-of-prokaryotes-bacteria-and-archaea) |
| Inmunología | [OpenStax · Biology 2e · Inmunología](https://openstax.org/books/biology-2e/pages/42-2-adaptive-immune-response) · [OpenStax · Biology 2e · Respuesta inmunitaria innata](https://openstax.org/books/biology-2e/pages/42-1-innate-immune-response) |
| Biología de proteínas | [OpenStax · Biology 2e · Biología de proteínas](https://openstax.org/books/biology-2e/pages/3-4-proteins) |
| Fisiología | [OpenStax · Biology 2e · Fisiología](https://openstax.org/books/biology-2e/pages/33-3-homeostasis) · [OpenStax · Biology 2e · Forma y función animal](https://openstax.org/books/biology-2e/pages/33-1-animal-form-and-function) |
| Biotecnología vegetal | [OpenStax · Biology 2e · Biotecnología vegetal](https://openstax.org/books/biology-2e/pages/17-1-biotechnology) |
| Biología sintética conceptual | [OpenStax · Biology 2e · Biología sintética conceptual](https://openstax.org/books/biology-2e/pages/17-1-biotechnology) · [OpenStax · Biology 2e · Regulación génica](https://openstax.org/books/biology-2e/pages/16-1-regulation-of-gene-expression) |

## Compatibilidad y recuperación

SQLite/documento/perfil/checkpoint siguen 3/3/1/1: no cambia representación, no hay migración SQL necesaria. La instantánea `tests/fixtures/biology-baseline/catalog-3734d2f.json` se capturó antes de autoría; no regenerarla con el catálogo nuevo. La fixture de progreso anterior conserva intentos, XP, laboratorios (incluida lectura 12.345) y checkpoints. El test SQLite escribe una respuesta nueva, exporta, cierra, reabre y restaura preservando el historial. No se recalifica progreso. Respaldar antes de actualizar una instalación; la recuperación existente se conserva.

## Entrega y comprobaciones

`npm run content:build` regenera la expansión desde `scripts/biology_content.py`. `npm run check` valida contenido/grafo, TS y regresiones; `tests/biology-content.test.ts` cubre las 20 lecciones y casos matemáticos/científicos; `tests/e2e/biology.spec.ts` comprueba lector de las veinte, biblioteca, dos tramos, reanudación, recompensas, navegación web cargada sin red y bases pendientes. Resultados finales en PROGRESS/evidence/biology-2026-10-23.json.

El APK previo no incluye esta expansión. Cambiar el contenido cambia la huella de aplicación: requiere una nueva compilación para instalarlo en Android. Exportar Hermes no equivale a generar/ejecutar un APK. La política preview-arm64-v1 y su build anterior se mantienen históricos, sin cambiar hashes para forzar aprobación. P3-03/P5-02/P5-03, seguridad R-04 y revisión humana mantienen sus pendientes.
