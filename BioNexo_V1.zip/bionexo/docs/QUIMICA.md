# Química · expansión CHEM-01

Este documento conserva la evidencia histórica de CHEM-01. MAT-PHY-01 añadió después las bases físicas/matemáticas: total actual 88 lecciones/530 ejercicios y nueve conceptos integrados planificados. Los cinco prerrequisitos de otras rutas aquí descritos como pendientes ya tienen lecciones, sin cambiar contenido ni firmas químicas. Ver [FISICA_MATEMATICAS.md](FISICA_MATEMATICAS.md).

2026-10-23, base `1fe7c48`, ADR-016. Se implementan los **16 conceptos químicos que seguían planificados**, conservando los seis fundamentos anteriores. **22 lecciones/132 ejercicios, 10 unidades y cuatro cursos**. Total app: **60 lecciones/362 ejercicios**, 60 conceptos con lección y 37 planificados. Diagnóstico 12, variantes 14 y transferencia/proyecto 8 ejercicios se cuentan aparte.

Cada tema nuevo tiene objetivo medible, activación, dos tramos, dos ejemplos desarrollados diferentes, seis retos progresivos, pistas, feedback, aplicación y resumen propio. Diez minutos es estimación no calibrada. Selección, selección múltiple, cálculo con unidades, gráficos, predicción y casos se usan según tema. Opciones se distribuyen determinísticamente por ID v1 para evitar que elegir siempre la primera baste; no se altera el orden de opciones de ejercicios anteriores.

Son **introducciones con práctica**, no asignaturas universitarias completas ni revisión docente. Los temas amplios requerirán más profundidad y evaluación con estudiantes. No se modifican resultados históricos para simular dominio de lo nuevo.

## Lecciones añadidas

| Tema / ID | Unidad | Objetivo | Retos |
|---|---|---|---:|
| Reacciones y estequiometría / `chem-reactions` | 04 · Estequiometría y concentración | Balancear una ecuación sencilla y usar proporciones molares para identificar un reactivo limitante. | 6 |
| Disoluciones y concentración / `chem-solutions` | 04 · Estequiometría y concentración | Calcular concentración molar y cantidad de soluto usando volumen final de disolución. | 6 |
| Diluciones / `chem-dilution` | 05 · Dilución, gases y equilibrio | Aplicar conservación del soluto a una dilución ideal y distinguir volumen final de solvente añadido. | 6 |
| Gases / `chem-gases` | 05 · Dilución, gases y equilibrio | Usar PV=nRT con unidades compatibles y temperatura absoluta, e identificar límites del gas ideal. | 6 |
| Equilibrio químico / `chem-equilibrium` | 05 · Dilución, gases y equilibrio | Distinguir equilibrio dinámico de igualdad de concentraciones y usar Q frente a K en un modelo ideal 1:1. | 6 |
| Ácidos, bases y pH / `chem-ph` | 06 · Ácidos, bases y amortiguación | Identificar ácido/base conjugados y calcular pH/pOH bajo una aproximación acuosa diluida a 25 °C. | 6 |
| Sistemas amortiguadores / `chem-buffer` | 06 · Ácidos, bases y amortiguación | Explicar capacidad amortiguadora finita y calcular pH aproximado de un par HA/A⁻. | 6 |
| Termodinámica química / `chem-thermo` | 07 · Energía y velocidad | Calcular ΔG=ΔH−TΔS con unidades coherentes y separar favorabilidad de velocidad. | 6 |
| Cinética química / `chem-kinetics` | 07 · Energía y velocidad | Calcular una velocidad media y usar una ley de primer orden dada sin inferir órdenes de la estequiometría. | 6 |
| Oxidación y reducción / `chem-redox` | 08 · Transferencia electrónica y estructura orgánica | Identificar oxidación, reducción y agentes, y conservar electrones/carga en semirreacciones. | 6 |
| Química orgánica / `chem-organic` | 08 · Transferencia electrónica y estructura orgánica | Reconocer grupos funcionales e isomería constitucional y distinguir fórmula molecular de estructura. | 6 |
| Aminoácidos y proteínas / `chem-proteins` | 09 · Química de biomoléculas | Relacionar grupos de aminoácidos, enlace peptídico y niveles de estructura con efectos condicionados del pH. | 6 |
| Carbohidratos y lípidos / `chem-lipids` | 09 · Química de biomoléculas | Distinguir enlaces glucosídicos y ésteres y relacionar estructura con reserva y membranas. | 6 |
| Cinética enzimática / `chem-enzyme` | 10 · Modelos y análisis bioquímico | Usar un modelo Michaelis–Menten sencillo y distinguir concentración de sustrato, Km y Vmax. | 6 |
| Metabolismo y bioenergética / `chem-metabolism` | 10 · Modelos y análisis bioquímico | Conectar balances de energía, transferencia electrónica y acoplamiento sin confundirlos con velocidad. | 6 |
| Técnicas analíticas conceptuales / `chem-analytical` | 10 · Modelos y análisis bioquímico | Interpretar blanco, calibración lineal simulada y límites de inferencia al estimar concentración. | 6 |

Cuantitativa comprende las unidades 04–05; avanzada 06–08; bioquímica 09–10. Las unidades originales 01–03 permanecen idénticas. Aprender/Biblioteca integran el catálogo sin rutas ni dependencias nuevas. El horizonte vacío de Química deja de aparecer. Biología → proteínas enlaza ahora con la lección real de cinética enzimática.

## Supuestos y límites científicos

| Área | Relación / condiciones | Límite que se enseña |
|---|---|---|
| Estequiometría | Conteo de átomos/carga; relaciones en mol; reactivo limitante | Máximo teórico supone conversión completa sin otras reacciones; masa de muestra no garantiza pureza. |
| Soluciones | c=n/V final; mol/L y mL↔L | No asumir volúmenes aditivos; temperatura y solubilidad pueden importar. |
| Dilución | c₁V₁=c₂V₂, sin reacción/pérdida/precipitación; factores se multiplican | Mezclar dos soluciones exige sumar n; V₂ es final y no solvente añadido. |
| Gases | PV=nRT; R=8,314 L·kPa/(mol·K); presión absoluta | Idealidad aproximada; kelvin en cocientes; no extrapolar a condensación/alta presión. |
| Equilibrio | Actividades adimensionales; Q≈[B]/[A] solo para el modelo ideal 1:1 | Igualdad de velocidades no de concentraciones; K depende de temperatura y no de catálisis. |
| pH | Actividad de H₃O⁺; concentración diluida como aproximación | pH+pOH≈14 y neutro≈7 se restringen a agua a 25 °C; fuerza no significa concentración; no hay límites universales 0–14. |
| Buffer | Henderson–Hasselbalch aproximado, con ambas especies presentes | Neutralizar antes de calcular razón; capacidad finita; igual pH no implica igual capacidad. |
| Termodinámica | ΔG=ΔH−TΔS con K, J↔kJ; T/P constantes para favorabilidad | ΔG° no es ΔG celular; favorabilidad no implica velocidad; suma no prueba acoplamiento. |
| Cinética | Velocidad media Δ[P]/Δt para A→P 1:1; ley v=k[A] dada | Órdenes no se deducen en general de ecuación global; ajuste no identifica mecanismo único. |
| Redox | Números de oxidación formales, electrones y carga conservados | Oxidante se reduce; transferencia de protones no implica redox. |
| Orgánica/biomoléculas | Conectividad, grupos funcionales, amidas/glucosídicos/ésteres | Igual fórmula no implica misma estructura; desnaturalización no implica hidrólisis; no todos los lípidos son polímeros. |
| Enzimas | v₀=Vmax[S]/(Km+[S]), Km>0, [S]≥0; velocidades iniciales | Enzima/pH/T fijos, complejo en aproximación estacionaria; no cooperatividad/inhibición ni agotamiento grande. Km no es afinidad universal ni pH óptimo. |
| Bioenergética | Balances de materia/energía/electrones separados | Romper un enlace aislado requiere energía; ATP casi constante no significa flujos nulos. |
| Analítica | A=εlc ideal; recta ficticia A=0,020+0,50c, c en mmol/L, rango 0–1,0 | Blanco no elimina toda interferencia, intercepto no se resta dos veces; extrapolación no validada; señal no identifica molécula inequívocamente. |

**Datos y parámetros propios, ficticios o simulados**, sin resultados experimentales reales ni protocolos de preparación/manipulación. La hipérbola de Michaelis–Menten es distinta de la gaussiana didáctica pH del BioLab; ninguna valida a la otra. El caso [S]=0 se trata como límite de la ecuación, sin afirmar sustrato en exceso en ese punto. Todas las lecciones conservan `requires-human-review`.

## Fuentes y licencias

Consulta 2026-10-23: páginas oficiales OpenStax y entradas IUPAC. La indexación oficial de Gold Book permite comprobar ecuación/términos; algunas aperturas completas devolvieron 403, límite registrado y sin inventar lecturas. OpenStax Chemistry 2e y Biology 2e: CC BY-NC-SA 4.0 según prefacio/licencia consultados. Texto, ejemplos, preguntas y datos propios bajo CONTENT_LICENSE; no se incluyen libros, figuras, pasajes ni preguntas copiadas. Gold Book se enlaza como referencia terminológica y no se reproducen definiciones. Las fuentes no validan cifras ficticias ni eficacia educativa.

| Lección | Referencias concretas |
|---|---|
| Reacciones y estequiometría | [OpenStax · Chemistry 2e · 4.3 Reaction Stoichiometry](https://openstax.org/books/chemistry-2e/pages/4-3-reaction-stoichiometry) · [OpenStax · Chemistry 2e · 4.1 Writing and Balancing Chemical Equations](https://openstax.org/books/chemistry-2e/pages/4-1-writing-and-balancing-chemical-equations) |
| Disoluciones y concentración | [OpenStax · Chemistry 2e · 3.3 Molarity](https://openstax.org/books/chemistry-2e/pages/3-3-molarity) |
| Diluciones | [OpenStax · Chemistry 2e · 3.3 Molarity](https://openstax.org/books/chemistry-2e/pages/3-3-molarity) |
| Gases | [OpenStax · Chemistry 2e · 9.2 Ideal Gas Law](https://openstax.org/books/chemistry-2e/pages/9-2-relating-pressure-volume-amount-and-temperature-the-ideal-gas-law) |
| Equilibrio químico | [OpenStax · Chemistry 2e · 13.1 Chemical Equilibria](https://openstax.org/books/chemistry-2e/pages/13-1-chemical-equilibria) · [OpenStax · Chemistry 2e · 13.2 Equilibrium Constants](https://openstax.org/books/chemistry-2e/pages/13-2-equilibrium-constants) |
| Ácidos, bases y pH | [OpenStax · Chemistry 2e · 14.1 Brønsted–Lowry Acids and Bases](https://openstax.org/books/chemistry-2e/pages/14-1-bronsted-lowry-acids-and-bases) · [OpenStax · Chemistry 2e · 14.2 pH and pOH](https://openstax.org/books/chemistry-2e/pages/14-2-ph-and-poh) |
| Sistemas amortiguadores | [OpenStax · Chemistry 2e · 14.6 Buffers](https://openstax.org/books/chemistry-2e/pages/14-6-buffers) |
| Termodinámica química | [OpenStax · Chemistry 2e · 16.4 Free Energy](https://openstax.org/books/chemistry-2e/pages/16-4-free-energy) |
| Cinética química | [OpenStax · Chemistry 2e · 12.3 Rate Laws](https://openstax.org/books/chemistry-2e/pages/12-3-rate-laws) · [OpenStax · Chemistry 2e · 12.1 Chemical Reaction Rates](https://openstax.org/books/chemistry-2e/pages/12-1-chemical-reaction-rates) · [OpenStax · Chemistry 2e · 12.7 Catalysis](https://openstax.org/books/chemistry-2e/pages/12-7-catalysis) |
| Oxidación y reducción | [OpenStax · Chemistry 2e · 17.1 Review of Redox Chemistry](https://openstax.org/books/chemistry-2e/pages/17-1-review-of-redox-chemistry) |
| Química orgánica | [OpenStax · Chemistry 2e · 20.1 Hydrocarbons](https://openstax.org/books/chemistry-2e/pages/20-1-hydrocarbons) · [OpenStax · Chemistry 2e · 20.3 Aldehydes, Ketones, Carboxylic Acids, and Esters](https://openstax.org/books/chemistry-2e/pages/20-3-aldehydes-ketones-carboxylic-acids-and-esters) |
| Aminoácidos y proteínas | [OpenStax · Biology 2e · 3.4 Proteins](https://openstax.org/books/biology-2e/pages/3-4-proteins) |
| Carbohidratos y lípidos | [OpenStax · Biology 2e · 3.2 Carbohydrates](https://openstax.org/books/biology-2e/pages/3-2-carbohydrates) · [OpenStax · Biology 2e · 3.3 Lipids](https://openstax.org/books/biology-2e/pages/3-3-lipids) |
| Cinética enzimática | [IUPAC Gold Book · Michaelis–Menten equation](https://goldbook.iupac.org/terms/view/11546) · [IUPAC Gold Book · Michaelis–Menten mechanism](https://goldbook.iupac.org/terms/view/M03893) · [OpenStax · Biology 2e · 6.5 Enzymes](https://openstax.org/books/biology-2e/pages/6-5-enzymes) |
| Metabolismo y bioenergética | [OpenStax · Biology 2e · 6.1 Energy and Metabolism](https://openstax.org/books/biology-2e/pages/6-1-energy-and-metabolism) · [OpenStax · Chemistry 2e · 16.4 Free Energy](https://openstax.org/books/chemistry-2e/pages/16-4-free-energy) · [OpenStax · Chemistry 2e · 17.1 Review of Redox Chemistry](https://openstax.org/books/chemistry-2e/pages/17-1-review-of-redox-chemistry) |
| Técnicas analíticas conceptuales | [IUPAC Gold Book · Beer–Lambert law](https://goldbook.iupac.org/terms/view/B00626) · [OpenStax · Chemistry 2e · 1.5 Measurement Uncertainty, Accuracy, and Precision](https://openstax.org/books/chemistry-2e/pages/1-5-measurement-uncertainty-accuracy-and-precision) |

## Compatibilidad y ampliación

Autoría `scripts/chemistry_content.py`, invocada por `npm run content:build`. Cada ID de concepto previo se conserva; ejercicios nuevos usan `chem-…-v1-qN`, sin reusar IDs de fundamentos o proyectos. El grafo permanece byte por byte. Los prerequisitos `phys-temperature`, `phys-thermo`, `math-log`, `math-functions-rational` y `phys-optics` siguen planificados; el lector mantiene aviso y exploración libre, con ejemplos elementales para esta introducción.

SQLite/documento/perfil/checkpoint **3/3/1/1**, sin migración de representación. Se congelaron catálogo, firmas de las 44 lecciones y perfil con intento/feedback de ADN ANTES de autoría (`tests/fixtures/chemistry-baseline`); no regenerar esas fixtures con el contenido actual. Regresiones verifican las 44 firmas, todas las lecciones biológicas, IDs/aristas, diagnósticos/proyectos, XP e historial exactos. SQLite de Node guarda química y conserva Biología al cerrar/reabrir/restaurar; no es prueba del driver Android. Exportar respaldo antes de actualizar; no desinstalar para eludir conflictos de firma, y usar recuperación explícita existente si hay corrupción.

## Verificación y pendientes

Ver comandos/resultados efectivos en PROGRESS y evidence/chemistry-2026-10-23.json. Tests de química comprueban todas las soluciones, distractores, 37 cálculos numéricos por relaciones independientes, conversiones/tolerancias y cuatro gráficos. Son comprobaciones técnicas, no sustituto de revisión docente. Los recorridos web prueban mapa, Biblioteca, lección completa, unidades, reanudación y navegación cargada sin red.

**El APK anterior no incluye Biología ampliada ni esta Química.** Este incremento entrega fuentes/exportaciones: para instalarlo se requiere otra compilación identificada y aceptación Android. Exportar JS/Hermes no genera APK. Permanecen R-04 y P3-03/P5-02/P5-03; no se modifica la política histórica del binario para aprobar fuentes nuevas. Faltan revisión humana, profundidad avanzada, evaluación de aprendizaje y tiempos, y las 37 bases/temas de otras rutas.
