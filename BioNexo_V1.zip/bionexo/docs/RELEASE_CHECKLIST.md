# Checklist de integración y entrega

Fecha: 2026-10-22. Fase 4 y P5-01 DONE en alcance local; P3-03 TESTING, P5-02 BLOCKED y P5-03 TESTING. Fase 5 no se declara finalizada ni autoriza lanzamiento.

## MAT-PHY-01 · Física/Matemáticas · 2026-10-23

- [x] 28 lecciones/168 retos originales nuevos, dos tramos/ejemplos/pistas/fuentes/condiciones; app 88/530, nueve conceptos integrados pendientes.
- [x] 60 lecciones/firmas previas y grafo exactos; fixture anterior y SQLite reopen/restauración preservan progreso, sin migración.
- [x] Check 266/266, 77 soluciones numéricas/tres gráficos, E2E 88/88, determinismo, exportaciones y guarda PASS.
- [x] Inspección de lector/gráfico a 320 px, sin desbordamiento del documento ni errores en esas vistas.
- [x] Auditoría nueva conservada: 4 high/0 critical por node-forge y dependientes; braces oficialmente retirado, dependencias intactas.
- [ ] Revisión académica humana y evaluación de comprensión/dificultad/tiempos.
- [ ] APK actualizado y aceptación Android preservando datos; Hermes no es APK ni ejecución nativa.
- [ ] Resolver node-forge/R-04 antes de publicar. SEC-01 sigue BLOCKED.

Las secciones siguientes registran ejecuciones históricas; sus conteos de 19 alertas y catálogo anterior no reemplazan el resultado actual.

## SEC-01 · remediación R-04 · 2026-10-23

- [x] Auditoría viva y árbol/registro/padres consultados; simulación aislada sin modificar package/lockfile.
- [x] Check 227/227, matriz instalada y árbol sin problemas; evidencia conserva 19 high/0 critical, sin excepciones.
- [ ] Corrección publicada/compatible aplicada y auditoría aprobada: **BLOCKED**, no hay versión reparada publicada de las dos raíces.
- [ ] Instalación limpia/Doctor/E2E y aceptación nativa de la futura actualización cuando exista.
- [ ] R-04 cerrado/publicación: no autorizado mientras persistan las alertas y pendientes nativos.

## CHEM-01 · Química · 2026-10-23

- [x] 16 lecciones/96 retos originales nuevos, dos tramos/ejemplos; química 22 lecciones y 132 ejercicios en mapa/Biblioteca.
- [x] Fuentes, unidades, modelos y límites documentados; toda lección requiere revisión humana.
- [x] 44 lecciones/firmas anteriores exactas, Biología conservada; grafo/perfil/checkpoints/XP y SQLite reopen/restauración aprobados.
- [x] Check 227/227, E2E completo 80/80, determinismo, exportaciones web/Android y guarda PASS.
- [ ] Revisión docente y evaluación de comprensión/dificultad/tiempos.
- [ ] APK nuevo y aceptación Android; el artefacto histórico no incluye estas expansiones.
- [ ] Cerrar R-04 antes de publicación; 19 high/0 critical siguen abiertos.

## BIO-01 · Biología primero · 2026-10-23

- [x] 20 lecciones/120 ejercicios originales nuevos; biología 26 lecciones/12 unidades/4 cursos y biblioteca con enseñanza real.
- [x] IDs/aristas y 24 bloques previos exactos; perfil/XP/checkpoints/lecturas preservados; SQL/formatos sin cambios.
- [x] 201 pruebas, TS/catálogo, autoría determinista, exportaciones y guarda PASS.
- [x] Interfaz completa E2E: 74/74 PASS móvil/escritorio; no Android.
- [ ] Revisión docente y evaluación con estudiantes; temas avanzados son introducciones.
- [ ] APK actualizado con este contenido y aceptación Android; APK previo es histórico.
- [ ] R-04: 19 high/0 critical abiertas, publicación bloqueada.

## Continuación de Fase 5 · 2026-10-23

- [x] APK anterior recuperado y comprobado con inspector reproducible; firma, fuentes, identidad/permisos, alineación y bundle incluido coinciden.
- [x] Doce regresiones del inspector, sin dependencias ni cambios de aplicación/datos; mensaje de puerta nativa actualizado.
- [ ] Aceptación instalada P5-02/P3-03 y cierre P5-03. Inspector ≠ ejecución Android.
- [ ] R-04: auditoría viva mantiene 19 high/0 critical. Publicación bloqueada.
- [ ] Definición funcional de Fase 6: el usuario eligió aportar sus requisitos; todavía no recibidos.

La evidencia actual está al principio de PROGRESS. Las comprobaciones siguientes corresponden a sus ejecuciones históricas.

## Integración actual Fases 4/5

- [x] ADR-013 previa; fixture 18eb63a congelada y formatos 3/3/1/1 conservados.
- [x] Guía/controles/predicción del laboratorio, mínimo nuevo de comparación y reapertura íntegra con datos guardados.
- [x] Proyecto de seis ejercicios originales: bases disponibles, unidades/datos simulados, análisis y conclusión limitada; 60 XP máximo por primeros aciertos.
- [x] 163/163 pruebas, 68/68 E2E finales secuenciales, TS/catálogo/grafo, ambas exportaciones/guardas PASS.
- [x] Autoría determinista; 24 lecciones/soluciones/primera transferencia/grafo previos exactos; todas las fixtures anteriores conservadas.
- [x] Instalación limpia npm ci, Doctor 20/20, matriz instalada y árbol de dependencias PASS.
- [x] Inspección móvil nueva y carga de 100/1.000/10.000 condiciones históricas; tabla/gráfico limitados y respaldo original intacto.
- [x] JDK/SDK/build-tools/NDK disponibles y preflight TOOLS_PRESENT; fuentes de copia nativa idénticas al commit de implementación.
- [x] APK ARM64 final con build exit 0, firma v2/hash/origen/versiones verificados, ZIP/alineación 16 KB y contenido incluido; overlay eliminado, certificado de prueba conservado. Instalación sigue pendiente.
- [ ] Instalación/actualización compatible preservando perfil; SQLite nativo, modo avión desde arranque, TalkBack, escalas, orientación, respaldo y tiempos reales.
- [ ] Revisión académica humana y evaluación con estudiantes.
- [ ] Seguridad pública: R-04 resuelto. Auditoría viva sigue exit 1, 19 high/0 critical; no se oculta CI rojo.

Las secciones siguientes son históricas y no sustituyen esta aceptación. La presión de memoria de la primera ejecución concurrente y el fallo del retorno web se documentan en PROGRESS/evidence; solo se cuenta el informe final secuencial.

## Preparación de entrada a Fase 4

- [x] Base f23fc84 limpia y check 136/136 antes de editar; ADR-012.
- [x] Preflight Android y plantilla nativa que bloquean ante ausencia real, con comandos/guía Windows.
- [x] Registro vinculado a fuentes/archivos/APK; integridad, rutas y casos/muestras comprobables; resultado completo requiere revisión humana.
- [x] Prebuild aislado ejecutado, aviso SystemUI reproducido/corregido con 58.0.6 compatible, apariencia automática generada y config conservada.
- [x] 148/148 pruebas y 62/62 E2E, TS/catálogo, exportaciones/guardas, Doctor 20/20/matriz y npm ls PASS.
- [x] Fuentes académicas/datos/fixtures/SQL/formato intactos; sin secretos/keystore incluido, costes o builds remotos.
- [ ] Entorno Android completo, APK compilado/identificado y firmado de forma compatible, sin pérdida de progreso.
- [ ] Matriz nativa completa con evidencias reales revisadas para marcar P3-03 y Fase 3 DONE.
- [ ] P4-01 autorizada e iniciada después de documentar ese cierre.
- [ ] R-04 resuelto para publicar: auditoría continúa exit 1, 19 high/0 critical.

La preparación completada no marca estas casillas pendientes. Guía y límites en PHASE4_HANDOFF.

## Integración Fase 3 · aceptación nativa pendiente

- [x] Base 6d5e92d limpia, 125 pruebas; ADR-011 y fixture previa congelada antes de editar.
- [x] Diagrama/regiones/radios sincronizados, texto completo, feedback y checkpoint/XP sin cambio.
- [x] Gráfico/lecturas/comparación/óptimo coherentes, unidades y rangos; controles conservados al navegar/recargar, URLs inválidas y límites probados.
- [x] Contexto de gráfico separado de cuaderno guardado; notas transitorias declaradas, sin datos privados en URL.
- [x] Foco/contraste/reajuste/movimiento verificados en navegador; diagramas y vista móvil inspeccionados.
- [x] Medidas antes/después y carga de 100/1.000/10.000; índice local mantiene exactamente el selector anterior sin alterar eventos/calendarios.
- [x] 136/136 pruebas y 62/62 E2E, ambas exportaciones nuevas, guardas limpias, Doctor 20/20 y matriz instalada compatibles.
- [x] Catálogo/grafo/fixtures/formatos/lockfile conservados, sin migración innecesaria ni recalificación.
- [x] Evidencia/documentación/riesgos y siguiente paso actualizados; no Fase 4.
- [ ] P3-03 DONE: dispositivo/OS identificado, TalkBack, escalas reales, legibilidad de pestañas, foco/gestos/orientación y tiempos nativos registrados.
- [ ] APK/driver SQLite/compartir/importar/cierre/arranque offline nativos comprobados.
- [ ] Revisión humana científica/pedagógica y uso con estudiantes.
- [ ] R-04 cerrado para publicar: auditoría sigue exit 1, 19 high/0 critical.

Los siguientes cierres son históricos; no sustituyen la aceptación actual.

## Cierre Fase 2 · P2-02/P2-01/P2-03/P2-04

- [x] Base d2a3258 limpia, 93/93 de línea base; ADR-010 y fixture del evaluador anterior antes del cambio.
- [x] Overflow/underflow/unidades/tolerancias con regresiones previas y nuevos intentos corregidos; historial no recalificado.
- [x] 14 variantes con IDs/semillas/soluciones congelados y premio compartido, SQLite/reapertura/restauración sin pérdida.
- [x] Diez reglas explícitas con bases/ejemplos/fuentes; dos retos de transferencia con modelo supuesto, unidades/dominio y limitaciones.
- [x] Ayuda/muestra inicial/prácticas recientes diferenciadas; retorno del puente conserva respuesta y ayuda.
- [x] Razones reproducibles sin reordenar/reprogramar: fuente solo si el replay coincide; calendario sin procedencia usa fallback.
- [x] Medianoche local/cambio de zona, intervalos y evento origen distinto de última respuesta cubiertos.
- [x] 125/125 pruebas, 52/52 E2E, exportaciones nuevas, guardas sin coincidencias y Doctor 20/20 PASS.
- [x] Matriz Expo offline y npm ls compatibles; configuración APK preview intacta, sin dependencia ni secreto nuevo.
- [x] Tres vistas móviles sin desbordamiento, estado ARIA web de selección corregido y verificado.
- [x] Documentos/evidencia/riesgos y siguiente incremento actualizados; diff, formato y enlaces revisados al cierre.
- [ ] Revisión académica humana/evaluación con estudiantes; rondas transitorias no conservan ayuda consultada y abandonada antes de responder.
- [ ] APK, instalación/actualización, driver SQLite/importar/compartir/cierre/arranque offline y TalkBack Android nativos.
- [ ] R-04 resuelto para publicar: auditoría exit 1 con 19 high/0 critical sigue bloqueando lanzamiento.

Los cierres anteriores siguientes son registros históricos; no sustituyen la aceptación de una publicación.

## Cierre Fase 1 · P1-02/P1-03

- [x] Base ae7a8ab limpia; línea base 83/83 y dependencias de tareas satisfechas.
- [x] ADR-009 previa al catálogo; fixture v3 anterior congelada; no cambia SQL/formato ni algoritmos de dominio/repaso.
- [x] Piloto con cuatro tramos, ejemplos y ocho retos; 24 lecciones accesibles y 144 contratos/soluciones anteriores conservados.
- [x] Modelo geométrico supuesto con fuentes, dominio/unidades y limitaciones; revisión humana pendiente visible.
- [x] Tres pistas por reto, ejemplo alternativo oculto hasta la tercera; ayuda persistida sin evidencia independiente ni premios duplicados.
- [x] Feedback por distractor y retorno del puente con elección original conservada; gate por contenido revisado con descarte explícito sin pérdida.
- [x] 93/93 pruebas, 40/40 E2E, exportaciones, guardas y Doctor 20/20; matriz Expo instalada offline y npm ls compatibles.
- [x] Vistas móviles de tramo/ayuda revisadas, sin desbordamiento ni errores de página a 412×915.
- [x] Documentación, evidencia, riesgos y siguiente tarea actualizados; diff/formato/enlaces revisados antes de commit.
- [ ] Revisión académica humana y tiempos con estudiantes. No se acredita eficacia educativa.
- [ ] APK y pruebas nativas Android (SQLite, importar/compartir, cierre forzado, arranque sin red y TalkBack).
- [ ] Alertas R-04 resueltas para publicar: 19 high/0 critical continúan abiertas.

Los cierres siguientes son históricos; no sustituyen los controles actuales ni la aceptación de un lanzamiento público.

## Cierre P1-01

- [x] Base ff375cc limpia; 66 pruebas iniciales; dependencias P0-03/P0-04 revisadas.
- [x] ADR-008 antes del cambio; fixture de envoltorio 2 capturada con motor anterior y fixture 0.1.0 intacta.
- [x] Migración de payload 2→3 preserva perfil y original; SQL permanece en esquema 3.
- [x] Borrador, unidades, pistas, cursor, feedback y apoyo conservados por lección.
- [x] Confirmación/avance/finalización atómicos, IDs estables, doble toque y errores antes/después de commit comprobados.
- [x] Descartar o terminar elimina solo esa sesión; no borra historial/XP ni otras sesiones.
- [x] 83/83 pruebas, TS/catálogo, 32/32 E2E, exportaciones y guarda de bundles; Doctor 20/20 y matriz Expo offline compatibles.
- [x] Inspección visual móvil 412×915, sin desbordamiento horizontal. No equivale a accesibilidad/TalkBack nativos.
- [x] Documentos, riesgos, versiones, instrucción siguiente y evidencia actualizados; diff/formato/enlaces revisados antes de commit.
- [ ] Validación nativa de SQLite, importación/compartir, cierre forzado y modo avión sobre un APK Android. No generado en este incremento.
- [ ] R-04 cerrado para lanzamiento: siguen 19 high/0 critical en auditoría viva, no se silencia el control.

## Cierre P0-04 por acotación

- [x] Línea base 57/57, Git limpio y P0-03 comprobado como dependencia.
- [x] Auditoría viva completa y con omit=dev; 19 high, 0 critical, exit 1 conservado.
- [x] Rastrear raíces y uso en tooling/runtime; consultar avisos/versiones oficiales y evaluar opciones compatibles.
- [x] No aplicar degradaciones/overrides sin reparación; versiones/lockfile intactos.
- [x] Guarda de bundles y nueve pruebas nuevas, 66/66 suite y 20/20 E2E; hashes de ambos bundles/mapas y ausencia de las dos raíces registrados.
- [x] Exportaciones, Doctor 20/20, configuración y matriz Expo local verificados. Consulta online agotó tiempo en proxy; no se declara éxito remoto.
- [x] Job separado de auditoría CI sin excepciones, con informe conservado al fallar; comandos probados localmente y YAML inspeccionado.
- [x] ADR-007 documenta decisión de desarrollo local y límites; P0-04 DONE no significa vulnerabilidades reparadas.
- [ ] R-04 remediado/cerrado para lanzamiento público. Sigue abierto; job de auditoría rojo. No se ejecutó GitHub Actions remoto ni hay protección de rama/pipeline de publicación configurados.

## Cierre del incremento P0-03

- [x] Git/base y módulos inspeccionados; dependencias P0-02 verificadas.
- [x] Reproducir rechazo por catálogo corregido/retirado y creación indebida de fila ausente antes de implementar.
- [x] Documentar contrato, impacto y recuperación antes del cambio (ADR-006).
- [x] Cambios limitados a lectura histórica, persistencia, rescate y pruebas/UI relacionados; catálogo/IDs/evaluación actual/SDK intactos.
- [x] Fixture 0.1.0 intacta y datos conservados en migración/reapertura/restauración.
- [x] TypeScript, catálogo y 57 pruebas aprobadas; exportaciones web/Android y 20 E2E aprobados.
- [x] Documentos de progreso, riesgos, arquitectura y evidencia actualizados; diff revisado antes del commit.

## Pruebas técnicas de una entrega funcional

Esta sección se evalúa de nuevo para cada release. No se marca una entrega 2.0 como aprobada por los controles de la auditoría; los resultados de la línea base están en PROGRESS.

- [ ] Instalación reproducible con `npm ci` desde entorno limpio para esa entrega.
- [ ] `npm run check` aprobado con pruebas relevantes del incremento.
- [ ] Catálogo, soluciones, fuentes y grafo coherentes; no contar planificado como implementado.
- [ ] `npx expo install --check` y Expo Doctor aprobados; registrar la versión usada.
- [ ] `npm audit --json` revisado; alertas abiertas resueltas o con decisión de riesgo revisada. **Revisión MAT-PHY-01: 4 high abiertas; consultar DEPENDENCY_SECURITY.**
- [ ] Exportaciones web/Android del commit a entregar.
- [ ] Playwright sobre la exportación web actual; viewport móvil no se denomina Android.
- [ ] Revisar accesibilidad y rendimiento medidos; no confundir atributos con auditoría nativa.

## Si cambian datos, contenido o algoritmos

- [x] Inventariar perfiles, IDs, significado histórico e invariantes afectados.
- [x] Documentar versiones de contrato y esquema por separado y diseñar migración compatible.
- [x] Fixture `progress-v0.1.0.json` y otras versiones conservadas sin regenerarlas con el motor nuevo.
- [x] Verificar XP/dominio/repasos/intentos/diagnóstico/laboratorio y ajustes antes/después.
- [x] Probar rollback, versión futura, datos corruptos y reejecución de migración.
- [x] Probar rescate desde error de apertura sin reinicializar ni borrar bytes originales.
- [x] Definir recuperación/rollback compatible y advertir si una versión anterior no puede leer una migración nueva.

P0-03 aplica migración SQLite 3 y envoltorio 2 manteniendo el perfil 1. Se verificó recuperación desde datos accesibles corruptos, no reconstrucción de archivos SQLite físicamente ilegibles. No hay downgrade automático. Ver ADR-006 y PROGRESS. Estos checks corresponden a P0-03, no a migraciones futuras.

## Preparación Android comprobable sin cuenta externa

- [x] `eas.json`: perfil preview, `distribution: internal`, Android `buildType: apk`.
- [x] Configuración pública Expo inspeccionada; package `org.bionexo.learning` y versionCode 1 conservados.
- [x] Bundle Hermes y recursos exportados localmente; esto no es APK.
- [x] Revisión acotada de archivos/patrones sensibles sin valores de secretos detectados en el repositorio.
- [x] No solicitar build remoto ni gastar cuota para esta auditoría.

## Antes de solicitar EAS/build remoto

- [ ] Necesidad del build y commit exacto identificados; controles locales pertinentes aprobados.
- [ ] Alertas de dependencias revisadas para el canal de entrega.
- [ ] Perfil preview conserva APK; revisar package, versionCode y política de firma/actualización.
- [ ] Informar cuenta/autenticación requeridas y cuota/costes vigentes. No solicitar secretos pegados en el repo/chat.
- [ ] Si hay gasto adicional, obtener autorización específica; si falta cuenta, continuar con trabajo local verificable.

## Antes de afirmar «APK entregado y probado»

- [ ] Build nativo finalizado correctamente, no solo comenzado ni exportación de JS.
- [ ] Archivo APK accesible, tamaño/hash y procedencia registrados; firma y versión comprobadas.
- [ ] Instalar/actualizar sobre Android identificado; preservar progreso con firma/package compatibles.
- [ ] Cierre forzado/reapertura, modo avión desde arranque, lección, diagnóstico, laboratorio y respaldos nativos comprobados.
- [ ] TalkBack, texto grande, orientación, permisos y rendimiento registrados.
- [ ] Revisión académica humana realizada o pendiente expresamente identificada para el canal.
- [ ] README/PROGRESS y pendientes coherentes; no credenciales ni claves privadas en fuentes/artefactos.

## Evidencia mínima del cierre

Registrar fecha, commit base y de entrega, comando/entorno, resultado/contadores, artefactos reales y límites. Un test con error por navegador ausente se registra como fallo de infraestructura, se corrige y se repite; no se oculta ni se confunde con regresión funcional.
