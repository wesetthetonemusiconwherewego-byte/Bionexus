# Progreso de BioNexo

## Estado actual · MAT-PHY-01 Física y Matemáticas · 2026-10-23

Base `1cb18a8`, Git limpio al iniciar. Autorización «Dale ahora con física y matemáticas». **MAT-PHY-01 DONE en alcance de contenido local verificado**. No se inventan Fase 6, aceptación Android ni cierre de seguridad. BIO-01/CHEM-01 se conservan.

### Cambio funcional

- **17 lecciones matemáticas + 11 físicas, 168 ejercicios originales nuevos**, con dos tramos, dos ejemplos desarrollados diferentes, tres pistas por reto, feedback y aplicaciones con condiciones. Precálculo, cálculo inicial, estadística/matrices/modelos y física aplicada/biofísica tienen contenido real en mapa/Biblioteca/lector.
- Matemáticas: **23 lecciones/140 ejercicios, 11 unidades/cuatro cursos**. Física: **17/102, ocho unidades/tres cursos**. Total **88 lecciones/530 ejercicios, 41 unidades/15 cursos**; 88 conceptos con lección y **9 integrados aún planificados**. Diagnóstico/variantes/proyectos se cuentan aparte.
- Todas las bases de las cuatro rutas tienen ahora lección; enlaces cruzados funcionan, incluidos ondas→trigonometría y química/pH→logaritmos. Eso no declara dominio automático ni elimina prerrequisitos. Exploración conceptual libre conservada.
- Autoría separada en scripts/math_content.py, physics_content.py y science_authoring.py; contenido incluido offline. Fuentes/ecuaciones/unidades/supuestos en [FISICA_MATEMATICAS.md](FISICA_MATEMATICAS.md). Textos/problemas/cifras propios, sin copiar libros/figuras. Todo requiere revisión humana; introducciones no equivalen a asignaturas completas y diez minutos sigue siendo estimación.

### Verificación de aceptación

| Control | Resultado comprobado |
|---|---|
| Línea base / final | **227/227 → 266/266 PASS**, 39 regresiones nuevas; TS estricto, catálogo/grafo válidos, sin omitidas |
| Matemática/ciencia | **77 respuestas numéricas** contrastadas con relaciones independientes; tres gráficos; dominio, límites, signos, unidades, conversiones/tolerancias y errores plausibles |
| Compatibilidad | **60 lecciones/firmas anteriores exactas**, Biología/Química intactas; 97 IDs/aristas y bytes de grafo conservados; fuentes/unidades/cursos anteriores, diagnóstico/variantes/proyectos sin cambios |
| Perfil previo | Fixture anterior con feedback/sesiones ADN y dilución, historial/XP/dominio/repasos/lecturas preservados; nuevas respuestas y checkpoints sobreviven cierre/reapertura/exportación/restauración SQLite de Node |
| Datos | SQL/documento/perfil/checkpoint **3/3/1/1**, sin cambio representacional ni migración necesaria; no recalificación ni reemplazo de progreso |
| Autoría | Dos generaciones idénticas; distractores/respuestas remapeados al distribuir posiciones determinísticamente |
| Interfaz | **88/88 E2E PASS**, 80 anteriores + 8 nuevos, cero fallos/omitidos/flaky, 290.915 s; Chromium móvil/escritorio, **no Android** |
| Exportaciones | Web nueva y Android/Hermes nueva PASS; guarda de mapas PASS, sin ambas raíces; **no APK** |
| Dependencias | package/lockfile/Expo/EAS exactos; matriz instalada al día con advertencia offline, npm ls completo exit 0/sin problemas |
| Visual | Lector de límites y gráfico muestreado de ondas inspeccionados a 320×915, ancho documento=320 y sin errores de página en esas vistas; no TalkBack |
| Seguridad nueva | Auditoría exit 1: **4 high/0 critical**, node-forge y dependientes. Braces retirado oficialmente hoy; sin actualización de dependencias. R-04/SEC-01/publicación siguen bloqueados |

Evidencia: [incremento](evidence/math-physics-2026-10-23.json), [auditoría](evidence/math-physics-audit-2026-10-23.json), [bundles](evidence/math-physics-bundles-2026-10-23.json). Las fixtures tests/fixtures/math-physics-baseline se capturaron con el código anterior; no regenerarlas para hacer pasar incompatibilidades. La huella actual es `720bcda02f5385170d949a8bd807707e69aaa36daf1c84fddefdb7806d327cab`.

La primera validación detectó feedback de phys-waves-v1-q2 demasiado breve: se amplió la explicación y regeneró, sin relajar la prueba. Cambios en pruebas anteriores se limitan a conteos/estados de bases ahora autorizadas; la nueva instantánea protege las 60 lecciones/firmas completas. No se eliminan pruebas ni aumentan timeouts. La retirada oficial [GHSA-vfj7-8cjw-p6xm](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm) explica el descenso de auditoría; [node-forge](https://github.com/advisories/GHSA-86w9-cpqp-85rv) sigue sin parche indicado. Los números de 19 en registros anteriores son históricos, no el resultado nuevo.

### Pendientes y continuación

**El APK histórico no incluye las expansiones actuales.** No se compiló APK nuevo ni se ejecutó Gradle/Android/EAS/TalkBack/CI remoto. Hace falta build identificado y prueba de actualización que conserve perfil, SQLite, arranque offline, respaldo y accesibilidad/rendimiento reales. P3-03/P5-02/P5-03 y revisión docente permanecen abiertos.

Quedan nueve conceptos de Biotecnología integrada, profundización de temas amplios/fundamentos originales, revisión académica/calibración y límites ya registrados del diagnóstico. No se consideran resueltos por añadir una introducción.

**Siguiente incremento recomendado:** una unidad vertical de Biotecnología integrada con las bases ya disponibles, sin repetir las cuatro rutas ni el laboratorio/proyectos existentes. Instrucción sugerida: «Continúa BioNexo según AGENTS/PROGRESS; implementa la primera unidad pendiente de Biotecnología integrada, preserva las 88 lecciones y progreso, añade pruebas de transferencia y registra fuentes/supuestos. Mantén abiertos seguridad y aceptación Android». Solo iniciar ese nuevo alcance cuando se solicite.

## Registro histórico · SEC-01

## Estado actual · SEC-01 Remediación de dependencias · 2026-10-23

Base `c0a0f01`, Git limpio al iniciar. Autorización «Resuelve alertas de dependencias». **SEC-01 BLOCKED: no existe una actualización corregida publicada/compatible para las dos raíces. No se resolvieron las 19 alertas** ni se cambia R-04 a cerrado. P0-04 conserva su cierre histórico por acotación, no reparación. BIO-01/CHEM-01 y pendientes nativos se mantienen.

- Auditoría viva **exit 1: 19 high/0 critical**, propagadas desde braces 3.0.3 y node-forge 1.4.0, ambas últimas publicadas según registro consultado.
- Consulta de padres actuales: Expo 58.0.17, CLI 58.1.14, code-signing-certificates 0.0.7, @expo/metro 58.0.0, metro-file-map 0.87.1 y micromatch 4.0.8 siguen requiriendo las raíces. Los dos avisos oficiales mantienen «sin versión corregida». La PR forge #1152 sigue abierta; no es release incorporable como actualización estable. Desacuerdo del mantenedor de braces no equivale a retirada del aviso.
- Simulación de `npm audit fix --dry-run --ignore-scripts` en copia aislada: **exit 1, permanecen 19 high/0 critical**, sin modificación de package/lockfile. La salida simula 565 altas por tratarse de una copia sin node_modules; no se aplicaron ni se interpretan como 565 actualizaciones. Hubo avisos de peer override; no se usaron como prueba de compatibilidad.
- Las sugerencias Expo 44.0.6/RN 0.72.17 implican downgrades incompatibles. Sin force, excepciones, paquetes vacíos/versiones inventadas ni parches criptográficos locales para ocultar la auditoría.
- Exportaciones **web y Android/Hermes nuevas PASS**, guarda de mapas PASS sin rutas braces/node-forge. No significa reparación de las raíces instaladas ni es prueba de un APK/nativo.
- **Check 227/227 PASS**, TS/catálogo/grafo; matriz Expo instalada al día con advertencia de validación offline; npm ls sin problemas. Aplicación, dependencias, 60 lecciones/362 ejercicios, grafo e historial/fixtures permanecen exactos. SQL/documento/perfil/checkpoint 3/3/1/1, sin migración. No se repitieron los 80 E2E de CHEM-01 como si fueran nuevos: sin cambios de app/instalación, su evidencia queda histórica.

Evidencia y resultados de exportaciones/guarda en [security-resolution-2026-10-23.json](evidence/security-resolution-2026-10-23.json); [auditoría](evidence/security-resolution-audit-2026-10-23.json), [simulación](evidence/security-resolution-dry-run-2026-10-23.json), [documento de seguridad](DEPENDENCY_SECURITY.md). No se compila APK ni se ejecuta Android/EAS/CI remoto.

**Siguiente paso para desbloquear:** una release mantenida que corrija/retire las raíces y sea compatible con Expo; después actualizar en copia aislada, npm ci/check/Doctor/matriz, exportaciones y guardas/E2E, y comprobar Android según impacto. Mientras no exista, conservar alerta/bloqueo y no sustituir el SDK por versiones incompatibles ni afirmar remediación. Esta sesión deja investigación comprobable y documentación, sin cambios de aplicación que no reparen la vulnerabilidad.

## Registro histórico · CHEM-01

## Estado actual · CHEM-01 Química · 2026-10-23

Base `1fe7c48`, Git inicialmente limpio. Autorización: «Implementa ahora los temas de química faltantes». **CHEM-01 DONE en alcance de contenido local verificado**. BIO-01 se conserva; no se crea Fase 6 ni se cierran P3-03/P5-02/P5-03 o seguridad R-04.

### Cambios funcionales

- Los **16 temas químicos planificados** tienen lecciones introductorias reales y **96 ejercicios originales nuevos**: estequiometría; concentración/diluciones/gases/equilibrio; pH/amortiguadores; termodinámica/cinética/redox/orgánica; biomoléculas, cinética enzimática, bioenergética y analítica conceptual.
- Química: **22 lecciones/132 ejercicios, 10 unidades/cuatro cursos**. Total app: **60 lecciones/362 ejercicios**, 60 conceptos implementados y 37 planificados. Dos tramos y dos ejemplos diferentes por lección nueva, pistas/feedback, resumen, fuentes y aplicación con condiciones. La posición correcta se distribuye determinísticamente en los IDs nuevos; no se puede resolver todo el bloque eligiendo siempre la primera opción.
- Mapas, Biblioteca y lector existentes incorporan el catálogo sin modificar UI/motor. Biología → proteínas enlaza a la nueva cinética enzimática; cinco bases de física/matemáticas siguen planificadas, con aviso y exploración libre. No se finge completar esas rutas.
- Autoría modular `scripts/chemistry_content.py` y [QUIMICA.md](QUIMICA.md): ecuaciones, unidades, fuentes OpenStax/IUPAC, supuestos y límites. Redacción y cifras ficticias propias, sin copiar libros/figuras/preguntas. Todo `requires-human-review`; introducción no equivale a asignatura universitaria, y diez minutos es estimación pendiente de evaluación.

### Evidencia comprobada

| Control | Resultado |
|---|---|
| Línea base | check 201/201 antes de autoría |
| Final | **227/227 PASS**, 26 regresiones nuevas, TS estricto y catálogo/grafo válidos |
| Cálculos | Las **37 respuestas numéricas nuevas** se contrastan con relaciones independientes; cuatro curvas, errores plausibles, coma/exponentes, conversiones dimensionales y tolerancias |
| Compatibilidad | **44 lecciones y sus 44 firmas exactas**, todas las biológicas intactas; diagnóstico/variantes/proyectos, unidades/fuentes previas e IDs/aristas sin cambios |
| Perfil anterior | Fixture congelada con intento/feedback y sesión ADN, XP/historial/dominio/repasos/lecturas conservados; respuesta química y checkpoints sobreviven cierre/reapertura/exportación/restauración SQLite de Node |
| Persistencia | SQL/documento/perfil/checkpoint **3/3/1/1**, sin cambio de representación ni migración necesaria; sin recalificar o reemplazar datos |
| Autoría | Dos generaciones idénticas, grafo conserva bytes y 97 identidades |
| Interfaz | **80/80 E2E PASS**, 74 anteriores + 6 nuevos, sin fallos/omitidos/flaky; móvil/escritorio Chromium, **no Android** |
| Exportaciones | Web y Android/Hermes nuevas PASS; guarda de mapas PASS; no es APK |
| Dependencias | Matriz instalada Expo al día con advertencia offline; npm ls sin problemas; sin modificar package/lockfile |
| Visual | Lector y gráfico de analítica inspeccionados a 320×915; documento=320 px, sin desbordamiento/errores en esas vistas; no TalkBack |
| Seguridad | Auditoría viva exit 1: **19 high/0 critical**, R-04/publicación siguen bloqueados |

Evidencia: [chemistry-2026-10-23.json](evidence/chemistry-2026-10-23.json), [auditoría](evidence/chemistry-audit-2026-10-23.json), [bundles](evidence/chemistry-bundles-2026-10-23.json). Las fixtures de `tests/fixtures/chemistry-baseline` se capturaron contra código/catalogo anterior; no regenerarlas con la expansión.

Los controles nuevos detectaron feedback demasiado breve y dos enunciados genéricos repetidos: se enriquecieron textos/enunciados, sin relajar umbrales. TS detectó etiqueta de aserción posiblemente undefined y se corrigió el tipo. Las regresiones BIO-01 cambian únicamente el conteo global/estado del prerrequisito químico autorizado; las 44 firmas/contenidos anteriores ahora tienen snapshot adicional. No se eliminan tests ni se elevan timeouts.

### Entrega y siguientes pasos

**El APK histórico no incluye las expansiones de Biología ni Química**. Hace falta nueva compilación identificada e instalación/aceptación real para usarlas desde Android; exportar Hermes no genera APK. La política del binario antiguo permanece histórica. No se ejecutó Gradle, EAS, Android/TalkBack ni revisión docente.

Quedan revisión académica/tiempos, profundización de temas amplios y fundamentos originales, límites del diagnóstico ya registrados y **37 conceptos de otras rutas**. Se conserva la exploración libre. Siguiente incremento académico recomendado: bases de Matemáticas (polinomios, racionales, exponenciales/logaritmos), que desbloquean razonamiento de pH y cinética; requiere la próxima autorización de materia. En paralelo, preparar build nuevo y aceptación nativa sin confundirlo con publicación mientras R-04 siga abierto.

## Registro histórico · BIO-01

## Estado actual · BIO-01 Biología primero · 2026-10-23

Base `3734d2f` recuperada de la última entrega, sin cambios ajenos. Prioridad del usuario: «Dale implementando los contenidos de biología primero». **BIO-01 DONE en alcance de contenido local verificado**; no se crea una Fase 6 ni se cierran P3-03/P5-02/P5-03 o R-04. Las fases históricas conservan su alcance.

### Implementación

- Los **20 conceptos biológicos planificados** tienen ahora lecciones introductorias reales: homeostasis; ciclo/mitosis y meiosis; señalización/enzimas; metabolismo/ATP, fotosíntesis/respiración; ADN/ARN, replicación, expresión, mutación, regulación y genética; microbiología/inmunología, proteínas/fisiología, vegetal y sintética conceptual.
- **120 ejercicios originales nuevos**, seis por lección, dos tramos con ejemplos, pistas y feedback, resumen propio y aplicaciones con límites. Biología: **26 lecciones/156 ejercicios, 12 unidades y cuatro cursos**. Total app: **44 lecciones/266 ejercicios**, 44 conceptos con lección y 53 planificados en otras áreas. Diagnóstico/variantes/proyectos aparte.
- Aprender distingue los cursos y elimina el horizonte vacío de Biología; Biblioteca incorpora sus explicaciones y vocabulario inglés. El lector muestra el curso real y advierte bases de otras rutas aún planificadas. Mi progreso calcula el denominador desde el catálogo; no conserva el 24 fijo descubierto en la prueba.
- Autoría modular en `biology_content.py`; referencias específicas de OpenStax verificadas, hechos separados de modelos/datos ficticios. Sin protocolos de cultivo/manipulación, sin figuras/preguntas copiadas. Todo conserva `requires-human-review`; diez minutos es estimación sin evaluación con estudiantes. **Introducción conceptual no equivale a asignatura universitaria completa.**

### Compatibilidad y pruebas

Línea base: instalación limpia y check **175/175 PASS**. Final de lógica: **201/201 PASS**, TS estricto, catálogo/grafo y 26 regresiones nuevas (20 recorridos de soluciones/XP más integridad, conteos científicos y persistencia). La prueba SQLite de Node añade respuesta/checkpoint de ADN a un perfil anterior, exporta, cierra/reabre/restaura y comprueba historial/XP/lecturas conservados; no prueba driver Android.

Los 24 bloques anteriores (incluidas las seis lecciones biológicas), diagnóstico, variantes/reglas/proyectos y aristas/IDs del grafo se mantienen exactos. `prerequisites.json` conserva bytes. Instantánea previa de catálogo congelada en tests/fixtures/biology-baseline/catalog-3734d2f.json; fixture de progreso anterior sin regenerar conserva lectura 12.345 y sesiones compatibles. SQL/documento/perfil/checkpoint **3/3/1/1**, sin cambio de representación ni migración necesaria. No se recalifica historial ni se duplica XP. Dominio/almacenamiento/dependencias/config Expo/EAS no cambian.

Lector de Biología sintética inspeccionado visualmente a 320×915: ancho documento=320, sin desbordamiento horizontal ni errores de página en esa vista. No es una auditoría nativa de accesibilidad. Autoría determinista; exportaciones web y Android/Hermes y guarda de mapas aprobadas. Auditoría viva **exit 1, 19 high/0 critical**; no force fix ni ocultación. Interfaz: **74/74 E2E PASS**, 68 anteriores + 6 nuevos, cero fallos/omitidos/flaky; Chromium headless shell 156.0.8078.47 móvil/escritorio. No es prueba Android. Resultado final en [evidencia BIO-01](evidence/biology-2026-10-23.json). Ver [detalle de cursos/fuentes](BIOLOGIA.md), [auditoría](evidence/biology-audit-2026-10-23.json) y [bundles](evidence/biology-bundles-2026-10-23.json).

Los tests nuevos inicialmente usaban IDs de sesión distintos al completar y omitían guardar borrador antes de submit: las guardas existentes los rechazaron; se corrigió el recorrido de prueba sin quitar validaciones. E2E detectó una recarga anticipada y un selector de pestaña no disponible en móvil; se usa destino observado y el acceso accesible común. La unión de accesos resultó ambigua en escritorio y se sustituyó por el botón compartido. El contador fijo de 24 sí era un defecto de UI al ampliar catálogo y se corrigió/añadió regresión. No se borraron pruebas ni elevaron timeouts.

### Entrega y pendientes

**El APK previo no incluye Biología ampliada.** Cambió la huella del contenido/UI; se necesita otro build identificado para instalarlo. La política histórica preview-arm64-v1 permanece vinculada al APK anterior y debe bloquear al compararse con fuentes actuales. No se presenta exportación Hermes como APK ni se reutiliza el hash antiguo como resultado nuevo. No se ejecutó Gradle, Android, TalkBack, revisión humana, EAS o publicación.

Quedan revisión académica/tiempos, profundización de las seis lecciones biológicas originales (conservadas por compatibilidad), diagnóstico de límites y resúmenes originales identificados en el informe de revisión, y desarrollo de otras rutas. No se resolvieron esos temas ajenos silenciosamente. Genética/proteínas mantienen bases cruzadas todavía planificadas con aviso y exploración libre. R-04 sigue bloqueando publicación; pendientes nativos de Fase 5 permanecen.

Siguiente: revisar este contenido con docentes y preparar su nueva compilación/aceptación Android; escoger después la siguiente materia prioritaria. No repetir los 20 temas como si siguieran sin lección ni confundir esta expansión con cierre de Fase 5.

## Registro histórico · Continuación de Fase 5

## Estado actual · Continuación de Fase 5 · 2026-10-23

Base recuperada `6bc0d87`, Git limpio e historial completo. Se verificó el SHA-256 del ZIP anterior antes de recuperar el checkout; no se repitieron Fases 1–4 ni P5-01. **Fase 5 sigue TESTING; P5-02 BLOCKED, P5-03 TESTING y P3-03 TESTING.** El incremento comprobable es la verificación automatizada del artefacto de P5-03, no una aceptación instalada.

### Qué cambió

- Inspector de solo lectura `scripts/verify-apk.ts` y `scripts/readiness/apk.ts`, sin dependencias: hash/tamaño, huella de fuentes, firma v2/certificado único, package/versiones/SDK/ABI, manifiesto release, permisos exactos, alineación 16 KB y bundle offline incluido. Detecta cambio del APK durante la inspección y nombres potencialmente sensibles. Argumentos separados, sin shell ni claves; herramientas con tiempo/salida acotados. No instala, firma, descarga, desinstala ni modifica datos.
- Política explícita `docs/release/preview-arm64-v1.json` ligada al APK anterior y su commit de origen. No se genera una política nueva para hacer pasar un archivo distinto. Cambiar código exige reconstrucción y nueva revisión; un hash coincidente no autentica por sí solo la procedencia del build.
- Doce pruebas nuevas para el inspector, con runners sintéticos claramente separados de resultados nativos. La comprobación real del APK recuperado también pasó con Build Tools 37.0.0 oficiales. No es un APK nuevo: se mantienen bytes/certificado/versiones de la entrega anterior.
- Corregido el mensaje obsoleto del comando `phase4:readiness`: ahora orienta a las tareas nativas pendientes P3-03/P5-02/P5-03. Conserva el mismo contrato/validación y bloqueo de plantilla PENDING; no marca tareas terminadas.

### Evidencia y límites

Línea base: `npm ci` limpio y `npm run check` **163/163 PASS**. Final: `npm run check` **175/175 PASS**, TypeScript estricto/catálogo/grafo, ambas exportaciones nuevas y guarda de mapas PASS; matriz Expo instalada compatible (comprobación offline con advertencia), árbol npm sin problemas. Interfaz: **68/68 E2E PASS**, 203,94 s, 0 fallos/omitidos/flaky, Chrome headless shell 156.0.8078.47 en móvil/escritorio; no Android. La implementación nueva pasa sus **12/12** pruebas; controles finales y evidencia consolidada en [phase5-followup-2026-10-23.json](evidence/phase5-followup-2026-10-23.json). [Inspector real](evidence/phase5-apk-verification-2026-10-23.json), [auditoría](evidence/phase5-audit-2026-10-23.json) y [guarda de bundles](evidence/phase5-bundles-2026-10-23.json).

La primera verificación TS detectó un tipo no estrechado en una tupla de pruebas; se corrigió sin alterar aceptación. La descarga Playwright predeterminada falló al extraer; Chrome completo después no arrancó por restricción de sockets Unix (tras corregir permisos locales del binario). Se canceló esa pasada y se comprobó el arranque de headless shell oficial antes de repetir los 68 recorridos completos. Solo se cuenta el informe final aprobado; no se quitaron pruebas ni se cambiaron timeouts.

La auditoría viva mantiene **19 high/0 critical**, exit 1. Se volvieron a consultar registro y avisos oficiales: braces 3.0.3/node-forge 1.4.0, sin parche indicado; Expo 58.0.17 se conserva. No force fix, overrides ni downgrade. R-04 sigue abierto; firma válida no cierra seguridad ni autoriza publicación.

Las fuentes/configuración de aplicación, package/lockfile, catálogo/grafo y fixtures se mantienen exactos respecto a `6bc0d87`; huella `88262fd1af232dcf05f18c60c064e75f9ec93dc2599b307baf83e2032392dc2e`. SQL/documento/perfil/checkpoint **3/3/1/1**, sin cambio de representación ni migración necesaria. El APK mantiene SHA-256 `76815af134ab5970269c42ee4153f5a647ad6184965ed9c6ab82ab627b8bbfc2`, versión 0.1.0/versionCode 1 y firma pública de prueba. Las comprobaciones unitarias de SQLite son de Node, no del driver nativo.

El entorno recuperado no tiene JDK completo, SDK de compilación/adb, emulador ni KVM/dispositivo conectado. Se aprovisionaron solo Build Tools para inspección, sin instalar un SDK de compilación ni ejecutar Gradle. **No se instaló ni ejecutó Android**. Quedan SQLite/reinicio, actualización preservando progreso, respaldo/importación nativos, arranque en modo avión, TalkBack, escalas/orientación y rendimiento real. Revisión académica humana pendiente. P5-02 y P5-03 no pueden cerrarse con estos resultados locales.

### Fase 6 y siguiente paso

La instrucción nueva pide Fase 6, pero ningún documento recuperado la define: el plan acordado contiene Fases 0–5. Se preguntó su alcance y el usuario eligió **«Enviar sus requisitos»**. Se espera ese texto; no se inventa funcionalidad ni se presenta una fase inexistente como completa. En paralelo se completó el incremento verificable de P5-03 descrito arriba (ADR-014).

Siguiente: ejecutar la matriz Android sobre el APK identificado, registrar/revisar evidencias de P5-02/P3-03, resolver R-04 antes de publicar y cerrar P5-03 solo cuando cumpla. Incorporar los requisitos de Fase 6 cuando se reciban, sin repetir trabajo terminado.

## Registro histórico · Integración de Fases 4/5

## Estado actual · Fase 4 DONE · Fase 5 TESTING · APK generado · 2026-10-22

Se ejecutó «lo que falta y la fase 5» desde `18eb63a` limpio. **P4-01/02/03 y P5-01 DONE en alcance local comprobado; P5-02 BLOCKED y P5-03 TESTING por aceptación instalada pendiente. P3-03 sigue TESTING.** ADR-013 permitió continuar implementación sin fabricar un cierre nativo ni levantar el bloqueo público R-04.

### Cambios funcionales

- BioLab: pregunta, variables/controles, hipótesis, cuatro pasos, ejemplo desarrollado y predicción antes de calcular. Modelo gaussiano/supuestos/límites explícitos, sin experimentos reales ni XP por predicción.
- Nuevos registros exigen dos pH distintos de un mismo modelo y notas; no duplican condiciones ni interpretan repetición como réplica. Guardado con identidad/fecha estables e idempotencia. Datos antiguos de una condición siguen disponibles, con lecturas originales sin recalcular.
- Informe reabrible `/lab-session/[id]`: hipótesis/observación, tabla paginada, gráfico por modelo y comparación de valores guardados. Hasta 200 puntos dibujados con aviso si hay más; respaldo completo intacto. Acceso a registros anteriores en grupos de cinco, resumen limitado para móviles.
- Proyecto integrado de seis retos originales: supuestos, volumen/dilución ideal, conversión de unidades, gráfico, media de conteos simulados y conclusión con límites. Todas sus bases están implementadas. Conserva respuestas confirmadas y continúa pendientes; borrador/cursor de esa ronda transitorio y declarado. Primeros aciertos suman como máximo 60 XP; practicar otra vez no duplica premios. Mi progreso dirige al proyecto correspondiente.
- Validación del grafo incluido y más referencias de catálogo; estructuras malformadas devuelven errores desde validateCatalog. No se admite contenido externo ni se afirma un esquema universal. Guía/proyecto separados de UI y generados por phase4_content.py.
- La precarga del destino de progreso corrige el fallo reproducido del retorno web después de recargar el proyecto y desconectar. La vista web sigue sin PWA/arranque offline desde cero; el objetivo nativo incluye sus recursos en el APK.

### Verificaciones reales

| Control | Resultado y límite |
|---|---|
| Línea base | check **148/148 PASS** antes de editar |
| Final | check **163/163 PASS**, TypeScript estricto, contenido/grafo; 15 pruebas nuevas |
| Interfaz final | **68/68 PASS**, 173,2 s; 62 previas + 6 nuevas, cero fallos/omitidos/flaky; Chromium móvil/escritorio, no Android |
| Último ajuste nativo | Solo bloqueo de permiso; check 163/163 repetido. Exportación web final idéntica byte por byte a los archivos probados, sin cambiar UI/contenido |
| Exportaciones y seguridad JS | Hermes Android y web en salidas finales nuevas; guarda de mapas PASS, sin las dos raíces afectadas; no es auditoría binaria |
| Compatibilidad | 24 lecciones/146 retos, primera transferencia y grafo literalmente iguales a 18eb63a; fixtures anteriores intactas y nueva fixture conservada, restauración/reopen SQLite PASS |
| Autoría y ciencia | Generador determinista, seis retos/cálculos/unidades comprobados; revisión técnica en ACADEMIC_REVIEW, humana pendiente |
| Herramientas | Instalación limpia npm ci PASS (565 paquetes), npm ls sin problemas, Doctor 1.21.5 20/20 y matriz instalada offline PASS con advertencia |
| Visual/carga | Dos vistas nuevas inspeccionadas a 412×915; informe guardado a 320 px/texto CSS 200% sin overflow/errores; 100/1.000/10.000 condiciones con tabla 20→40 y gráfico 100/200/200, datos intactos |
| Configuración nativa | JDK/SDK/adb/build-tools disponibles, preflight TOOLS_PRESENT; huella de copia aislada igual a fuentes del commit nativo |
| APK final | **Gradle exit 0 / BUILD SUCCESSFUL in 5m 41s**, recompilación offline con dependencias ya cacheadas; 643 tareas, 615 ejecutadas/28 actualizadas |
| Verificación de artefacto | Firma v2 verificada, certificado de prueba conservado, ZIP íntegro, alineación 16 KB PASS, Hermes y contenido nuevo incluidos; sin archivos privados de firma/env empaquetados |
| Seguridad pública | Auditoría viva **exit 1, 19 high/0 critical**; R-04 y CI rojo permanecen, sin force fix ni downgrade |
| Higiene | Diff/formato y enlaces locales revisados; patrones de secretos/archivos de firma sin coincidencias en revisión acotada; no revisión exhaustiva |

Las mediciones de navegación del informe histórico fueron 426,7/385,1/860,0 ms (una muestra por volumen, navegador y automatización incluidos). No son presupuestos móviles ni evidencia de rendimiento Android. Las cifras no monotónicas no demuestran mejora; solo se comprueba límite de renderizado y conservación de datos.

### Artefacto y protección de datos

**BioNexo-Android-ARM64-Prueba.apk**, 33.567.238 bytes (~32,0 MiB), package `org.bionexo.learning`, versión `0.1.0`, versionCode `1`, minSdk 24/targetSdk 36, solo `arm64-v8a`, variante release no debuggable. Firma con la clave pública de prueba de la plantilla, sin política de producción. SHA-256:

`76815af134ab5970269c42ee4153f5a647ad6184965ed9c6ab82ab627b8bbfc2`

Certificado SHA-256: `fac61745dc0903786fb9ede62a962b399f7348f0bb6f899b8332667591033b9c`. SYSTEM_ALERT_WINDOW, micrófono y permisos amplios de almacenamiento ausentes. Fuente de implementación `3dcca6d`; ajuste de manifiesto/build `83eb426`; huella final `88262fd1af232dcf05f18c60c064e75f9ec93dc2599b307baf83e2032392dc2e`. Copia CNG/SDK/keystore fuera del repositorio; el archivo entregado no contiene clave privada. No se solicitó EAS, cuenta, coste ni publicación.

SQL/documento/perfil/checkpoint siguen **3/3/1/1**, sin representación nueva ni migración innecesaria. Nueva fixture capturada con motor 18eb63a antes de editar: progress-pre-phase45-v3.json, SHA-256 `cb2ce6187f255f63d761f5371d9701b55186e7c3f66b308f9d483a68f828c8dc`; conserva lectura histórica 12.345, XP, intentos y checkpoints exactos. No hay recalificación. Antes de actualizar una instalación real: exportar respaldo y comprobar firma/package compatibles; no desinstalar para eludir conflicto de firma.

### Fallos reproducidos y límites pendientes

La prueba inicial de diferencia 10 encontró 9.999999999999998 por coma flotante: se usa tolerancia 1e-12 en esa aserción, sin redondear historia. El primer E2E omitía seleccionar la materia integrada: se corrigió el recorrido. La suite v3 detectó el fallo real del chunk de retorno offline (66/68); tras precarga, proyecto 2/2 y suite final 68/68 PASS. Una pasada concurrente con Gradle alcanzó 8 GB y provocó timeout en una prueba anterior; se interrumpió y repitió secuencialmente sin elevar timeouts. Compilación limitada a dos trabajadores/sin paralelismo/Kotlin in-process, con logs diagnósticos; la primera compilación correcta detectó permiso overlay heredado, bloqueado y recompilado antes de entregar. Advertencias de deprecación de terceros Gradle/AGP/Kotlin no se presentan como resueltas ni se recomienda actualizar a Gradle 10 sin revisión.

**No se instaló ni ejecutó el APK en dispositivo/emulador.** TalkBack, escalas/orientación/legibilidad nativas, driver expo-sqlite, cierre/reanudación, respaldo/compartir/importar, arranque en modo avión y tiempos reales siguen pendientes. No hay emulador configurado/KVM ni teléfono disponible en este entorno. Revisión académica humana y eficacia educativa pendientes; 19 high bloquean lanzamiento público. Ayuda/borradores abandonados antes de confirmar en rondas transitorias no prueban independencia. R-07/historial serializado y R-10/importación de contenido externo no se declaran resueltos globalmente.

**Siguiente:** P5-02 y aceptación P3-03 con Android identificado, usando PHASE4_HANDOFF y registro manual. Comprobar firma/respaldo antes de actualizar; ejecutar escenarios reales y revisar evidencia. Después cerrar P5-03 si procede; resolver R-04 antes de publicar. No repetir Fase 4/P5-01 ni convertir resultados web/build en aceptación nativa.

Evidencia: [integración](evidence/phase45-2026-10-22.json), [build/artefacto](evidence/phase45-native-build-2026-10-22.json), [tareas Gradle](evidence/phase45-gradle-summary-2026-10-22.txt), [equivalencia web final](evidence/phase45-final-web-equivalence-2026-10-22.json), [carga/visual](evidence/phase45-visual-load-2026-10-22.json). Lo siguiente conserva registros históricos.

## Registro histórico · PREP-04

## Estado actual · PREP-04 DONE · Fase 3 TESTING · 2026-10-22

Se completaron los preparativos solicitados desde `f23fc84` limpio. **La preparación está DONE; P3-03/Fase 3 siguen TESTING y Fase 4 PENDING.** No se inició BioLab, no se redefinió la aceptación nativa ni se inventó un APK.

### Preparación funcional implementada

- `npm run android:preflight` detecta herramientas locales/JAVA_HOME/SDK y devuelve diagnóstico JSON. Probado con JDK/SDK ausentes y carpetas inválidas: bloquea sin tocar dispositivos/cuentas/preferencias ni descargar herramientas.
- `npm run phase4:readiness -- RUTA` verifica registro manual, huella de fuentes/fecha/build/dispositivo, once casos nativos y mediciones para tres volúmenes. Exige archivos/hash dentro de la carpeta indicada; bloquea plantilla PENDING, datos incompletos/duplicados, cambios de fuentes, archivos modificados, rutas externas y symlink fuera de carpeta. Un registro completo produce REVIEW_REQUIRED: no certifica observación humana, firma/build ni cambia el plan automáticamente.
- Huella funciona también con ZIP extraído sin Git y normaliza texto LF/CRLF entre Windows/Linux; conserva binarios. CNG es la fuente canónica, no modificaciones manuales externas en android/. Plantilla sin resultados inventados incluida.
- Prebuild Android **realmente ejecutado en copia aislada**, con plantilla local de Expo y sin npm install/Gradle en esa copia. Primera ejecución mostró ausencia de expo-system-ui para userInterfaceStyle automático. Instalación compatible `~58.0.6` mediante expo install; segunda generación sin ese aviso y recurso nativo automatic presente. Copia/keystore generados no se incluyen en repositorio ni entrega.
- Guía [PHASE4_HANDOFF.md](PHASE4_HANDOFF.md): ruta Windows/Android, protección de firma/progreso, evidencias y primer incremento P4-01 delimitado para después de cerrar P3-03. AGENTS/plan/checklist/arquitectura y riesgos actualizados.

### Verificaciones ejecutadas

| Control | Resultado y límite |
|---|---|
| Base | npm run check **136/136 PASS**, TS/catálogo |
| Final | **148/148 PASS**, 12 nuevas para diagnóstico/registro/rutas/huellas/CLI; TypeScript estricto y catálogo PASS |
| Playwright | **62/62 PASS**, 192,1 s; cero fallos/omitidos/flaky y errores de reporte vacíos; navegador móvil/escritorio, no Android |
| Prebuild aislado | PASS después de corregir aviso; aplicación org.bionexo.learning, 0.1.0/versionCode 1 y apariencia nativa automatic generados; no compilación Gradle |
| Exportaciones/guardas | Hermes Android/web PASS en rutas nuevas, web usada directamente en E2E; 1 bundle/1.332 fuentes Android y 11/859 web, sin raíces afectadas en mapas JS |
| Expo | Doctor 1.21.5 **20/20 PASS**, matriz instalada offline PASS con advertencia; npm ls exit 0 |
| Diagnóstico Android | **BLOCKED/exit 1**: Java disponible, sin javac/JDK completo, SDK, adb o build-tools; no evidencia de dispositivo |
| Puerta nativa | **BLOCKED/exit 1 intencional** ante plantilla vacía; ningún resultado nativo marcado PASS |
| Seguridad | Auditoría viva **exit 1, 19 high/0 critical**; R-04 y bloqueo público continúan, CI no silenciado |
| Compatibilidad | Fuentes app/dominio/contenido/grafo/fixtures/formatos previos intactos; paquete/firma prevista/versiones persistentes conservados. Solo una dependencia añadida, sin actualización de Expo/RN |

No hay representación persistente nueva: SQL 3/envoltorio 3/perfil 1/checkpoint 1; no migración ni reemplazo del progreso. ADR-012 documentó el alcance antes de editar. Hubo errores de tipos en narrowing de campos unknown y un import de fs omitido durante la evolución del comprobador; se corrigieron y repitió check, sin eliminar pruebas. El prebuild anterior con aviso se conserva como reproducción; solo la segunda generación sin aviso se considera corrección.

### Puerta restante y siguiente paso

No hay SDK/JDK completo/dispositivo ni APK compilado/firmado/instalado aquí. TalkBack, fontScale real/legibilidad de pestañas, orientación, SQLite/reanudación, arranque offline, respaldos y tiempos de dispositivo siguen pendientes. Datos sintéticos del validador prueban su lógica, nunca constituyen resultados Android. Un hash consistente no demuestra que un APK se construyó con esas fuentes o que se ejecutó una prueba manual. Revisión humana obligatoria antes de actualizar estado.

**Siguiente:** seguir PHASE4_HANDOFF en un entorno Android real, completar registro/evidencias y revisar P3-03. Después de documentar cierre, seleccionar P4-01, sin rehacer P3-01/02. No se solicitó EAS, autenticación, cuota, credenciales, costes ni publicación. La dependencia nueva requiere reconstrucción nativa; verificar firma compatible sin desinstalar/perder el cuaderno.

Evidencia [phase4-prep-2026-10-22.json](evidence/phase4-prep-2026-10-22.json), [generación nativa](evidence/phase4-prep-native-project-2026-10-22.json), [entorno](evidence/phase4-prep-android-environment-2026-10-22.json), [puerta](evidence/phase4-prep-readiness-2026-10-22.json). Lo siguiente conserva registros históricos.

## Registro histórico · Fase 3

## Estado actual · Fase 3 TESTING · 2026-10-22

Base `6d5e92d` limpia; toda la Fase 3 autorizada. **P3-01 y P3-02 DONE; P3-03 TESTING**: implementación y auditoría local terminadas, aceptación Android pendiente. No se inicia Fase 4 ni se marca la fase completa sin dispositivo. Fases 0–2 conservadas. R-04 sigue abierto y bloquea publicación; no se inventó el informe funcional 2.0 ausente.

### Qué cambió

- Diagrama celular controlado con regiones A/B/C de 70×56, selección por marca/borde y descripción textual completa. Los radios y el diagrama comparten la respuesta/borrador existente, sin revelar orgánulos antes de comprobar. Recarga conserva selección/feedback sin reenviar ni duplicar XP. Mismo enunciado, solución, IDs y firma.
- Laboratorio: lecturas de N/A al mismo pH y diferencia en **puntos porcentuales**, curva continua/discontinua, control para ir al óptimo y límites accesibles. Ejes/rangos se leen también fuera del SVG; etiquetas fraccionarias ya no se redondean a enteros y datos inválidos muestran texto seguro. Motor gaussiano/valores/supuestos intactos, datos simulados explícitos.
- pH/modelo/comparación se conservan como parámetros de navegación validados al cambiar pestaña/recargar. No son campos del perfil ni se exportan en su respaldo; abrir una URL nueva sin parámetros usa valores iniciales. Hipótesis/observaciones/condiciones sin guardar siguen transitorias: aviso visible para guardar antes de salir. Cuaderno guardado conserva el mecanismo anterior.
- Foco visible en botones/pestañas/regiones, estado web de pestaña explícito, bordes de controles con contraste suficiente y reajuste de botones/badges/fila pH. La marca deja espacio a accesos en cabecera estrecha o escala nativa alta. Configuración muestra movimiento efectivo del sistema/app y responde a cambios en vivo.
- Cuello medido de repaso: índice local de última aparición por ejercicio sustituye copias/inversiones repetidas del historial en el comparador. Selección exactamente igual al código anterior, incluido orden estable, diagnósticos y fechas desordenadas. No modifica dominio, XP, calendarios ni eventos.

### Datos y alcance preservados

ADR-011 escrita antes de cambios. Fixture `progress-phase2-v3.json` capturada con el motor anterior: historial previo, variante y transferencia, dos checkpoints y cuaderno. SHA-256 `3f7be3e76a11bd9f5894ffca01dc235b10d9d2770bc2b71ff4667d7ba13ffc84`; perfil/exportación/restauración exactos y firmas compatibles. Fixtures anteriores intactas. Oráculo de selección congelado en `tests/helpers/review-queue-phase2.ts`, con 30 conjuntos de historia y límites/empates/fechas más perfiles históricos.

SQL 3/envoltorio 3/perfil 1/checkpoint 1 sin cambios: no hay representación que migrar ni datos iniciales que sustituyan progreso. Catálogo/grafo/IDs/soluciones/generador v1 no cambiaron: 24 lecciones/146 retos + 12 diagnósticos, 14 variantes y dos retos de transferencia. Sin nuevas dependencias, lockfile, claves, cuentas ni costes. La figura nueva es propia; fuente conceptual OpenStax Biology 2e §4.3 verificada, revisión humana pendiente.

### Evidencia ejecutada

| Control | Resultado real |
|---|---|
| Línea base | `npm run check` **125/125 PASS**, TS y contenido |
| Final | **136/136 PASS**, 11 nuevas, TypeScript estricto y catálogo válidos |
| Nuevos recorridos | **10/10 PASS**, selección/reanudación, gráfico/navegación/URLs/límites, teclado/foco, movimiento y 320 px/200% |
| Suite general final | **62/62 PASS**, 52 anteriores + 10 nuevos, cero omitidos/flaky/fallos y reporte de errores vacío; Chromium móvil/escritorio |
| Comparación/preservación | Oráculo previo idéntico, inmutabilidad, fixture exacta, firmas compatibles; regresiones de SQLite/reapertura/restauración/errores y premios siguen pasando |
| Exportaciones | Android Hermes y web PASS, directorios nuevos; E2E sirve directamente la web nueva mediante BIONEXO_WEB_ROOT |
| Guarda de mapas | PASS: Android 1 bundle/1.332 fuentes; web 11 bundles/859 fuentes, sin coincidencias de las dos raíces; no auditoría binaria |
| Configuración | Doctor 1.21.5 **20/20 PASS**, matriz instalada offline PASS con advertencia; npm ls exit 0; preview APK/package/versionCode 1 conservados |
| Visual/movimiento | Diagrama y gráfico inspeccionados a 412×915; 320×915 con font-size/line-height CSS x2, cero overflow final/errores de página; foco 3 px, preferencias en vivo/persistidas |
| Contraste | Texto activo mínimo oscuro 6,79:1 / claro 4,52:1; bordes y foco ≥3:1 en fondos auditados; controles deshabilitados y totalidad de pantallas no auditados |
| Medidas | 100/1.000/10.000 intentos sintéticos; selección grande **16,302→0,423 ms** mediana Node y razones **24,951→11,519 ms**; inicio/Practicar medidos en navegador, muestras y límites registrados |
| Seguridad | Auditoría viva **exit 1, 19 high/0 critical**; R-04 y bloqueo público conservados |
| Higiene | Formato de archivos tocados, diff/enlaces revisados al cierre; sin dependencias ni secretos nuevos |

Las pruebas iniciales nuevas detectaron un nombre de helper inexistente y una función que ocultaba el `document` del navegador; se corrigieron las pruebas y se repitieron checks. TypeScript detectó handlers de foco añadidos accidentalmente a Line SVG; se dejaron solo en controles y se repitió. La primera medida visual capturó un relayout incompleto del slider; dos frames estabilizan la medida y el caso final conserva la aserción. Se corrigió la colisión de marca observada después de la primera suite general; se reexportaron ambas plataformas y se repitió toda la suite: 62/62. No se ocultan estas pasadas ni se presentan como aprobación final.

### Pendientes y siguiente paso

**P3-03 no es DONE:** no existen SDK/adb/emulador/Gradle/dispositivo aquí. TalkBack, escalado real de Android, foco/gestos/orientación, driver SQLite y tiempos de dispositivo siguen pendientes. CSS/viewport Pixel 7 no son Android. No se generó APK ni se ejecutó CI/EAS remotos. La barra inferior envuelve mucho sus etiquetas a 320 px/200%; revisar legibilidad/estrategia de navegación en dispositivo al cerrar la tarea. SVG tiene texto fijo con alternativas escalables; no se afirma accesibilidad universal.

Historial de pruebas sintético con respuestas correctas/25% ayuda, no todos los patrones de error ni datos reales. A 10.000 intentos ~1,86 MB; serialización completa ~53 ms Node sigue sin optimizar, copias no se purgan y R-07 permanece abierto. Mediciones de navegador incluyen carga/automatización/competencia y no son monotónicas ni presupuestos móviles. R-09/revisión humana y evaluación con estudiantes continúan abiertos. App sigue 0.1.0; no se declara 2.0 finalizado.

**Siguiente: cerrar P3-03 en Android disponible**, usando [UX_AUDIT.md](UX_AUDIT.md) y la instrucción concreta de DEVELOPMENT_PLAN. No repetir P3-01/02 ni iniciar Fase 4. Evidencia principal [phase3-2026-10-22.json](evidence/phase3-2026-10-22.json), mapas/auditoría/medidas asociados. Los estados siguientes son históricos.

## Registro histórico · Fase 2

## Estado actual · Fase 2 DONE · 2026-10-22

Se completó toda la Fase 2 autorizada, sin iniciar la Fase 3. Base `d2a3258` limpia. Orden por dependencias/riesgo: P2-02 (`50fbfad`), P2-01 (`502b1d3`), P2-03 (`0b4866f`), P2-04 (commit que contiene este cierre). Fases 0/1 conservadas; fases 3–5 PENDING. R-06 corregido para respuestas nuevas. R-04 permanece abierto y bloquea lanzamiento público bajo ADR-007. Informe 2.0 completo ausente: solo requisitos visibles y plan autorizado, sin inventar funcionalidades.

### Incremento funcional completo

- **P2-02:** gramática numérica acotada; operandos/cociente/conversión finitos, sin underflow silencioso a cero ni unidades heredadas de prototipo. Tolera equivalencias declaradas y usa margen relativo sin piso absoluto que oculte escalas pequeñas. Sin eval ni álgebra simbólica general. Los tests nuevos reprodujeron fallos antes y pasaron después.
- **P2-01:** familia de trinomios mónicos con 14 pares/semillas inmutables, rondas de tres (inéditas, después menos recientes), IDs que reconstruyen parámetros/solución y un premio de 10 XP compartido. No infla las 24 lecciones. Las variantes falladas pueden volver en repaso/revisión de errores.
- **P2-03:** diez reglas explícitas para distractores/omisiones, con fuentes, ejemplos y bases relacionadas. Se puede visitar una base sin perder el checkpoint de la lección; el puente existente conserva elección, feedback y ayuda al retornar. Dos retos de transferencia interpretan raíces/evaluación en una diferencia de señales hipotéticas, distinta del ejemplo geométrico. Progreso muestra primera respuesta y la más reciente, separando ayuda, sin reemplazar la muestra inicial ni certificar capacidad.
- **P2-04:** Inicio explica la lección sugerida; Practicar/Repaso explican concepto, vencimiento, intervalo, lapsos y procedencia. Solo atribuye un evento si reproducir el planificador con los resultados registrados coincide con el calendario. La respuesta más reciente se distingue del evento origen. Historial insuficiente o cambio de zona usa fallback explícito. Mostrar razones no modifica estado, prioridad, pesos ni calendario; práctica libre permanece.

Catálogo actual: **24 lecciones/146 retos**, 12 diagnósticos, **14 variantes adicionales y 2 retos de transferencia**, diez reglas, 97 conceptos (73 planificados). Los 24 contenidos anteriores, diagnóstico, conceptos, unidades, cursos, materias y grafo son idénticos a la base. Hay nueva autoría en `phase2_content.py` y definición/generador de familia versionada; contenido y software mantienen sus licencias documentadas.

### Datos y compatibilidad comprobados

ADR-010 se escribió antes de editar evaluador/dominio. Fixture `tests/fixtures/progress-phase1-v3.json`, capturada con el motor d2a3258: perfil previo, un intento de phys-vectors-q3 con 1/1e309 aceptado antes y checkpoints actuales de fracciones/factorización. SHA-256 `89b43a23c06ef1c5851db0ddb395d649874a5c71dbccdf03fdef2d215c83528c`. El resultado anterior, XP, dominio, revisiones y sesiones se conservan exactamente; el evaluador nuevo rechaza la misma respuesta sin recalificarla en el historial. Las fixtures raíz/v2/v3 anteriores permanecen intactas.

SQL 3/envoltorio 3/perfil 1/checkpoint 1: **sin cambio de representación ni migración nueva**. Los nuevos IDs usan las referencias históricas existentes; se incluyen al exportar/restaurar. Las variantes comparten su ID semilla 0 como premio canónico; el cálculo histórico 10×premios + 20×lecciones permanece válido. Los ejercicios antiguos conservan su política e IDs. Reabrir/restaurar SQLite preserva intentos previos y variantes nuevas. Checkpoints de Fase 1 siguen compatibles; la guarda de contenido cambiado y recuperación continúan pasando sus regresiones.

Las rondas de revisión/variantes/transferencia son transitorias, igual que el repaso previo: conservan respuestas confirmadas, no cursor/borradores de ronda. Las lecciones sí conservan pistas y sesión. En rondas transitorias, «sin pistas» significa sin ayuda registrada en ese intento; consultar ayuda y abandonar sin responder no deja ese evento en el perfil. No se interpreta esta marca como independencia experimental verificada ni medición psicométrica.

### Evidencia ejecutada

| Control | Resultado y alcance |
|---|---|
| Línea base | `npm run check` 93/93 PASS |
| P2-02 antes de ampliar | 100/100 PASS; corpus numérico, unidades/tolerancias e historial exacto |
| P2-01 antes de adaptación | 108/108 PASS; E2E focal 4/4 móvil/escritorio y web exportada |
| P2-03 antes de razones | 115/115 PASS; E2E focal 8/8, fuentes/modelo/ayuda y autoría determinista |
| `npm run check` final | **125/125 PASS**, 32 nuevas; TypeScript estricto y contenido válidos |
| Playwright final | **52/52 PASS, 137,9 s**, cero fallos/omitidos/flaky y errores de reporte vacíos; 40 anteriores + 12 nuevos, Chromium 153.0.8010.0 móvil/escritorio |
| Temporales | Origen de fecha frente a última respuesta, ayuda/errores/aciertos, límites exactos, medianoche en Santiago y cambio a UTC sin reescribir calendario |
| Integridad/compatibilidad | Fixtures intactas, 24 lecciones/146 retos y diagnóstico idénticos, semillas/matemática congeladas, autoría byte a byte reproducible, SQLite/reapertura/restauración y XP compartido |
| Exportaciones actuales | Android Hermes y web PASS en rutas nuevas, sin residuos; 42 archivos web coinciden byte a byte con los usados en los recorridos |
| Guarda de dos raíces | PASS: Android 1 bundle/1.328 fuentes; web 11 bundles/855 fuentes, cero coincidencias. Alcance de mapas JS, no binario nativo |
| Configuración | Doctor 1.21.5 **20/20 PASS**; matriz instalada Expo offline PASS con advertencia de fiabilidad; npm ls sin problemas; preview APK/versionCode 1/package conservados |
| Vista móvil | Razones, variante y modelo de transferencia a 412×915; ancho de contenido 412 en las tres, cero errores de página. Capturas solo internas |
| Seguridad | Auditoría viva **exit 1, 19 high/0 critical**; R-04 abierto y lanzamiento público bloqueado; dependencias/lockfile sin cambios |
| Diff/formato/enlaces | Prettier de archivos tocados y git diff --check PASS; enlaces relativos revisados al cierre |

La pasada focal de adaptación detectó estado ARIA web ausente: se añadió aria-checked conservando el estado accesible nativo y se verificó la selección retenida. El test de transferencia se acotó al texto visible porque Expo conserva pantallas anteriores en su pila; no se quitaron aserciones. La primera suite general tuvo 51/52: una prueba consultó tres encabezados de adelanto antes de completar la navegación al reto. Se añadió espera de URL/pregunta y se repitió toda la suite: 52/52. Salidas de exportación reutilizadas contenían archivos de entregas previas; las guardas finales usan rutas nuevas, con coincidencia byte a byte de la web probada. No se presentan las pasadas fallidas como aprobación.

### Pendientes y siguiente paso

Revisión científica/pedagógica humana, duración con estudiantes y evaluación de aprendizaje/retención pendientes. Las reglas indican coincidencias de respuestas, no causas psicológicas ni diagnóstico de capacidad. La transferencia es una función matemática supuesta en UR y tiempo normalizado; no datos experimentales, concentración, actividad enzimática ni modelo validado de un instrumento. Number tiene precisión limitada; no es un CAS.

No se generó APK ni se ejecutó Gradle/SDK/adb/dispositivo/TalkBack. E2E web usa localStorage y corte de red tras cargar recursos; SQLite de integración usa Node, no el driver nativo. No hubo CI remota, builds EAS, credenciales, costes ni backend. App sigue en versión 0.1.0; no se declara BioNexo 2.0 terminado. Mantener controles de R-04 y medir historial/razones/copias en P3-03.

**Siguiente: P3-01**, interacción científica y diagrama accesible; no iniciado aquí. Instrucción concreta al final de [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md). Evidencia: [phase2-2026-10-22.json](evidence/phase2-2026-10-22.json), [bundles](evidence/phase2-bundles-2026-10-22.json), [audit](evidence/phase2-audit-2026-10-22.json). Los registros siguientes son históricos.

## Registro histórico · Fase 1

## Estado actual · Fase 1 DONE · 2026-10-22

Se completó toda la Fase 1 autorizada. P1-01 conserva su implementación de reanudación; P1-02 y P1-03 DONE. Las fases 2–5 siguen PENDING, sin iniciar. Base `ae7a8ab` limpia; piloto P1-02 en commit `86ca140`. No se inventó el informe funcional 2.0 ausente (REQ-02); el piloto sigue los requisitos visibles de álgebra, ejemplos, práctica y transferencia. R-04 sigue abierto: desarrollo local permitido por ADR-007, lanzamiento público bloqueado.

### Cambios funcionales comprobados

- Una lección piloto: `math-factor-lesson`, cuatro tramos con objetivos medibles, explicación, ejemplos en pasos y dos retos por tramo. Estructura, construcción, dominio y transferencia a un modelo geométrico supuesto. Ocho retos, incluidos dos nuevos con IDs propios; catálogo total 24 lecciones/146 ejercicios + 12 diagnósticos. Las otras 23 lecciones permanecen idénticas.
- Tramo derivado del cursor persistido: salir/reanudar y recargar vuelven al reto correcto. Se corrigieron contadores de UI antes fijos en seis. Las lecciones sin tramos usan su flujo anterior.
- Cada reto del piloto tiene tres pistas: orientación, procedimiento y ejemplo alternativo en pasos, oculto hasta la tercera. Los ejemplos usan expresiones/valores distintos de los retos. Consultar se registra como ayuda; un acierto ayudado no suma días independientes. Las explicaciones posteriores responden al distractor seleccionado; omisiones y números tienen feedback general específico, sin diagnóstico automático nuevo.
- Volver del puente conserva la elección/borrador original y aumenta el contador de reintentos. Se verifica ayuda, feedback, recarga y premios idempotentes. Etiquetas accesibles de opciones y estado deshabilitado reflejan la interacción.
- Autoría modular `scripts/factoring_pilot.py`, tipos opcionales y validaciones de cobertura/orden de tramos, ejemplos, fuentes y distractores. No cambia evaluación, planificador, dependencias, lockfile ni configuración nativa.

### Datos y compatibilidad

ADR-009 se escribió antes de editar el catálogo. Se capturó con el motor `ae7a8ab` la fixture `tests/fixtures/progress-p1-01-v3.json`: respaldo anterior más dos borradores/pista. SHA-256 `6a54f58649415aefe2d00f5232f05f412e93c8c2a7438d14889915221fbc5ad8`. Conserva exactamente el perfil al leer/exportar y contiene una sesión de fracciones que sigue siendo compatible. Las fixtures raíz 0.1.0 y envoltorio 2 permanecen intactas.

No hay cambio de representación ni migración nueva: SQLite 3, envoltorio 3, perfil 1 y checkpoint 1. Tramos/ejemplos/feedback son contenido, no campos persistentes. Los seis retos originales mantienen orden, IDs, respuestas y forma. Una sesión anterior del piloto conserva su checkpoint y muestra «La lección cambió»; se permite conservar/exportar o descartar explícitamente solo esa sesión. No se reinterpreta la respuesta ni se revocan historial, completados o XP. Abrir otra lección sigue funcionando. El descarte se prueba sin pérdida de otras sesiones. Una corrección futura de contenido aplicará la misma guarda por firma.

### Evidencia ejecutada

| Control | Resultado y alcance |
|---|---|
| Línea base antes de editar | `npm run check`: 83/83 PASS, TS y catálogo |
| Aceptación P1-02 antes de P1-03 | 88/88 PASS; web exportada y piloto E2E 4/4 móvil/escritorio |
| `npm run check` final | **93/93 PASS**, 10 nuevas; TS estricto, catálogo, fórmulas, unidades, compatibilidad, persistencia y ayudas |
| Playwright final | **40/40 PASS, 112,9 s**, cero fallos/omitidos/flaky y errores de reporte vacíos. 32 recorridos anteriores + 8 nuevos, Chromium 153.0.8010.0, móvil/escritorio |
| Flujos nuevos | Piloto completo, pausa/reanudación entre tramos, transferencia con unidades, ayuda escalonada/oculta/reanudada, feedback por distractor, errores sin bloqueo ni falso dominio, actualización explícita y perfil conservado |
| Autoría/contratos | Regeneración byte a byte idéntica en ambos JSON; comparación con `ae7a8ab`: 23 lecciones, 144 contratos/soluciones y 12 diagnósticos conservados |
| Exportaciones Android/web | PASS con mapas; Android generado en directorio limpio. Hermes no es APK ni prueba nativa |
| Guarda de dos raíces | PASS: Android 1 bundle/1.321 fuentes; web 9 bundles/848 fuentes, cero coincidencias |
| Expo/configuración | Doctor 1.21.5 **20/20 PASS**; matriz instalada con EXPO_OFFLINE=1 PASS, advertencia de fiabilidad limitada; npm ls sin problemas; EAS preview APK conservado |
| Inspección visual móvil | Tramo y ejemplo de ayuda revisados a 412×915; ancho contenido 412, cero errores de página. Capturas solo para revisión interna |
| Seguridad | Auditoría actual **exit 1, 19 high/0 critical**, lanzamiento público bloqueado; sin cambio de dependencias ni silenciamiento de CI |
| Formato/diff | Prettier de archivos modificados y git diff --check PASS; enlaces internos revisados al cierre |

Las pruebas iniciales nuevas distinguían +0/−0 con igualdad estricta y confundían texto de 3/−3; se corrigieron las aserciones sin cambiar la matemática ni quitar cobertura. La primera pasada general tuvo 36/40: el helper de reanudación esperaba seis retos y el test nuevo recargaba antes de terminar la navegación. Se corrigieron el contador dinámico y la espera de URL/tramo; se repitió toda la suite con 40/40. Al revisar salidas Android se detectó un bundle antiguo junto al actual; se regeneró solo ese directorio de artefactos y se repitió la guarda sobre una salida limpia. Ninguna de estas pasadas fallidas se presenta como aprobación final.

### Pendientes reales y siguiente paso

La Fase 1 profundiza solo el piloto previsto, no todo el catálogo. Revisión académica humana y duración de 12 minutos con estudiantes pendientes; 73 conceptos avanzados siguen planificados. No se evaluó eficacia educativa/psicométrica ni se diagnostican capacidades con los mensajes. Bandeja: modelo supuesto, s sin unidades, 0 ≤ s ≤ 5, lados en cm y área en cm²; no datos experimentales reales.

No se generó APK, no hay Gradle/SDK/adb/dispositivo Android probado ni auditoría TalkBack. Los E2E usan web/localStorage con recursos cargados al cortar la red; los tests SQLite usan Node, no el driver nativo. No se ejecutó CI remota ni build EAS; versión de app sigue 0.1.0 y no se declara BioNexo 2.0 terminado.

**Próximo incremento recomendado: P2-02**, por R-06 (`1/1e309` aceptado como cero), antes de parametrizar familias. Sus dependencias están satisfechas. La Fase 2 queda PENDING, sin implementar en esta ejecución. Instrucción concreta al final de [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md). Evidencia: [phase1-2026-10-22.json](evidence/phase1-2026-10-22.json), [bundles](evidence/phase1-bundles-2026-10-22.json), [audit](evidence/phase1-audit-2026-10-22.json). Los registros siguientes son históricos.

## Registro histórico · P1-01

# Progreso de desarrollo · BioNexo 2.0

## Ejecución 2026-10-22 · P1-01 DONE

Base `ff375cc`, Git limpio. Se leyeron AGENTS/README, plan/progreso, arquitectura/decisiones y módulos de sesión, ejercicio, dominio y almacenamiento. El usuario autorizó «Siguiente» tras P0-04; se implementa únicamente P1-01. **Fase 1 IN_PROGRESS; P1-01 DONE; P1-02/P1-03 PENDING.** Fase 0 conserva el cierre local por acotación y R-04 abierto; no hay lanzamiento autorizado ni APK.

### Cambio funcional

- Inicio ofrece «Reanudar lección» para cada expedición en pausa; abrirla desde el mapa recupera el reto automáticamente. Se conservan cursor, borrador/unidades, pistas, contador de intento, feedback confirmado y paso de apoyo con su borrador/feedback.
- «Salir» guarda y pausa. «Descartar sesión» pide confirmación, elimina solo ese punto de reanudación y conserva historial, XP, dominio, repasos y otras lecciones. Terminar guarda premio y limpia checkpoint juntos. Diagnóstico y repaso mantienen el flujo transitorio previo.
- `sessions.ts` implementa transiciones puras con IDs estables, duplicados idempotentes, bloqueo de envíos incompatibles y escrituras tardías a otro cursor/sesión. Intento+checkpoint se confirman en la misma actualización SQLite/localStorage. La UI serializa borradores y espera su guardado antes de responder/avanzar/salir; un fallo permite reintentar sin ID nuevo. El proveedor limpia el aviso tras un guardado exitoso.
- Firma no criptográfica de lección y apoyo detecta cambios al reanudar; una sesión incompatible se conserva y ofrece decisión explícita, sin reiniciarla ni recalificar historial.

### Contrato y conservación

**Envoltorio 3, perfil interno 1 con `lessonSessions?`, SQLite 3, checkpoint 1.** Se documentó ADR-008 y se capturó `progress-p0-03-v2.json` con el motor de ff375cc antes de editar persistencia. La fixture 0.1.0 y el registro histórico de identidades no se modificaron. Migración 2→3 guarda el texto original en rescate y conserva exactamente valores anteriores, sin inventar sesiones. No cambia SQL: se usa la transacción existente para convertir el payload; web copia antes de convertir y deduplica reintentos tras fallos.

El respaldo nuevo incluye sesiones; versiones futuras bloquean reemplazo. Restaurar uno antiguo conserva su perfil sin sesiones tras confirmación y copia de lo reemplazado. El código previo no entiende envoltorio 3: no hay downgrade automático. Originales se exportan desde recuperación/Configuración. Un cierre abrupto antes de commit conserva la última escritura confirmada, no un carácter aún pendiente. No se reconstruye SQLite físicamente ilegible.

### Evidencia ejecutada

| Control | Resultado actual y alcance |
|---|---|
| Línea base antes de editar | `npm run check`: 66/66 pruebas, TS y catálogo PASS |
| Compatibilidad/migración | Fixture raíz y envoltorio 2 con perfil idéntico; copia exacta, rollback de conversión, reapertura SQLite en disco y reintentos web con cuota sin copias duplicadas |
| Casos nuevos de sesiones | Duplicación/concurrencia, cursor tardío, intento+feedback atómicos, antes/después de commit, fallo de finalización, descarte aislado, contenido/apoyo cambiado, checkpoint futuro y rescate protegidos |
| `npm run check` final | **83/83 PASS**, 17 nuevas; TypeScript estricto y catálogo 24 lecciones/144 ejercicios + 12 diagnósticos válidos |
| Exportaciones Android/web con mapas | PASS, Hermes/recursos y 9 bundles web. No APK ni ejecución del driver nativo |
| `security:bundles` | PASS en alcance de dos raíces: Android 1 bundle/1.319 entradas de fuentes; web 9 bundles/846 entradas, cero coincidencias |
| Playwright final | **32/32 PASS, 90,8 s**, 0 fallos/omitidos/flaky. 20 recorridos anteriores + 12 de reanudación; móvil/escritorio, Chromium 153.0.8010.0 |
| Inspección visual | Pantalla de borrador móvil 412×915 revisada; sin desbordamiento horizontal. Captura solo para revisión interna, no entregada |
| Configuración/compatibilidad | Expo config válida, package/versionCode/EAS conservados; matriz Expo con EXPO_OFFLINE=1 PASS y advertencia de fiabilidad offline limitada |
| Expo Doctor | 1.21.5, **20/20 PASS**. Primer intento offline sin paquete en caché; se ejecutó después con paquete temporal fijado, fuera de dependencias del proyecto |
| `security:audit` actual | **Exit 1, 19 high, 0 critical**, sigue bloqueando aprobación pública. Sin excepciones, overrides ni cambio de dependencias |
| Formato/diff/enlaces | PASS al cierre; catálogo/autoría, algoritmos de evaluación/repaso, lockfile y configuración nativa intactos |

Incidencias de verificación: TypeScript detectó que el nombre de la función interna forwardRef ocultaba el componente recursivo; se corrigió el nombre antes de correr la suite completa. La primera ejecución E2E tuvo 32 fallos de lanzamiento por Chromium temporal ausente y no probó la app. Se repuso desde el paquete de pruebas ya disponible fuera del repo (sin añadir dependencias); la extracción inicial del helper falló por chown y se extrajeron recursos sin cambiar propietario. Con el navegador operativo se aprobaron los 32 recorridos; tras ajustes finales de estado por ID/controles se repitieron y volvieron a aprobar los 32 con reporte JSON. No se ocultaron fallos ni eliminaron pruebas.

Se adaptaron solo aserciones necesarias: 3 es ahora envoltorio válido y 4 prueba futuro; el recorrido de apoyo reinicia explícitamente descartando su checkpoint, porque «Salir» ahora pausa. Se conservan las regresiones de P0-03/P0-04. No se ejecutó npm ci nuevo, GitHub Actions remoto, Gradle, APK ni Android real/Windows. Pruebas SQLite usan Node y navegador usa localStorage: no acreditan el driver/selector/compartir/TalkBack nativos.

### Pendientes y continuación

P1-02: profundizar una lección piloto con objetivos, niveles/tramos, ejemplos desarrollados y transferencia, sin inventar detalles de REQ-02. P1-03 y otras fases no iniciadas. Revisión académica humana sigue pendiente; no hubo cambios científicos ni soluciones nuevas en este incremento. Medir rendimiento con historiales grandes y comprobar cierre/reapertura en Android quedan en sus tareas previstas.

R-04 mantiene 19 alertas altas y la decisión de desarrollo local con controles; no hay permiso de lanzamiento. Instrucción concreta al final de [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md). Evidencia: [p1-01-2026-10-22.json](evidence/p1-01-2026-10-22.json), [bundles actuales](evidence/p1-01-bundles-2026-10-22.json), [audit actual](evidence/p1-01-audit-2026-10-22.json). Los registros siguientes son históricos, no el estado actual.

## Registro histórico: P0-04 y anteriores

## Ejecución 2026-10-22 · P0-04 completado por acotación

Base `bce4170`, Git limpio. AGENTS, README, plan, progreso, arquitectura, riesgos, decisiones, dependencias y pruebas revisados. **P0-04 DONE en alcance de análisis y controles; vulnerabilidades NO reparadas. Fase 0 DONE en auditoría/estabilización local; fases 1–5 PENDING.** ADR-007 permite continuar desarrollo local con controles; R-04 permanece abierto y el lanzamiento público está bloqueado. No se inicia otra fase, cambia SDK, solicita EAS ni genera APK.

### Cambio implementado y comprobado

- `security:audit` consulta avisos vivos sin excepciones y falla ante high/critical o fallo de consulta. CI añade job independiente para que un fallo de seguridad no impida ejecutar las regresiones funcionales, ni se confunda su éxito con aprobación del conjunto. El JSON de auditoría se conserva incluso al fallar; no hay continue-on-error.
- `security:bundles` inspecciona todos los `.js`/`.hbc` de los directorios entregados y exige mapa por chunk. Detecta las dos raíces P0-04 mediante rutas de fuentes, incluidos mapas indexados/Windows/sourceRoot; rechaza mapas ausentes, inválidos y secciones remotas/profundas. Genera evidencia con hashes de bundle/mapa. No es auditoría de todas las dependencias ni de binarios nativos.
- Nueve pruebas nuevas cubren ambos paquetes, rutas y falsos positivos, todos los chunks, mapas desconocidos/corruptos, límites, enlaces simbólicos/bundle vacío y la CLI (exit correcto). Las 57 pruebas anteriores siguen pasando. No cambian módulos de aplicación ni persistencia/contenido; el lockfile y las versiones quedan intactos. Solo se añaden scripts npm y soporte de formato para scripts anidados.
- Informe técnico, evidencia nueva, ADR-007 y reglas/documentos actualizados. El informe previo no se sustituye.

### Exposición y decisión

Auditoría actual: **19 high, 0 critical**, propagadas desde `braces@3.0.3` y `node-forge@1.4.0`. Registry/avisos oficiales: últimas estables aún afectadas, sin parche indicado; consumidores consultados y parche Expo 58 ya están en su última estable. No se ejecutan audit fix, overrides, forks ni degradaciones de Expo/RN.

Las rutas instaladas son Metro→micromatch→braces y CLI→node-forge, también vía certificados. La llamada Metro inspeccionada usa micromatch.some→picomatch, no las APIs de braces; la verificación de certificados sí existe en tooling. No se reprodujo explotación. Los mapas de exportaciones actuales no contienen rutas de las dos raíces: **Android 1 bundle/1.318 entradas de fuentes; web 9 bundles/845 entradas**, cero coincidencias. Algunas fuentes auxiliares de CLI sí están incluidas; no se afirma que toda herramienta quede fuera del bundle.

`npm audit --omit=dev` también da 19 high: Expo es dependencia de producción y contiene herramientas Node; esta opción no distingue runtime de tooling. La revisión solo acota el alcance actual. No se rebaja severidad ni se declara seguridad nativa/Gradle/servidores/certificados. Detalles y fuentes en [DEPENDENCY_SECURITY.md](DEPENDENCY_SECURITY.md).

### Verificación actual

| Control | Resultado y límite |
|---|---|
| Línea base `npm run check` | PASS: TS/catálogo, 57/57 pruebas antes de modificar |
| `npm ls --all --json` + árbol focal | Exit 0, sin problemas de instalación; rutas/versiones registradas |
| Auditoría actual, auditoría con omit=dev y nuevo security:audit | **Exit 1 esperado por 19 high**, no PASS; no se silencian alertas |
| `npm view` de raíces/consumidores/Expo58 + fuentes oficiales | Versiones y avisos comprobados; no se encontró parche estable compatible |
| Nuevo control antes de implementación | No existía el módulo de guarda; la suite nueva no podía cargarlo. No es una reproducción de explotación |
| `npm run check` final | **PASS 66/66**, TypeScript estricto y catálogo 24/144 + 12 diagnósticos |
| Exportación Android con source-maps | PASS, bundle Hermes y mapa en dist-security-android; no APK ni driver nativo |
| Exportación web con source-maps | PASS, 9 bundles/mapas y recursos |
| security:bundles sobre ambas exportaciones | PASS en su alcance de dos raíces; hashes de cada bundle/mapa registrados |
| Playwright final con reportes list/json | **20/20 PASS**, 58,4 s, 0 fallos/omitidos/flaky; Chromium 153.0.8010.0, móvil/escritorio. Conserva recuperación, diagnóstico, lecciones, laboratorio y UI offline ya cargada |
| Expo config pública | PASS, package/versionCode/preview APK conservados; sin updates/EAS project configurado |
| Expo Doctor 1.21.5 | **20/20 PASS** en esta sesión; no sustituye audit ni prueba Android |
| Expo install --check | Consulta online falló por timeout del proxy. Repetido con EXPO_OFFLINE=1: matriz instalada compatible, con aviso de fiabilidad offline limitada |
| Formato/diff, YAML y enlaces | PASS; estructura de CI y comandos inspeccionados localmente, archivos protegidos y fixture histórica intactos |

Una primera invocación E2E solo dejó el encabezado de ejecución, sin un resumen verificable: no se cuenta como aprobada. Se repitió con JSON y se comprobaron los 20 casos completados. No se reutilizó como evidencia el .last-run de otra ejecución. El cambio a junta de directorio en la prueba de enlaces facilita Windows; no se ejecutó Windows aquí.

No se ejecutó npm ci nuevo, GitHub Actions remoto, Gradle, APK ni Android real. Los checks se hicieron con las dependencias instaladas y lockfile conservado. La prueba SQLite usa Node; no acredita el driver nativo. Fuentes de la app, contenido académico, IDs, perfil 1/envoltorio 2/esquema SQLite 3, motor de aprendizaje y recuperación P0-03 permanecen intactos.

### Pendientes y siguiente paso

R-04 sigue abierto. La auditoría será roja hasta corregir/revisar sus avisos; los mapas limpios no permiten publicar. No hay pipeline de publicación ni protección de rama remotos que impidan manualmente EAS/Gradle. Antes de cualquier lanzamiento o cambio de lockfile, repetir la auditoría y la matriz completa y revisar soluciones mantenidas.

El próximo incremento del plan es **P1-01, reanudación de sesiones**, tras revisar esta entrega y una nueva instrucción que lo delimite. ADR-007 documenta la decisión técnica para desarrollo local, sin autorización de lanzamiento. No se implementó esa fase. Instrucción concreta en [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md).

Evidencia: [resumen P0-04](evidence/p0-04-2026-10-22.json), [audit](evidence/p0-04-audit-2026-10-22.json), [exposición/versiones](evidence/p0-04-exposure-2026-10-22.json), [bundles](evidence/p0-04-bundles-2026-10-22.json). Los registros siguientes son históricos; no sustituyen este estado actual.

## Registro histórico: P0-03 y auditoría

## Ejecución 2026-10-22 · P0-03 completado

Base `41566ea`, Git limpio al comenzar, sin remotos configurados. Se leyeron AGENTS, README, plan, progreso, arquitectura, decisiones, riesgos, configuración y pruebas. P0-02 estaba DONE; se seleccionó P0-03 por orden/dependencias. **Fase 0 sigue IN_PROGRESS; P0-03 DONE; P0-04 PENDING; fases 1–5 PENDING.** No se repitió la auditoría ni se amplió alcance funcional.

### Cambio comprobado

- `progress-document.ts` separa validación histórica de evaluación actual. Conserva resultados registrados, XP, dominio, repasos, diagnóstico, laboratorio y preferencias. Corregir una solución o retirar IDs actuales no invalida el perfil anterior; intentos nuevos usan el evaluador vigente.
- Registro congelado de identidades/formas 0.1.0 desde `41566ea`, sin soluciones. Documentos nuevos llevan referencias propias y conservan IDs retirados. Cambios de forma requieren ID nuevo o migración.
- **Perfil interno 1, envoltorio 2, SQLite 3**: migración transaccional conserva el texto original; reapertura no duplica copias. El estado de la fixture anterior es idéntico tras convertir, restaurar y reabrir. No se recalcula evidencia histórica ni se presenta el respaldo como prueba autenticada de dominio.
- Error de apertura ofrece exportación de rescate, selección y validación de respaldo, resumen, cancelación/confirmación, búsqueda de copia local anterior y reintento. Una BD existente sin perfil no crea progreso nuevo. Versiones futuras solo admiten rescate y no reemplazo.
- Web copia antes de reemplazar y deduplica la migración automática tras un fallo de escritura. Cuotas, copias dañadas e interrupciones preservan el original accesible. SQLite revierte cambios parciales.
- Ajustes permiten exportar rescate; progreso muestra etiqueta de concepto archivado. El catálogo académico, IDs, motor de aprendizaje/respuestas, dependencias/lockfile y Expo/EAS permanecen intactos.

### Evidencia ejecutada en esta continuación

| Control | Resultado | Alcance |
|---|---|---|
| Línea base `npm run check` antes de editar | PASS, 32/32 pruebas + TS/catálogo | Base `41566ea` |
| Reproducciones P0-03 antes de implementación | FAIL esperado: catálogo corregido/ID retirado y BD existente sin fila | Casos nuevos detectaron problemas del código anterior |
| Regresiones añadidas durante revisión | Dos fallos detectados (copias web duplicadas y claves reservadas), corregidos y repetidos | No se eliminan pruebas para aprobar |
| `npm run check` final | PASS, TypeScript estricto, catálogo válido, **57/57 pruebas**, 0 fallos | 32 previas conservadas/adaptadas al nuevo envoltorio y 25 nuevas |
| Fixture 0.1.0 | Hash y valores conservados; 18 intentos, 80 XP y resto del perfil | SQLite Node real + web; no datos reales del estudiante |
| `npm run export:web` | PASS, recursos y bundles | Expo informó handle abierto y terminó forzadamente con exit 0 después de exportar |
| Playwright final | **20/20 PASS, 55,9 s**, Chromium 153.0.8010.0 | 12 recorridos previos + 8 nuevos (4 recuperación × móvil/escritorio). Navegación offline de interfaz ya cargada; no PWA desde arranque |
| `npm run export:android` final | PASS, bundle Hermes 3,2 MB y recursos | No APK, Gradle ni ejecución nativa |
| `expo config --type public --json` | PASS | package/versionCode/EAS conservados |
| Compatibilidad Expo | `EXPO_OFFLINE=1 npx expo install --check`: PASS contra matriz instalada, con aviso de validación offline menos fiable | Intento online agotó tiempo en proxy; no se presenta como consulta remota exitosa |
| Revisión final | `git diff --check`, formato de código afectado, enlaces Markdown, integridad de archivos protegidos | Sin cambios de paquetes/lockfile, contenido académico ni fixture |

No se repitió `npm ci`, Expo Doctor ni `npm audit` en esta continuación. Los resultados previos permanecen abajo como históricos. Las **19 entradas high** del informe anterior siguen abiertas y requieren P0-04; no se comprobó que su exposición haya cambiado. El navegador ya estaba aprovisionado fuera del repo. No se añadió ninguna dependencia.

### Recuperación y límites

El original queda en `profile_recovery` (SQLite) o `bionexo-recovery-v1` (web) antes de migrar/restaurar. Desde la pantalla de error se puede exportar un contenedor `bionexo-recovery` con el texto accesible incluso inválido; no se importa como un perfil sin validarlo. La búsqueda local ofrece la última copia válida y exige confirmación. Un archivo de versión futura se conserva: usar una versión compatible para recuperarlo.

El código anterior no entiende SQLite 3/envoltorio 2. No hay downgrade automático: exportar antes de actualizar/revertir y conservar copias para recuperación manual con versión compatible. No se reconstruye SQLite físicamente ilegible; tampoco se borran copias para liberar cuota. Una migración que exceda tamaño/cuota falla conservando el original. Los respaldos son JSON sin cifrado/firma. Persistencia nativa, selector/compartir, TalkBack y comportamiento en un dispositivo Android siguen sin comprobarse. No se generó ni solicitó un APK.

### Siguiente tarea

**P0-04**, exposición y remediación compatible de dependencias. Mantener Fase 0 hasta resolver sus alertas o documentar una decisión de riesgo revisada; no avanzar automáticamente a Fase 1. Instrucción concreta al final de [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md). Evidencia estructurada: [p0-03-2026-10-22.json](evidence/p0-03-2026-10-22.json). ADR-006 detalla la decisión implementada. El registro que sigue describe la auditoría anterior y no sustituye este estado actual.

## Registro histórico: auditoría inicial

## Ejecución 2026-10-22 · auditoría y preparación de Fase 0

Base inspeccionada: `0a5451d` — MVP BioNexo 0.1.0. Git estaba limpio, sin remotos configurados ni cambios ajenos que reconciliar. Esta ejecución no cambia la versión del producto, SQLite/contratos, IDs, catálogo, dominio ni Expo/EAS. «2.0» es la meta del plan, no una entrega terminada.

Corrección y regresiones: commit `23c1a04`. Planificación/documentación: commit de proceso posterior en `git log`.

**Estado general:** Fase 0 `IN_PROGRESS`; fases 1–5 `PENDING`. No se ha generado ni solicitado un APK. Los criterios de preparación local no acreditan dispositivo, build Gradle o seguridad de dependencias.

## Lo que se sabe y cómo se sabe

| Área | Observado en código/configuración | Comprobado en esta ejecución | Pendiente/declarado |
|---|---|---|---|
| Catálogo | 5 rutas, 12 unidades; 24 lecciones/144 ejercicios en 4 ciencias; 12 diagnósticos; 97 conceptos, 73 planificados | Validador y pruebas de soluciones/tipos | Revisión académica humana y 73 conceptos avanzados no implementados |
| Aprendizaje | Pistas, ejemplos, apoyo por errores, calendario determinista y XP separado | Pruebas de dominio y recorridos de adaptación | Multinivel profundo, parametrización, razones avanzadas y transferencia específica |
| Persistencia | Formato perfil 1; esquema SQLite 2; snapshot JSON transaccional | SQLite en Node: migración, reapertura, rollback, concurrencia; fixture completa antigua | Driver Android, catálogo histórico mutable y recuperación UI desde error |
| Interfaz | Siete secciones; claro/oscuro/sistema; labels; SVG y controles | Recorridos web móvil/escritorio | TalkBack, rendimiento y texto grande en dispositivo real |
| Laboratorio | Gaussiana didáctica, pH, dos modelos, cuaderno | Cálculos, comparación, persistencia y UI web | Diseño experimental profundo/proyectos; no datos experimentales reales |
| Android | Preview configurado para APK; package/versionCode conservados | Expo config, compatibilidad y bundle Hermes | APK, firma, instalación, drivers/respaldos nativos y modo avión desde arranque |
| Dependencias | Lockfile y versiones existentes conservados | Expo check/Doctor y npm audit | 19 entradas high abiertas; no equivalen a 19 fallos independientes ni a explotación probada |

## Requisitos anteriores

Se leyeron README, AGENTS y toda la documentación previa, además de modelos, respuestas/aprendizaje/laboratorio, validación, almacenamiento, proveedor/estado/UI, rutas y suites. No existe documento completo de mejoras 2.0 en este repositorio. La consulta de contexto solo devolvió un resumen de propuestas previas del asistente, sin texto íntegro o decisiones adicionales del usuario. Se registra REQ-02 y no se incorpora BioTutor ni detalles inventados. Las fases y temas expresos del mensaje actual sí se planifican.

## Incremento de esta sesión

1. Reconciliar AGENTS y crear el proceso enlazado: plan, índice de arquitectura, decisiones, progreso, checklist y riesgos. Conservar arquitectura/documentos originales sin duplicarlos como fuentes competidoras.
2. Capturar un perfil sintético del motor 0.1.0 (18 intentos, 80 XP, diagnóstico, dominio/repasos, ajustes y laboratorio). Añadir ocho pruebas de compatibilidad que no regeneran datos con un motor nuevo.
3. Reproducir y corregir el adaptador web: clave presente vacía ≠ ausencia. Ahora se rechaza la corrupción sin escribir un perfil nuevo. Ningún dato real fue leído, convertido o reemplazado.
4. Inspeccionar configuración Android y dependencias. No aplicar cambios de paquetes/SDK, no usar credenciales y no solicitar EAS.

### Estado de tareas de Fase 0

| ID | Estado | Evidencia / límite |
|---|---|---|
| P0-01 | DONE | Inspección completada; documentos y enlaces verificados; 21 tareas con campos/estados válidos y evidencia registrada |
| P0-02 | DONE | Commit 23c1a04; caso falló antes del fix; 8/8 nuevas regresiones, 32/32 totales y 12/12 E2E después del cambio |
| P0-03 | PENDING | Protección histórica y recuperación desde fallo de apertura; primer incremento recomendado |
| P0-04 | PENDING | Exposición/remediación compatible de las alertas npm; sin fix forzado |
| P0-05 | DONE | Preview APK, configuración pública, Doctor/compatibilidad, bundle y revisión acotada de secretos comprobados. Solo preparación local, no prueba Android |

## Línea base y verificaciones

| Comando/caso | Resultado registrado | Alcance |
|---|---|---|
| `npm run check` antes de editar | PASS: TypeScript, catálogo y 24 pruebas | Base 0.1.0 |
| Compatibilidad histórica nueva antes del fix | FAIL: 7/8; la prueba de clave web vacía no obtuvo el rechazo esperado | Reproducción del defecto; también se corrigió una aserción de la prueba que debía capturar un throw síncrono |
| `npm run check` después del fix | PASS: TypeScript, catálogo, 32/32 pruebas (24 originales + 8 nuevas), 0 fallos | Formato de perfil y esquema sin cambios |
| `npx expo install --check` | PASS: dependencias compatibles | Compatibilidad de versiones, no seguridad |
| `npx expo-doctor` | PASS: 20/20 controles | Configuración/ecosistema; no dispositivo |
| `npm audit --json` | EXIT 1: 19 high, 0 critical | Informe en `evidence/dependency-audit-2026-10-22.json`; hallazgo abierto |
| Exportación web base y después del fix | PASS en ambas | Bundle + recursos; no PWA offline desde arranque. La última ejecución completó la exportación y forzó salida por handle abierto, con exit 0 |
| Playwright base, navegador ya aprovisionado | PASS: 12/12 en dos tamaños | Usa localStorage web, no expo-sqlite nativo |
| Exportación Android | PASS: bundle Hermes de 3,1 MB y recursos | No APK; módulos nativos no ejecutados |
| `expo config --type public` | PASS, JSON inspeccionado | Preview/EAS y package observados sin autenticar |
| Caso de catálogo cambiado | Reproducido: cambiar respuesta o retirar ID rechaza el perfil antiguo; restaurar catálogo en memoria lo vuelve a aceptar | Caso aislado sin editar fuentes/fixture ni datos reales; P0-03 abierto |
| Documentación/formato | PASS: enlaces locales, 21 tareas con campos/estados válidos y Prettier sobre código/pruebas afectados | Revisión del alcance por diff |
| Secretos | Sin archivos sensibles versionados ni coincidencias en inspección acotada de patrones | No análisis exhaustivo ni auditoría del binario |
| Playwright después del fix | PASS: 12/12, 45,2 s | Sobre exportación web actualizada; no driver nativo |

Incidente de infraestructura registrado: el navegador temporal usado en la entrega anterior ya no existía. La primera invocación E2E tuvo 12 fallos de lanzamiento por ejecutable ausente, sin probar la app. Se aprovisionó Chromium 153 solo fuera del repositorio; se repitieron y aprobaron los 12 recorridos base. No se eliminaron ni relajaron pruebas ni se añadieron dependencias al proyecto por ese motivo. La invocación local utiliza `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH`; en un entorno estándar usa `npx playwright install chromium` y `npm run test:e2e` tras exportar web.

No se ejecutó `npm ci` de nuevo en esta sesión: se verificaron las dependencias instaladas y el lockfile conservado. La instalación limpia y CI ejecutada en un servicio remoto no se presentan como comprobaciones actuales.

## Próximo incremento

**P0-03:** separar validación histórica y catálogo, con recuperación explícita de perfiles que hoy no pueden abrirse. Consultar ADR-003 antes de diseñar migración. Mantener abiertas las alertas de P0-04. No iniciar Fase 1 automáticamente.

Instrucción de continuación completa en el final de [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md). Riesgos y aceptación en ese plan, [RISKS.md](RISKS.md) y [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md).

## Evidencia y límites de cierre

Resumen ejecutable de auditoría y hashes de fixture/bundle en [baseline-2026-10-22.json](evidence/baseline-2026-10-22.json). Auditoría de paquetes en [dependency-audit-2026-10-22.json](evidence/dependency-audit-2026-10-22.json). Los avisos NO se cerraron. La estructura de planes y los enlaces internos se comprobaron con un script de inspección de Markdown; no se presentan como pruebas de ejecución móvil.

No se modificaron package.json, package-lock.json, app.json, eas.json, src/domain, src/content ni las migraciones/SQLite. El único cambio de comportamiento es la comprobación de ausencia en open.web.ts. No se modificó el contenido científico ni se inició Fase 1.
