# Física y Matemáticas · MAT-PHY-01

2026-10-23, base `1cb18a8`, ADR-018. Autorización «Dale ahora con física y matemáticas». Se desarrollan **17 temas matemáticos y 11 físicos antes planificados**, con **28 lecciones/168 ejercicios originales nuevos**. Dos tramos, dos ejemplos desarrollados diferentes, tres pistas por ejercicio, feedback, resumen y aplicación. Diez minutos es estimación no calibrada. Cada lección conserva `requires-human-review`.

## Alcance comprobable

| Ruta | Lecciones | Ejercicios de lección | Unidades | Cursos |
|---|---:|---:|---:|---:|
| Biología conservada | 26 | 156 | 12 | 4 |
| Química conservada | 22 | 132 | 10 | 4 |
| Física ampliada | 17 | 102 | 8 | 3 |
| Matemáticas ampliada | 23 | 140 | 11 | 4 |
| Total | 88 | 530 | 41 | 15 |

88 conceptos tienen lección; los **9 conceptos de la ruta integrada siguen planificados**, además del laboratorio y proyectos que ya funcionan. Diagnóstico 12 ítems, 14 variantes y 8 retos de transferencia/proyecto se cuentan aparte, no se duplican como lecciones.

**Disponible como introducción no significa curso universitario completo**, dominio demostrado ni revisión docente. No se prometen competencias de cálculo, estadística o biofísica por completar una lección. El contenido se amplía sobre las 60 lecciones anteriores, que conservan texto/soluciones/firmas. Las seis lecciones originales de cada nueva ruta siguen presentes; su profundización se trata como una revisión futura compatible.

## Orden recomendado

Si falta base, reforzar fracciones, potencias, ecuaciones, factorización y funciones/cuadráticas originales. Luego polinomios y racionales; exponenciales/logaritmos y trigonometría; límites/continuidad; derivadas y optimización; integrales y ecuaciones diferenciales. Probabilidad/estadística acompañan genética y datos; matrices/modelamiento se apoyan en esas bases. Todos los temas son explorables; la evidencia de dominio es distinta de XP.

Física continúa desde unidades, movimiento, fuerza y energía originales: presión/temperatura, termodinámica/electricidad, ondas/óptica y biofísica. Las nuevas bases eliminan avisos de prerrequisitos aún planificados en las cuatro rutas principales, pero no fingen que el estudiante ya los domina. Biología→genética enlaza probabilidad; Química→pH enlaza logaritmos; cinética enzimática enlaza racionales; gases/termodinámica/analítica enlazan las bases físicas disponibles.

## Matemáticas añadida

| ID / tema | Unidad | Objetivo medible | Retos |
|---|---|---|---:|
| `math-polynomial` · Polinomios | 04 · Polinomios, cocientes y ángulos | Reconocer grado, evaluar y factorizar polinomios para comprobar raíces sin perder términos. | 6 |
| `math-functions-rational` · Funciones racionales | 04 · Polinomios, cocientes y ángulos | Determinar dominio de cocientes y simplificar conservando exclusiones del denominador original. | 6 |
| `math-trig` · Trigonometría esencial | 04 · Polinomios, cocientes y ángulos | Usar razones de triángulos rectángulos y convertir grados a radianes con convención explícita. | 6 |
| `math-exp` · Funciones exponenciales | 05 · Crecimiento y escala logarítmica | Evaluar crecimiento/decaimiento exponencial y distinguir factor multiplicativo de aumento aditivo. | 6 |
| `math-log` · Logaritmos | 05 · Crecimiento y escala logarítmica | Interpretar logaritmo como exponente, verificar su dominio y aplicarlo a razones adimensionales. | 6 |
| `math-limits` · Límites | 06 · Aproximación y continuidad | Distinguir límite y valor puntual, factorizar una indeterminación y comparar límites laterales. | 6 |
| `math-continuity` · Continuidad | 06 · Aproximación y continuidad | Comprobar las tres condiciones de continuidad y completar una discontinuidad removible cuando proceda. | 6 |
| `math-derivative` · Derivadas | 07 · Cambio local y optimización | Interpretar derivada como tasa local y calcularla en polinomios sencillos con unidades. | 6 |
| `math-app-derivative` · Aplicaciones de derivadas | 07 · Cambio local y optimización | Localizar y verificar un máximo en un intervalo cerrado, incluyendo extremos y factibilidad. | 6 |
| `math-integral` · Integrales | 08 · Acumulación y tasas | Interpretar integral definida como acumulación con signo y calcularla en funciones sencillas. | 6 |
| `math-ode` · Ecuaciones diferenciales sencillas | 08 · Acumulación y tasas | Verificar una solución de ecuación diferencial con condición inicial e interpretar unidades de tasa. | 6 |
| `math-probability` · Probabilidad | 09 · Azar y descripción de datos | Calcular probabilidades sencillas, distinguir independencia y exclusión, e interpretar valores esperados. | 6 |
| `math-stat` · Estadística descriptiva | 09 · Azar y descripción de datos | Calcular media, mediana y rango, y distinguir descripción de datos e inferencia poblacional. | 6 |
| `math-inference` · Inferencia estadística | 10 · Inferencia y predicción | Interpretar una decisión de prueba y un intervalo de confianza sin confundirlos con certeza causal. | 6 |
| `math-regression` · Regresión | 10 · Inferencia y predicción | Usar una recta de predicción dada y calcular residuos con signo, evitando extrapolación y causalidad indebida. | 6 |
| `math-matrix` · Matrices | 11 · Matrices y modelos biológicos | Interpretar dimensiones de una matriz y calcular suma y producto matriz-vector de tamaños compatibles. | 6 |
| `math-models` · Modelamiento biológico | 11 · Matrices y modelos biológicos | Calcular tasas de un modelo logístico e identificar parámetros, supuestos y validación independiente. | 6 |

## Física añadida

| ID / tema | Unidad | Objetivo medible | Retos |
|---|---|---|---:|
| `phys-fluids` · Fluidos y presión | 04 · Presión y estado térmico | Calcular presión y diferencia hidrostática con unidades de área y referencia explícitas. | 6 |
| `phys-temperature` · Temperatura y calor | 04 · Presión y estado térmico | Distinguir temperatura, calor y energía interna y aplicar Q=mcΔT sin cambio de fase. | 6 |
| `phys-thermo` · Termodinámica | 05 · Balances y electricidad | Aplicar la primera ley con convención de signos y distinguir conservación de posibilidad de proceso. | 6 |
| `phys-electric` · Electricidad | 05 · Balances y electricidad | Relacionar carga, corriente, voltaje y resistencia en un circuito óhmico ideal con unidades. | 6 |
| `phys-waves` · Ondas | 06 · Ondas e imágenes | Relacionar frecuencia, período, longitud de onda y velocidad en un medio definido. | 6 |
| `phys-optics` · Óptica e instrumentos | 06 · Ondas e imágenes | Usar un modelo de lente delgada con convención explícita y distinguir imagen real/virtual. | 6 |
| `phys-diffusion` · Difusión | 07 · Transporte y membranas | Interpretar dirección de flujo difusivo y calcular J=−DΔc/Δx en un modelo unidimensional simple. | 6 |
| `phys-osmosis` · Ósmosis y transporte | 07 · Transporte y membranas | Predecir tendencia osmótica bajo supuestos y calcular presión osmótica ideal con unidades coherentes. | 6 |
| `phys-surface` · Fenómenos de superficie | 08 · Superficies, calor e instrumentos | Interpretar tensión superficial y calcular fuerzas/presión en geometrías ideales explícitas. | 6 |
| `phys-heat` · Transferencia de calor | 08 · Superficies, calor e instrumentos | Distinguir conducción, convección y radiación y calcular potencia conducida en una placa ideal. | 6 |
| `phys-instruments` · Fundamentos de instrumentos | 08 · Superficies, calor e instrumentos | Distinguir aumento, resolución, precisión y exactitud al interpretar un instrumento científico conceptual. | 6 |

## Relaciones, condiciones y límites

| Tema | Relación/modelo | Condiciones y límites explícitos |
|---|---|---|
| Polinomios/racionales | Factorización, producto nulo y P/Q | Cancelar factores conserva exclusiones; no cancelar sumandos ni evaluar división por cero. No se asigna grado al polinomio cero aquí. |
| Trigonometría | sen=opuesto/hipotenusa, cos=adyacente/hipotenusa; 360°=2π rad | Razones adimensionales, ángulo agudo para el triángulo; se distingue coeficiente de π de valor completo en radianes. |
| Exponenciales/logaritmos | Nₖ=N₀bᵏ; log_b(x)=y⇔bʸ=x | b>0, b≠1 para log, argumento positivo; argumentos físicos adimensionales. Factor constante no es aumento absoluto constante; crecimiento no ilimitado por evidencia. |
| Límites/continuidad | Cocientes reducidos cerca del punto, laterales, valor/límite/coincidencia | 0/0 indeterminada; límites distintos no se promedian. Tabla finita no es prueba. Continua no implica derivable. No se traza un hueco como si fuera valor definido. |
| Derivadas/optimización | Límite de cociente incremental; regla de potencia; candidatos y extremos | Tasa local vs media; unidades de salida/entrada. f′=0 no basta para máximo; restricciones/extremos del dominio importan. |
| Integración/ODE | F(b)−F(a); dN/dt=rN; paso de Euler dado | Acumulación con signo vs área total; añadir condición inicial para cantidad final. Euler aproxima; verificar una solución no valida el sistema real. |
| Probabilidad | Equiprobabilidad cuando se da, complementos e independencia explícita | Excluyentes con P>0 no son independientes. np es esperado, no conteo garantizado; herencia compleja no se reduce al modelo simple. |
| Estadística/inferencia | Media/mediana/rango; p/α e intervalos dados | Unidad experimental y réplicas; p no es probabilidad de H₀ ni causalidad. No rechazo no prueba igualdad; IC95 % refiere al procedimiento repetido, no 95 % de observaciones. |
| Regresión/matrices/modelos | ŷ=a+bx, residuo y−ŷ; producto fila-columna; rN(1−N/K) | Predicción no observación, rango/etiquetas/unidades; producto no conmutativo. r,K positivos constantes, K efectivo, ajuste/implementación no validación biológica. |
| Presión | P=F⊥/A; ΔP=ρgh | Fuerza normal uniforme; área convertida al cuadrado; fluido estático, ρ/g constantes; diferencia vs absoluta. |
| Calor/termodinámica | T(K)=t(°C)+273,15; Q=mcΔT; ΔU=Q−W | Diferencia K/°C igual magnitud, valores absolutos no. c constante/sin cambio de fase. W por sistema positivo, sistema cerrado; organismos abiertos requieren más términos. |
| Electricidad/ondas | I=Δq/Δt; V=IR; P=VI; f=1/T; v=fλ | Modelo óhmico a condiciones fijas; corriente/voltaje/potencia/energía diferentes. Medio/no dispersión cuando corresponda; muestreo no identifica toda señal. |
| Óptica | 1/f=1/dₒ+1/dᵢ; m=−dᵢ/dₒ | Lente delgada/paraxial en aire y convención de signos explícita; imagen virtual no inexistente; aumento no resolución. |
| Difusión/ósmosis | J=−DΔc/Δx; t característico∝L²; Π≈icRT | Fick1D/D constante/sin convección/reacción; equilibrio neto no inmovilidad. Agua/soluto/permeabilidad/presión definidos, diluido ideal, kelvin y mol/m³ coherentes con R. Isosmótico no siempre isotónico. |
| Superficies/calor/instrumentos | F=2γL para película dos caras; ΔP=2γ/r para gota; P=kAΔT/L | Contar interfaces; burbuja ideal dos interfaces usa 4γ/r. Placa plana/1D/estacionaria para conducción. Calibración, sesgo y precisión distintos; muchos decimales no garantizan exactitud. |

Los modelos biológicos, señales, parámetros y datos de los ejemplos son **ficticios o simulados**, sin resultados experimentales reales. No hay protocolos de cultivo, intervención clínica, equipos conectados a personas, manipulación eléctrica o instrucciones de preparación de sustancias.

## Fuentes verificadas y reutilización

Consulta 2026-10-23. Solo referencias oficiales OpenStax: Algebra and Trigonometry 2e, Calculus Volumes 1/2, Introductory Statistics 2e, College Physics 2e y Chemistry 2e. Se verificaron secciones concretas y licencias en prefacios: CC BY-NC-SA 4.0 en las ediciones consultadas. Algunos intentos con numeración equivocada devolvieron error y se sustituyeron por las secciones correctas (exponenciales 6.1, logaritmos 6.3, matrices 11.5); no se retienen URLs fallidas como fuentes. No se copian libros, figuras ni preguntas; nuestros ejemplos/textos son originales bajo CONTENT_LICENSE. Las referencias no validan números elegidos ni eficacia pedagógica.

| Lección | Referencias conceptuales |
|---|---|
| Polinomios | [OpenStax · Algebra and Trigonometry 2e · 5.2 Polynomial Functions](https://openstax.org/books/algebra-and-trigonometry-2e/pages/5-2-power-functions-and-polynomial-functions) |
| Funciones racionales | [OpenStax · Algebra and Trigonometry 2e · 5.6 Rational Functions](https://openstax.org/books/algebra-and-trigonometry-2e/pages/5-6-rational-functions) |
| Trigonometría esencial | [OpenStax · Algebra and Trigonometry 2e · 7.2 Right Triangle Trigonometry](https://openstax.org/books/algebra-and-trigonometry-2e/pages/7-2-right-triangle-trigonometry) · [OpenStax · Algebra and Trigonometry 2e · 7.1 Angles](https://openstax.org/books/algebra-and-trigonometry-2e/pages/7-1-angles) |
| Funciones exponenciales | [OpenStax · Algebra and Trigonometry 2e · 6.1 Exponential Functions](https://openstax.org/books/algebra-and-trigonometry-2e/pages/6-1-exponential-functions) |
| Logaritmos | [OpenStax · Algebra and Trigonometry 2e · 6.3 Logarithmic Functions](https://openstax.org/books/algebra-and-trigonometry-2e/pages/6-3-logarithmic-functions) |
| Límites | [OpenStax · Calculus Volume 1 · 2.2 The Limit of a Function](https://openstax.org/books/calculus-volume-1/pages/2-2-the-limit-of-a-function) |
| Continuidad | [OpenStax · Calculus Volume 1 · 2.4 Continuity](https://openstax.org/books/calculus-volume-1/pages/2-4-continuity) |
| Derivadas | [OpenStax · Calculus Volume 1 · 3.1 Defining the Derivative](https://openstax.org/books/calculus-volume-1/pages/3-1-defining-the-derivative) |
| Aplicaciones de derivadas | [OpenStax · Calculus Volume 1 · 4.3 Maxima and Minima](https://openstax.org/books/calculus-volume-1/pages/4-3-maxima-and-minima) |
| Integrales | [OpenStax · Calculus Volume 1 · 5.2 The Definite Integral](https://openstax.org/books/calculus-volume-1/pages/5-2-the-definite-integral) · [OpenStax · Calculus Volume 1 · 5.3 Fundamental Theorem of Calculus](https://openstax.org/books/calculus-volume-1/pages/5-3-the-fundamental-theorem-of-calculus) |
| Ecuaciones diferenciales sencillas | [OpenStax · Calculus Volume 2 · 4.1 Basics of Differential Equations](https://openstax.org/books/calculus-volume-2/pages/4-1-basics-of-differential-equations) · [OpenStax · Calculus Volume 2 · 4.3 Separable Equations](https://openstax.org/books/calculus-volume-2/pages/4-3-separable-equations) |
| Probabilidad | [OpenStax · Introductory Statistics 2e · 3.1 Probability terminology](https://openstax.org/books/introductory-statistics-2e/pages/3-1-terminology) · [OpenStax · Introductory Statistics 2e · 3.2 Independent and Mutually Exclusive Events](https://openstax.org/books/introductory-statistics-2e/pages/3-2-independent-and-mutually-exclusive-events) |
| Estadística descriptiva | [OpenStax · Introductory Statistics 2e · 2.5 Center](https://openstax.org/books/introductory-statistics-2e/pages/2-5-measures-of-the-center-of-the-data) · [OpenStax · Introductory Statistics 2e · 2.7 Spread](https://openstax.org/books/introductory-statistics-2e/pages/2-7-measures-of-the-spread-of-the-data) |
| Inferencia estadística | [OpenStax · Introductory Statistics 2e · 9.4 Decision and Conclusion](https://openstax.org/books/introductory-statistics-2e/pages/9-4-rare-events-the-sample-decision-and-conclusion) · [OpenStax · Introductory Statistics 2e · 8.1 Confidence interval for a mean](https://openstax.org/books/introductory-statistics-2e/pages/8-1-a-single-population-mean-using-the-normal-distribution) |
| Regresión | [OpenStax · Introductory Statistics 2e · 12.3 The Regression Equation](https://openstax.org/books/introductory-statistics-2e/pages/12-3-the-regression-equation) |
| Matrices | [OpenStax · Algebra and Trigonometry 2e · 11.5 Matrices and Matrix Operations](https://openstax.org/books/algebra-and-trigonometry-2e/pages/11-5-matrices-and-matrix-operations) |
| Modelamiento biológico | [OpenStax · Calculus Volume 2 · 4.4 The Logistic Equation](https://openstax.org/books/calculus-volume-2/pages/4-4-the-logistic-equation) · [OpenStax · Calculus Volume 2 · 4.1 Basics of Differential Equations](https://openstax.org/books/calculus-volume-2/pages/4-1-basics-of-differential-equations) |
| Fluidos y presión | [OpenStax · College Physics 2e · 11.3 Pressure](https://openstax.org/books/college-physics-2e/pages/11-3-pressure) · [OpenStax · College Physics 2e · 11.4 Pressure with depth](https://openstax.org/books/college-physics-2e/pages/11-4-variation-of-pressure-with-depth-in-a-fluid) |
| Temperatura y calor | [OpenStax · College Physics 2e · 13.1 Temperature](https://openstax.org/books/college-physics-2e/pages/13-1-temperature) · [OpenStax · College Physics 2e · 14.2 Temperature Change and Heat Capacity](https://openstax.org/books/college-physics-2e/pages/14-2-temperature-change-and-heat-capacity) |
| Termodinámica | [OpenStax · College Physics 2e · 15.1 First Law of Thermodynamics](https://openstax.org/books/college-physics-2e/pages/15-1-the-first-law-of-thermodynamics) · [OpenStax · College Physics 2e · 15.6 Entropy and Second Law](https://openstax.org/books/college-physics-2e/pages/15-6-entropy-and-the-second-law-of-thermodynamics-disorder-and-the-unavailability-of-energy) |
| Electricidad | [OpenStax · College Physics 2e · 20.2 Ohm’s Law](https://openstax.org/books/college-physics-2e/pages/20-2-ohms-law-resistance-and-simple-circuits) · [OpenStax · College Physics 2e · 20.1 Current](https://openstax.org/books/college-physics-2e/pages/20-1-current) |
| Ondas | [OpenStax · College Physics 2e · 16.9 Waves](https://openstax.org/books/college-physics-2e/pages/16-9-waves) |
| Óptica e instrumentos | [OpenStax · College Physics 2e · 25.6 Image Formation by Lenses](https://openstax.org/books/college-physics-2e/pages/25-6-image-formation-by-lenses) · [OpenStax · College Physics 2e · 25.3 The Law of Refraction](https://openstax.org/books/college-physics-2e/pages/25-3-the-law-of-refraction) |
| Difusión | [OpenStax · College Physics 2e · 12.7 Molecular Transport](https://openstax.org/books/college-physics-2e/pages/12-7-molecular-transport-phenomena-diffusion-osmosis-and-related-processes) |
| Ósmosis y transporte | [OpenStax · College Physics 2e · 12.7 Molecular Transport](https://openstax.org/books/college-physics-2e/pages/12-7-molecular-transport-phenomena-diffusion-osmosis-and-related-processes) · [OpenStax · Chemistry 2e · 11.4 Colligative Properties](https://openstax.org/books/chemistry-2e/pages/11-4-colligative-properties) |
| Fenómenos de superficie | [OpenStax · College Physics 2e · 11.8 Surface Tension](https://openstax.org/books/college-physics-2e/pages/11-8-cohesion-and-adhesion-in-liquids-surface-tension-and-capillary-action) |
| Transferencia de calor | [OpenStax · College Physics 2e · 14.4 Heat Transfer Methods](https://openstax.org/books/college-physics-2e/pages/14-4-heat-transfer-methods) · [OpenStax · College Physics 2e · 14.5 Conduction](https://openstax.org/books/college-physics-2e/pages/14-5-conduction) |
| Fundamentos de instrumentos | [OpenStax · College Physics 2e · 26.4 Microscopes](https://openstax.org/books/college-physics-2e/pages/26-4-microscopes) · [OpenStax · College Physics 2e · 27.6 Limits of Resolution](https://openstax.org/books/college-physics-2e/pages/27-6-limits-of-resolution-the-rayleigh-criterion) · [OpenStax · Chemistry 2e · 1.5 Measurement Uncertainty, Accuracy, and Precision](https://openstax.org/books/chemistry-2e/pages/1-5-measurement-uncertainty-accuracy-and-precision) |

## Autoría, progreso y recuperación

`npm run content:build` invoca `math_content.py` y `physics_content.py` tras Biología/Química. Las utilidades `science_authoring.py` solo comparten estructura de autoría y distribución determinista de opciones; no generan versiones de relleno ni cambian módulos anteriores. Cada bloque tiene seis preguntas redactadas para su tema, dos ejemplos y resumen propio. IDs nuevos `…-v1-qN`; grafo/97 IDs sin cambios.

Antes de autoría se congelaron catálogo y **60 firmas** de `1cb18a8`, más perfil del motor anterior con respuestas/feedback de ADN y diluciones. `tests/fixtures/math-physics-baseline` no debe regenerarse con el contenido actual. Regresiones conservan las 60 lecciones/firmas, todas las de Biología/Química, diagnóstico/variantes/proyectos, fuentes/unidades/cursos previos y aristas. SQL/documento/perfil/checkpoint **3/3/1/1**, sin migración de representación, sin recalificar ni conceder XP por abrir contenido nuevo.

SQLite de Node escribe respuestas de las dos rutas, cierra/reabre/exporta/restaura y verifica que las sesiones e historial previos persisten. No es prueba del driver nativo. Respalda antes de actualizar una instalación; conserva la recuperación explícita y no desinstales para eludir conflictos de firma.

## Comprobación y pendientes

La suite nueva verifica 77 soluciones numéricas mediante relaciones independientes, equivalencias y tolerancias, signo de lentes/Fick/trabajo, cero de tasa logística, dominios/removibilidad, tres curvas y explicaciones de límites estadísticos. Ver tests/math-physics-content.test.ts y tests/e2e/math-physics.spec.ts. Resultados efectivos en PROGRESS/evidence/math-physics-2026-10-23.json, sin atribuir pruebas no ejecutadas.

Pendientes: revisión docente y profundidad/dificultad/tiempos; fundamentos originales y alcance del diagnóstico (incluida asociación conceptual del ítem 6 ya registrada en la auditoría, sin recalificarlo); 9 temas formales de ruta integrada. Las lecciones amplias de esta entrega son primeras aproximaciones, no cursos completos de cálculo o física universitaria.

**El APK histórico no incluye las expansiones actuales.** Hace falta compilar otro APK identificado y verificar actualización/SQLite/offline/TalkBack/rendimiento en Android. Exportar Hermes es comprobación de empaquetado JS, no APK. No se cambian política/hash del APK anterior, Expo/EAS/dependencias ni se cierra SEC-01/R-04: publicación sigue bloqueada: auditoría nueva 4 high/0 critical por node-forge y dependientes, sin parche indicado. El aviso de braces fue retirado oficialmente el 2026-10-23; no se modificaron dependencias para bajar el conteo.
