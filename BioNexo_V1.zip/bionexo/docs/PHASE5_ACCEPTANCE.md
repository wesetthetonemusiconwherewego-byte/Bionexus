# Aceptación restante de Fase 5

**Después de BIO-01:** el APK y la política preview-arm64-v1 son históricos y no contienen las lecciones nuevas. La huella actual cambia; el inspector debe bloquear si se compara ese APK con las fuentes nuevas. No modificar la política para eludirlo: generar/revisar otro build antes de aceptación Android.

El APK de prueba ya existe. P5-02 está BLOCKED y P5-03 TESTING: falta ejecución Android, no otra implementación de BioLab/proyectos. Esta guía complementa la matriz de [PHASE4_HANDOFF.md](PHASE4_HANDOFF.md) y [UX_AUDIT.md](UX_AUDIT.md), cuyos pasos de preparación anteriores son históricos.

## Comprobar el archivo antes de instalar

```bash
npm ci
node --import tsx scripts/verify-apk.ts RUTA_APK RUTA_BUILD_TOOLS docs/release/preview-arm64-v1.json
```

Build Tools debe contener aapt/aapt2/zipalign y lib/apksigner.jar; Java debe estar en PATH o JAVA_HOME. Las rutas con espacios van entre comillas. No se instala ni modifica nada al ejecutar el inspector. `ARTIFACT_VERIFIED` identifica el binario esperado y su certificado público de prueba; no certifica su procedencia, compatibilidad de actualización instalada ni ausencia universal de secretos. Los nombres sensibles se buscan mediante una lista acotada. La alineación ZIP de 16 KB no prueba por sí sola todos los binarios ELF o dispositivos de 16 KB.

La política fija SHA-256, tamaño, commit de build, huella de fuentes, firma v2 y un firmante, versiones/package/SDK/ABI, permisos exactos y recursos incluidos. Cambiar aplicación/dependencias requiere otro build y revisión de política. No basta cambiar el hash para eludir un bloqueo. Este inspector no firma ni solicita claves; falla ante herramientas ausentes/no verificadas, manifiesto inválido o una comprobación fallida. No comprueba una cadena de rotación de certificados: este canal de prueba conserva un único certificado.

## Pruebas que siguen pendientes

En un dispositivo/emulador identificado y con respaldo previo, comprobar instalación/actualización compatible sin desinstalar para eludir firma. Registrar el perfil de prueba antes/después, completar una lección, cerrar/reabrir, verificar SQLite/reanudación/XP y respaldo/exportación/importación. Abrir de nuevo en modo avión y estudiar con recursos incluidos. Ejecutar TalkBack, escalas reales 100/150/200%, orientación, temas/movimiento y medidas con tres volúmenes de historial según la matriz. Usar datos sintéticos separados del progreso personal.

El inspector no ejecuta esas acciones. El APK mantiene versión 0.1.0/versionCode 1 y firma pública de prueba; no se presenta como actualización nueva de producción.

Copia `docs/evidence/android-acceptance.template.json` fuera del repositorio, completa solo resultados observados y conserva archivos/hashes. Después:

```bash
npm run phase4:readiness -- RUTA_DEL_REGISTRO
```

El nombre del comando se conserva por compatibilidad. `BLOCKED` indica evidencia incompleta; `REVIEW_REQUIRED` permite revisar integridad/completitud, sin certificar ejecución humana ni marcar P3-03/P5-02/P5-03 DONE. Las pruebas sintéticas de ese verificador nunca son evidencia Android.

Antes de publicar, repetir auditoría y resolver R-04. Las 19 entradas high permanecen abiertas en la comprobación del 2026-10-23; no hay actualización compatible identificada de sus dos raíces. Ver [DEPENDENCY_SECURITY.md](DEPENDENCY_SECURITY.md). Revisión académica humana también pendiente. No se requiere contratar EAS para estos pasos locales.

Fuentes oficiales consultadas el 2026-10-23: [apksigner](https://developer.android.com/tools/apksigner), [zipalign](https://developer.android.com/tools/zipalign), [AAPT2](https://developer.android.com/tools/aapt2). Son instrucciones de herramientas, no validación del aprendizaje ni aceptación de este APK en un dispositivo.


CHEM-01 (2026-10-23) amplía contenido químico después de BIO-01 y vuelve a cambiar la huella de entradas. El APK/política previos siguen históricos y no incluyen las expansiones. Exige reconstrucción identificada y matriz nativa; un bundle Android nuevo no es APK ni aceptación instalada.


MAT-PHY-01 (2026-10-23) amplía otras 28 lecciones y cambia de nuevo la huella de fuentes. Ninguno de los incrementos académicos está en el APK histórico. Conservar política/hash de ese artefacto y exigir nueva compilación identificada/aceptación real; Hermes/exportaciones no cierran APK, TalkBack/SQLite nativo ni R-04.
