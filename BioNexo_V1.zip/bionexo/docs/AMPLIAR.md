# Añadir cursos, conceptos y ejercicios

1. Edita `scripts/build_content.py`, fuente de autoría, o cambia el contrato y el generador juntos. No edites solo el JSON y luego lo sobrescribas sin querer.
2. Asigna ID estable y único a cada entidad. Una corrección de redacción conserva ID; un cambio de habilidad o significado exige ID nuevo y una estrategia de migración de progreso.
3. Cada concepto debe declarar materia, título en ambos idiomas, explicación, ejemplo, fuente, origen y prerrequisitos existentes. `planned` no crea una lección ejecutable. Para pasar a `implemented`, escribe la lección completa y revisa exactitud, distractores y fuentes.
4. Cada lección lleva objetivo medible, activación, explicación, ejemplo en pasos, aplicación, resumen y al menos seis ejercicios. Usa errores plausibles como distractores; varía contextos y demanda cognitiva. La revisión humana queda registrada como pendiente hasta que exista un revisor real.
5. Ejercicios: `choice`, `multi`, `text`, `numeric`, `match`, `order`, `chart`, `diagram`, `prediction`, `case`. Las variantes de gráfico y diagrama tienen datos/estructura propios; no dependen de recursos remotos. Actualmente el diagrama soportado es una célula esquemática. Añade una variante tipada y su renderizador para estructuras nuevas.
6. En numéricos, `correct` y `tolerance` se expresan en `unit`; `acceptedUnits` mapea unidad → factor hacia esa unidad de referencia. Ejemplo: unidad L, factores `{L:1,mL:0.001}`. Decimales con coma, fracciones y exponentes están admitidos; expresiones algebraicas arbitrarias no se evalúan. Especifica siempre los supuestos de una fórmula.
7. Ejecuta `npm run content:build`, `npm run check`, las exportaciones y las pruebas de interfaz pertinentes. Revisa el grafo para no crear ciclos. El validador comprueba referencias, soluciones validables, datos y coherencia de unidades/rangos; no demuestra toda la corrección científica.

## Nuevos laboratorios

Separa el cálculo puro y sus parámetros del renderizador. Declara dominio, unidades, supuestos, limitaciones, y si los datos son simulados. Añade pruebas de casos conocidos, límites y simetrías cuando correspondan. El cuaderno conserva hipótesis, puntos y observaciones. Nunca etiquetes valores del modelo como mediciones reales.

## Futuros idiomas, cuentas o IA

El contenido está separado de la UI, pero la internacionalización completa de textos de interfaz es un trabajo pendiente. El glosario inglés es gradual, no un curso bilingüe completo. No añadas una dependencia de red a la calificación ni al progreso local. Proveedores externos deben ser opcionales y tener pruebas de fallo/sin conexión.

## Compatibilidad de sesiones al cambiar contenido

Los documentos de progreso actuales usan envoltorio 3; conservan las referencias de perfiles anteriores. No edites `src/content/history/v0.1.0-contracts.json` ni regeneres las fixtures antiguas para aceptar un catálogo cambiado. `lessonSignature` incluye la lección y su apoyo: un cambio de contenido impide reanudar automáticamente el punto anterior y conserva sus datos para revisión/descarte explícito. Mantén IDs cuando corresponda; cambios de forma de respuesta requieren ID nuevo o migración. Si añades otro estado interactivo, extiende el checkpoint tipado, validación, compatibilidad/versión y pruebas de interrupción, sin declarar confirmada una respuesta antes de guardar intento y checkpoint juntos.

## Tramos progresivos (P1-02)

`Lesson.stages?` es opcional; cada tramo contiene ID local estable, título, objetivo, explicación, ejemplo `{title, steps}`, `exerciseIds` y `sourceIds`. La concatenación de los IDs debe coincidir exactamente con los ejercicios de la lección, sin huecos/repeticiones ni reordenamientos. `stageAt` deriva el tramo del cursor persistido: reanudar no añade otro estado ni duplica premios. Las lecciones sin tramos usan el flujo previo. Ver piloto en `scripts/factoring_pilot.py` y compatibilidad ADR-009; no regenerar fixtures históricas.

## Ayuda graduada (P1-03)

En el piloto, `hints` tiene tres pistas originales: orientación, procedimiento y transición a otro ejemplo. `hintExample?: {title, steps}` se muestra únicamente al alcanzar la última pista. Consultar cualquier pista conserva `hintCount`; tras confirmar, el intento lleva `hinted=true`. No reutilices números/expresiones del reto en el ejemplo alternativo. `explanation.distractors?` relaciona IDs de opciones incorrectas con explicaciones; no se admiten opciones inexistentes, correctas o mensajes vacíos. En selección múltiple se explican las opciones erróneas elegidas; omisiones usan la explicación general. En respuestas numéricas se conserva el feedback específico redactado; no hay diagnóstico automático nuevo.

El feedback aparece después de confirmar y no altera la calificación guardada. Tras completar el puente de apoyo, volver conserva la respuesta original para revisarla y aumenta `attemptNo`; cualquier reintento cuenta como ayuda. No se añade un formato persistente nuevo. Mantén la etiqueta de revisión humana y verifica identidades/unidades con casos independientes, además del validador.

## Evaluación numérica vigente · P2-02

Gramática acotada de hasta 100 caracteres: decimal con coma o punto, signo (incluido −), exponente e/E y una división opcional. No admite cálculos simbólicos, separadores de miles, paréntesis ni código. Operand(os), cociente y conversión de unidad deben ser finitos. Un mantisa no nula que se redondea a cero, o un resultado/conversión no nulo que cae a cero, se rechazan; no hay aritmética de precisión arbitraria. Se admiten subnormales representables, p. ej. 5e-324, con precisión limitada de Number. Un cero matemático como 0e999 sigue siendo cero.

Unidad solo entre claves propias de `acceptedUnits`, con factor positivo/finito. Se compara error absoluto ≤ tolerancia declarada + 8·EPSILON·|correcta|; ya no hay piso absoluto EPSILON·1 que oculte errores a escalas pequeñas. Define tolerancias coherentes con la magnitud; una tolerancia de 1e-8 sí permite diferencias absolutas de ese orden. Los respaldos usan formas históricas, no parseNumber/grade: no recalificar intentos antiguos, incluso si antes se aceptó 1/1e309 como cero. Fixture y ADR-010 documentan esta transición sin modificar SQL ni formatos.

## Familia parametrizada v1 · P2-01

Autoría: `practiceFamilies` se genera en `scripts/build_content.py`. `variants.ts` produce catorce instancias: pares p<q entre 2 y 7, excluyendo (2,3), ya evaluado en la lección. `familyParameters`, `generateVariant` y `selectVariants` son puros. Cada ID `factor-trinomial-v1-sN` fija parámetros, opciones y solución; la prueba contiene la matriz exacta de semillas. No alterar su matemática: añadir otro generador/versionado/IDs cuando cambien límites o relaciones. No contar variantes como lecciones ni duplicar el banco en el JSON.

`allExercises` incorpora el banco y `createDocument` registra sus formas; los intentos conservan solo el ID y la respuesta, suficientes para reproducir la instancia instalada. No se agregan campos persistentes ni migración de SQL/formato. Todas las variantes comparten `rewardId=factor-trinomial-v1-s0`: la familia otorga 10 XP como máximo, sin alterar premios antiguos. El historial/mastery/repasos conserva cada intento y el evaluador consulta el registro instalado, sin confiar en `correct` o parámetros de UI. No se afirma autenticidad de respaldos sin firma.

La práctica libre abre rondas de tres, primero inéditas y luego menos recientes. No reanuda su cursor al salir, como los repasos previos; sus respuestas confirmadas y referencias sí se exportan/restauran. Un error de variante pendiente puede volver en repaso y revisión de errores. La definición inválida hace fallar validación, manteniendo importable la UI de rescate. Nunca regenerar fixtures para encubrir cambios de identidad.

## Reglas y transferencia · P2-03

Autoría en `scripts/phase2_content.py`, importada por el generador principal. `errorRules` contiene IDs versionados, ejercicios/familias objetivos, selector explícito (distractor o subconjunto propio de raíces correctas), explicación, ejemplo y bases del grafo con fuentes. `matchingMisconceptions` no adivina errores numéricos desconocidos ni marca respuestas correctas; `misconceptionEvidence` cuenta coincidencias en errores no diagnósticos guardados. Son observaciones históricas, incluso si después se acierta; no etiquetas de capacidad. No cambian intentos, XP, calendarios ni firmas de lecciones.

PatternSupport permite visitar una base relacionada sin perder el checkpoint original. El puente existente tras errores repetidos sigue teniendo ejercicio sencillo y retorno con ayuda/elección conservada. La clasificación solo añade explicación y enlaces; no cambia retrospectivamente la calificación ni inventa reglas para respuestas no cubiertas.

`transferActivities` añade actividad de dos retos sobre D(u)=(u²−5u+6) UR, u=t/(1 min), 0≤t≤5 min. D es diferencia hipotética de lecturas: puede ser negativa; no es actividad biológica, concentración ni resultado experimental. Se practica raíces dentro del dominio y evaluación con unidad relativa. Son IDs nuevos, con premio habitual de 10 XP por reto; no se cuentan como lecciones nuevas. `transferEvidence` muestra primera respuesta y respuesta más reciente, separa ayuda y no permite que repetir cambie la muestra inicial. No es medición psicométrica válida ni diagnóstico universitario. Mantener supuestos, fuentes y revisión humana pendiente.

## Razones de selección y calendario · P2-04

`guidance.ts` envuelve `recommendations` y `reviewQueue` sin cambiar su orden, pesos ni intervalos. La guía de lección declara objetivo inicial/diagnóstico/prioridad matemática/pendiente y sus bases; puede añadir una relación con una regla de una respuesta cuya última corrección siga siendo negativa. No afirma que ese patrón haya cambiado el orden.

La guía de repaso incluye concepto, vencimiento e intervalo/lapsos guardados. `scheduleSource` reproduce en memoria el planificador con los resultados ya registrados, excluyendo diagnóstico y respetando días locales; solo atribuye un evento cuando los cinco campos del calendario reconstruido coinciden. No reevalúa respuestas ni escribe ese cálculo. Si faltan eventos, hubo otro algoritmo o cambió la zona horaria y la reconstrucción no coincide, se muestra procedencia desconocida del calendario guardado. El último intento del concepto se distingue del que originó la fecha: un acierto posterior del mismo día puede no cambiar el vencimiento.

Practice presenta un adelanto de tres razones; el repaso mantiene su selección/razón del inicio y muestra cada una junto al reto. Fechas se presentan en hora local del dispositivo. No hay temporizador de notificaciones ni garantía de retención; práctica libre sigue disponible. Los tests fijan instantes y cambian zona local de forma controlada, incluyendo medianoche en Santiago y UTC.

## BioLab y proyectos · Fase 4

La guía `biolab.json` y el proyecto `project-dilution-v1` se generan desde `scripts/phase4_content.py`. Añadir un control requiere un modelo explícito, unidades/rango, supuestos y pruebas, no solo dibujar el control. `lab-notebook.ts` separa el criterio para registros nuevos de la lectura histórica: mínimo dos pH distintos del mismo modelo, sin duplicados, valores coherentes con el cálculo actual, notas hasta 2.000 caracteres y 100 condiciones nuevas. `labComparisons` usa la primera lectura y la primera posterior distinta de cada modelo; diferencia en puntos porcentuales, sin significación estadística. Nunca reevalúa valores guardados.

`/lab-session/[id]` reabre registros inmutables con tabla completa paginada, curva por modelo y muestra gráfica limitada a 200 puntos cuando sea necesario, con aviso. No se edita silenciosamente un informe previo. El borrador del cuaderno no persiste hasta guardar; la navegación conserva solo el contexto público del gráfico.

El proyecto usa TransferActivity y seis IDs nuevos, 10 XP por primer acierto de cada reto, sin premios por relectura ni laboratorio. Al reabrir continúa con retos aún sin respuesta confirmada; errores y conclusión permanecen en intentos. El borrador/cursor de esa ronda es transitorio, como en repasos. El componente TransferEvidence debe dirigir al ID/ruta correspondiente; no asumir que toda actividad es la primera transferencia. Las lecciones conservan su reanudación independiente. Mantener fuentes y revisión humana pendiente.

## Química · CHEM-01

La autoría de los 16 temas está en `scripts/chemistry_content.py`, invocada desde `build_content.py`. BLOCKS contiene contenidos redactados individualmente, no variantes de relleno: dos ejemplos distintos y seis retos por tema. REFS define referencias verificables; UNITS/cursos organizan lecciones. La rotación determinista cambia posiciones solo al crear ejercicios v1 nuevos. Cambiar autoría u orden puede cambiar sus firmas: no reutilizar sus IDs para otra pregunta ni regenerar fixtures históricas. Antes de revisar ejercicios publicados, documentar impacto de checkpoint y recuperación. Regenerar catálogo, ejecutar check/E2E/exportaciones y revisar fuentes/unidades/supuestos; revisión humana sigue pendiente.

## Física/Matemáticas · MAT-PHY-01

`math_content.py` (17 bloques) y `physics_content.py` (11) usan `science_authoring.py`. Cada bloque es redacción específica: objetivo/activación, dos párrafos explicativos, dos ejemplos de al menos tres pasos, aplicación, resumen y seis preguntas únicas. La utilidad asigna IDs/refs y rota opciones determinísticamente antes de publicar v1; cambiar orden/autoría de bloques puede cambiar firmas, por lo que los IDs publicados no se reutilizan para preguntas nuevas. El generador principal los aplica después de Química/Biología y sigue escribiendo el mismo JSON/grafo.

Unidades y conversiones deben ser explícitas y dimensionalmente coherentes; no usar factores multiplicativos para convertir temperatura absoluta °C↔K. Elegir tolerancia que no haga aceptar cero para cantidades pequeñas. Las fixtures de 1cb18a8 no se regeneran. Repetir check/E2E/exportaciones/guardas y revisión científica; publicar un modelo didáctico no demuestra su validez ni profundidad universitaria.
