# Índice de arquitectura · evolución a BioNexo 2.0

La descripción vigente y canónica sigue en [ARQUITECTURA.md](ARQUITECTURA.md). Se conserva su nombre y contenido para evitar dos documentos de arquitectura que diverjan. Este archivo es el punto de entrada solicitado para el proceso 2.0, no una arquitectura alternativa.

## Fronteras comprobadas por inspección

| Módulo | Responsabilidad existente | Límite que se conserva |
|---|---|---|
| `app/` | Expo Router: inicio, lección, diagnóstico, repaso | Navegación y coordinación; no almacenar lógica científica en rutas. |
| `src/content/` | Catálogo JSON y grafo incluido sin red | Autoría en `scripts/build_content.py`; no cambiar IDs silenciosamente. |
| `src/domain/` | Modelos, respuestas, progreso, repaso, validación, modelo enzimático | Funciones puras donde corresponda; separar cambios de calificación y migración histórica. |
| `src/storage/` | SQLite nativo, adaptador web, exportación/importación | Un único perfil; perfil `version: 1`, envoltorio `version: 3`, esquema SQLite `user_version=3`; son versiones distintas. |
| `src/ui/` | Tema, componentes, sesiones, siete secciones | Mantener accesibilidad y persistir antes de confirmar éxito en pantalla. |
| `tests/` | Dominio/SQLite, compatibilidad histórica y Playwright web | No equiparar estos adaptadores al driver nativo Android. |

## Riesgos de arquitectura observados

- P0-03 resolvió el acoplamiento de lectura histórica al catálogo: `progress-document.ts` valida referencias propias y resultados registrados sin recalificarlos. Ver ADR-006; no valida autenticidad de un respaldo editado.
- Todo el historial se serializa en un documento SQLite; las lecturas/escrituras validan el perfil completo. El coste crece con el historial; normalizar exige medición y migración, no se hará en esta auditoría.
- `src/ui/screens.tsx` agrupa siete secciones. La separación por módulo puede hacerse al tocar una funcionalidad concreta; no justifica por sí sola una refactorización completa.
- P1-01 conserva cursor, borradores, ayuda y feedback de lecciones. Diagnóstico y repaso siguen transitorios. No se garantiza recuperar una escritura sin commit.
- La clave web existente vacía se confundía con ausencia. La corrección de esta ejecución exige `getItem(...) === null` para crear un perfil; preserva el valor corrupto y deja actuar al flujo de error.

## Impacto de P0-03

SQLite añade migración 3 y copias originales transaccionales; el documento de progreso añade envoltorio 2 sin cambiar `UserState.version=1`. La UI de recuperación está disponible antes de tener un perfil válido. No cambian el catálogo académico, IDs, algoritmos de dominio ni Expo/EAS/dependencias. Detalles, límites y procedimiento de recuperación en la arquitectura canónica y ADR-006.

El plan, registro de decisiones y checklist se enlazan desde [DEVELOPMENT_PLAN.md](DEVELOPMENT_PLAN.md), [DECISIONS.md](DECISIONS.md) y [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md).

## Controles de dependencias (P0-04)

`security:audit` consulta avisos vivos y falla ante high/critical o error de consulta. `scripts/security/bundles.ts` y su CLI inspeccionan mapas por bundle para detectar las dos raíces identificadas en P0-04. CI separa regresiones de la auditoría sin silenciar esta última. No cambian módulos de aplicación, esquema/perfil ni dependencias. Alcance y límites en [DEPENDENCY_SECURITY.md](DEPENDENCY_SECURITY.md), decisión ADR-007. La estabilización local finaliza; alertas abiertas no autorizan lanzamiento.

## P1-01

El contrato nuevo es envoltorio 3, perfil 1 con `lessonSessions?`, SQLite 3. Migración de payload con copia original, sin tabla nueva. `sessions.ts` coordina borrador, confirmación, avance, fin y descarte sobre el mismo snapshot de progreso. Criterios y límites en la arquitectura canónica y ADR-008. No se modifican evaluación/planificador, catálogo/IDs ni dependencias.

## BioLab e integración · ADR-013

`src/ui/laboratory.tsx` separa el laboratorio de screens al añadir su diseño guiado; reusa los componentes, contexto de navegación y motor gaussiano. `src/domain/lab-notebook.ts` contiene predicción, comparación, altas nuevas e idempotencia sin tocar la lectura histórica. `/lab-session/[id]` presenta valores originales, paginación y gráfico limitado con aviso. `/project` coordina una TransferActivity nueva mediante StudySession existente. Ninguna ruta almacena lógica científica nueva ni depende de red.

La guía y proyecto se generan desde phase4_content.py; los contratos de las 24 lecciones y el grafo permanecen idénticos a 18eb63a. `curriculum-integrity.ts` coteja cada nodo/arista del grafo incluido con el catálogo; `validateCatalog` devuelve errores recuperables ante estructuras malformadas. No acepta paquetes externos ni sustituye revisión humana. SQL/documento/perfil/checkpoint permanecen 3/3/1/1; fixture previa y restauración exacta cubren compatibilidad, no se necesita migración de representación. Las rondas del proyecto conservan respuestas confirmadas, no borradores/cursor al salir.

## Expansión biológica · ADR-015

`biology_content.py` promueve los 20 conceptos ya existentes y agrega lecciones/ejercicios con IDs nuevos, sin cambiar aristas ni formatos. El lector muestra el curso real, el mapa distingue los cursos y progreso deriva su denominador del catálogo. Reusa sesiones/feedback/evaluación sin modificar su semántica ni recalificar historial. Snapshot anterior y fixture de progreso/SQLite comprueban conservación. Detalles y límites: [BIOLOGIA.md](BIOLOGIA.md).

## Expansión química · ADR-016

`chemistry_content.py` añade 16 lecciones a los conceptos existentes, invocada después de Biología por el generador principal. No cambia UI, motor, formatos ni dependencias. Usa los mismos contratos de dos tramos y evaluador numérico; unidades y factores se declaran en cada ejercicio. Distribución de opciones determinista para IDs nuevos v1. Fixtures del catálogo/firmas/perfil del commit anterior protegen todas las lecciones biológicas y seis químicas previas. Grafo y SQL/formatos 3/3/1/1 exactos, sin migración; ver [QUIMICA.md](QUIMICA.md).

## Física y Matemáticas · ADR-018

`math_content.py` y `physics_content.py` promueven los 28 conceptos existentes mediante `science_authoring.py`, sin refactorizar autoría previa. Las utilidades de autoría comparten formatos/hints/distribución determinista de opciones; el runtime sigue consumiendo JSON offline y los mismos contratos/evaluador/sesiones. No cambia UI, algoritmos de progreso, dependencias ni SQL/formatos 3/3/1/1; 60 firmas y perfil biología/química congelados protegen compatibilidad. Detalles y límites: [FISICA_MATEMATICAS.md](FISICA_MATEMATICAS.md).
