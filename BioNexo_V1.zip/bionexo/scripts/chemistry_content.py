"""Original introductory chemistry content. Stable IDs; fictional computational data only.

Source references are factual background, not provenance for our invented numbers.
No laboratory procedures, book excerpts, or copied exercises are included.
"""
from copy import deepcopy


def C(prompt, options, index, why, clue, kind='choice'):
    return dict(type=kind, prompt=prompt,
        options=[dict(id=chr(97+i), text=v) for i,v in enumerate(options)],
        correct=chr(97+index), explanation=dict(correct=why, misconception=clue,
        distractors={chr(97+i):f'La opción «{v}» confunde las condiciones del problema. {why}' for i,v in enumerate(options) if i!=index}),
        hints=[clue, 'Usa esta relación: '+why])


def M(prompt, options, indices, why, clue):
    q=C(prompt,options,0,why,clue)
    q.update(type='multi',correct=[chr(97+i) for i in indices])
    q['explanation']['distractors']={chr(97+i):why for i in range(len(options)) if i not in indices}
    return q


def N(prompt,value,unit,why,clue,accepted=None,tolerance=1e-8):
    return dict(type='numeric',prompt=prompt,correct=value,unit=unit,tolerance=tolerance,
        acceptedUnits=accepted or {unit:1},explanation=dict(correct=why,misconception=clue),
        hints=[clue,'Escribe la relación con unidades antes de sustituir. '+why])


def G(prompt,options,index,points,x,y,why,clue):
    q=C(prompt,options,index,why,clue,'chart')
    q.update(chart=[dict(x=a,y=b) for a,b in points],xLabel=x,yLabel=y)
    return q


BLOCKS=[]
def B(cid,level,unit,refs,objective,activation,explanation,example,second_example,application,summary,qs):
    assert len(qs)==6
    BLOCKS.append(dict(cid=cid,level=level,unit=unit,refs=refs,objective=objective,
        activation=activation,explanation=explanation,example=example,second_example=second_example,
        application=application,summary=summary,qs=qs))


B('chem-reactions',2,'chemistry-stoichiometry',['stoich','balance'],
'Balancear una ecuación sencilla y usar proporciones molares para identificar un reactivo limitante.',
'¿Cambiar un coeficiente tiene el mismo efecto que cambiar un subíndice químico?',
'Una ecuación balanceada conserva el número de átomos de cada elemento y la carga total. Los coeficientes multiplican fórmulas completas: 2 H₂O representa dos moléculas o dos moles de agua; no convierte agua en H₂O₂. La estequiometría relaciona cantidades en mol, no masas directamente. Para una reacción a A + b B → c C, las cantidades n(A)/a y n(B)/b permiten comparar cuánto puede avanzar: la menor identifica el reactivo limitante, si ese es el único proceso y la conversión es completa.\n\nEl rendimiento teórico es un máximo bajo esos supuestos. El rendimiento porcentual es 100×cantidad obtenida/cantidad teórica, con ambas cantidades en las mismas unidades. Pérdidas, reacciones secundarias o impurezas cambian el resultado observado; un cálculo no demuestra que una reacción ocurra ni especifica cómo realizarla.',
['Ecuación formal: 2 H₂ + O₂ → 2 H₂O.','Datos ficticios: 3 mol H₂ y 2 mol O₂. Compara 3/2=1,5 frente a 2/1=2.','Limita H₂: máximo 3 mol H₂O; se consumen 1,5 mol O₂ y sobran 0,5 mol.'],
['Rendimiento teórico ficticio: 8 g; cantidad obtenida simulada: 6 g.','Ambas masas se refieren al mismo producto y están en g.','Rendimiento=100×6/8=75 %. No demuestra pureza del producto.'],
'En un balance de bioproceso conceptual, convertir masa a mol y comprobar el sustrato limitante evita atribuir productos ilimitados a una cantidad finita de materia.',
'Balancea sin cambiar identidades químicas; compara mol/coeficientes, calcula un máximo y separa rendimiento teórico de resultado observado.',[
 C('¿Cuál balancea la formación formal de agua sin cambiar fórmulas?',['2 H₂ + O₂ → 2 H₂O','H₂ + O₂ → H₂O','H₂ + O₂ → H₂O₂, porque es la misma sustancia'],0,'La primera tiene 4 H y 2 O a cada lado; H₂O₂ es otra sustancia.','Cuenta átomos, no solo moléculas.'),
 M('¿Qué es válido al balancear?',['Modificar coeficientes','Cambiar H₂O por H₂O₂ para ajustar oxígeno','Conservar átomos de cada elemento','Comprobar carga total'],[0,2,3],'Los coeficientes ajustan cantidades; subíndices definen la sustancia.','Conservación no permite cambiar identidades.'),
 N('En 2 H₂ + O₂ → 2 H₂O, con O₂ suficiente y conversión completa, 1,2 mol H₂ dan como máximo ¿cuántos mol H₂O?',1.2,'mol','La proporción H₂:H₂O es 2:2; 1,2×2/2=1,2 mol.','Usa el cociente de coeficientes.',{'mol':1,'mmol':0.001}),
 N('Modelo anterior: 5 mol H₂ y 2 mol O₂, conversión completa. ¿Máximo de H₂O?',4,'mol','5/2=2,5 y 2/1=2: limita O₂, que produce 2×2=4 mol H₂O.','Compara cantidades divididas por coeficientes.',{'mol':1,'mmol':0.001}),
 N('Un modelo predice 10 g de producto puro; un resultado simulado obtiene 7,5 g. ¿Rendimiento porcentual?',75,'%','El cociente obtenido/teórico es 7,5/10=0,75; al multiplicar por 100, el rendimiento es 75 %.','Obtenido dividido por teórico.',{'%':1}),
 C('Un informe simulado obtiene 12 g de muestra cuando el máximo de producto puro es 10 g. ¿Qué revisar?',['Pureza, humedad y mediciones antes de declarar rendimiento de producto puro','Que se crearon átomos','Que balancear ecuaciones permite crear masa'],0,'Una muestra puede incluir otras sustancias; más masa medida no prueba más producto puro.','Distingue masa de muestra de masa de producto.','case')])

B('chem-solutions',2,'chemistry-stoichiometry',['molarity'],
'Calcular concentración molar y cantidad de soluto usando volumen final de disolución.',
'¿El volumen de solvente añadido es necesariamente el volumen final de la disolución?',
'Una disolución homogénea contiene soluto distribuido en un solvente. La concentración molar c=n/V usa cantidad de soluto en mol y volumen FINAL de disolución en L; la unidad mol/L también se escribe M. Una concentración no es la cantidad total: dos muestras de igual c pueden contener distintos n si sus volúmenes difieren. Convertir mL a L antes de dividir evita errores de factor 1000.\n\nSi se conoce una masa, n=m/Mₘ, donde Mₘ es masa molar en g/mol. Los volúmenes de componentes no son siempre aditivos y la concentración molar puede cambiar con temperatura por expansión. Aquí suponemos disoluciones homogéneas, temperatura fija y datos exactos del modelo; solubilidad, actividad e incertidumbre real requieren estudio adicional.',
['Dato ficticio: 0,06 mol de soluto en 300 mL de disolución final.','300 mL=0,300 L.','c=0,06/0,300=0,20 mol/L. No es 0,0002 mol/L.'],
['Modelo de muestra: c=0,30 mol/L y V=0,040 L.','n=cV=0,30×0,040=0,012 mol.','Duplicar V a igual concentración duplica n; no duplica c.'],
'Interpretar la etiqueta conceptual de una solución permite relacionar una alícuota con su cantidad de soluto sin confundir concentración y cantidad total.',
'Usa volumen final y unidades coherentes. c=n/V y n=cV describen propiedades distintas; homogeneidad no significa sustancia pura.',[
 C('En c=n/V, V corresponde a…',['Volumen final de disolución','Solo volumen de soluto','Siempre volumen de solvente antes de mezclar'],0,'La concentración relaciona soluto con volumen total final.','Pregunta respecto de qué volumen se define c.'),
 N('Modelo: 0,15 mol en 500 mL finales. ¿Concentración molar?',0.3,'mol/L','0,15/0,500=0,30 mol/L.','Convierte 500 mL a L.',{'mol/L':1,'M':1,'mmol/L':0.001}),
 N('Muestra homogénea: c=0,08 mol/L, V=250 mL. ¿Cantidad de soluto?',0.02,'mol','0,08×0,250=0,020 mol.','Multiplica concentración por volumen en L.',{'mol':1,'mmol':0.001}),
 N('Soluto ficticio Mₘ=50 g/mol; hay 5 g en 0,40 L finales. ¿c?',0.25,'mol/L','n=5/50=0,10 mol; c=0,10/0,40=0,25 mol/L.','Primero convierte masa a cantidad.',{'mol/L':1,'M':1,'mmol/L':0.001}),
 M('Dos muestras de la misma disolución homogénea tienen 20 y 40 mL. ¿Qué es válido?',['Tienen igual concentración a la misma temperatura','La de 40 mL tiene el doble de soluto','La de 40 mL tiene doble concentración','Sus cantidades de soluto son iguales'],[0,1],'n=cV: a igual c, el doble de volumen contiene el doble de n.','No confundas una razón con el total.'),
 C('Se mezclan 30 mL y 70 mL de componentes. ¿Puede calcularse c exacta suponiendo siempre 100 mL finales?',['No: se necesita volumen final o un supuesto explícito de aditividad','Sí, los volúmenes siempre son aditivos','No existe concentración en mezclas'],0,'Los volúmenes pueden no ser aditivos; debe declararse la aproximación o conocer V final.','Volumen inicial sumado y final medido no son equivalentes por definición.','case')])

B('chem-dilution',2,'chemistry-dilution-gases',['molarity'],
'Aplicar conservación del soluto a una dilución ideal y distinguir volumen final de solvente añadido.',
'¿Añadir solvente crea o elimina moles de soluto?',
'Una dilución ideal reduce concentración al aumentar volumen de disolución conservando la cantidad del soluto que seguimos: n₁=n₂. De c=n/V resulta c₁V₁=c₂V₂. Supone ausencia de reacción, precipitación o pérdida del soluto. V₂ es volumen FINAL; no es automáticamente el volumen de solvente que se añade. Usa las mismas unidades de volumen en ambos lados y las mismas unidades de concentración.\n\nEl factor de dilución D=V₂/V₁=c₁/c₂ es mayor que uno al diluir. En diluciones sucesivas ideales los factores se multiplican. Si se añade otra solución que ya contiene el mismo soluto, hay que sumar sus cantidades: no se trata de añadir solvente puro. Los cálculos aquí son escenarios matemáticos, no instrucciones para preparar reactivos.',
['Modelo: c₁=0,80 mol/L, V₁=15 mL y V₂=120 mL finales.','c₂=0,80×15/120=0,10 mol/L.','D=120/15=8; la cantidad seguida de soluto se conserva.'],
['Dilución ficticia en dos etapas con factores 4 y 5.','D total=4×5=20.','Desde 0,60 mol/L resulta 0,60/20=0,030 mol/L, bajo conservación ideal.'],
'En datos simulados de ensayos biotecnológicos, registrar el factor total permite expresar una lectura en términos de la muestra original, solo si el modelo de medición admite esa corrección.',
'Diluir conserva soluto bajo condiciones explícitas. Usa V final y multiplica factores sucesivos; mezclar dos soluciones requiere balance de cantidades.',[
 C('Para justificar c₁V₁=c₂V₂ en una dilución ideal se requiere…',['Conservar la cantidad del soluto seguido','Conservar obligatoriamente el volumen','Crear soluto al añadir solvente'],0,'La igualdad es n₁=n₂, no V₁=V₂.','¿Qué propiedad debe mantenerse?'),
 N('Modelo: 0,60 mol/L y 10 mL de muestra se llevan a 150 mL finales. ¿c final?',0.04,'mol/L','0,60×10/150=0,040 mol/L.','V final es 150, no 150+10.',{'mol/L':1,'M':1,'mmol/L':0.001}),
 N('c₁=0,90 mol/L; se desea c₂=0,15 mol/L y V₂=180 mL finales en el modelo. ¿V₁?',30,'mL','V₁=0,15×180/0,90=30 mL.','Despeja V₁, no inviertas las concentraciones.',{'mL':1,'L':1000}),
 N('Dos diluciones ideales sucesivas tienen factores 3 y 5. ¿Factor total?',15,'','Cada etapa divide de nuevo la concentración: el factor total es 3×5=15, no la suma 3+5.','Cada paso divide de nuevo la concentración.'),
 N('Modelo de mezcla sin reacción y con volúmenes aditivos: 20 mL a 0,20 mol/L y 20 mL a 0,40 mol/L. ¿c final?',0.3,'mol/L','n=0,20×0,020+0,40×0,020=0,012 mol; V=0,040 L; c=0,30 mol/L.','Suma cantidades de soluto antes de dividir por V final.',{'mol/L':1,'M':1,'mmol/L':0.001}),
 C('Tras una dilución hay precipitación del soluto. ¿Qué puedes afirmar de c₁V₁=c₂V₂ para el soluto disuelto?',['Ya no se justifica sin considerar la fase precipitada','Siempre conserva toda la cantidad en disolución','Demuestra que aumentó la cantidad disuelta'],0,'La cantidad total puede conservarse, pero no toda permanece disuelta; hay que contabilizar fases.','Conservar materia total no equivale a conservar soluto disuelto.','case')])

B('chem-gases',2,'chemistry-dilution-gases',['gas'],
'Usar PV=nRT con unidades compatibles y temperatura absoluta, e identificar límites del gas ideal.',
'¿Duplicar grados Celsius equivale a duplicar temperatura absoluta?',
'El gas ideal es un modelo de partículas con volumen propio e interacciones despreciables. Su ecuación PV=nRT relaciona presión absoluta, volumen, cantidad y temperatura en kelvin. Para R=8,314 L·kPa/(mol·K), P debe estar en kPa, V en L y n en mol. La conversión es T(K)=t(°C)+273,15; en razones de temperatura se usa K, no °C.\n\nCon n y T fijos, P es inversamente proporcional a V; con n y V fijos, P es proporcional a T absoluta. Los gases reales se apartan del modelo, especialmente cerca de condensación y a altas presiones; no es una ley exacta universal. Estos ejercicios no consideran reacciones, fugas ni mezclas con vapor y no constituyen procedimientos con recipientes presurizados.',
['Modelo: n=0,50 mol, T=300 K y V=10 L.','P=nRT/V=0,50×8,314×300/10.','P=124,71 kPa, presión absoluta del modelo.'],
['Estado ideal inicial: P=80 kPa, V=6 L, T y n constantes.','Reducir V a 3 L multiplica P por 6/3.','P final=160 kPa; no extrapolar sin límites a gases reales.'],
'Un balance conceptual de gases en un sistema biotecnológico necesita especificar temperatura, presión, unidades y posibles componentes del gas antes de interpretar una cantidad.',
'PV=nRT requiere kelvin y presión absoluta. Identifica variables fijas y condiciones donde la idealidad deja de ser una aproximación razonable.',[
 N('Para usar PV=nRT, convierte 25 °C a kelvin.',298.15,'K','La escala kelvin suma 273,15 a grados Celsius: 25+273,15=298,15 K; no se usa 25 K.','La escala absoluta desplaza el origen.',{'K':1},0.001),
 C('En la ecuación de gas ideal, P es…',['Presión absoluta','Siempre presión relativa al ambiente','Una concentración molar'],0,'La ecuación emplea presión respecto del vacío, no presión manométrica sin corregir.','Distingue el origen de una escala.'),
 N('Modelo con n=0,20 mol, T=300 K, V=5 L y R=8,314 L·kPa/(mol·K). ¿P?',99.768,'kPa','0,20×8,314×300/5=99,768 kPa.','Cancela unidades al aplicar nRT/V.',{'kPa':1,'Pa':0.001},0.01),
 N('Gas ideal: inicialmente P=90 kPa y V=4 L. Con n y T constantes, V pasa a 6 L. ¿P final?',60,'kPa','P₂=P₁V₁/V₂=90×4/6=60 kPa.','Al aumentar V con n y T fijos, P disminuye.',{'kPa':1,'Pa':0.001}),
 G('Datos ideales simulados con V y n fijos. ¿Qué relación muestra el gráfico?',['P proporcional a T en K','P proporcional a 1/T','P independiente de T'],0,[(200,50),(300,75),(400,100)],'T (K)','P (kPa)','P/T=0,25 kPa/K en los tres puntos.','Compara cocientes usando temperatura absoluta.'),
 C('Un gas se aproxima a condensación a alta presión. ¿Es adecuado tratar PV=nRT como exacto?',['No: deben evaluarse desviaciones de idealidad','Sí, porque los gases no interactúan nunca','Sí, cualquier temperatura en °C sirve'],0,'Volumen molecular e interacciones pueden importar; la idealidad tiene límites.','Un modelo aproximado necesita condiciones de uso.','case')])

B('chem-equilibrium',2,'chemistry-dilution-gases',['equilibrium','equilibrium-constant'],
'Distinguir equilibrio dinámico de igualdad de concentraciones y usar Q frente a K en un modelo ideal 1:1.',
'¿Concentraciones constantes significan que las moléculas dejaron de reaccionar?',
'En una reacción reversible en equilibrio, las velocidades directa e inversa son iguales: las composiciones macroscópicas permanecen constantes sin detenerse los intercambios. No exige igual concentración de reactivos y productos. La constante termodinámica K se expresa con actividades adimensionales y depende de temperatura; no indica rapidez. Aquí modelamos A(ac) ⇌ B(ac) en disolución ideal a temperatura fija, con actividades aproximadas por c/c°. Entonces Q≈[B]/[A], y en equilibrio Q=K.\n\nSi Q<K, el avance neto favorece B hasta acercarse al equilibrio; si Q>K, favorece A, bajo estas condiciones. Los exponentes corresponden a coeficientes de la ecuación balanceada; no se generaliza la razón simple a cualquier reacción. Un catalizador acelera aproximación sin modificar K ni el equilibrio final a la misma temperatura. Las actividades de sólidos puros no se incluyen como concentraciones variables en K.',
['Modelo ideal A ⇌ B, K=3 y concentraciones iniciales [A]=0,40 M, [B]=0,20 M.','Q=0,20/0,40=0,5.','Q<K: se favorece avance neto hacia B; no se deduce cuánto tarda.'],
['Otro modelo 1:1: [A]eq=0,10 M y [B]eq=0,50 M.','K≈0,50/0,10=5, aunque concentraciones no son iguales.','Velocidades iguales no significan cantidades iguales.'],
'En un modelo bioquímico, comparar Q y K ayuda a razonar sobre composición; una enzima no transforma por sí sola un equilibrio desfavorable en otro favorable.',
'Equilibrio es dinámico; iguala velocidades, no concentraciones. Q compara el estado actual con K y catálisis no cambia K a temperatura fija.',[
 C('En equilibrio químico dinámico…',['Las velocidades directa e inversa son iguales','Cada reactivo tiene igual concentración que cada producto','Toda reacción molecular se detiene'],0,'Las transformaciones opuestas continúan con velocidades iguales.','Constancia macroscópica no significa inmovilidad.'),
 N('Modelo ideal A ⇌ B 1:1: [A]eq=0,20 M y [B]eq=0,60 M. ¿K aproximada?',3,'','K≈[B]/[A]=0,60/0,20=3.','Usa la razón de este modelo, no de cualquier ecuación.'),
 C('En A ⇌ B ideal, Q=0,5 y K=2 a temperatura fija. ¿Avance neto esperado?',['Hacia B','Hacia A','Ninguno, porque Q y K siempre son iguales'],0,'Q<K indica proporción de B inferior a la de equilibrio.','Compara estado actual con el cociente de equilibrio.','prediction'),
 M('¿Qué afirmaciones son correctas?',['K no determina cuánto tarda en alcanzarse el equilibrio','Un catalizador cambia K a igual temperatura','K puede cambiar con temperatura','Concentraciones distintas pueden estar en equilibrio'],[0,2,3],'Termodinámica, temperatura y cinética son aspectos diferentes.','Un catalizador ofrece otra vía, no otro balance energético.'),
 N('En A ⇌ B ideal, [A]=0,30 M y [B]=0,90 M. ¿Q?',3,'','Q≈0,90/0,30=3, usando ambas concentraciones en la misma unidad.','Divide producto entre reactivo para esta reacción 1:1.'),
 C('Dos sistemas idénticos a igual temperatura alcanzan equilibrio, uno con catalizador. ¿Qué comparación es válida?',['Mismo K; pueden diferir en tiempo para acercarse al equilibrio','El catalizado debe tener mayor K','El no catalizado debe tener concentraciones iguales'],0,'Catálisis cambia velocidades, no la constante ni composición final de estos sistemas idénticos.','No interpretes velocidad como desplazamiento del equilibrio.','case')])

B('chem-ph',3,'chemistry-acid-base',['acid-base','ph'],
'Identificar ácido/base conjugados y calcular pH/pOH bajo una aproximación acuosa diluida a 25 °C.',
'¿Un cambio de una unidad de pH corresponde a una diferencia de concentración de uno?',
'Un ácido de Brønsted dona un protón y una base lo acepta. Un par conjugado difiere en un protón: HA/A⁻. Fuerte y débil describen ionización, no concentración inicial. El pH se define con actividad adimensional de H₃O⁺; en un modelo diluido ideal se aproxima por pH≈−log₁₀([H₃O⁺]/c°), c°=1 mol/L. Para [H₃O⁺]=10⁻ˣ mol/L, pH≈x. Bajar una unidad implica multiplicar por diez la actividad, no sumar una cantidad fija.\n\nA 25 °C en el modelo acuoso usamos pH+pOH≈14 y neutralidad alrededor de pH 7. En otras temperaturas cambia K del agua y el pH neutro puede no ser 7. La escala no tiene universalmente límites 0 y 14; concentraciones muy altas requieren actividades. Los ejercicios dan directamente concentraciones de equilibrio, sin inferir pH de cualquier concentración inicial ni ignorar autoionización a dilución extrema.',
['Modelo diluido: [H₃O⁺]=10⁻⁵ mol/L a 25 °C.','log₁₀(10⁻⁵)=−5; pH≈−(−5)=5.','pOH≈14−5=9; es ácido respecto de neutralidad en estas condiciones.'],
['Dos modelos diluidos tienen pH 4 y pH 6.','Actividades relativas aproximadas: 10⁻⁴ y 10⁻⁶.','El primero tiene 10²=100 veces más actividad de H₃O⁺; no dos veces.'],
'Interpretar el pH del BioLab requiere distinguir la variable química del modelo de actividad enzimática: un óptimo simulado no es constante de toda enzima.',
'pH usa logaritmo de actividad; concentración es una aproximación diluida. Fija temperatura, distingue fuerza y concentración, y no conviertas un óptimo simulado en dato real.',[
 C('En HA + H₂O ⇌ A⁻ + H₃O⁺, la base conjugada de HA es…',['A⁻','H₃O⁺','HA sin cambio'],0,'HA pierde un protón y produce A⁻.','Un par conjugado difiere en un H⁺.'),
 N('Modelo ideal diluido: [H₃O⁺]=10⁻³ mol/L en equilibrio. ¿pH aproximado?',3,'','El logaritmo es −3 y el signo externo lo cambia: −log₁₀(10⁻³)=3; pH no tiene unidad.','El logaritmo de una potencia de diez es su exponente.'),
 N('A 25 °C, si pH=9 en el modelo acuoso, ¿pOH aproximado?',5,'','pOH≈14−9=5 a esta temperatura.','Usa la suma bajo las condiciones dadas.'),
 N('Modelos diluidos con pH 3 y pH 5: ¿cuántas veces mayor es la actividad de H₃O⁺ en pH 3?',100,'','Una diferencia de dos unidades implica dos factores de diez: 10⁻³/10⁻⁵=10²=100.','La diferencia de dos unidades es dos factores de diez.'),
 M('Selecciona afirmaciones válidas sobre fuerza ácida y escala de pH.',['Un ácido débil puede tener alta concentración inicial','Fuerte significa siempre muy concentrado','El pH neutro depende de temperatura','La escala de pH no tiene límites universales 0 y 14'],[0,2,3],'Fuerza, concentración y referencia térmica son conceptos distintos.','No extiendas la aproximación de agua a 25 °C a todo sistema.'),
 C('Un modelo enzimático tiene máximo a pH 7. ¿Prueba que toda enzima funciona mejor a pH 7?',['No: depende de enzima, condiciones y modelo','Sí: pH 7 es siempre óptimo biológico','Sí: neutro significa máxima velocidad de toda reacción'],0,'Neutralidad del agua y óptimo de una enzima son propiedades diferentes.','Un máximo de un modelo no valida una regla universal.','case')])

B('chem-buffer',3,'chemistry-acid-base',['buffers'],
'Explicar capacidad amortiguadora finita y calcular pH aproximado de un par HA/A⁻.',
'¿Dos soluciones con el mismo pH deben resistir igual una perturbación?',
'Un amortiguador o buffer contiene cantidades apreciables de un ácido débil y su base conjugada. A⁻ puede consumir parte de un ácido añadido y HA parte de una base añadida. Resiste pequeños cambios de pH, no los elimina ni tiene capacidad infinita. Henderson–Hasselbalch aproxima pH≈pKₐ+log₁₀([A⁻]/[HA]) cuando actividades se aproximan por concentraciones y ambas especies están presentes en cantidades adecuadas. pKₐ=−log₁₀(Kₐ).\n\nSi se añade ácido o base fuerte, primero hay que contabilizar la neutralización y después estimar el nuevo cociente: no se sustituyen sin más las cantidades anteriores. La capacidad depende de cantidades y concentración total; igual cociente puede dar pH parecido pero distinta resistencia. Diluir idealmente ambas especies mantiene aproximadamente el cociente, pero reduce capacidad por volumen y a dilución extrema fallan las aproximaciones. No se incluyen protocolos de preparación.',
['Par ficticio con pKₐ=6,0; [A⁻]=[HA]=0,05 mol/L.','El cociente es 1 y log₁₀(1)=0.','pH≈6,0: mismo pH no indica cuánta reserva amortiguadora existe.'],
['Modelo en cantidades: HA=8 mmol y A⁻=8 mmol.','Una perturbación de 2 mmol H⁺ consume A⁻: quedan 6 mmol A⁻ y 10 mmol HA.','Luego se estima pH con razón 6/10 y pKₐ; la capacidad no es infinita.'],
'Comparar pH y composición en un ensayo simulado ayuda a interpretar estabilidad del medio sin afirmar que el amortiguador mantiene cualquier sistema biológico.',
'Buffer requiere un par conjugado y tiene capacidad finita. Usa cantidades después de neutralizar y no confundas pH con reserva amortiguadora.',[
 C('¿Qué combinación puede formar un amortiguador ácido-base?',['Ácido débil y su base conjugada en cantidades apreciables','Solo un ácido fuerte a cualquier concentración','Dos sustancias cualesquiera de igual color'],0,'El par conjugado permite consumir cantidades pequeñas de ácido o base.','Se necesita una pareja que intercambie protones.'),
 N('Modelo de buffer: pKₐ=6,2 y [A⁻]=[HA]. ¿pH aproximado?',6.2,'','Con igual concentración de ambas especies, el cociente vale 1 y log₁₀(1)=0: pH≈6,2.','El logaritmo de 1 es cero.'),
 N('Modelo: pKₐ=5,0 y [A⁻]/[HA]=10. ¿pH aproximado?',6,'','Hay diez veces más base conjugada que ácido; log₁₀(10)=1 y pH≈5,0+1=6,0.','Un cociente diez aporta una unidad.'),
 N('Modelo inicial: 12 mmol HA y 8 mmol A⁻. Se consumen 3 mmol A⁻ al neutralizar ácido añadido. ¿Cuánto A⁻ queda?',5,'mmol','8−3=5 mmol A⁻; HA pasa a 15 mmol.','Contabiliza primero reacción del ácido con A⁻.',{'mmol':1,'mol':1000}),
 M('Dos buffers tienen igual cociente HA/A⁻ y pKₐ, pero concentraciones totales distintas. ¿Qué es válido bajo aproximación ideal?',['Pueden tener pH aproximado igual','Deben tener idéntica capacidad por volumen','El más concentrado puede resistir más ácido por volumen','Ninguno tiene capacidad infinita'],[0,2,3],'La razón orienta pH; la reserva total influye en capacidad.','Separa cociente y cantidad total.'),
 C('Se añade más ácido que la reserva de base conjugada. ¿Qué conclusión es razonable?',['Puede superarse la capacidad y cambiar mucho el pH','El pH debe ser exactamente constante','Se regenera infinitamente la base sin aporte'],0,'La neutralización consume la base disponible; la aproximación de buffer puede dejar de ser adecuada.','No extrapoles pequeñas perturbaciones a cualquier cantidad.','case')])

B('chem-thermo',3,'chemistry-energy-rate',['free-energy'],
'Calcular ΔG=ΔH−TΔS con unidades coherentes y separar favorabilidad de velocidad.',
'¿Una reacción energéticamente favorable debe ocurrir rápidamente?',
'La termodinámica compara estados y balances; la cinética estudia velocidades. A temperatura y presión constantes, ΔG<0 indica dirección favorable para un proceso bajo las condiciones consideradas; ΔG=0 corresponde al equilibrio y ΔG>0 desfavorece ese avance sin acoplamiento. La relación ΔG=ΔH−TΔS usa T en K y unidades de energía coherentes. ΔH negativo describe liberación de calor a presión constante bajo condiciones apropiadas, pero no determina solo el signo de ΔG.\n\nΔG depende de composición; ΔG° se refiere al estado estándar y no puede sustituirse indiscriminadamente por ΔG celular. Para sumar balances de procesos que se acoplan se mantienen condiciones y proporciones consistentes; una suma favorable no demuestra el mecanismo de acoplamiento. Romper un enlace aislado requiere energía: un balance neto favorable procede del conjunto de cambios e interacciones, no de romper por sí solo un enlace.',
['Modelo a 300 K: ΔH=+12 kJ/mol y ΔS=+60 J/(mol·K).','Convierte ΔS a 0,060 kJ/(mol·K); TΔS=18 kJ/mol.','ΔG=12−18=−6 kJ/mol: favorable en el modelo, sin información sobre rapidez.'],
['Modelo a 300 K: ΔH=−10 kJ/mol y ΔS=−50 J/(mol·K)=−0,050 kJ/(mol·K).','TΔS=−15 kJ/mol.','ΔG=−10−(−15)=+5 kJ/mol; exotérmico no implica siempre favorable.'],
'Interpretar metabolismo exige distinguir energía disponible, composición, catálisis y acoplamiento; una curva rápida y un balance favorable responden preguntas distintas.',
'Convierte J a kJ y usa kelvin. El signo de ΔG describe favorabilidad condicionada, sin garantizar rapidez ni un mecanismo de acoplamiento.',[
 C('Una reacción tiene ΔG<0 bajo condiciones dadas. ¿Qué permite concluir?',['Su avance es termodinámicamente favorable bajo esas condiciones','Ocurre de inmediato por definición','No necesita superar barrera de activación'],0,'El signo de ΔG no determina la velocidad.','Balance de estados y barrera de activación son distintos.'),
 N('Modelo a 300 K: ΔH=20 kJ/mol y ΔS=100 J/(mol·K). ¿ΔG?',-10,'kJ/mol','ΔS=0,100 kJ/(mol·K); ΔG=20−300×0,100=−10 kJ/mol.','Convierte entropía a kJ antes de multiplicar.',{'kJ/mol':1,'J/mol':0.001}),
 N('Modelo a 400 K: ΔH=−12 kJ/mol y ΔS=−20 J/(mol·K). ¿ΔG?',-4,'kJ/mol','ΔS=−0,020 kJ/(mol·K); −12−400×(−0,020)=−4 kJ/mol.','Conserva el signo de ΔS al restar.',{'kJ/mol':1,'J/mol':0.001}),
 M('Selecciona afirmaciones válidas sobre energía libre y enlaces.',['ΔG puede depender de composición','ΔG° siempre coincide con ΔG de una célula','Romper un enlace aislado requiere energía','La catálisis no cambia el balance ΔG entre los mismos estados'],[0,2,3],'Estado estándar, composición y barreras cinéticas no son intercambiables.','Compara los mismos estados y condiciones.'),
 N('Dos procesos formalmente sumados bajo condiciones y proporciones consistentes tienen ΔG −18 y +7 kJ/mol. ¿Suma?',-11,'kJ/mol','−18+7=−11 kJ/mol; no demuestra acoplamiento físico.','Suma algebraica conservando signos.',{'kJ/mol':1,'J/mol':0.001}),
 C('Un balance acoplado sobre papel da ΔG total negativo. ¿Qué falta para afirmar que un proceso impulsa al otro en una célula?',['Mecanismo de acoplamiento y evidencia apropiada','Solo poner las ecuaciones juntas','Suponer que cualquier mezcla los conecta'],0,'La suma es condición termodinámica; la conexión funcional debe establecerse.','Una operación algebraica no crea un mecanismo.','case')])

B('chem-kinetics',3,'chemistry-energy-rate',['rate-law','reaction-rates','catalysis'],
'Calcular una velocidad media y usar una ley de primer orden dada sin inferir órdenes de la estequiometría.',
'¿Los coeficientes de una ecuación global determinan siempre los exponentes de su ley de velocidad?',
'La velocidad expresa cambio por tiempo. Para A → P con coeficientes 1:1, velocidad media de formación de P es Δ[P]/Δt y la de consumo de A es −Δ[A]/Δt. Si otros coeficientes intervienen, hay que normalizar antes de comparar velocidades de reacción. Temperatura, concentración y catálisis pueden afectar rapidez. Las leyes de velocidad se establecen experimentalmente: los coeficientes de una reacción global no determinan en general sus órdenes.\n\nEn el modelo dado v=k[A], de primer orden en A y temperatura fija, duplicar [A] duplica v y k tiene unidad s⁻¹ si v está en mol/(L·s). Un catalizador proporciona una vía de menor barrera efectiva sin cambiar K a la misma temperatura. Una velocidad media no es necesariamente la inicial ni constante; datos simulados de una sola curva no identifican un mecanismo único.',
['Datos ficticios para A → P: [P] pasa de 0,02 a 0,08 mol/L en 30 s.','Δ[P]=0,06 mol/L.','Velocidad media=0,06/30=0,002 mol/(L·s).'],
['Modelo dado v=k[A]: k=0,04 s⁻¹ y [A]=0,50 mol/L.','v=0,04×0,50=0,020 mol/(L·s).','Si [A] se duplica a la misma temperatura, v=0,040 mol/(L·s).'],
'Comparar velocidades de ensayos ficticios requiere controlar condiciones y distinguir correlación con concentración de una ley cinética ya validada.',
'Define qué cambia y en qué intervalo. Usa solo la ley de velocidad dada; catálisis, orden y equilibrio no son sinónimos.',[
 N('A → P 1:1: [P] sube de 0,10 a 0,16 mol/L en 20 s. ¿Velocidad media de formación?',0.003,'mol/(L·s)','(0,16−0,10)/20=0,003 mol/(L·s).','Divide incremento, no valor final, por tiempo.',{'mol/(L·s)':1,'mmol/(L·s)':0.001}),
 C('Para una reacción global, los órdenes de la ley de velocidad…',['Se deben determinar con evidencia cinética','Siempre son sus coeficientes estequiométricos','Son siempre cero'],0,'La ley global no se deduce en general de los coeficientes.','Ecuación balanceada y mecanismo no dicen lo mismo.'),
 N('Modelo dado v=k[A], k=0,02 s⁻¹ y [A]=0,30 mol/L. ¿v?',0.006,'mol/(L·s)','0,02×0,30=0,006 mol/(L·s).','Multiplica k por concentración.',{'mol/(L·s)':1,'mmol/(L·s)':0.001}),
 G('Para A → P, esta curva ficticia muestra [P]. ¿Cómo cambia la velocidad media por intervalo?',['Disminuye entre intervalos sucesivos','Es idéntica siempre','Se hace negativa'],0,[(0,0),(10,0.06),(20,0.09),(30,0.105)],'Tiempo (s)','[P] (mol/L)','Incrementos por 10 s: 0,06; 0,03; 0,015 mol/L. Las pendientes medias disminuyen.','Compara cambios en intervalos de igual duración.'),
 M('Un catalizador a temperatura fija puede…',['Acelerar aproximación al equilibrio','Cambiar K por su mera presencia','Ofrecer una vía de menor barrera efectiva','Modificar las velocidades directa e inversa'],[0,2,3],'La catálisis cambia cinética sin cambiar el equilibrio entre los mismos estados.','No confundir rapidez con composición final.'),
 C('Una curva simulada se ajusta a v=k[A]. ¿Prueba un mecanismo molecular único?',['No: varios mecanismos pueden concordar en un intervalo','Sí: un ajuste identifica siempre cada paso','Sí: no hacen falta otras condiciones'],0,'Compatibilidad con una ley no demuestra unicidad del mecanismo ni validez fuera del intervalo.','Ajuste y explicación causal no son equivalentes.','case')])

B('chem-redox',3,'chemistry-redox-organic',['redox'],
'Identificar oxidación, reducción y agentes, y conservar electrones/carga en semirreacciones.',
'¿El agente oxidante gana electrones o los pierde?',
'Una oxidación aumenta el número de oxidación; una reducción lo disminuye. En semirreacciones con electrones explícitos, oxidarse corresponde a perder electrones y reducirse a ganarlos. El agente oxidante acepta electrones y se reduce; el reductor los cede y se oxida. El número de oxidación es una contabilidad formal, no siempre la carga real localizada en un átomo.\n\nAl sumar semirreacciones, los electrones cedidos y recibidos se igualan y cancelan: se conservan átomos y carga. No toda reacción ácido-base es redox; hay que revisar cambios de números de oxidación. En metabolismo los transportadores reducidos pueden transferir electrones, pero electrones y protones se contabilizan separadamente. Aquí solo hay modelos de ecuaciones, sin montaje de celdas ni manipulación de sustancias.',
['Semirreacción: Fe²⁺ → Fe³⁺ + e⁻.','El número de oxidación aumenta de +2 a +3: oxidación.','Carga derecha +3−1=+2, igual a la izquierda; Fe²⁺ actúa como donador.'],
['Modelo de semirreacciones: X → X²⁺ + 2 e⁻ y Y⁺ + e⁻ → Y.','Multiplica la segunda por dos.','X + 2 Y⁺ → X²⁺ + 2 Y conserva átomos y carga; electrones se cancelan.'],
'Un balance conceptual de transferencia electrónica ayuda a interpretar portadores del metabolismo sin confundir energía disponible con número de electrones transferidos.',
'Oxidar cede electrones y aumenta número de oxidación; el oxidante se reduce. Comprueba átomos, electrones y carga antes de interpretar el balance.',[
 C('Fe²⁺ → Fe³⁺ + e⁻ describe…',['Oxidación de Fe²⁺','Reducción de Fe²⁺','Ausencia de transferencia electrónica'],0,'Pierde un electrón y su número de oxidación aumenta.','Sigue el electrón, no el nombre del agente.'),
 C('Un agente oxidante…',['Acepta electrones y se reduce','Cede electrones y se oxida','Debe contener oxígeno siempre'],0,'Oxida a otra especie al aceptar electrones.','El agente hace a otra especie lo contrario de lo que le ocurre.'),
 N('Semirreacción conceptual X → X³⁺ + n e⁻. Para conservar carga, ¿n?',3,'','Cada electrón aporta carga −1: para igualar carga cero de X se exige 0=+3−n, luego n=3.','La carga total debe ser igual en ambos lados.'),
 N('Si una semirreacción cede 2 e⁻ por evento y otra recibe 3 e⁻, ¿mínimo número de electrones que deben cancelarse al combinarlas?',6,'','Mínimo común múltiplo de 2 y 3: 6; tres eventos cedentes y dos receptores.','Busca un múltiplo común, no suma de electrones.'),
 M('¿Qué debes comprobar al sumar semirreacciones?',['Átomos conservados','Carga total conservada','Electrones cancelados','Igual masa y carga de cada especie individual'],[0,1,2],'Se conservan totales, aunque las especies cambien.','Conservación global no significa conservar identidades.'),
 C('H⁺ + OH⁻ → H₂O: H sigue en +1 y O en −2. ¿Es redox por esa ecuación?',['No: no cambian esos números de oxidación','Sí: toda reacción con H⁺ es redox','Sí: formar agua siempre transfiere electrones formalmente'],0,'Es neutralización ácido-base; no hay cambio de números de oxidación.','Transferencia de protones no equivale a cambio redox.','case')])

B('chem-organic',3,'chemistry-redox-organic',['organic','carbonyl'],
'Reconocer grupos funcionales e isomería constitucional y distinguir fórmula molecular de estructura.',
'¿Dos compuestos con la misma fórmula molecular deben tener las mismas propiedades?',
'La química orgánica estudia muchas sustancias basadas en carbono; no todo compuesto con carbono se clasifica como orgánico. En representaciones simples de moléculas neutras habituales, el carbono completa cuatro enlaces en total, contando dobles como dos. Los grupos funcionales aportan patrones de reactividad: hidroxilo de un alcohol (C−OH), carbonilo (C=O), carboxilo (−COOH), amino y éster son ejemplos. Un carboxilo no es simplemente un alcohol porque contiene OH: importa el entorno del grupo.\n\nLa fórmula molecular cuenta átomos; la estructura muestra cómo se conectan. Isómeros constitucionales comparten fórmula y difieren en conectividad, de modo que pueden tener propiedades distintas. La estereoquímica añade orientación espacial, sin desarrollarse por completo aquí. Identificar un grupo no predice todas las propiedades, toxicidad o comportamiento de una molécula: también importan estructura completa y condiciones.',
['CH₃−CH₂−OH y CH₃−O−CH₃ tienen fórmula C₂H₆O.','La primera presenta un grupo alcohol; la segunda un éter.','Son isómeros constitucionales: igual conteo, distinta conectividad.'],
['CH₃−COOH contiene C=O y OH en el mismo carbono.','El conjunto −COOH se reconoce como carboxilo.','No se clasifica ese OH como un alcohol independiente del carbonilo.'],
'Reconocer grupos de aminoácidos y metabolitos permite anticipar preguntas sobre interacciones y protonación; no reemplaza medidas ni análisis de la estructura completa.',
'Cuenta enlaces y observa conectividad. Fórmula molecular no fija estructura; un grupo funcional se interpreta con su entorno.',[
 C('¿Qué estructura presenta un grupo alcohol?',['CH₃−CH₂−OH','CH₃−O−CH₃','CH₃−COOH como único grupo funcional'],0,'El OH unido al carbono saturado del primer compuesto corresponde a alcohol; el tercero tiene carboxilo.','Mira a qué entorno está unido el OH.'),
 C('Dos moléculas tienen fórmula molecular igual y conectividad distinta. Son…',['Isómeros constitucionales','La misma estructura por definición','Isótopos del mismo átomo'],0,'La isomería constitucional cambia conectividad sin cambiar fórmula.','Conteo de átomos y conexiones aportan datos distintos.'),
 M('Selecciona asociaciones correctas.',['C=O: carbonilo','−COOH: carboxilo','Todo compuesto con carbono es orgánico','Un éster contiene el patrón −C(=O)−O−C'],[0,1,3],'El patrón de enlaces define el grupo; existen compuestos carbonados clasificados como inorgánicos.','No clasifiques solo por la presencia de un elemento.'),
 N('En CH₂=CH₂, ¿cuántos enlaces en total completa cada C contando el doble como dos?',4,'','Dos enlaces C−H más dos del C=C suman cuatro por carbono.','Un doble cuenta dos, no uno.'),
 C('Para distinguir isómeros constitucionales, ¿qué información añade una estructura a la fórmula molecular?',['Qué átomos están conectados','Solo cuántos C hay','Solo la masa total'],0,'Dos isómeros pueden compartir masa y conteo pero cambiar conexiones.','Busca información que no sea solo cantidad.'),
 C('Dos moléculas comparten un grupo hidroxilo. ¿Deben tener igual solubilidad y efecto biológico?',['No: importan estructura completa y condiciones','Sí: un solo grupo determina toda propiedad','Sí: las condiciones nunca importan'],0,'Un grupo funcional contribuye, pero no fija por sí solo el comportamiento total.','No extiendas un patrón local a todas las propiedades.','case')])

B('chem-proteins',4,'chemistry-biomolecules',['proteins'],
'Relacionar grupos de aminoácidos, enlace peptídico y niveles de estructura con efectos condicionados del pH.',
'¿Desnaturalizar una proteína equivale necesariamente a cortar sus enlaces peptídicos?',
'Los aminoácidos habituales de proteínas tienen grupos amino y carboxilo y una cadena lateral R unida al carbono α. En agua, su estado de protonación depende del pH y de sus grupos ionizables; no se representa una carga fija universal. El enlace peptídico une el carboxilo de un residuo con el amino de otro y es un enlace amida. La secuencia define estructura primaria; hélices/láminas son elementos secundarios, el plegamiento tridimensional de una cadena es terciario y asociaciones de cadenas forman estructura cuaternaria cuando existe.\n\nInteracciones entre grupos y entorno influyen en plegamiento y función. Desnaturalizar altera organización sin implicar necesariamente hidrólisis de la cadena. No toda proteína tiene varias subunidades y una secuencia no permite deducir fácilmente toda función. Los conteos siguientes suponen una cadena lineal sin ramificaciones ni ciclos; cambios de pH pueden alterar carga, pero su efecto funcional requiere evidencia.',
['Modelo de cadena lineal con 4 aminoácidos.','Para conectar vecinos hay 4−1=3 enlaces peptídicos.','La longitud no informa por sí sola del plegamiento ni de la actividad.'],
['Modelo de grupo carboxilo: forma protonada COOH y desprotonada COO⁻.','Al perder H⁺, la carga formal cambia en −1.','La carga neta de todo un aminoácido requiere considerar también amino y cadena lateral.'],
'Interpretar un ensayo de actividad de proteína requiere separar cantidad, integridad de cadena, plegamiento y condiciones químicas; perder actividad no identifica automáticamente el mecanismo.',
'Une aminoácidos mediante amidas y separa secuencia, plegamiento y subunidades. pH cambia protonación; desnaturalización no implica necesariamente cortar la cadena.',[
 C('El enlace peptídico es…',['Una amida entre carboxilo y amino de residuos','Siempre un enlace entre cadenas laterales R','La unión que convierte aminoácidos en ADN'],0,'La cadena proteica se enlaza por grupos del esqueleto de aminoácidos.','Distingue esqueleto de cadena lateral.'),
 C('La estructura primaria describe…',['Secuencia de aminoácidos','Solo asociación entre cuatro cadenas','Cualquier cambio de temperatura'],0,'Primaria se refiere al orden de residuos, no al plegamiento.','Separa orden lineal de organización tridimensional.'),
 N('Modelo de cadena lineal no cíclica con 9 aminoácidos. ¿Cuántos enlaces peptídicos conectan vecinos?',8,'','n−1=9−1=8 enlaces para conectar nueve residuos en una sola cadena.','Una cadena abierta de n elementos tiene n−1 uniones.'),
 M('¿Qué afirmaciones sobre estructura de proteínas y pH son válidas?',['La protonación depende del pH','Toda proteína tiene estructura cuaternaria','La desnaturalización puede dejar intacta la secuencia','Cadenas laterales influyen en interacciones'],[0,2,3],'Varias subunidades no son universales y perder plegamiento no exige hidrolizar la cadena.','No confundas plegamiento con secuencia.'),
 C('Un grupo COOH pierde H⁺ y queda COO⁻. ¿Cómo cambia su carga formal?',['Disminuye en una unidad','Aumenta en una unidad','Se mantiene necesariamente cero'],0,'Perder el protón positivo deja la base conjugada con una carga más negativa.','Sigue el protón y conserva carga.'),
 C('Una proteína pierde actividad tras cambiar pH. ¿Qué conclusión está respaldada sin más datos?',['Hay asociación bajo esas condiciones; falta distinguir protonación, plegamiento u otras causas','Se cortaron necesariamente todos los enlaces peptídicos','Se demostró una mutación del ADN'],0,'Actividad por sí sola no determina el mecanismo ni una alteración genética.','Una misma señal puede tener varias causas.','case')])

B('chem-lipids',4,'chemistry-biomolecules',['carbohydrates','lipids'],
'Distinguir enlaces glucosídicos y ésteres y relacionar estructura con reserva y membranas.',
'¿Todos los lípidos son polímeros con el mismo tipo de monómero?',
'Los carbohidratos incluyen monosacáridos y sus derivados/uniones; enlaces glucosídicos conectan azúcares en muchos oligo y polisacáridos. La orientación y el tipo de enlace influyen en estructura y reconocimiento enzimático: compartir monómeros no garantiza igual función ni degradación por la misma enzima. Los lípidos son una familia diversa definida por propiedades químicas, no un polímero universal.\n\nUn triacilglicérido reúne glicerol y tres ácidos grasos mediante enlaces éster. Muchos fosfolípidos de membrana son anfipáticos, con región polar y regiones hidrofóbicas; las bicapas emergen de interacciones con agua, no de enlazar covalentemente todos los lípidos vecinos. Los modelos de cadenas saturadas/insaturadas no agotan la diversidad: posición y geometría de dobles enlaces y composición total influyen en propiedades. Esta lección no da recomendaciones nutricionales.',
['Cadena lineal ficticia de cinco azúcares unidos sin ramificaciones ni ciclos.','Necesita cinco−uno=cuatro enlaces entre vecinos.','El conteo no especifica orientación del enlace ni qué enzima podrá hidrolizarlo.'],
['Un modelo de dos triacilglicéridos contiene tres ácidos grasos por molécula.','Total de grupos acilo=2×3=6.','No implica seis fosfatos ni que todo lípido tenga esta estructura.'],
'Relacionar reserva y membranas requiere identificar la familia molecular: no se usa el mismo modelo para un triacilglicérido y un fosfolípido.',
'Azúcares se conectan por enlaces glucosídicos; muchos lípidos contienen ésteres pero no forman una familia de polímeros iguales. Estructura y entorno condicionan función.',[
 C('El enlace típico que conecta azúcares en un polisacárido es…',['Glucosídico','Peptídico','Siempre un puente disulfuro'],0,'Los enlaces glucosídicos unen residuos de azúcares.','No traslades el enlace de proteínas a carbohidratos.'),
 C('Un triacilglicérido típico contiene…',['Glicerol y tres ácidos grasos enlazados como ésteres','Tres aminoácidos y un fosfato por definición','Un polímero de nucleótidos'],0,'Sus tres uniones al glicerol son ésteres.','Tri indica tres grupos acilo, no tres proteínas.'),
 N('Cadena lineal no ramificada ni cíclica de 7 azúcares. ¿Cuántas uniones conectan vecinos?',6,'','Una cadena abierta de siete azúcares tiene seis espacios entre vecinos: 7−1=6 uniones.','Cuenta espacios entre vecinos en una cadena abierta.'),
 M('Sobre modelos de membrana, selecciona afirmaciones válidas.',['Muchos fosfolípidos son anfipáticos','Todos los lípidos son polímeros idénticos','Interacciones con agua influyen en organización','No hacen falta enlaces covalentes entre todos los vecinos para formar bicapa'],[0,2,3],'La anfipaticidad permite autoorganización; la diversidad lipídica no es un polímero universal.','Distingue unión interna de molécula de interacción entre moléculas.'),
 C('Dos polisacáridos comparten azúcares, pero sus enlaces tienen orientación distinta. ¿Qué es razonable?',['Pueden diferir en reconocimiento por enzimas','Deben degradarse con cualquier enzima idénticamente','Deben ser la misma molécula'],0,'La geometría del enlace puede cambiar estructura y reconocimiento.','La conectividad y orientación aportan información.','prediction'),
 C('Un dato simulado muestra cambio en fluidez al variar composición lipídica. ¿Qué conclusión evita exceder la evidencia?',['El efecto depende de composición y condiciones; no prueba una regla para cualquier membrana','Todos los lípidos tienen igual efecto','La membrana perdió necesariamente todos sus lípidos'],0,'La comparación es contextual y necesita controlar condiciones; una variable no fija la causa completa.','No generalices una composición a todas las membranas.','case')])

B('chem-enzyme',4,'chemistry-biochemical-models',['michaelis-menten','michaelis-mechanism','enzymes'],
'Usar un modelo Michaelis–Menten sencillo y distinguir concentración de sustrato, Km y Vmax.',
'¿Duplicar sustrato duplica siempre la velocidad de una enzima?',
'La cinética enzimática estudia velocidad bajo condiciones definidas. Un modelo Michaelis–Menten sencillo escribe v₀=Vmax[S]/(Km+[S]): [S] y Km usan la misma unidad de concentración y v₀ y Vmax la misma unidad de velocidad. Para Km>0 y [S]≥0, predice v₀=0 en cero sustrato, v₀=Vmax/2 cuando [S]=Km y aproximación a Vmax al aumentar [S]; no un crecimiento lineal ilimitado.\n\nAquí suponemos una enzima con comportamiento compatible con ese modelo, concentración de enzima, pH y temperatura fijos, velocidades iniciales, producto inicialmente despreciable y aproximación de estado estacionario del complejo con sustrato en exceso respecto de enzima. No incluye cooperatividad, inhibición ni agotamiento considerable. Km es la concentración que da media Vmax en este modelo, no una medida universal de afinidad ni del óptimo de pH. Los parámetros y curvas son ficticios, no ajustes de datos reales.',
['Modelo ficticio: Vmax=12 µmol/min, Km=3 mmol/L, [S]=3 mmol/L.','v₀=12×3/(3+3).','v₀=6 µmol/min; al igualar Km se alcanza la mitad de Vmax.'],
['Mismo modelo con [S]=9 mmol/L.','v₀=12×9/(3+9)=9 µmol/min.','Triplicar [S] desde Km no triplica v₀: aparece saturación.'],
'Comparar una curva calculada con lecturas simuladas ayuda a proponer preguntas sobre saturación. El modelo de pH del BioLab es distinto: no representa por sí solo Michaelis–Menten.',
'Explicita condiciones de velocidad inicial y unidades. Km da media Vmax en este modelo; saturación y óptimo de pH describen preguntas distintas.',[
 N('Modelo: Vmax=20 µmol/min, Km=4 mmol/L y [S]=4 mmol/L. ¿v₀?',10,'µmol/min','20×4/(4+4)=10 µmol/min.','Si [S]=Km, la velocidad es media Vmax.',{'µmol/min':1,'umol/min':1,'mmol/min':1000}),
 C('En el modelo Michaelis–Menten sencillo, Km se expresa en…',['Unidad de concentración','Unidad de velocidad','Una escala de pH siempre'],0,'Se suma a [S], por lo que debe tener la misma dimensión.','Solo puedes sumar magnitudes compatibles.'),
 M('¿Qué supuestos se usan aquí?',['Velocidades iniciales','pH, temperatura y enzima fijos','Cooperatividad ilimitada incluida automáticamente','Comportamiento compatible con Michaelis–Menten sencillo'],[0,1,3],'El modelo no describe automáticamente toda enzima ni cualquier intervalo temporal.','Identifica lo que se mantiene fijo y lo que se omite.'),
 N('Modelo: Vmax=18 µmol/min, Km=2 mmol/L y [S]=0. ¿v₀?',0,'µmol/min','18×0/(2+0)=0 µmol/min para este modelo.','Evalúa numerador y denominador con [S]=0.',{'µmol/min':1,'umol/min':1,'mmol/min':1000}),
 G('Modelo ficticio con Vmax=12 µmol/min y Km=2 mmol/L. ¿Qué indica la curva?',['Se aproxima a saturación, sin crecimiento lineal ilimitado','Cada duplicación de [S] siempre duplica v₀','Km tiene unidad µmol/min'],0,[(0,0),(2,6),(6,9),(10,10)],'[S] (mmol/L)','v₀ (µmol/min)','La función 12[S]/(2+[S]) se acerca a 12, con incrementos cada vez menores.','Mira pendiente y dimensión de cada eje.'),
 C('Un conjunto simulado muestra cooperatividad. ¿Debes tratar este modelo sencillo como explicación universal?',['No: revisar supuestos y considerar otro modelo con evidencia','Sí: toda enzima obedece exactamente la misma hipérbola','Sí: Km equivale siempre a afinidad y pH óptimo'],0,'Cooperatividad no está incluida aquí; un modelo debe evaluarse con condiciones y datos apropiados.','Una ecuación útil no es universal.','case')])

B('chem-metabolism',4,'chemistry-biochemical-models',['metabolism','free-energy','redox'],
'Conectar balances de energía, transferencia electrónica y acoplamiento sin confundirlos con velocidad.',
'¿Una enzima vuelve favorable cualquier reacción por el mero hecho de catalizarla?',
'El metabolismo conecta rutas de degradación (catabolismo) y síntesis (anabolismo), con transferencia de materia y energía. Portadores como ATP y NADH participan en procesos distintos: ATP puede acoplar transferencias de energía libre y NADH participa en transferencia electrónica. No son reservas infinitas ni unidades intercambiables. La bioenergética analiza balances bajo condiciones especificadas; un ΔG° no describe por sí solo condiciones celulares.\n\nPara procesos realmente acoplados, se suman ΔG según sus proporciones y condiciones. El total favorable permite un avance termodinámico, pero no prueba mecanismo ni velocidad. La hidrólisis de ATP puede tener balance neto favorable por los cambios completos de reactivos, productos y entorno, no porque romper aisladamente un enlace libere energía. Una enzima modifica barreras y velocidades sin cambiar el balance entre los mismos estados. Todos los valores usados aquí son modelos ficticios, sin rendimientos universales de ATP por célula.',
['Modelo con pasos acoplados: uno cuesta +11 kJ/mol y otro aporta ΔG=−25 kJ/mol bajo las mismas condiciones.','Suma: +11−25=−14 kJ/mol para esas proporciones.','Hay favorabilidad del balance, pero falta establecer acoplamiento real y rapidez.'],
['Contabilidad ficticia: un proceso forma 5 unidades de ATP y otro consume 3 en el mismo intervalo.','Cambio neto=5−3=+2 unidades de ATP.','No demuestra rendimiento universal ni creación de energía: deben considerarse los demás balances.'],
'Analizar datos simulados de metabolismo exige separar cambios de concentración, flujos y energía; una cantidad de ATP aislada no determina toda la actividad de una célula.',
'Conecta materia, energía y electrones con balances separados. Catálisis no cambia ΔG y una suma favorable necesita acoplamiento para interpretar su función.',[
 C('Un transportador reducido como NADH participa principalmente en…',['Transferencia electrónica','Crear energía de la nada','Sustituir cualquier molécula de ATP en proporción universal'],0,'Su estado redox permite donar electrones en rutas apropiadas; no es intercambiable con ATP por una regla universal.','Distingue portadores de electrones y acoplamiento con ATP.'),
 C('Una enzima cataliza un proceso entre los mismos estados. ¿Qué cambia directamente?',['La barrera y velocidad, sin cambiar ΔG del balance','ΔG pasa siempre a negativo','La cantidad de materia deja de conservarse'],0,'Catálisis ofrece una vía distinta; no modifica la diferencia de energía libre entre los mismos estados.','Otra vía no cambia los estados inicial y final.'),
 N('Modelo de procesos acoplados con proporciones y condiciones consistentes: ΔG=+16 y −28 kJ/mol. ¿Total?',-12,'kJ/mol','16−28=−12 kJ/mol para el balance especificado.','Suma con signos; no conviertas la suma en prueba de mecanismo.',{'kJ/mol':1,'J/mol':0.001}),
 M('¿Qué afirmaciones sobre balances metabólicos son válidas?',['Anabolismo y catabolismo están conectados','El ATP se regenera con aportes de otros procesos','Romper aisladamente un enlace es la fuente neta de energía','ΔG depende de condiciones y composición'],[0,1,3],'La regeneración requiere aportes y el balance completo determina ΔG.','No atribuyas un balance global a un único enlace roto.'),
 N('Modelo contable en un intervalo: se forman 9 unidades de ATP y se consumen 6. ¿Cambio neto?',3,'','9−6=+3 unidades del modelo, sin atribuir rendimiento real.','Distingue producción bruta de cambio neto.'),
 C('Una célula simulada mantiene ATP casi constante. ¿Implica que dejó de producirlo y consumirlo?',['No: producción y consumo pueden compensarse','Sí: concentración constante implica flujo cero','Sí: ATP no puede regenerarse'],0,'Un estado estacionario de cantidad puede tener flujos opuestos no nulos.','Cantidad acumulada y flujo por tiempo son distintos.','case')])

B('chem-analytical',4,'chemistry-biochemical-models',['beer-lambert','measurement'],
'Interpretar blanco, calibración lineal simulada y límites de inferencia al estimar concentración.',
'¿Una señal medida determina concentración sin un modelo de calibración y controles?',
'Las técnicas analíticas convierten una propiedad medida en información sobre una muestra, mediante modelos, controles y límites. En espectrofotometría ideal, absorbancia A=εlc es adimensional si ε, longitud de paso l y concentración c tienen unidades compatibles. La proporcionalidad requiere condiciones como radiación suficientemente monocromática, medio adecuado y ausencia de desviaciones relevantes por dispersión, cambios químicos o instrumentales. No es válida automáticamente para cualquier muestra.\n\nUn blanco ayuda a caracterizar señal de solvente y otros componentes; no corrige todo interferente. Una calibración relaciona señales de patrones de cantidad conocida con concentración en un intervalo validado. Aquí la recta ficticia A=0,020+0,50c usa c en mmol/L y una pendiente de 0,50 L/mmol; el intercepto recoge un fondo simulado. Se despeja c=(A−0,020)/0,50, sin restar el blanco dos veces. Fuera del intervalo, una extrapolación no queda validada. No se incluyen instrucciones de manejo de equipos ni datos experimentales reales.',
['Calibración ficticia válida en 0–1,0 mmol/L: A=0,020+0,50c.','Para A=0,320, resta fondo: 0,320−0,020=0,300.','c=0,300/0,50=0,600 mmol/L; resultado condicionado a esa calibración.'],
['Modelo ideal separado A=εlc con l y c fijos.','Si se duplica l y siguen cumpliéndose los supuestos, A se duplica.','La señal sola no distingue cambio de c de cambio de l sin controlar condiciones.'],
'En un análisis conceptual de muestra biológica, registrar blanco, intervalo y posibles interferencias evita presentar una cifra calculada como concentración validada o identificación molecular inequívoca.',
'La medida necesita calibración y controles. Respeta intervalo, intercepto y unidades; señal simulada y concentración estimada no son datos experimentales ni identificación inequívoca.',[
 C('¿Para qué sirve un blanco en el modelo de medida?',['Evaluar contribución de fondo de solvente y componentes elegidos','Eliminar todo error e interferencia automáticamente','Demostrar la identidad de cada molécula'],0,'El blanco caracteriza un fondo específico; no resuelve todos los sesgos.','Define qué fuentes de señal incluye el control.'),
 N('Recta ficticia A=0,020+0,50c, c en mmol/L, válida de 0 a 1,0 mmol/L. Si A=0,220, ¿c?',0.4,'mmol/L','c=(0,220−0,020)/0,50=0,400 mmol/L.','Resta intercepto una sola vez y divide por pendiente.',{'mmol/L':1,'mol/L':1000,'mM':1}),
 G('Patrones simulados con A=0,020+0,50c. ¿Qué representa A=0,020 en c=0?',['Fondo/intercepto del modelo','Concentración negativa demostrada','Ausencia de cualquier señal instrumental'],0,[(0,0.02),(0.2,0.12),(0.6,0.32),(1,0.52)],'c (mmol/L)','Absorbancia (adimensional)','La recta tiene intercepto no nulo; usar A/pendiente sin restarlo sesga la estimación.','Mira dónde corta el eje de señal.'),
 M('¿Qué debe documentar una estimación por calibración?',['Unidades y modelo','Intervalo evaluado','Blanco/controles y posibles interferencias','Solo el número calculado'],[0,1,2],'Sin modelo y límites no se interpreta de forma válida una concentración estimada.','Una cifra aislada no explica su procedencia.'),
 N('Modelo ideal A=εlc. A inicial=0,30 y se duplica l con c y ε fijos, manteniendo supuestos. ¿A final?',0.6,'','A es proporcional a l: 2×0,30=0,60, adimensional.','Duplica solo el factor que cambió.'),
 C('Una muestra da señal fuera del intervalo de la calibración simulada. ¿Qué procede conceptualmente?',['Indicar que la estimación por extrapolación no está validada y revisar el modelo/diseño','Informar como concentración exacta validada','Suponer que la misma recta vale sin límite'],0,'Un ajuste dentro de un rango no establece linealidad ni exactitud fuera de él.','Intervalo de validación y dominio algebraico no son lo mismo.','case')])

# Verified official references, accessed 2026-10-23. Only links/metadata and original text.
REFS={
 'stoich':('Chemistry 2e · 4.3 Reaction Stoichiometry','chemistry-2e','4-3-reaction-stoichiometry'),
 'balance':('Chemistry 2e · 4.1 Writing and Balancing Chemical Equations','chemistry-2e','4-1-writing-and-balancing-chemical-equations'),
 'molarity':('Chemistry 2e · 3.3 Molarity','chemistry-2e','3-3-molarity'),
 'gas':('Chemistry 2e · 9.2 Ideal Gas Law','chemistry-2e','9-2-relating-pressure-volume-amount-and-temperature-the-ideal-gas-law'),
 'equilibrium':('Chemistry 2e · 13.1 Chemical Equilibria','chemistry-2e','13-1-chemical-equilibria'),
 'equilibrium-constant':('Chemistry 2e · 13.2 Equilibrium Constants','chemistry-2e','13-2-equilibrium-constants'),
 'acid-base':('Chemistry 2e · 14.1 Brønsted–Lowry Acids and Bases','chemistry-2e','14-1-bronsted-lowry-acids-and-bases'),
 'ph':('Chemistry 2e · 14.2 pH and pOH','chemistry-2e','14-2-ph-and-poh'),
 'buffers':('Chemistry 2e · 14.6 Buffers','chemistry-2e','14-6-buffers'),
 'free-energy':('Chemistry 2e · 16.4 Free Energy','chemistry-2e','16-4-free-energy'),
 'rate-law':('Chemistry 2e · 12.3 Rate Laws','chemistry-2e','12-3-rate-laws'),
 'reaction-rates':('Chemistry 2e · 12.1 Chemical Reaction Rates','chemistry-2e','12-1-chemical-reaction-rates'),
 'catalysis':('Chemistry 2e · 12.7 Catalysis','chemistry-2e','12-7-catalysis'),
 'redox':('Chemistry 2e · 17.1 Review of Redox Chemistry','chemistry-2e','17-1-review-of-redox-chemistry'),
 'organic':('Chemistry 2e · 20.1 Hydrocarbons','chemistry-2e','20-1-hydrocarbons'),
 'carbonyl':('Chemistry 2e · 20.3 Aldehydes, Ketones, Carboxylic Acids, and Esters','chemistry-2e','20-3-aldehydes-ketones-carboxylic-acids-and-esters'),
 'proteins':('Biology 2e · 3.4 Proteins','biology-2e','3-4-proteins'),
 'carbohydrates':('Biology 2e · 3.2 Carbohydrates','biology-2e','3-2-carbohydrates'),
 'lipids':('Biology 2e · 3.3 Lipids','biology-2e','3-3-lipids'),
 'enzymes':('Biology 2e · 6.5 Enzymes','biology-2e','6-5-enzymes'),
 'metabolism':('Biology 2e · 6.1 Energy and Metabolism','biology-2e','6-1-energy-and-metabolism'),
 'measurement':('Chemistry 2e · 1.5 Measurement Uncertainty, Accuracy, and Precision','chemistry-2e','1-5-measurement-uncertainty-accuracy-and-precision')}
UNITS=[
 ('chemistry-stoichiometry','04 · Estequiometría y concentración',['chem-reactions','chem-solutions'],'chemistry-quantitative'),
 ('chemistry-dilution-gases','05 · Dilución, gases y equilibrio',['chem-dilution','chem-gases','chem-equilibrium'],'chemistry-quantitative'),
 ('chemistry-acid-base','06 · Ácidos, bases y amortiguación',['chem-ph','chem-buffer'],'chemistry-advanced'),
 ('chemistry-energy-rate','07 · Energía y velocidad',['chem-thermo','chem-kinetics'],'chemistry-advanced'),
 ('chemistry-redox-organic','08 · Transferencia electrónica y estructura orgánica',['chem-redox','chem-organic'],'chemistry-advanced'),
 ('chemistry-biomolecules','09 · Química de biomoléculas',['chem-proteins','chem-lipids'],'chemistry-biochemistry'),
 ('chemistry-biochemical-models','10 · Modelos y análisis bioquímico',['chem-enzyme','chem-metabolism','chem-analytical'],'chemistry-biochemistry')]


def extend_chemistry(concepts,lessons,units,courses,sources):
    by_id={c['id']:c for c in concepts}
    for key,(title,book,slug) in REFS.items():
        sources.append(dict(id='chem-expand-'+key,title='OpenStax · '+title,
            url=f'https://openstax.org/books/{book}/pages/{slug}',
            note='Consulta 2026-10-23. Referencia conceptual, CC BY-NC-SA 4.0. Texto, datos ficticios y ejercicios propios de BioNexo, sin extractos ni figuras. Revisión humana pendiente.'))
    for key,title,term in [('michaelis-menten','Michaelis–Menten equation','11546'),('beer-lambert','Beer–Lambert law','B00626'),('michaelis-mechanism','Michaelis–Menten mechanism','M03893')]:
        sources.append(dict(id='chem-expand-'+key,title='IUPAC Gold Book · '+title,
            url='https://goldbook.iupac.org/terms/view/'+term,
            note='Consulta 2026-10-23. Referencia terminológica oficial; no se reproducen definiciones, figuras ni datos del recurso. Explicación y valores ficticios propios; la referencia no valida la simulación.'))
    for block_index,b in enumerate(BLOCKS):
        c=by_id[b['cid']]
        assert c['status']=='planned','Existing content must not be silently replaced'
        refs=['chem-expand-'+key for key in b['refs']]
        qs=deepcopy(b['qs'])
        for i,q in enumerate(qs):
            # Stable positional balance for new v1 IDs; no random answer-at-first bias.
            if 'options' in q:
                shift=(block_index+i)%len(q['options'])
                ordered=q['options'][shift:]+q['options'][:shift]
                mapping={option['id']:chr(97+j) for j,option in enumerate(ordered)}
                q['options']=[dict(id=chr(97+j),text=option['text']) for j,option in enumerate(ordered)]
                q['correct']=[mapping[x] for x in q['correct']] if isinstance(q['correct'],list) else mapping[q['correct']]
                q['explanation']['distractors']={mapping[k]:v for k,v in q['explanation']['distractors'].items()}
            q.update(id=f'{c["id"]}-v1-q{i+1}',subjectId='chemistry',level=b['level'],
                conceptIds=[c['id']],prerequisites=list(c['prerequisites']),sourceIds=list(refs))
        stages=[dict(id=c['id']+'-understand-v1',title='Comprender y distinguir',objective=b['objective'],
            explanation=b['explanation'].split('\n\n')[0],example=dict(title='Ejemplo desarrollado',steps=b['example']),
            exerciseIds=[q['id'] for q in qs[:3]],sourceIds=list(refs)),
            dict(id=c['id']+'-apply-v1',title='Aplicar y evaluar límites',
            objective='Aplicar relaciones químicas y justificar una conclusión bajo condiciones explícitas.',
            explanation=b['explanation'].split('\n\n')[-1]+' '+b['application'],
            example=dict(title='Segundo ejemplo desarrollado',steps=b['second_example']),
            exerciseIds=[q['id'] for q in qs[3:]],sourceIds=list(refs))]
        c.update(status='implemented',explanation=b['explanation'],example=' → '.join(b['example']),sourceIds=list(refs))
        lessons.append(dict(id=c['id']+'-lesson',unitId=b['unit'],subjectId='chemistry',title=c['title'],minutes=10,
            objective=b['objective'],activation=b['activation'],conceptIds=[c['id']],prerequisites=list(c['prerequisites']),
            explanation=b['explanation'],example=b['example'],application=b['application'],summary=b['summary'],
            exercises=qs,sourceIds=list(refs),reviewStatus='requires-human-review',stages=stages))
    for uid,title,ids,course in UNITS:
        units.append(dict(id=uid,subjectId='chemistry',title=title,lessonIds=[cid+'-lesson' for cid in ids],
            prerequisites=list(by_id[ids[0]]['prerequisites'])))
    for cid,title in [('chemistry-quantitative','Química · Química cuantitativa: introducción'),
                      ('chemistry-advanced','Química · Química avanzada: introducción'),
                      ('chemistry-biochemistry','Química · Bioquímica: introducción')]:
        courses.append(dict(id=cid,subjectId='chemistry',title=title,
            unitIds=[uid for uid,_,_,course in UNITS if course==cid]))
