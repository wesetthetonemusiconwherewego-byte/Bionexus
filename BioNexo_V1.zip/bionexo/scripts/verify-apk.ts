import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { parseApkPolicy, verifyApk } from "./readiness/apk";

let report;
try {
  const [artifact, tools, policy] = process.argv.slice(2);
  if (!artifact || !tools || !policy || process.argv.length !== 5)
    throw Error(
      "Uso: node --import tsx scripts/verify-apk.ts APK BUILD_TOOLS POLITICA_JSON",
    );
  report = verifyApk(
    resolve(artifact),
    resolve(tools),
    parseApkPolicy(JSON.parse(readFileSync(resolve(policy), "utf8"))),
    process.cwd(),
  );
} catch (error) {
  report = {
    format: "bionexo-apk-verification",
    version: 1,
    status: "BLOCKED",
    issues: [
      error instanceof Error ? error.message : "No se pudo verificar el APK.",
    ],
  };
}
console.log(JSON.stringify(report, null, 2));
process.exitCode = report.status === "ARTIFACT_VERIFIED" ? 0 : 1;
