import { lstatSync } from "node:fs";
import { join } from "node:path";
import { spawnSync } from "node:child_process";
import { applicationFingerprint, sha256File } from "./native";

export interface ApkPolicy {
  format: "bionexo-apk-policy";
  version: 1;
  sourceCommit: string;
  applicationFingerprint: string;
  sha256: string;
  bytes: number;
  package: string;
  appVersion: string;
  versionCode: number;
  minSdk: number;
  targetSdk: number;
  abis: string[];
  certificateSha256: string;
  permissions: string[];
  requiredEntries: string[];
}
const hash = (x: unknown): x is string =>
  typeof x === "string" && /^[a-f0-9]{64}$/.test(x);
const positive = (x: unknown): x is number =>
  Number.isSafeInteger(x) && Number(x) > 0;
const strings = (x: unknown): x is string[] =>
  Array.isArray(x) &&
  x.length > 0 &&
  x.every((s) => typeof s === "string" && s.trim().length > 0) &&
  new Set(x).size === x.length;

export function parseApkPolicy(value: unknown): ApkPolicy {
  if (!value || typeof value !== "object" || Array.isArray(value))
    throw Error("Política APK inválida.");
  const p = value as Record<string, unknown>;
  if (
    p.format !== "bionexo-apk-policy" ||
    p.version !== 1 ||
    typeof p.sourceCommit !== "string" ||
    !/^[a-f0-9]{40}$/.test(p.sourceCommit) ||
    !hash(p.applicationFingerprint) ||
    !hash(p.sha256) ||
    !hash(p.certificateSha256) ||
    !positive(p.bytes) ||
    p.bytes > 250_000_000 ||
    p.package !== "org.bionexo.learning" ||
    typeof p.appVersion !== "string" ||
    !/^\d+\.\d+\.\d+$/.test(p.appVersion) ||
    !positive(p.versionCode) ||
    !positive(p.minSdk) ||
    !positive(p.targetSdk) ||
    p.targetSdk < p.minSdk ||
    !strings(p.abis) ||
    !strings(p.permissions) ||
    !strings(p.requiredEntries) ||
    !p.requiredEntries.includes("assets/index.android.bundle") ||
    !p.requiredEntries.includes("AndroidManifest.xml")
  )
    throw Error("Política APK incompleta o no soportada.");
  return p as unknown as ApkPolicy;
}

export interface ToolResult {
  status: number | null;
  stdout: string;
  stderr: string;
}
export type ToolRunner = (command: string, args: string[]) => ToolResult;
const run: ToolRunner = (command, args) => {
  const r = spawnSync(command, args, {
    encoding: "utf8",
    timeout: 60_000,
    maxBuffer: 8_000_000,
    windowsHide: true,
    shell: false,
  });
  return {
    status: r.error ? null : r.status,
    stdout: r.stdout || "",
    stderr: r.stderr || "",
  };
};
const forbiddenPermissions = [
  "SYSTEM_ALERT_WINDOW",
  "RECORD_AUDIO",
  "READ_EXTERNAL_STORAGE",
  "WRITE_EXTERNAL_STORAGE",
];

/** Read-only artifact inspection. Does not install, sign, accept a device or publish. */
export function verifyApk(
  artifact: string,
  tools: string,
  policy: ApkPolicy,
  root: string,
  runner: ToolRunner = run,
) {
  const issues: string[] = [];
  const checks: Record<string, boolean> = {};
  const check = (id: string, ok: boolean, message: string) => {
    checks[id] = ok;
    if (!ok) issues.push(message);
  };
  const finish = () => ({
    format: "bionexo-apk-verification",
    version: 1,
    status: issues.length ? "BLOCKED" : "ARTIFACT_VERIFIED",
    sha256: policy.sha256,
    sourceCommit: policy.sourceCommit,
    applicationFingerprint: policy.applicationFingerprint,
    checks,
    issues,
    nativeAcceptance: "PENDING",
    publicRelease:
      "BLOCKED: requiere seguridad y aceptación nativa independientes.",
    scope:
      "Firma/identidad/alineación y nombres incluidos; no certifica procedencia del build, ausencia universal de secretos, instalación, actualización ni ejecución Android.",
  });
  // Also validate callers that bypass the JSON CLI.
  try {
    parseApkPolicy(policy);
  } catch {
    check("policy", false, "Política APK inválida.");
    return finish();
  }
  try {
    const stat = lstatSync(artifact);
    check(
      "regularFile",
      stat.isFile() && !stat.isSymbolicLink(),
      "El APK debe ser un archivo regular, sin enlace simbólico.",
    );
    check(
      "size",
      stat.size === policy.bytes && stat.size <= 250_000_000,
      "Tamaño APK distinto de la política.",
    );
    if (issues.length) return finish();
    check(
      "hash",
      sha256File(artifact) === policy.sha256,
      "SHA-256 APK distinto; no usar este archivo como actualización.",
    );
    check(
      "sources",
      applicationFingerprint(root) === policy.applicationFingerprint,
      "Fuentes actuales distintas de las asociadas al APK.",
    );
  } catch {
    check("inputs", false, "No se pudo leer el APK o las fuentes.");
  }
  if (issues.length) return finish();
  const suffix = process.platform === "win32" ? ".exe" : "";
  const invoke = (id: string, command: string, args: string[]) => {
    try {
      const r = runner(command, args);
      check(
        id,
        r.status === 0,
        `${id}: herramienta ausente, fallida, sin respuesta o con salida excesiva.`,
      );
      return r.status === 0 ? r.stdout : "";
    } catch {
      check(id, false, `${id}: no se pudo ejecutar la herramienta.`);
      return "";
    }
  };
  const java = process.env.JAVA_HOME
    ? join(process.env.JAVA_HOME, "bin", `java${suffix}`)
    : "java";
  const signature = invoke("signatureTool", java, [
    "-jar",
    join(tools, "lib", "apksigner.jar"),
    "verify",
    "--verbose",
    "--print-certs",
    artifact,
  ]);
  const certs = [
    ...signature.matchAll(
      /^(?:Signer #\d+|V\d(?:\.\d+)? Signer): certificate SHA-256 digest: ([a-f\d]{64})\s*$/gm,
    ),
  ].map((m) => m[1]!.toLowerCase());
  check(
    "certificate",
    certs.length === 1 &&
      certs[0] === policy.certificateSha256 &&
      /^Number of signers: 1\s*$/m.test(signature),
    "Certificado o cantidad de firmantes distintos; conservar la instalación existente.",
  );
  check(
    "signatureV2",
    /^Verified using v2 scheme \(APK Signature Scheme v2\): true\s*$/m.test(
      signature,
    ),
    "No se confirmó firma APK v2.",
  );
  const badging = invoke("manifestTool", join(tools, `aapt2${suffix}`), [
    "dump",
    "badging",
    artifact,
  ]);
  const identity =
    /^package: name='([^']+)' versionCode='(\d+)' versionName='([^']+)'/m.exec(
      badging,
    );
  check(
    "identity",
    !!identity &&
      identity[1] === policy.package &&
      Number(identity[2]) === policy.versionCode &&
      identity[3] === policy.appVersion,
    "Package o versión APK distintos de la política.",
  );
  check(
    "sdk",
    Number(/^(?:minSdkVersion|sdkVersion):'(\d+)'/m.exec(badging)?.[1]) ===
      policy.minSdk &&
      Number(/^targetSdkVersion:'(\d+)'/m.exec(badging)?.[1]) ===
        policy.targetSdk,
    "SDK mínimo/objetivo APK distintos.",
  );
  const abis = [
    ...(/^native-code: (.+)$/m.exec(badging)?.[1] || "").matchAll(/'([^']+)'/g),
  ].map((m) => m[1]!);
  const same = (a: string[], b: string[]) =>
    JSON.stringify([...a].sort()) === JSON.stringify([...b].sort());
  check("abis", same(abis, policy.abis), "Arquitecturas APK distintas.");
  check(
    "releaseManifest",
    /^application: /m.test(badging) &&
      !/^application-debuggable\b/m.test(badging),
    "Manifiesto ausente o aplicación debuggable.",
  );
  const permissions = [
    ...badging.matchAll(/^uses-permission(?:-sdk-\d+)?: name='([^']+)'/gm),
  ].map((m) => m[1]!);
  check(
    "permissions",
    same(permissions, policy.permissions) &&
      !permissions.some((p) =>
        forbiddenPermissions.some((f) => p === `android.permission.${f}`),
      ),
    "Permisos APK inesperados o prohibidos.",
  );
  invoke("alignment16k", join(tools, `zipalign${suffix}`), [
    "-c",
    "-P",
    "16",
    "4",
    artifact,
  ]);
  const entries = invoke("entriesTool", join(tools, `aapt${suffix}`), [
    "list",
    artifact,
  ])
    .split(/\r?\n/)
    .filter(Boolean);
  check(
    "embeddedResources",
    policy.requiredEntries.every((e) => entries.includes(e)),
    "Faltan recursos offline requeridos dentro del APK.",
  );
  check(
    "sensitiveFilenames",
    !entries.some((e) =>
      /(?:^|\/)\.env(?:\.|$)|\.(?:jks|keystore|p12|pfx|pem|key)$/i.test(e),
    ),
    "Nombre de archivo potencialmente privado incluido; revisar antes de entregar.",
  );
  try {
    check(
      "unchangedArtifact",
      sha256File(artifact) === policy.sha256,
      "El APK cambió durante la verificación.",
    );
  } catch {
    check("unchangedArtifact", false, "El APK dejó de estar disponible.");
  }
  return finish();
}
