"""Shared authoring for the new mathematics/physics introductions (not runtime code).

All prompts/examples are original. Existing biology/chemistry authoring is untouched.
"""
from copy import deepcopy


def C(prompt,options,index,why,clue,kind='choice'):
    return dict(type=kind,prompt=prompt,options=[dict(id=chr(97+i),text=s) for i,s in enumerate(options)],
        correct=chr(97+index),explanation=dict(correct=why,misconception=clue,
        distractors={chr(97+i):f'«{s}» no satisface las condiciones. {why}' for i,s in enumerate(options) if i!=index}),
        hints=[clue,'Separa los datos dados de la conclusión que se pide.','Comprueba con esta relación: '+why])


def M(prompt,options,indices,why,clue):
    q=C(prompt,options,0,why,clue);q.update(type='multi',correct=[chr(97+i) for i in indices])
    q['explanation']['distractors']={chr(97+i):why for i in range(len(options)) if i not in indices}
    return q


def N(prompt,value,unit,why,clue,accepted=None,tolerance=1e-8):
    return dict(type='numeric',prompt=prompt,correct=value,unit=unit,tolerance=tolerance,acceptedUnits=accepted or {unit:1},
        explanation=dict(correct=why,misconception=clue),hints=[clue,'Organiza la relación y conserva las unidades antes de calcular.',why])


def G(prompt,options,index,points,x,y,why,clue):
    q=C(prompt,options,index,why,clue,'chart');q.update(chart=[dict(x=a,y=b) for a,b in points],xLabel=x,yLabel=y)
    return q


def block(cid,level,unit,refs,objective,activation,explanation,example,second_example,application,summary,qs):
    assert len(qs)==6 and len(example)>=3 and len(second_example)>=3
    return dict(cid=cid,level=level,unit=unit,refs=refs,objective=objective,activation=activation,
        explanation=explanation,example=example,second_example=second_example,application=application,summary=summary,qs=qs)


def extend_subject(subject,blocks,unit_defs,course_defs,refs,concepts,lessons,units,courses,sources):
    by_id={c['id']:c for c in concepts}
    for key,(book,slug,title) in refs.items():
        sources.append(dict(id=f'{subject}-expand-{key}',title='OpenStax · '+title,
            url=f'https://openstax.org/books/{book}/pages/{slug}',
            note='Consulta 2026-10-23. Referencia conceptual oficial, CC BY-NC-SA 4.0. Explicaciones, ejercicios y datos ficticios originales de BioNexo; sin extractos, preguntas ni figuras copiadas. Revisión humana pendiente.'))
    for bi,b in enumerate(blocks):
        c=by_id[b['cid']]
        assert c['subjectId']==subject and c['status']=='planned','Never silently replace a published lesson'
        source_ids=[f'{subject}-expand-{key}' for key in b['refs']]
        qs=deepcopy(b['qs'])
        for i,q in enumerate(qs):
            if 'options' in q:
                shift=(bi+i)%len(q['options']);ordered=q['options'][shift:]+q['options'][:shift]
                mapping={option['id']:chr(97+j) for j,option in enumerate(ordered)}
                q['options']=[dict(id=chr(97+j),text=option['text']) for j,option in enumerate(ordered)]
                q['correct']=[mapping[x] for x in q['correct']] if isinstance(q['correct'],list) else mapping[q['correct']]
                q['explanation']['distractors']={mapping[k]:v for k,v in q['explanation']['distractors'].items()}
            q.update(id=f'{c["id"]}-v1-q{i+1}',subjectId=subject,level=b['level'],conceptIds=[c['id']],
                prerequisites=list(c['prerequisites']),sourceIds=list(source_ids))
        stages=[dict(id=c['id']+'-understand-v1',title='Comprender y representar',objective=b['objective'],
            explanation=b['explanation'].split('\n\n')[0],example=dict(title='Ejemplo desarrollado',steps=b['example']),
            exerciseIds=[q['id'] for q in qs[:3]],sourceIds=list(source_ids)),
            dict(id=c['id']+'-apply-v1',title='Aplicar y comprobar condiciones',objective='Resolver una aplicación y justificar el alcance del resultado.',
            explanation=b['explanation'].split('\n\n')[-1]+' '+b['application'],example=dict(title='Otro ejemplo, paso a paso',steps=b['second_example']),
            exerciseIds=[q['id'] for q in qs[3:]],sourceIds=list(source_ids))]
        c.update(status='implemented',explanation=b['explanation'],example=' → '.join(b['example']),sourceIds=list(source_ids))
        lessons.append(dict(id=c['id']+'-lesson',subjectId=subject,unitId=b['unit'],title=c['title'],minutes=10,
            objective=b['objective'],activation=b['activation'],conceptIds=[c['id']],prerequisites=list(c['prerequisites']),
            explanation=b['explanation'],example=b['example'],application=b['application'],summary=b['summary'],
            exercises=qs,sourceIds=list(source_ids),reviewStatus='requires-human-review',stages=stages))
    for uid,title,ids,course in unit_defs:
        units.append(dict(id=uid,subjectId=subject,title=title,lessonIds=[cid+'-lesson' for cid in ids],
            prerequisites=list(by_id[ids[0]]['prerequisites'])))
    for cid,title in course_defs:
        courses.append(dict(id=cid,subjectId=subject,title=title,unitIds=[uid for uid,_,_,course in unit_defs if course==cid]))
